"use strict";

(function ($) {
	window.OfscPlugin = function (debugMode) {
		this.debugMode = debugMode || false;
	};

	$.extend(window.OfscPlugin.prototype, {
		/**
		 * Dictionary of enums
		 */
		dictionary: {
			astatus: {
				pending: {
					label: 'pending',
					translation: 'Pending',
					outs: ['started', 'cancelled', 'suspended'],
					color: '#FFDE00'
				},
				started: {
					label: 'started',
					translation: 'Started',
					outs: ['complete', 'suspended', 'notdone', 'cancelled'],
					color: '#A2DE61'
				},
				complete: {
					label: 'complete',
					translation: 'Completed',
					outs: [],
					color: '#79B6EB'
				},
				suspended: {
					label: 'suspended',
					translation: 'Suspended',
					outs: [],
					color: '#9FF'
				},
				notdone: {
					label: 'notdone',
					translation: 'Not done',
					outs: [],
					color: '#60CECE'
				},
				cancelled: {
					label: 'cancelled',
					translation: 'Cancelled',
					outs: [],
					color: '#80FF80'
				}
			},
			invpool: {
				customer: {
					label: 'customer',
					translation: 'Customer',
					outs: ['deinstall'],
					color: '#04D330'
				},
				install: {
					label: 'install',
					translation: 'Installed',
					outs: ['provider'],
					color: '#00A6F0'
				},
				deinstall: {
					label: 'deinstall',
					translation: 'Deinstalled',
					outs: ['customer'],
					color: '#00F8E8'
				},
				provider: {
					label: 'provider',
					translation: 'Resource',
					outs: ['install'],
					color: '#FFE43B'
				}
			}
		},

		mandatoryActionProperties: {},

		/**
		 * Which field shouldn't be editable
		 *
		 * format:
		 *
		 * parent: {
		 *     key: true|false
		 * }
		 *
		 */
		renderReadOnlyFieldsByParent: {
			data: {
				apiVersion: true,
				method: true,
				entity: true
			},
			resource: {
				pid: true,
				pname: true,
				gender: true
			}
		},

		/**
		 * Check for string is valid JSON
		 *
		 * @param {*} str - String that should be validated
		 *
		 * @returns {boolean}
		 *
		 * @private
		 */
		_isJson: function (str) {
			try {
				JSON.parse(str);
			} catch (e) {
				return false;
			}
			return true;
		},

		/**
		 * Return origin of URL (protocol + domain)
		 *
		 * @param {String} url
		 *
		 * @returns {String}
		 *
		 * @private
		 */
		_getOrigin: function (url) {
			if (url != '') {
				if (url.indexOf("://") > -1) {
					return 'https://' + url.split('/')[2];
				} else {
					return 'https://' + url.split('/')[0];
				}
			}

			return '';
		},

		/**
		 * Return domain of URL
		 *
		 * @param {String} url
		 *
		 * @returns {String}
		 *
		 * @private
		 */
		_getDomain: function (url) {
			if (url != '') {
				if (url.indexOf("://") > -1) {
					return url.split('/')[2];
				} else {
					return url.split('/')[0];
				}
			}

			return '';
		},

		//added for MPF Phase 4 - CHG0069304
		_getDomainURL: function () {
			//return document.referrer.match(/\:\/\/([^\/]+)\.etadirect\.com\//)[1];
			//Reg Ex modified to handle both etadirect.com and fs.ocs.oraclecloud.com URLs
			return document.referrer.match(/\:\/\/([^\/]+)\.(?:etadirect.com|fs.ocs.oraclecloud.com)/)[1];
		},
		//

		/**
		 * Sends postMessage to document.referrer
		 *
		 * @param {Object} data - Data that will be sent
		 *
		 * @private
		 */
		_sendPostMessageData: function (data) {
			var originUrl = document.referrer || (document.location.ancestorOrigins && document.location.ancestorOrigins[0]) || '';

			if (originUrl) {
				this._log(window.location.host + ' -> ' + data.method + ' ' + this._getDomain(originUrl), JSON.stringify(data, null, 4));

				parent.postMessage(data, this._getOrigin(originUrl));
			} else {
				this._log(window.location.host + ' -> ' + data.method + ' ERROR. UNABLE TO GET REFERRER');
			}
		},

		/**
		 * Handles during receiving postMessage
		 *
		 * @param {MessageEvent} event - Javascript event
		 *
		 * @private
		 */
		_getPostMessageData: function (event) {

			if (typeof event.data === 'undefined') {
				this._log(window.location.host + ' <- NO DATA ' + this._getDomain(event.origin), null, null, true);

				return false;
			}

			if (!this._isJson(event.data)) {
				this._log(window.location.host + ' <- NOT JSON ' + this._getDomain(event.origin), null, null, true);

				return false;
			}

			var data = JSON.parse(event.data);

			if (!data.method) {
				this._log(window.location.host + ' <- NO METHOD ' + this._getDomain(event.origin), null, null, true);

				return false;
			}

			this._log(window.location.host + ' <- ' + data.method + ' ' + this._getDomain(event.origin), JSON.stringify(data, null, 4));

			switch (data.method) {
				case 'init':
					this.pluginInitEnd(data);
					break;

				case 'open':
					this.pluginOpen(data);
					break;

				case 'wakeup':
					this.pluginWakeup(data);
					break;

				case 'error':
					data.errors = data.errors || {
						error: 'Unknown error'
					};
					this._showError(data.errors);
					break;

				default:
					this._log(window.location.host + ' <- UNKNOWN METHOD: ' + data.method + ' ' + this._getDomain(event.origin), null, null, true);
					break;
			}
		},

		/**
		 * Show alert with error
		 *
		 * @param {Object} errorData - Object with errors
		 *
		 * @private
		 */
		_showError: function (errorData) {
			alert(JSON.stringify(errorData, null, 4));
		},
		// Start changes for CHG0069377-Service_Advantage_Billing
		/**
		 * Check Null value
		 *
		 * @param {value} - Actual value
		 *
		 * return value
		 */
		_checkNull: function (value) {
			if (value == null || 'undefined' == value)
				return "";
			else
				return value;
		},
		/**
		 * Check single digit
		 *
		 * @param {value} - Actual value
		 *
		 * return value
		 */
		_checkSingleDigit: function (value) {
			if (value >= 0 && value < 10)
				return '0' + value;
			else
				return value;
		}, // End changes for CHG0069377-Service_Advantage_Billing

		/**
		 * Logs to console
		 *
		 * @param {String} title - Message that will be log
		 * @param {String} [data] - Formatted data that will be collapsed
		 * @param {String} [color] - Color in Hex format
		 * @param {Boolean} [warning] - Is it warning message?
		 *
		 * @private
		 */
		_log: function (title, data, color, warning) {
			if (!this.debugMode) {
				return;
			}
			if (!color) {
				color = '#0066FF';
			}
			if (!!data) {
				console.groupCollapsed('%c[Plugin API] ' + title, 'color: ' + color + '; ' + (!!warning ? 'font-weight: bold;' : 'font-weight: normal;'));
				console.log('[Plugin API] ' + data);
				console.groupEnd();
			} else {
				console.log('%c[Plugin API] ' + title, 'color: ' + color + '; ' + (!!warning ? 'font-weight: bold;' : ''));
			}
		},

		/**
		 * Business login on plugin init
		 */
		saveToLocalStorage: function (data) {
			this._log(window.location.host + ' INIT. SET DATA TO LOCAL STORAGE', JSON.stringify(data, null, 4));

			if (data.attributeDescription) {
				localStorage.setItem('pluginInitData', JSON.stringify(data.attributeDescription));
			}
		},

		/**
		 * Business login on plugin init end
		 *
		 * @param {Object} data - JSON object that contain data from OFSC
		 */
		pluginInitEnd: function (data) {
			this.saveToLocalStorage(data);

			var messageData = {
				apiVersion: 1,
				method: 'initEnd'
			};

			if (localStorage.getItem('pluginWakeupCount') < localStorage.getItem('pluginWakeupMaxCount')) {
				this._log(window.location.host + ' UNFINISHED WAKEUP DATA FOUND IN LOCAL STORAGE');

				messageData.wakeupNeeded = true;
			}

			this._sendPostMessageData(messageData);
		},

		/**
		 * Business login on plugin open
		 *
		 * @param {Object} receivedData - JSON object that contain data from OFSC
		 */
		pluginOpen: function (receivedData) {

			// CHG0083146 starts

			if (receivedData.securedData.knowledgeFlag.localeCompare("Y") === 0) {
				$("#knowledgeButton").removeClass("cp_hidden");
			}

			// CHG0083146 ends

			//start of CHG0076155 Remove the ability for billing to be possible on auto install calls
			//by Neha Singh
			var installTypeList = ["3PL Install", "3PL Install/Deinstall", "Assist - Install", "Delivery Install", "Delivery Install/Deinstall", "Tech Install", "Tech Install/Deinstall", "Remote Install", "Remote Install/Deinstall"];
			var IntallCallValue = receivedData.activity.A_TASK_TYPE;
			var isIntallCall = installTypeList.indexOf(IntallCallValue) > -1;
			console.log("Activity Task type is " + IntallCallValue);
			console.log("Activity Task Type value matches with array [installTypeList] or no " + isIntallCall);
			//End of CHG0076155 Remove the ability for billing to be possible on auto install calls

			// Changes start for CHG0069304
			var domainName = this._getDomainURL();
			console.log("Domain Name - " + domainName);
			var errorLogs = receivedData.activity.A_PLUGIN_ERROR_LOG;
			var activityId = receivedData.activity.aid;
			//  var installed_parts_details_first = ""; //CHG0080567- OFSC MPF Group 2B Change
			var installed_parts_details_first = [];
			// var all_parts_details ="";
			// if(receivedData.activity.A_ITEM_TRACKING !=null){
			// var all_parts_details =receivedData.activity.A_ITEM_TRACKING;
			// }
			// Changes end for CHG0069304
			// Base 64 encryption for REST API calls
			var headers = {
				'Authorization':
					'Basic ' + btoa(receivedData.securedData.client_id + "@" + domainName + ":" + receivedData.securedData.client_secret)
			};

			$.ErrorUpdate = function (activityId, sErrorLogs) {

				this._sendPostMessageData({
					"apiVersion": 1,
					"method": "update",
					"activity": {
						"A_PLUGIN_ERROR_LOG": sErrorLogs,
						"aid": activityId
					}

				});
			}.bind(this);

			this._clearWakeupData();
			if (localStorage.getItem('pluginInitData')) {
				this._log(window.location.host + ' OPEN. GET DATA FROM LOCAL STORAGE', JSON.stringify(JSON.parse(localStorage.getItem('pluginInitData')), null, 4));
				$('.json__local-storage').text(JSON.stringify(JSON.parse(localStorage.getItem('pluginInitData')), null, 4));
			}
			this.initChangeOfWakeup(document);
			this.initChangeOfDataItems();

			var $parentThis = this; // Added for CHG0069377-Service_Advantage_Billing

			//Added for OFSC Mobility Phase2 CHG0062368            
			var envVar = window.location.hostname;
			var temp1 = envVar.split('.');
			var env = temp1[0];
			var nowDate = new Date();
			var now = nowDate.toISOString();
			var dateArr = now.split('T');
			var currentDate = dateArr[0];
			var pluginName = "PI-Service_Ticket";
			var ofscDate = '';

			var company = receivedData.securedData.company;
			var clientId = receivedData.securedData.client_id;
			var clientSecret = receivedData.securedData.client_secret;
			// Base 64 encryption for REST API calls
			var authorizationB64 = btoa(clientId + "@" + company + ":" + clientSecret);

			// Start changes for CHG0069377-Service_Advantage_Billing
			//Prevent EST Flag
			var preventEST = (receivedData.activity.A_PREVENT_EST == null || "N" == receivedData.activity.A_PREVENT_EST) ? false : true;

			//SA Account Flag
			var saAccountFlag = (receivedData.activity.A_SA_ACCOUNT_FLAG == null || "N" == receivedData.activity.A_SA_ACCOUNT_FLAG) ? false : true;
			//End changes for CHG0069377-Service_Advantage_Billing

			var shiftLabel = null;
			var activityLog = null;
			var todaysDate = new Date();

			$.convertDate = function (date) {
				var yyyy = date.getFullYear().toString();
				var mm = (date.getMonth() + 1).toString();
				var dd = date.getDate().toString();

				var mmChars = mm.split('');
				var ddChars = dd.split('');

				return yyyy + '-' + (mmChars[1] ? mm : "0" + mmChars[0]) + '-' + (ddChars[1] ? dd : "0" + ddChars[0]);
			};

			var todaysDate = $.convertDate(todaysDate);


			$.getshiftTypeList = function () {

				// changes done for MPF Phase 4 -CHG0069304
				var shiftTypeRESTServiceURL = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/resources/" + receivedData.resource.external_id + "/workSchedules/calendarView?dateFrom=" + todaysDate + "&dateTo=" + todaysDate;
				console.log("getshiftTypeList webservice call started URL-"
					+ shiftTypeRESTServiceURL);

				//
				$.ajax({
					url: shiftTypeRESTServiceURL,
					dataType: 'json',
					processData: false,
					async: false,
					crossDomain: true,
					headers: headers,
					contentType: 'application/json; charset=utf-8',
					method: "GET",
					timeout: 15000,
					success: function (responseData) {
						console
							.log('REST CALL FOR getting Shift Type call -- success....:'
								+ JSON.stringify(responseData));
						$.processFnCallBkshiftType(responseData);
					},
					error: function (response) {

						//changes done for MPF Phase 4 -CHG0069304
						var now = new Date(Date.now());
						//var errorTime = now.getHours() + ":" + now.getMinutes() + ":" + now.getSeconds();

						if (response.responseJSON) {
							var errorDetails = response.responseJSON;
							var eDetail = errorDetails.detail.replace(/(\r\n|\n|\r)/gm, " ");
							var eStatus = errorDetails.status;
							if (errorLogs == null) {
								errorLogs = "";
							}
							errorLogs = errorLogs + "||" + now.toString() + "|Plugin:Service Ticket " + "|URL:" + shiftTypeRESTServiceURL.toString() + "|Error Status:" + eStatus + "|Error Details:" + eDetail;
							console.log(errorLogs);
							$.ErrorUpdate(activityId, errorLogs);

							// Changes end for CHG0069304
						}

						console.log('REST CALL FOR getting Shift Type call -- failure:'
							+ JSON.stringify(response));
						if (activityLog != null && activityLog != "") {
							activityLog = activityLog + ";ServiceTicker-Error-getting Shift Type";
						}
						else {
							activityLog = "ServiceTicker-Error-getting Shift Type";
						}
					}

				});
			};
			$.processFnCallBkshiftType = function (responseJSON) {
				console.log(' In processFnCallBkshiftType');
				if (responseJSON.data) {
					var shiftTypeArray = responseJSON.data;
					var shiftType = 'REGULAR';
					if (receivedData.resource.P_PAYCODE == 'CALL_IN_IO') {
						shiftType = 'ON-CALL';
					}
					console.log(' shiftType :' + shiftType);
					console.log('shiftTypeArray legth :' + shiftTypeArray.length);
					for (var i = 0; i < shiftTypeArray.length; i++) {
						var shiftTypeRow = shiftTypeArray[i];
						console.log(' shiftType :' + shiftTypeRow.shiftType);
						if (shiftTypeRow.shiftType == shiftType) {
							shiftLabel = shiftTypeRow.shiftLabel;
							console.log(' shiftLabel :' + shiftLabel);
						}

					}
				}
			};
			//$.getshiftTypeList();
			//end OFSC Mobility Phase2 CHG0062368

			// Get the content of the DD value Divs need to append to TD.
			this.QtyDDSection = $("#QtyDDSection").html();
			this.billingReasonDDSection = $("#billingReasonDDSection").html();
			this.billingAmountUndoSection = $("#billingAmountUndoSection").html();
			var activityId = receivedData.activity.aid;
			var activityStatus = receivedData.activity.A_STATUS;
			var aScanOutTime = receivedData.activity.A_SCAN_OUT_TIME;
			console.log('aScanOutTime #1:' + aScanOutTime);
			//inventoryList
			var inventoryList = receivedData.inventoryList;

			// Current Date Time Section:
			var TodayDate = new Date();
			var year = TodayDate.getYear().toString().substr(-2);
			var day = TodayDate.getDate(); //it returns the date
			day = ("0" + day).slice(-2);
			var month = TodayDate.getMonth() + 1;
			month = ("0" + month).slice(-2);
			var hours = TodayDate.getHours();
			hours = ("0" + hours).slice(-2);
			var minutes = TodayDate.getMinutes();
			minutes = ("0" + minutes).slice(-2);
			var date_MM_DD = month + "-" + day;
			var date_MM_DD_YY = month + "/" + day + "/" + year;
			var date_YYYY_MM_DD = TodayDate.getFullYear().toString() + "-" + month + "-" + day;
			var currDateTimeFormat = TodayDate.getFullYear().toString() + "-" + month + "-" + day + " " + hours + ":" + minutes;
			var currDateTime = month + "-" + day + " " + hours + ":" + minutes;
			// var currdateTime = date_MM_DD_YY + " " + hours + ":" + minutes;
			var showExtraLaborRow = false;

			var g_current_pass_count = 1;

			//read timezone from URL //changes done for MPF Phase 4 -CHG0069304
			// $.urlParam = function(name)
			// {
			// 	try{
			//         var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
			//         return results[1] || 0;
			// 	}
			// 	catch(err){
			// 		activityLog = activityLog + ';Exception in urlParam '+ name +' :'+err.message;
			// 		console.log(" Exception in durlParam "+ name +" :"+err.message);
			// 		return '';
			// 	}
			// } 
			var timeZoneName = receivedData.resource.time_zone;
			console.log(timeZoneName);
			//OFSC Mobility Phase2 CHG0062368
			// ofscDate      = decodeURIComponent($.urlParam('date'));
			// console.log(' ofscDate :'+ofscDate);
			$.getshiftTypeList();
			//OFSC Mobility Phase2 CHG0062368


			// get the Billing Info XML field-

			console.log('A_EXPENSES_OUTBOUND -' + JSON.stringify(receivedData.activity.A_EXPENSES_OUTBOUND));
			console.log('A_SE_EXPENSES_OUTBOUND-' + JSON.stringify(receivedData.activity.A_SE_EXPENSES_OUTBOUND));
			console.log('A_EXPENSES_PLUGIN -' + JSON.stringify(receivedData.activity.A_EXPENSES_PLUGIN));
			console.log('A_SE_EXPENSES_PLUGIN -' + JSON.stringify(receivedData.activity.A_SE_EXPENSES_PLUGIN));
			console.log('A_BILLING_INFO ' + JSON.stringify(receivedData.activity.A_BILLING_INFO));
			console.log('A_SE_BILLING_INFO ' + JSON.stringify(receivedData.activity.A_SE_BILLING_INFO));
			console.log('A_BILLING_INFO_HTML-' + JSON.stringify(receivedData.activity.A_BILLING_INFO_HTML));
			console.log('A_BILLING_INFO_HTML -' + JSON.stringify(receivedData.activity.A_SE_BILLING_INFO_HTML));


			// set the Top section general Information:

			$("#sr_ref_num").text(receivedData.activity.A_SR_NUMBER);
			$("#model_number").text(receivedData.activity.A_MODEL);
			$("#serial_number").text(receivedData.activity.A_SERIAL);
			$("#equipment_number").text(receivedData.activity.A_EQUIPMENT_NUMBER);

			$("#employee_number").text(receivedData.resource.R_EMPLOYEE_NUMBER);
			$("#resource_name").text(receivedData.resource.pname);

			//Customer Section:
			$("#contact_name").text(receivedData.activity.cname);
			$("#contact_address").text(receivedData.activity.caddress);
			$("#a_contact").text(receivedData.activity.A_CONTACT);
			$("#contract_flag").text(receivedData.activity.A_CONTRACT_FLAG);
			$("#po_number").val(receivedData.activity.A_PO_NUMBER);
			var poRequiredFlag = receivedData.activity.A_PO_REQUIRED;

			if (poRequiredFlag && poRequiredFlag == 'Y') {
				poRequiredFlag = true;
			} else {
				poRequiredFlag = false;

			}

			if (poRequiredFlag) {
				// display asterik on page:
				$("#po_number_asterik").removeClass("cp_hidden");
			}
			$("#po_number").on("input", function (e) {

				var enteredPONum = $(this).val();
				var len = enteredPONum.length;

				if (len > 20) {
					enteredPONum = enteredPONum.slice(0, 20);
					// alert(enteredPONum+" value too large. Restricting to first 20 characters.");
					$(this).val(enteredPONum); date_MM_DD_TT
				}
			});

			//Date Formatted #completion_date --11/20/17 00:19
			var arrival_date = receivedData.activity.A_DISPATCH_TIME; //A_START_TIME_OVERRIDE;
			//CHG0060060 - code changes for showing arrival date in billing section of service ticket
			var frmtdArvlDate = new Date(arrival_date);


			var arvlMonthVal = frmtdArvlDate.getMonth() + 1;
			arvlMonthVal = ("0" + arvlMonthVal).slice(-2);
			var arvlDayVal = frmtdArvlDate.getDate();
			arvlDayVal = ("0" + arvlDayVal).slice(-2);
			var date_MM_DD_arvlDate = arvlMonthVal + "-" + arvlDayVal;
			// start of CHG0080567- OFSC MPF Group 2B Change
			var delimitToTime = 'T';
			var array = arrival_date.split(delimitToTime);
			var delimitToHH_MM = ':';
			var timeArray = array[1].split(delimitToHH_MM);
			var date_MM_DD_TT = date_MM_DD_arvlDate + " " + timeArray[0] + ":" + timeArray[1];
			console.log("date_MM_DD_TT ", date_MM_DD_TT)
			// end of CHG0080567- OFSC MPF Group 2B Change
			console.log("date_MM_DD_arvlDate " + date_MM_DD_arvlDate);
			//CHG0060060- end of code changes

			var eta_Time = (receivedData.activity.ETA) ? receivedData.activity.ETA : "";
			eta_Time = eta_Time.replace(/[a-zA-Z ]/g, ""); // CHG0070258-removing AM/PM from ETA while the format is 12hrs // Modified for INC2148272
			var startTimeVal = receivedData.activity.A_START_TIME_OVERRIDE
			//var completion_date = ""(receivedData.activity.A_SCAN_OUT_TIME_OVERRIDE)?receivedData.activity.A_SCAN_OUT_TIME_OVERRIDE:currdateTime;
			console.log("arrival_date " + arrival_date);

			if ((startTimeVal !== undefined) && startTimeVal != null && startTimeVal != "") {
				var mom = moment.utc(startTimeVal);
				$("#arrival_date").text(mom.format('MM/DD/YY HH:mm'));

			} else if ((arrival_date !== undefined) && arrival_date != null && arrival_date != "") {
				arrival_date = arrival_date.substr(0, 10);
				var mom = moment.utc(arrival_date);
				console.log('format ' + mom.format('MM/DD/YY'));
				arrival_date = mom.format('MM/DD/YY');
				//arrival_date = arrival_date.replace(/\.[0-9]+Z/g, '');
				//arrival_date = arrival_date.replace(/T/g, ' ');
				//var secondsPresent = arrival_date.match(/\d{2}:\d{2}:\d{2}/g);
				//if(secondsPresent){

				//  arrival_date = arrival_date.slice(0, -3);
				//}

				$("#arrival_date").text(arrival_date + " " + eta_Time);

			}

			var completion_date = "";
			if (receivedData.activity.A_SCAN_OUT_TIME_OVERRIDE) {
				completion_date = receivedData.activity.A_SCAN_OUT_TIME_OVERRIDE;
				completion_date = completion_date.replace(/\.[0-9]+Z/g, '');
				completion_date = completion_date.replace(/T/g, ' ');
				var secondsPresent = completion_date.match(/\d{2}:\d{2}:\d{2}/g);
				if (secondsPresent) {

					completion_date = completion_date.slice(0, -3);
				}

				var unformattedCompDate = completion_date.substr(0, 10);
				var mom = moment.utc(formattedCompDate);
				// console.log('format '+mom.format('MM/DD/YY'));
				var formattedCompDate = mom.format('MM/DD/YY');
				completion_date = completion_date.replace(unformattedCompDate, formattedCompDate);
				$("#completion_date").text(completion_date);


			}
			else {
				console.log(timeZoneName);
				var TimeZoneMapping = {
					"19": "Alaska",
					"6": "Arizona",
					"4": "Central",
					"2": "Eastern",
					"15": "GMT",
					"17": "Hawaii (Adak)",
					"18": "Hawaii (Honolulu)",
					"5": "Mountain",
					"7": "Pacific"
				};

				var timeOffset = {
					'Alaska': 9,
					'dAlaska': 8,
					'Arizona': 7,
					'dArizona': 7,
					'Central': 6,
					'dCentral': 5,
					'Eastern': 5,
					'dEastern': 4,
					'GMT': 0,
					'dGMT': 0,
					'Hawaii(Adak)': 10,
					'dHawaii(Adak)': 10,
					'Hawaii(Honolulu)': 10,
					'dHawaii(Honolulu)': 10,
					'Mountain': 7,
					'dMountain': 6,
					'Pacific': 8,
					'dPacific': 7
				}


				var timeZone = TimeZoneMapping[timeZoneName];

				Date.prototype.stdTimezoneOffset = function () {
					var jan = new Date(this.getFullYear(), 0, 1);
					console.log(jan);
					var jul = new Date(this.getFullYear(), 6, 1);
					console.log(jul);
					return Math.max(jan.getTimezoneOffset(), jul.getTimezoneOffset());
				}

				Date.prototype.dst = function () {
					return this.getTimezoneOffset() < this.stdTimezoneOffset();
				}

				var today = new Date();
				if (today.dst()) {
					var timeZoneId = timeOffset['d' + timeZone.replace(' ', '')];
				} else {
					var timeZoneId = timeOffset[timeZone.replace(' ', '')];
				}

				//$("#completion_date").text(currdateTime);
				var tempCurrentDate;
				var indainDateObj = new Date();
				indainDateObj.setHours(indainDateObj.getHours() - timeZoneId);
				tempCurrentDate = indainDateObj.toISOString();
				if (tempCurrentDate != null) {
					aScanOutTime = tempCurrentDate.substr(0, 19);
				}

				var tFormSplit = tempCurrentDate.split('T');
				$("#completion_date").val(tempCurrentDate)
					.text(tFormSplit[0].split('-')[1] + '/' + tFormSplit[0].split('-')[2] + '/' + tFormSplit[0].split('-')[0].toString().substr(-2) + ' ' + tFormSplit[1].split(':')[0] + ':' + tFormSplit[1].split(':')[1]);
			}
			//MeterInformation
			var blacknwhitemeter = receivedData.activity.A_COUNTER_BLACK_WHITE;
			var colormeter = receivedData.activity.A_COUNTER_COLOR;
			var totalmeter = receivedData.activity.A_COUNTER_TOTAL;
			var scanning = receivedData.activity.A_COUNTER_SCANNING;

			//A_COUNTER_BLCK_WHITE IS NOT EMPTY AND A_COUNTER_BLCK_WHITE>0
			if (blacknwhitemeter != "" && blacknwhitemeter > 0) {
				$("#blacknwhitemeterSection").removeClass("cp_hidden");
				$("#blacknwhitemeter").text(blacknwhitemeter);
			}
			if (colormeter != "" && colormeter > 0) {
				$("#colormeterSection").removeClass("cp_hidden");
				$("#colormeter").text(colormeter);
			}
			if (totalmeter != "" && totalmeter > 0) {
				$("#totalmeterSection").removeClass("cp_hidden");
				$("#totalmeter").text(totalmeter);
			}
			if (scanning != "" && scanning > 0) {
				$("#scanningSection").removeClass("cp_hidden");
				$("#scanning").text(scanning);
			}

			// CHG0083146 starts

			$.generateCallIdTemp = function () {
				return btoa(String.fromCharCode.apply(null, window.crypto.getRandomValues(new Uint8Array(16))));
			},

				$.openURLinkNewTab = function (aURL) {
					var uniquecallid = $.generateCallIdTemp();
					var jsonToSend = {
						"apiVersion": 1,
						"callId": uniquecallid,
						"method": "callProcedure",
						"procedure": "openLink",
						"params": {
							"url": aURL
						}
					}
					console.log("Opening New tab" + jsonToSend);
					this._sendPostMessageData(jsonToSend);
				}.bind(this);

			$('#knowledgeButton').click(function () {
				var problem_work_performed = $("#probWorkPerformed").val();
				if (problem_work_performed.length < 4) {
					console.log("problem_work_performed :" + problem_work_performed.length);
					alert("Please provide an explanation of the work performed.");
					return;
				}

				var knowledgeURL = "";
				if (domainName == "ricoh2.test") {
					knowledgeURL = "https://jcsd.ricohonline.net/PI-TSRC/index.jsp?";
				}

				if (domainName == "ricoh3.test") {
					knowledgeURL = "https://jcsq.ricohonline.net/PI-TSRC/index.jsp?";
				}

				if (domainName == "ricoh4.test") {
					knowledgeURL = "https://jcst.ricohonline.net/PI-TSRC/index.jsp?";
				}

				if (domainName == "ricoh") {
					knowledgeURL = "https://jcsp.ricohonline.net/PI-TSRC/index.jsp?";
				}

				var resourceEmail = receivedData.resource.email;

				knowledgeURL = knowledgeURL + "&aid=" + activityId + "&instance=" + domainName + "&email=" + encodeURIComponent(resourceEmail) + "&result=" + btoa(problem_work_performed);

				$.openURLinkNewTab(knowledgeURL);

			});

			// CHG0083146 ends	


			// Signature Section.
			var sigdiv = $("#signature");
			sigdiv.signature();
			var onloadedEmptySignatureBlock = sigdiv.signature('toDataURL');
			$('#clear_btn').click(function () {
				//alert(sigdiv.signature('toDataURL'));
				// console.log('signature' + sigdiv.signature('toDataURL'));
				sigdiv.signature('clear');
			});

			var canvas = document.getElementsByTagName("canvas")[0];
			// start of CHG0083631(code is no longer needed)
			// var ctx = canvas.getContext("2d");
			// ctx.strokeStyle = "#222222";
			// ctx.lineWith = 2;
			// // Set up mouse events for drawing
			// var drawing = false;
			// var mousePos = { x: 0, y: 0 };
			// var lastPos = mousePos;
			// canvas.addEventListener("mousedown", function (e) {
			// 	drawing = true;
			// 	jQuery(':focus').blur();  //Change done for INC1505018
			// 	lastPos = getMousePos(canvas, e);
			// }, false);
			// canvas.addEventListener("mouseup", function (e) {
			// 	drawing = false;
			// }, false);
			// canvas.addEventListener("mousemove", function (e) {
			// 	mousePos = getMousePos(canvas, e);
			// }, false);

			// // Get the position of the mouse relative to the canvas
			// function getMousePos(canvasDom, mouseEvent) {
			// 	var rect = canvasDom.getBoundingClientRect();
			// 	return {
			// 		x: mouseEvent.clientX - rect.left,
			// 		y: mouseEvent.clientY - rect.top
			// 	};
			// }
			// // Get a regular interval for drawing to the screen
			// window.requestAnimFrame = (function (callback) {
			// 	return window.requestAnimationFrame ||
			// 		window.webkitRequestAnimationFrame ||
			// 		window.mozRequestAnimationFrame ||
			// 		window.oRequestAnimationFrame ||
			// 		window.msRequestAnimaitonFrame ||
			// 		function (callback) {
			// 			window.setTimeout(callback, 1000 / 60);
			// 		};
			// })();
			// // Draw to the canvas
			// function renderCanvas() {
			// 	if (drawing) {
			// 		ctx.moveTo(lastPos.x, lastPos.y);
			// 		ctx.lineTo(mousePos.x, mousePos.y);
			// 		ctx.stroke();
			// 		lastPos = mousePos;
			// 	}
			// }

			// // Allow for animation
			// (function drawLoop() {
			// 	requestAnimFrame(drawLoop);
			// 	renderCanvas();
			// })();
			// canvas.addEventListener("touchstart", function (e) {
			// 	jQuery(':focus').blur(); //Change done for INC1505018
			// 	mousePos = getTouchPos(canvas, e);
			// 	var touch = e.touches[0];
			// 	var mouseEvent = new MouseEvent("mousedown", {
			// 		clientX: touch.clientX,
			// 		clientY: touch.clientY
			// 	});
			// 	canvas.dispatchEvent(mouseEvent);
			// }, false);
			// canvas.addEventListener("touchend", function (e) {
			// 	var mouseEvent = new MouseEvent("mouseup", {});
			// 	canvas.dispatchEvent(mouseEvent);
			// }, false);
			// canvas.addEventListener("touchmove", function (e) {
			// 	var touch = e.touches[0];
			// 	var mouseEvent = new MouseEvent("mousemove", {
			// 		clientX: touch.clientX,
			// 		clientY: touch.clientY
			// 	});
			// 	canvas.dispatchEvent(mouseEvent);
			// }, false);

			// // Get the position of a touch relative to the canvas
			// function getTouchPos(canvasDom, touchEvent) {
			// 	var rect = canvasDom.getBoundingClientRect();
			// 	return {
			// 		x: touchEvent.touches[0].clientX - rect.left,
			// 		y: touchEvent.touches[0].clientY - rect.top
			// 	};
			// }
			// document.body.addEventListener("touchstart", function (e) {

			// 	var canvas = document.getElementsByTagName("canvas")[0];
			// 	if (e.target == canvas) {
			// 		e.preventDefault();
			// 	}
			// }, false);
			// document.body.addEventListener("touchend", function (e) {
			// 	var canvas = document.getElementsByTagName("canvas")[0];
			// 	if (e.target == canvas) {
			// 		e.preventDefault();
			// 	}
			// }, false);
			// document.body.addEventListener("touchmove", function (e) {
			// 	var canvas = document.getElementsByTagName("canvas")[0];
			// 	if (e.target == canvas) {
			// 		e.preventDefault();
			// 	}
			// }, false);// end of CHG0083631(code is no longer needed)

			if (receivedData.activity.A_CONTACT) {
				$("#signeeName").val(receivedData.activity.A_CONTACT);
			} else {
				if (receivedData.activity.A_SIGNEE_NAME) {
					$("#signeeName").val(receivedData.activity.A_SIGNEE_NAME);
				}
			}

			if (receivedData.activity.A_CUSTOMER_CONTACT_EMAIL) {
				$("#signeeEmail").val(receivedData.activity.A_CUSTOMER_CONTACT_EMAIL);
			} else {
				if (receivedData.activity.A_SIGNEE_EMAIL) {
					$("#signeeEmail").val(receivedData.activity.A_SIGNEE_EMAIL);
				}
			}


			$("#signeeName").on("input", function (e) {

				var enteredName = $(this).val();
				var len = enteredName.length;

				if (len > 50) {
					enteredName = enteredName.slice(0, 50);
					//alert(enteredName+" value too large. Restricting to first 50 characters.");
					$(this).val(enteredName);
				}
			});
			$("#signeeEmail").on("input", function (e) {

				var enteredEmail = $(this).val();
				var len = enteredEmail.length;

				if (len > 50) {
					enteredEmail = enteredEmail.slice(0, 50);
					// alert(enteredEmail+" value too large. Restricting to first 50 characters.");
					$(this).val(enteredEmail);
				}
			});
			if (receivedData.activity.A_BILLING_COMMENT) {
				$("#probWorkPerformed").text(receivedData.activity.A_BILLING_COMMENT);
			}
			// get the time values from receivedData JSON:

			var aStartTimeOverride = receivedData.activity.A_START_TIME_OVERRIDE;
			var aStartTime = receivedData.activity.A_START_TIME;
			var aScanInTimeOverride = receivedData.activity.A_SCAN_IN_TIME_OVERRIDE;
			var aScanInTime = receivedData.activity.A_SCAN_IN_TIME;
			var aScanOutTimeOverride = receivedData.activity.A_SCAN_OUT_TIME_OVERRIDE;
			//var aScanOutTime = receivedData.activity.A_SCAN_OUT_TIME;

			//A_START_TIME_OVERRIDE:=IF(A_START_TIME_OVERRIDE=A_START_TIME,NULL,A_START_TIME_OVERRIDE)
			// A_START_TIME_OVERRIDE : aStartTimeOverride

			if (aStartTimeOverride == aStartTime) {
				aStartTimeOverride = "";
			}
			//  A_SCAN_IN_TIME_OVERRIDE:=IF(A_SCAN_IN_TIME_OVERRIDE=A_SCAN_IN_TIME,NULL,A_SCAN_IN_TIME_OVERRIDE)
			//A_SCAN_IN_TIME_OVERRIDE : aScanInTimeOverride
			if (aScanInTimeOverride == aScanInTime) {
				aScanInTimeOverride = "";
			}
			//A_SCAN_OUT_OVERRIDE:=IF(A_SCAN_OUT_OVERRIDE=A_SCAN_OUT,NULL,A_SCAN_OUT_OVERRIDE)
			// A_SCAN_OUT_OVERRIDE : aScanOutTimeOverride
			if (aScanOutTimeOverride == aScanOutTime) {
				aScanOutTimeOverride = "";
			}

			// Get values from receivedData JSON:
			var se_billing_info = receivedData.activity.A_BILLING_INFO;
			var se_billing_info_xml = "";
			var se_expenses_plugin = receivedData.activity.A_EXPENSES_PLUGIN;
			var rowCount = 0;
			var a_status = receivedData.activity.A_STATUS;
			var aContractFlag = receivedData.activity.A_CONTRACT_FLAG;
			var aContractCoverage = receivedData.activity.A_CONTRACT_COVERAGE      // CHG0084485
			var alaborTime = receivedData.activity.A_LABOR_TIME;

			var g_showMaterialRow = false;
			if (a_status == 'CM') {

				$("#cpf_serviceTicket_closure").removeClass("cp_hidden");
				g_showMaterialRow = true;

				//$("#cpf_SigneeSignature").removeClass("cp_hidden");

			}
			if (!((typeof alaborTime != "undefined") && alaborTime != null && alaborTime != "")) {
				alaborTime = 1;
			}

			if (isNaN(alaborTime)) {
				alaborTime = 0;
			}
			var materialFee = parseFloat(receivedData.activity.A_MATERIAL_FEE).toFixed(2);

			if (isNaN(materialFee) || materialFee == "") {
				materialFee = "0.00";
			}
			/*	if(aContractFlag)
			{
				materialFee = "0.00";
			}*/

			var isBillingInfohasValue = false;
			if (aContractFlag == 'Y') {
				aContractFlag = true;
			} else {
				aContractFlag = false;
			}

			var laborRate = parseFloat(receivedData.activity.A_LABOR_RATE);
			var afterHrsLaborRate = parseFloat(receivedData.activity.A_AFTR_HRS_LABOR_RATE);
			var inflightFlag = false;

			// CHG0080567- OFSC MPF Group 2B Change changes decoding the A_INSTALLED_PARTS parts details
			// Start of CHG0080567- OFSC MPF Group 2B Change
			var installedParts = [];
			if (receivedData.activity.A_INSTALLED_PARTS != null) {
				var installed = receivedData.activity.A_INSTALLED_PARTS;
				var delimiter = '|';
				var installPartList = installed.split(delimiter);

				$.each(installPartList, function (key, part) {
					if (part.length != 0 && part != null) {
						var delimit = '~';
						var array = part.split(delimit);
						const object = {
							name: array[0],
							description: array[1],
							qty: array[2],
							billAmount: array[3],
							billReason: array[4],
							date: array[5],
							subinventory: array[6],// new change for CHG0080567


						};
						installedParts.push(object);
					}
				});
			}

			var allParts = [];
			if (receivedData.activity.A_ITEM_TRACKING != null) {
				var installed = receivedData.activity.A_ITEM_TRACKING;
				var delimiter = '|';
				var allPartList = installed.split(delimiter);

				$.each(allPartList, function (key, part) {
					if (part.length != 0 && part != null) {
						var delimit = '~';
						var array = part.split(delimit);
						const object = {
							name: array[0],
							description: array[1],
							qty: array[2],
							billAmount: array[3],
							billReason: array[4],
							extPrice: array[5],
							date: array[6],
							subinventory: array[7],// new change for CHG0080567

						};
						allParts.push(object);
					}
				});
			}

			// end of CHG0080567- OFSC MPF Group 2B Change



			//create XML elements:
			//group 2b changes
			// Start of CHG0080567- OFSC MPF Group 2B Change
			var newlyInstalled = [];
			var prevInstalled = [];
			if (installedParts.length != 0) {

				$.each(inventoryList, function (key, invItem) {
					var flag = false;
					$.each(installedParts, function (key, part) {
						if (invItem.I_ITEM_NUMBER == part.name && invItem.inv_aid == receivedData.activity.aid && invItem.I_SUBINVENTORY == part.subinventory && invItem.invpool == "install") {
							if (invItem.quantity == part.qty) {
								flag = true;
								const object = {
									partNum: invItem.I_ITEM_NUMBER,
									quant: invItem.quantity
								};
								installed_parts_details_first.push(object); // change for CHG0083631
								// installed_parts_details_first = installed_parts_details_first + invItem.I_ITEM_NUMBER + "~" + invItem.I_ITEM_DESCRIPTION + "~" + invItem.quantity + "~" + part.billAmount + "~" + part.billReason + "~" + date_MM_DD_TT + "~" + invItem.I_SUBINVENTORY + "|";
							}
							// if (invItem.quantity >= part.qty) {
							// 	prevInstalled.push(invItem.I_ITEM_NUMBER);
							// }
						}


					})
					if (flag == false && invItem.inv_aid == receivedData.activity.aid) {
						newlyInstalled.push(invItem.I_ITEM_NUMBER);
					};
				});
			}
			// end of CHG0080567- OFSC MPF Group 2B Change

			$.createElement = function (name, value) {
				var temp = document.createElementNS(name, name);
				if (value !== undefined) {
					temp.innerHTML = value;
				}
				return temp;

			};

			var $se_billing_info_firstLoadXml = $('<XMLDocument />');
			var $se_billing_info_billInfo = $.createElement('billingInfo');
			var $se_billing_info_billItems = $.createElement('billingItems');

			// start of CHG0083631 changes
			$.autoSetBillAmoutReason = function (itemNumber, itemAmount, itemReason, itemQuantity, date) {
				try {


					$('table tr.cpf_parts_row').each(function () {


						let prod_number = $(this).find('.item_number').text();
						let part_date = $(this).find('.dateColumn').text();
						if (prod_number == itemNumber && part_date != date) {
							var amountId = $(this).find(".cpf_input_overriden_val").attr("id");
							var reasonId = $(this).find(".billreasondropdownParts").attr("id");

							var originalAmountId = $(this).find(".billing-amount-original-value-link").attr("id");
							var originalReasonId = $(this).find(".billing-reason-original-value-container").attr("id");
							var quantity = $(this).find('.cpf_quantity').text();
							var value = (itemAmount / itemQuantity) * quantity;
							console.log("amount", $(this).find("#" + amountId).val());
							console.log("reason", $(this).find("#" + reasonId).val());
							console.log("originalAmount", $(this).find("#" + originalAmountId).val());
							$(this).find("#" + amountId).text((value).toFixed(2));
							$(this).find("#" + amountId).val((value).toFixed(2));

							$(this).find("#" + reasonId).val(itemReason).attr("selected", "selected");
							$(this).find("#" + originalAmountId).text('$' + (value).toFixed(2));
							$(this).find("#" + originalReasonId).text(itemReason);

						}
					})
				} catch (err) {
					activityLog = activityLog + ';Exception in recalculateBillAmountTotal:' + err.message;
					console.log(" Exception in recalculateBillAmountTotal :" + err.message);
				}
			};// end of CHG0083631 changes

			$.recalculateBillAmountTotal = function () {
				try {
					var billingAmt = 0;
					console.log('billingAmt' + billingAmt);
					$('table tr.billing-items-grid-row').each(function () {
						//  alert("row");
						$(this).find('.cpf_inner_overriden_val').each(function () {
							var billAmt = $(this).val();
							billAmt = parseFloat(billAmt);

							if (!isNaN(billAmt)) {
								billingAmt += parseFloat(billAmt);
								console.log('summed up-' + billingAmt);
							}
						});
					});
					// Update the total.
					$(".billAmt_total").text("$ " + billingAmt.toFixed(2));
					// Update the total excluding the taxes.
					$("#cpf_TotalExcludingTaxes_inner").text("$ " + billingAmt.toFixed(2));
				} catch (err) {
					activityLog = activityLog + ';Exception in recalculateBillAmountTotal:' + err.message;
					console.log(" Exception in recalculateBillAmountTotal :" + err.message);
				}
			};

			// calculate the ext Price column-
			$.recalculateExtPriceTotal = function () {
				try {
					var extOverPrice = 0;

					$('table tr.billing-items-grid-row').each(function () {

						$(this).find('.ext-price').each(function () {
							var extOverP = $(this).text();
							extOverP = extOverP.replace("$", "");
							extOverP = $.trim(extOverP);
							extOverP = parseFloat(extOverP);
							if (!isNaN(extOverP) && extOverP.length !== 0) {
								extOverPrice += extOverP;
							}
						});


					});
					var ext_price_total = extOverPrice.toFixed(2);

					$("#ext_price_Total").text("$ " + ext_price_total);
				} catch (err) {
					activityLog = activityLog + ';Exception in recalculateExtPriceTotal:' + err.message;
					console.log(" Exception in recalculateExtPriceTotal :" + err.message);
				}
			};

			$.generateExpenseRowsPlugin = function (se_expenses_plugin, expenseItemNumXMLArr, expenseDate) {
				try {
					var $se_billing_expenseItems;
					// To generate the expenses xml rows:begin
					if ((se_expenses_plugin != null) && (typeof se_expenses_plugin != "undefined")) {
						var findme = "&gt;";
						if (se_expenses_plugin.indexOf(findme) > -1) {
							se_expenses_plugin = $("<div />").html(se_expenses_plugin).text(); // to decode the lt gt;
						}


						se_expenses_pluginXml = '<ExpenseOutBound>' + se_expenses_plugin + '</ExpenseOutBound>';
						var se_expenses_plugin_xmlDoc = $.parseXML(se_expenses_pluginXml);
						var se_expenses_pluginXml = $(se_expenses_plugin_xmlDoc);
						var expenseType, quantity, origBillamount, OvrPrice, OvrPriceReason, isOverriden, date, expenseSection, expenseLabel, expenseTypeInfo;
						var bill_reason_code = "";



						se_expenses_pluginXml.find('ExpenseOutBound').find('DebriefExpenseLine').each(function () {

							$(this).children().each(function () {
								var tagNam = this.tagName;

								if (tagNam == "A_EXPENSE_TYPE") {
									expenseType = $(this).text();
								}
								if (tagNam == "A_QUANTITY") {
									quantity = $(this).text();
								}
								if (tagNam == "A_AMOUNT") {
									origBillamount = $(this).text();
								}

								if (tagNam == "A_OVERRIDE_PRICE") {
									OvrPrice = $(this).text();
									if (OvrPrice == "" || parseInt(OvrPrice) == 0) {
										OvrPrice = origBillamount;
									}
								}

								if (tagNam == "A_PRICE_OVERRIDE_REASON_CODE") {
									OvrPriceReason = $(this).text();

								}

								if (tagNam == "A_EXPENSE_SECTION") {
									expenseSection = $(this).text(); // reimbursable_expenses_type, chargeable_activities_type, activities_type, ServiceAdvantageChargeableActivitiesType
								}

								if (tagNam == "A_EXPENSE_LABEL") {
									expenseLabel = $(this).text();
								}

								if (origBillamount != OvrPrice) {

									if (aContractFlag && parseInt(OvrPrice) > 0) {

										isOverriden = "Y";
									} else {
										isOverriden = "N";
									}
								} else {

									isOverriden = "N";
								}
							});
							// rowCount += 1;
							if (expenseSection == "reimbursable_expenses_type") {
								if (aContractFlag) {
									OvrPriceReason = "";
									OvrPrice = 0;
								} else {
									bill_reason_code = "Not Covered By Contract";
									OvrPriceReason = "Not Covered By Contract";
								}
								expenseTypeInfo = "reimbursable";

							} else if (expenseSection == "chargeable_activities_type") {
								if (aContractFlag) {
									OvrPriceReason = "";
									OvrPrice = 0;
								} else {
									bill_reason_code = "E01-Billable";
									OvrPriceReason = "Standard Billable";
								}
								expenseTypeInfo = "training";
							} else if (expenseSection == "service_advantage_chargeable_activities_type") { //service_advantage_chargeable_activities_type
								if (aContractFlag) {
									OvrPriceReason = "";
									OvrPrice = 0;
								} else {
									bill_reason_code = "E01-Billable";
									OvrPriceReason = "Standard Billable";
								}
								expenseTypeInfo = "service advantage chargeable activities";
							} else if (expenseSection == "cbm_activities_type") {  //CHG0067765 Condition Based Maintenance
								/*if (aContractFlag) {
									OvrPriceReason = "";
									OvrPrice = 0;
								} else {
									bill_reason_code = "E01-Billable";
									OvrPriceReason = "Standard Billable";
								}*/
								OvrPriceReason = "na";
								expenseTypeInfo = "condition based maintainance";
							} else {
								OvrPriceReason = "na";
								expenseTypeInfo = "activities";
							}
							var isPresent = $.inArray(expenseType, expenseItemNumXMLArr);
							/* 	var changeInDate = false;
							  if(expenseDate != date_MM_DD){
	
								  changeInDate = true;
	
							  }*/


							// if (expenseItemNumXMLArr.length > 0 && !(isPresent == -1)) {
							// value present in XML dont do anything.
							//}else{
							// This expense not present in XML -- process and add to table.
							var $se_billing_info_Expenses = $.createElement('expense');
							$se_billing_info_Expenses.append($.createElement('key', currDateTimeFormat + " " + expenseType));
							//$se_billing_info_Expenses.append($.createElement('date',date_MM_DD));//CHG0060060 - Commented for issue#6969 wrong date issue in service ticket
							// $se_billing_info_Expenses.append($.createElement('date', date_MM_DD_arvlDate)); //CHG0060060 modified date to arrival date for issue#6969 issue fix
							$se_billing_info_Expenses.append($.createElement('date', date_MM_DD_TT)); // modified for  CHG0080567 change
							$se_billing_info_Expenses.append($.createElement('quantity', quantity));
							$se_billing_info_Expenses.append($.createElement('quantity_unit', 'hrs'));
							$se_billing_info_Expenses.append($.createElement('prod_number', expenseType));
							$se_billing_info_Expenses.append($.createElement('name', expenseLabel));
							$se_billing_info_Expenses.append($.createElement('price', origBillamount));
							$se_billing_info_Expenses.append($.createElement('price_summ', origBillamount));
							$se_billing_info_Expenses.append($.createElement('is_overriden', isOverriden));
							$se_billing_info_Expenses.append($.createElement('billing_amount', OvrPrice));
							$se_billing_info_Expenses.append($.createElement('billing_reason', bill_reason_code));
							$se_billing_info_Expenses.append($.createElement('billing_reason_title', OvrPriceReason));
							$se_billing_info_Expenses.append($.createElement('expense_type', expenseTypeInfo));
							$se_billing_info_Expenses.append($.createElement('pass_count', g_current_pass_count));

							$se_billing_info_billItems.append($se_billing_info_Expenses);
							//}
						});
					}
					return $se_billing_info_billItems;
				} catch (err) {
					activityLog = activityLog + ';Exception in generateExpenseRowsPlugin:' + err.message;
					console.log(" Exception in generateExpenseRowsPlugin :" + err.message);
				}
			};

			$.generateLaborRows = function () {
				try {

					var payCode = receivedData.resource.P_PAYCODE;
					var name, quantity = alaborTime,
						quantity_unit = "hrs",
						prod_number = "standard",
						price = "",
						price_summ = "",
						billing_amount = "",
						billing_reason_title = "";
					if (!receivedData.activity.A_SCAN_OUT_TIME_OVERRIDE || saAccountFlag) // Added SA Accoung flag for CHG0069377-Service_Advantage_Billing
					{
						//quantity = $("#completion_date") - $("#arrival_date")
						var laborTimeVal;
						var tempTimeGraph = [];
						for (var i = 1; i < 100; i++) {
							tempTimeGraph.push(i + '.00', i + '.25', i + '.50', i + '.75');
						}
						console.log('calculating activityDispatchTimeVal:');

						console.log('calculating activityLaborTimeVal:');
						var startTimeVal = $("#arrival_date").text();
						var labourEndVal = $("#completion_date").text();
						var startDate = new Date(startTimeVal.substr(0, 16));
						var laborEndDate = new Date(labourEndVal.substr(0, 16));

						console.log('startDate:', startDate);
						console.log('laborEndDate:', laborEndDate);

						var startDay = startDate.getDate();
						var startHour = startDate.getHours();
						var startMinutes = startDate.getMinutes();
						var laborDay = laborEndDate.getDate();
						var laborHour = laborEndDate.getHours();
						var laborMinutes = laborEndDate.getMinutes();
						console.log('laborHour:', laborHour);
						console.log('laborMinutes:', laborMinutes);
						console.log('startHour:', startHour);
						var tempDay = laborDay - startDay;
						var tempHour = laborHour - startHour;
						var tempMinutes = laborMinutes - startMinutes;
						var firstDate = (tempDay * 24 * 60) + (tempHour * 60) + (tempMinutes);
						var displayHour = parseInt(firstDate / 60);
						var displayMinute = parseInt(firstDate % 60);
						if (displayMinute <= 9 && displayMinute >= 0) {
							displayMinute = '0' + displayMinute;
						}
						if (saAccountFlag) { // Start chagnes for CHG0069377-Service_Advantage_Billing
							if (displayMinute > 0) {
								var minutePercentage = Math.ceil((parseFloat(displayMinute) / 60) * 100);
								if (minutePercentage >= 0 && minutePercentage < 10) {
									minutePercentage = '0' + minutePercentage;
								}
								laborTimeVal = displayHour + '.' + minutePercentage;
							} else {
								laborTimeVal = displayHour + '.00';
							}

						} else { // End changes for CHG0069377-Service_Advantage_Billing
							if (firstDate <= 60) {
								$('#labour_time').val(tempTimeGraph[0]).text(displayHour + ':' + displayMinute);
								laborTimeVal = tempTimeGraph[0];
							}
							else {
								var tempDate = firstDate - 60;
								var indexedTime = Math.ceil(tempDate / 15);
								if (tempTimeGraph[indexedTime]) {
									laborTimeVal = tempTimeGraph[indexedTime];
								}
								else {
									laborTimeVal = '99.00';
								}
								//$('#labour_time').val(laborTimeVal).text(displayHour + ':' + displayMinute);
							}
						}
						quantity = laborTimeVal;//.text(displayHour + ':' + displayMinute); // Moved out from loop for CHG0069377-Service_Advantage_Billing
					}
					/*
					"CLOCK": {
					"text": "REGULAR SHIFT"
					},
					"CALL_IN_IO": {
					"text": "ON CALL"
					*/
					if (payCode == "CLOCK") { //"REGULAR SHIFT"
						name = "Labor – Regular Hours";
						if (laborRate != "" && !isNaN(laborRate) && laborRate != null) {
							price = parseFloat(quantity * laborRate).toFixed(2);

						} else {
							price = "0.00";
						}
					}
					if (payCode == "CALL_IN_IO") { //ON CALL
						name = "Labor – After Hours";

						if (afterHrsLaborRate != "" && !isNaN(afterHrsLaborRate) && afterHrsLaborRate != null) {
							price = parseFloat(quantity * afterHrsLaborRate).toFixed(2);

						} else {
							price = "0.00";
						}
					}
					price_summ = price;
					if (aContractFlag) {
						billing_amount = 0;
					} else {
						billing_amount = price;
					}
					var $se_billing_info_labor = $.createElement('labor');
					$se_billing_info_labor.append($.createElement('key'));
					//$se_billing_info_labor.append($.createElement('date',date_MM_DD));//CHG0060060 - Commented for issue#6969 wrong date issue in service ticket
					// $se_billing_info_labor.append($.createElement('date', date_MM_DD_arvlDate));//CHG0060060 modified date to arrival date for issue#6969 issue fix
					$se_billing_info_labor.append($.createElement('date', date_MM_DD_TT)); // modified for  CHG0080567 change
					$se_billing_info_labor.append($.createElement('quantity', quantity));
					$se_billing_info_labor.append($.createElement('quantity_unit', quantity_unit));
					$se_billing_info_labor.append($.createElement('prod_number', prod_number));
					$se_billing_info_labor.append($.createElement('name', name));
					$se_billing_info_labor.append($.createElement('price', price));
					$se_billing_info_labor.append($.createElement('price_summ', price_summ));
					$se_billing_info_labor.append($.createElement('is_overriden'));
					$se_billing_info_labor.append($.createElement('billing_amount', billing_amount));
					$se_billing_info_labor.append($.createElement('billing_reason'));
					$se_billing_info_labor.append($.createElement('billing_reason_title'));

					$se_billing_info_billItems.append($se_billing_info_labor);

					return $se_billing_info_billItems;
				} catch (err) {
					activityLog = activityLog + ';Exception in generateLaborRows:' + err.message;
					console.log(" Exception in generateLaborRows :" + err.message);
				}

			};

			//If se_billing_info is empty generate a same xml format with getting the values from different places.

			if (se_billing_info == null || se_billing_info == "" || (typeof se_billing_info == "undefined")) {
				//function call to generate labor row:

				var $genLaborRows = $.generateLaborRows();

				//Create the XML for Total Labour.
				var name, quantity = "1",
					quantity_unit = "hrs",
					prod_number = "standard",
					price = "",
					price_summ = "",
					billing_amount = "",
					billing_reason = "",
					billing_reason_title = "";


				if (!aContractFlag) {

					billing_reason = 'L01';
					billing_reason_title = 'Standard Billable';
				}

				var $se_billing_info_Totlabor = $.createElement('total_labor');
				$se_billing_info_Totlabor.append($.createElement('key'));
				$se_billing_info_Totlabor.append($.createElement('date'));
				$se_billing_info_Totlabor.append($.createElement('quantity', '1'));
				$se_billing_info_Totlabor.append($.createElement('quantity_unit', quantity_unit));
				$se_billing_info_Totlabor.append($.createElement('prod_number'));
				$se_billing_info_Totlabor.append($.createElement('name', 'Total Labor'));
				$se_billing_info_Totlabor.append($.createElement('price', price));
				$se_billing_info_Totlabor.append($.createElement('price_summ', price_summ));
				$se_billing_info_Totlabor.append($.createElement('is_overriden'));
				$se_billing_info_Totlabor.append($.createElement('billing_amount', billing_amount));
				$se_billing_info_Totlabor.append($.createElement('billing_reason', billing_reason));
				$se_billing_info_Totlabor.append($.createElement('billing_reason_title', billing_reason_title));


				$se_billing_info_billItems.append($se_billing_info_Totlabor);

				if (g_showMaterialRow) {
					//Create the XML for Material Handling fee:

					if (aContractFlag) {
						billing_reason = "Contract";
						billing_reason_title = "Contract";
					} else {
						billing_reason = "No_contract";
						billing_reason_title = "No contract";
					}


					var $se_billing_info_Material = $.createElement('material_handling_fee');
					$se_billing_info_Material.append($.createElement('key'));
					//$se_billing_info_Material.append($.createElement('date',date_MM_DD));//CHG0060060 - Commented for issue#6969 wrong date issue in service ticket
					// $se_billing_info_Material.append($.createElement('date', date_MM_DD_arvlDate));//CHG0060060 modified date to arrival date for issue#6969 issue fix
					$se_billing_info_Material.append($.createElement('date', date_MM_DD_TT));// Modified for CHG0080567 
					$se_billing_info_Material.append($.createElement('quantity', '1'));
					$se_billing_info_Material.append($.createElement('quantity_unit', quantity_unit));
					$se_billing_info_Material.append($.createElement('prod_number', 'eX2'));
					$se_billing_info_Material.append($.createElement('name', 'Material Handling fee'));
					$se_billing_info_Material.append($.createElement('price', materialFee));
					$se_billing_info_Material.append($.createElement('price_summ', materialFee));
					$se_billing_info_Material.append($.createElement('is_overriden', 'N'));
					$se_billing_info_Material.append($.createElement('billing_amount', materialFee));
					$se_billing_info_Material.append($.createElement('billing_reason', billing_reason));
					$se_billing_info_Material.append($.createElement('billing_reason_title', billing_reason_title));

					$se_billing_info_billItems.append($se_billing_info_Material);
				}
				// To generate the Parts section XML :


				var invQty, itemPrice, itemNumber, itemDesc, extPrice, subinventory;
				$.each(inventoryList, function (key, invItem) {

					if (invItem.inv_aid == receivedData.activity.aid) {
						if (invItem.invpool == "install" && parseInt(invItem.quantity) > 0) {
							// || (invItem.invpool == "deinstall" && invItem.I_ITEM_ORDER && parseInt(invItem.I_ITEM_ORDER) > 0 )) {

							invQty = invItem.quantity;;

							//itemPrice = parseFloat(invItem.I_ITEM_PRICE).toFixed(2);
							if (invItem.I_PRICE) {
								itemPrice = parseFloat(invItem.I_PRICE).toFixed(2);
							} else {
								itemPrice = 0;
							}
							itemNumber = invItem.I_ITEM_NUMBER;
							itemDesc = invItem.I_ITEM_DESCRIPTION;
							subinventory = invItem.I_SUBINVENTORY;// new change for CHG0080567

							//console.log(quantity +" "+itemPrice+" "+itemNumber+" "+itemDesc);
							extPrice = parseFloat(invQty * itemPrice).toFixed(2);

							if (aContractFlag) {
								billing_amount = 0;
								billing_reason_title = "";
							} else {
								billing_amount = extPrice;
								billing_reason_title = 'Not Covered by Contract';
							}

							var $se_billing_info_Parts = $.createElement('part');
							$se_billing_info_Parts.append($.createElement('key', currDateTimeFormat + " " + itemNumber));
							//$se_billing_info_Parts.append($.createElement('date',date_MM_DD));//CHG0060060 - Commented for issue#6969 wrong date issue in service ticket
							$se_billing_info_Parts.append($.createElement('date', date_MM_DD_TT));//CHG0080567- OFSC MPF Group 2B Change
							$se_billing_info_Parts.append($.createElement('quantity', invQty));
							$se_billing_info_Parts.append($.createElement('quantity_unit', ''));
							$se_billing_info_Parts.append($.createElement('prod_number', itemNumber));
							$se_billing_info_Parts.append($.createElement('name', itemDesc));
							$se_billing_info_Parts.append($.createElement('price', itemPrice));
							$se_billing_info_Parts.append($.createElement('price_summ', extPrice));
							$se_billing_info_Parts.append($.createElement('is_overriden'));
							$se_billing_info_Parts.append($.createElement('billing_amount', billing_amount));
							$se_billing_info_Parts.append($.createElement('billing_reason', ''));
							$se_billing_info_Parts.append($.createElement('billing_reason_title', billing_reason_title));
							$se_billing_info_Parts.append($.createElement('pass_count', g_current_pass_count));
							$se_billing_info_Parts.append($.createElement('subinventory', subinventory));// new change for CHG0080567


							$se_billing_info_billItems.append($se_billing_info_Parts);
						}
					}

				});

				// expense rws
				var $se_billing_expenses = $.generateExpenseRowsPlugin(se_expenses_plugin, [], "");
				//append labour, total labour, materialHandling fee:
				$se_billing_info_billInfo.append($se_billing_info_billItems);
				$se_billing_info_firstLoadXml.append($se_billing_info_billInfo);
				//set the xml
				se_billing_info_xml = $se_billing_info_firstLoadXml;
			} else {



				var findme = "&gt;";
				var partItemNumXMLArr = [];
				var expenseItemNumXMLArr = [];
				var partItemNumXMLJSON = {};
				var expenseDate = "";
				if (se_billing_info.indexOf(findme) > -1) {
					se_billing_info = $("<div />").html(se_billing_info).text(); // to decode the lt gt;
				}
				var se_billing_info_xmlDoc = $.parseXML(se_billing_info);
				se_billing_info_xml = $(se_billing_info_xmlDoc);

				var billingItemsParentNode = se_billing_info_xml.find('billingInfo').find('billingItems');
				var $genLaborRows = $.generateLaborRows();

				//count the labor rows in SE
				var se_laborRowCount = 0;
				se_billing_info_xml.find('billingInfo').find('billingItems').find('labor').each(function () {

					se_laborRowCount++;


				});
				g_current_pass_count = se_laborRowCount + 1;

				var partsFoundInXML = false;
				//check for parts from billing info and compare with the inventory List of install and deinstall parts:
				//first loop through the parts xml and get the itemNumbers in a sep arr.
				se_billing_info_xml.find('billingInfo').find('billingItems').find('part').each(function () {
					var itemNumber_xml = $(this).find("prod_number").text();
					var overPrice = $(this).find("billing_amount").text();
					var billingReasonTitle = $(this).find("billing_reason_title").text();
					var isOverride = $(this).find("is_overriden").text();
					var passCount = $(this).find("pass_count").text();
					partItemNumXMLArr.push(itemNumber_xml);
					$.extend(partItemNumXMLJSON, {
						[itemNumber_xml]: {
							overridenPrice: overPrice,
							billingReason: billingReasonTitle,
							isOverride: isOverride,
							passCount: passCount

						}
					});

				});
				// Remove the parts from the stored XML and regenerate every time from inventoryList:
				var $billingItems = se_billing_info_xml.find('billingInfo').find('billingItems');
				$billingItems.each(function () {
					$(this).find('part').remove();
				});


				// Start of CHG0080567- OFSC MPF Group 2B Change
				if (allParts.length == 0) {
					var invQty, itemPrice, itemNumber, itemDesc, extPrice, billing_amount, billing_reason_title, subinventory;;
					$.each(inventoryList, function (key, invItem) {

						if (invItem.inv_aid == receivedData.activity.aid) {
							if (invItem.invpool == "install" && parseInt(invItem.quantity) > 0) {

								//|| (invItem.invpool == "deinstall" && invItem.I_ITEM_ORDER && parseInt(invItem.I_ITEM_ORDER) > 0 )) {
								invQty = invItem.quantity;

								if (invItem.I_PRICE) {
									itemPrice = parseFloat(invItem.I_PRICE).toFixed(2);
								} else {
									itemPrice = 0;
								}
								itemNumber = invItem.I_ITEM_NUMBER;
								itemDesc = invItem.I_ITEM_DESCRIPTION;
								subinventory = invItem.I_SUBINVENTORY;// new change for CHG0080567

								extPrice = parseFloat(invQty * itemPrice).toFixed(2);

								if (aContractFlag) {
									billing_amount = 0;
									billing_reason_title = "";
								} else {
									billing_amount = extPrice;
									billing_reason_title = 'Not Covered by Contract';
								}

								var isPresent = $.inArray(itemNumber, partItemNumXMLArr);

								var isoverRide = "N";
								var passCount = g_current_pass_count;
								if (!(isPresent == -1)) {
									// value present in XML , so copy the override price, billing reason.
									// duplicate items exist.
									//do not process it., will get processed if g_ShowDuplicateItems == true;
									billing_amount = partItemNumXMLJSON[itemNumber].overridenPrice;
									billing_reason_title = partItemNumXMLJSON[itemNumber].billingReason;
									isoverRide = partItemNumXMLJSON[itemNumber].isOverride;
									passCount = partItemNumXMLJSON[itemNumber].passCount;

								}//else{
								// no duplicates
								var $se_billing_info_Parts = $.createElement('part');
								$se_billing_info_Parts.append($.createElement('key', currDateTimeFormat + " " + itemNumber));
								//$se_billing_info_Parts.append($.createElement('date',date_MM_DD));//CHG0060060 - Commented for issue#6969 wrong date issue in service ticket
								//$se_billing_info_Parts.append($.createElement('date',date_MM_DD));//CHG0060060 - Commented for issue#6969 wrong date issue in service ticket
								$se_billing_info_Parts.append($.createElement('date', date_MM_DD_TT));//CHG0060060 modified date to arrival date for issue#6969 issue fix
								$se_billing_info_Parts.append($.createElement('quantity', invQty));
								$se_billing_info_Parts.append($.createElement('quantity_unit', ''));
								$se_billing_info_Parts.append($.createElement('prod_number', itemNumber));
								$se_billing_info_Parts.append($.createElement('name', itemDesc));
								$se_billing_info_Parts.append($.createElement('price', itemPrice));
								$se_billing_info_Parts.append($.createElement('price_summ', extPrice));
								$se_billing_info_Parts.append($.createElement('is_overriden', isoverRide));
								$se_billing_info_Parts.append($.createElement('billing_amount', billing_amount));
								$se_billing_info_Parts.append($.createElement('billing_reason', ''));
								$se_billing_info_Parts.append($.createElement('billing_reason_title', billing_reason_title));
								$se_billing_info_Parts.append($.createElement('pass_count', passCount));
								$se_billing_info_Parts.append($.createElement('subinventory', subinventory));// new change for CHG0080567
								$(billingItemsParentNode).append($se_billing_info_Parts);

								// }

							}
						}

					});
				}
				else {


					$.each(allParts, function (key, item) {

						var qty = item.qty;
						var partNumber = item.name;
						var partDesc = item.description;
						var itemPrice = item.extPrice;
						var extPrice = item.extPrice;
						var billing_amount = item.billAmount;
						var billing_reason_title = item.billReason;
						var date = item.date;
						var subinventory = item.subinventory;// new change for CHG0080567



						var $se_billing_info_Parts = $.createElement('part');
						$se_billing_info_Parts.append($.createElement('key', item.date + " " + itemNumber));
						//$se_billing_info_Parts.append($.createElement('date',date_MM_DD));//CHG0060060 - Commented for issue#6969 wrong date issue in service ticket
						$se_billing_info_Parts.append($.createElement('date', date));//CHG0060060 modified date to arrival date for issue#6969 issue fix
						$se_billing_info_Parts.append($.createElement('quantity', qty));
						$se_billing_info_Parts.append($.createElement('quantity_unit',));
						$se_billing_info_Parts.append($.createElement('prod_number', partNumber));
						$se_billing_info_Parts.append($.createElement('name', partDesc));
						$se_billing_info_Parts.append($.createElement('price', itemPrice));
						$se_billing_info_Parts.append($.createElement('price_summ', extPrice));
						if (qty < 0) {
							$se_billing_info_Parts.append($.createElement('is_overriden', 'D'));
						}
						else {
							$se_billing_info_Parts.append($.createElement('is_overriden', ''));
						}
						// $se_billing_info_Parts.append($.createElement('is_overriden', ''));
						$se_billing_info_Parts.append($.createElement('billing_amount', billing_amount));
						$se_billing_info_Parts.append($.createElement('billing_reason', ''));
						$se_billing_info_Parts.append($.createElement('billing_reason_title', billing_reason_title));
						$se_billing_info_Parts.append($.createElement('pass_count', g_current_pass_count));
						$se_billing_info_Parts.append($.createElement('subinventory', subinventory));// new change for CHG0080567
						$(billingItemsParentNode).append($se_billing_info_Parts);


					});





					if (installedParts.length != 0) {
						$.each(installedParts, function (key, item) {
							let partsExists = false;
							let installQty = false;
							let deinstallQty = false
							var extPrice = 0;
							var subinventory;// new change for CHG0080567

							$.each(inventoryList, function (key, parts) {
								if (parts.invpool == "install") {
									if (parts.inv_aid == receivedData.activity.aid) {
										if (parts.I_ITEM_NUMBER === item.name && parts.I_SUBINVENTORY == item.subinventory) { // new change for CHG0080567
											if (item.qty - parts.quantity > 0) {
												extPrice = (parts.I_PRICE * (parts.quantity - item.qty));
												extPrice = parseFloat(extPrice).toFixed(2);
												deinstallQty = true;
											}
											if (parts.quantity - item.qty > 0) {
												extPrice = (parts.I_PRICE * (parts.quantity - item.qty));
												extPrice = parseFloat(extPrice).toFixed(2);
												installQty = true;
											}

											partsExists = true;
											return false;
										}
									}
								}
							});


							if (partsExists == false) {

								$.each(allParts, function (key, partItem) {
									if (item.name == partItem.name) {
										extPrice = partItem.extPrice * (-1);
									}

								});

								var itemPrice = 0;
								var billing_amount = item.billAmount * (-1);
								billing_amount = parseFloat(billing_amount).toFixed(2);
								billing_reason_title = item.billReason;
								var qty = item.qty * (-1);
								var partNumber = item.name;
								var partDesc = item.description;
								subinventory = item.subinventory;// new change for CHG0080567






								var $se_billing_info_Parts = $.createElement('part');
								$se_billing_info_Parts.append($.createElement('key', currDateTimeFormat + " " + itemNumber));
								//$se_billing_info_Parts.append($.createElement('date',date_MM_DD));//CHG0060060 - Commented for issue#6969 wrong date issue in service ticket
								$se_billing_info_Parts.append($.createElement('date', date_MM_DD_TT));//CHG0060060 modified date to arrival date for issue#6969 issue fix
								$se_billing_info_Parts.append($.createElement('quantity', qty));
								$se_billing_info_Parts.append($.createElement('quantity_unit',));
								$se_billing_info_Parts.append($.createElement('prod_number', partNumber));
								$se_billing_info_Parts.append($.createElement('name', partDesc));
								$se_billing_info_Parts.append($.createElement('price', itemPrice));
								$se_billing_info_Parts.append($.createElement('price_summ', extPrice));
								$se_billing_info_Parts.append($.createElement('is_overriden', 'D'));
								$se_billing_info_Parts.append($.createElement('billing_amount', billing_amount));
								$se_billing_info_Parts.append($.createElement('billing_reason', ''));
								$se_billing_info_Parts.append($.createElement('billing_reason_title', billing_reason_title));
								$se_billing_info_Parts.append($.createElement('pass_count', g_current_pass_count));
								$se_billing_info_Parts.append($.createElement('subinventory', subinventory));// new change for CHG0080567
								$(billingItemsParentNode).append($se_billing_info_Parts);
							}




							else if (partsExists == true && installQty == true) {
								let inventoryQty = 0;
								$.each(inventoryList, function (key, part) {
									// && activityFlag == true
									if (part.inv_aid == receivedData.activity.aid) {
										if (part.I_ITEM_NUMBER == item.name && part.I_SUBINVENTORY == item.subinventory) { // new change for CHG0080567
											inventoryQty = part.quantity;
										}
									}

								});
								var itemPrice = 0;
								var billing_amount = item.billAmount;

								billing_reason_title = item.billReason;
								var qty = inventoryQty - item.qty;
								var billing_amount = (qty * parseFloat(item.billAmount).toFixed(2)) / item.qty;
								billing_amount = parseFloat(billing_amount).toFixed(2);
								var partNumber = item.name;
								var partDesc = item.description;
								subinventory = item.subinventory;// new change for CHG0080567





								var $se_billing_info_Parts = $.createElement('part');
								$se_billing_info_Parts.append($.createElement('key', currDateTimeFormat + " " + itemNumber));
								//$se_billing_info_Parts.append($.createElement('date',date_MM_DD));//CHG0060060 - Commented for issue#6969 wrong date issue in service ticket
								$se_billing_info_Parts.append($.createElement('date', date_MM_DD_TT));//CHG0060060 modified date to arrival date for issue#6969 issue fix
								$se_billing_info_Parts.append($.createElement('quantity', qty));
								$se_billing_info_Parts.append($.createElement('quantity_unit',));
								$se_billing_info_Parts.append($.createElement('prod_number', partNumber));
								$se_billing_info_Parts.append($.createElement('name', partDesc));
								$se_billing_info_Parts.append($.createElement('price', itemPrice));
								$se_billing_info_Parts.append($.createElement('price_summ', extPrice));
								$se_billing_info_Parts.append($.createElement('is_overriden', ''));
								$se_billing_info_Parts.append($.createElement('billing_amount', billing_amount));
								$se_billing_info_Parts.append($.createElement('billing_reason', ''));
								$se_billing_info_Parts.append($.createElement('billing_reason_title', billing_reason_title));
								$se_billing_info_Parts.append($.createElement('pass_count', g_current_pass_count));
								$se_billing_info_Parts.append($.createElement('subinventory', subinventory));// new change for CHG0080567
								$(billingItemsParentNode).append($se_billing_info_Parts);

							}
							else if (partsExists == true && deinstallQty == true) {
								let inventoryQty = 0;
								$.each(inventoryList, function (key, part) {
									// && activityFlag == true
									if (part.inv_aid == receivedData.activity.aid) {
										if (part.I_ITEM_NUMBER == item.name && part.I_SUBINVENTORY == item.subinventory) { // new change for CHG0080567
											inventoryQty = part.quantity;
										}
									}

								});
								var itemPrice = 0;
								var billing_amount = item.billAmount;

								billing_reason_title = item.billReason;
								var qty = inventoryQty - item.qty;
								var billing_amount = (qty *  parseFloat(item.billAmount).toFixed(2)) / item.qty;
								billing_amount = parseFloat(billing_amount).toFixed(2);
								var partNumber = item.name;
								var partDesc = item.description;
								subinventory = item.subinventory;// new change for CHG0080567




								var $se_billing_info_Parts = $.createElement('part');
								$se_billing_info_Parts.append($.createElement('key', currDateTimeFormat + " " + itemNumber));
								//$se_billing_info_Parts.append($.createElement('date',date_MM_DD));//CHG0060060 - Commented for issue#6969 wrong date issue in service ticket
								$se_billing_info_Parts.append($.createElement('date', date_MM_DD_TT));//CHG0060060 modified date to arrival date for issue#6969 issue fix
								$se_billing_info_Parts.append($.createElement('quantity', qty));
								$se_billing_info_Parts.append($.createElement('quantity_unit',));
								$se_billing_info_Parts.append($.createElement('prod_number', partNumber));
								$se_billing_info_Parts.append($.createElement('name', partDesc));
								$se_billing_info_Parts.append($.createElement('price', itemPrice));
								$se_billing_info_Parts.append($.createElement('price_summ', extPrice));
								$se_billing_info_Parts.append($.createElement('is_overriden', 'D'));
								$se_billing_info_Parts.append($.createElement('billing_amount', billing_amount));
								$se_billing_info_Parts.append($.createElement('billing_reason', ''));
								$se_billing_info_Parts.append($.createElement('billing_reason_title', billing_reason_title));
								$se_billing_info_Parts.append($.createElement('pass_count', g_current_pass_count));
								$se_billing_info_Parts.append($.createElement('subinventory', subinventory));// new change for CHG0080567
								$(billingItemsParentNode).append($se_billing_info_Parts);
							}
						});
						$.each(inventoryList, function (key, parts) {
							if (parts.invpool == "install") {
								if (parts.inv_aid == receivedData.activity.aid) {
									var flag = true;
									$.each(installedParts, function (key, item) {
										if (item.name == parts.I_ITEM_NUMBER && parts.I_SUBINVENTORY == item.subinventory) { // new change for CHG0080567
											flag = false;
										}

									});
									if (flag == true) {
										var invQty, itemPrice, itemNumber, itemDesc, extPrice, billing_amount, billing_reason_title;
										invQty = parts.quantity;;

										//itemPrice = parseFloat(invItem.I_ITEM_PRICE).toFixed(2);
										if (parts.I_PRICE) {
											itemPrice = parseFloat(parts.I_PRICE).toFixed(2);
										} else {
											itemPrice = 0;
										}
										itemNumber = parts.I_ITEM_NUMBER;
										itemDesc = parts.I_ITEM_DESCRIPTION;
										subinventory = parts.I_SUBINVENTORY;// new change for CHG0080567
										//console.log(quantity +" "+itemPrice+" "+itemNumber+" "+itemDesc);
										extPrice = parseFloat(invQty * itemPrice).toFixed(2);

										if (aContractFlag) {
											billing_amount = 0;
											billing_reason_title = "";
										}

										else {
											billing_amount = extPrice;
											billing_reason_title = 'Not Covered by Contract';
										}

										var $se_billing_info_Parts = $.createElement('part');
										$se_billing_info_Parts.append($.createElement('key', currDateTimeFormat + " " + itemNumber));
										//$se_billing_info_Parts.append($.createElement('date',date_MM_DD));//CHG0060060 - Commented for issue#6969 wrong date issue in service ticket
										$se_billing_info_Parts.append($.createElement('date', date_MM_DD_TT));//CHG0060060 modified date to arrival date for issue#6969 issue fix
										$se_billing_info_Parts.append($.createElement('quantity', invQty));
										$se_billing_info_Parts.append($.createElement('quantity_unit', ''));
										$se_billing_info_Parts.append($.createElement('prod_number', itemNumber));
										$se_billing_info_Parts.append($.createElement('name', itemDesc));
										$se_billing_info_Parts.append($.createElement('price', itemPrice));
										$se_billing_info_Parts.append($.createElement('price_summ', extPrice));
										$se_billing_info_Parts.append($.createElement('is_overriden', ''));
										$se_billing_info_Parts.append($.createElement('billing_amount', billing_amount));
										$se_billing_info_Parts.append($.createElement('billing_reason', ''));
										$se_billing_info_Parts.append($.createElement('billing_reason_title', billing_reason_title));
										$se_billing_info_Parts.append($.createElement('pass_count', g_current_pass_count));
										$se_billing_info_Parts.append($.createElement('subinventory', subinventory));// new change for CHG0080567

										$se_billing_info_billItems.append($se_billing_info_Parts);
									}
								}
							}

						});
					}
				}

				// Generate new set of rows everytime from A_SE_EXPENSES_PLUGIN.
				var expenseFoundInXML = false;
				//check for expense from billing info and compare with the A_SE_EXPENSES_PLUGIN

				//first loop through the expense xml and get the itemNumbers in a sep arr.
				se_billing_info_xml.find('billingInfo').find('billingItems').find('expense').each(function () {
					var itemNumber_xml = $(this).find("prod_number").text();
					expenseItemNumXMLArr.push(itemNumber_xml);
					expenseDate = $(this).find("date").text();

				});

				var $se_billing_expenses = $.generateExpenseRowsPlugin(se_expenses_plugin, expenseItemNumXMLArr, expenseDate);
				$(billingItemsParentNode).append($se_billing_expenses);
				/*
				////// Remove the existing expense nodes from the billing info HTML
				var $billingItems = se_billing_info_xml.find('billingInfo').find('billingItems');
				$billingItems.each(function() {
				$(this).find('expense').remove();
				});
				$(billingItemsParentNode).append($se_billing_expenses);
				*//////////////////


				if (g_showMaterialRow) {
					//Create the XML for Material Handling fee:
					if (aContractFlag) {
						billing_reason = "Contract";
						billing_reason_title = "Contract";
					} else {
						billing_reason = "No_contract";
						billing_reason_title = "No contract";
					}

					var $se_billing_info_Material = $.createElement('material_handling_fee');
					$se_billing_info_Material.append($.createElement('key'));
					//$se_billing_info_Material.append($.createElement('date',date_MM_DD));//CHG0060060 - Commented for issue#6969 wrong date issue in service ticket
					// $se_billing_info_Material.append($.createElement('date', date_MM_DD_arvlDate));//CHG0060060 modified date to arrival date for issue#6969 issue fix
					$se_billing_info_Material.append($.createElement('date', date_MM_DD_TT));// Modified for CHG0080567 
					$se_billing_info_Material.append($.createElement('quantity', '1'));
					$se_billing_info_Material.append($.createElement('quantity_unit', quantity_unit));
					$se_billing_info_Material.append($.createElement('prod_number', 'eX2'));
					$se_billing_info_Material.append($.createElement('name', 'Material Handling fee'));
					$se_billing_info_Material.append($.createElement('price', materialFee));
					$se_billing_info_Material.append($.createElement('price_summ', materialFee));
					$se_billing_info_Material.append($.createElement('is_overriden', 'N'));
					$se_billing_info_Material.append($.createElement('billing_amount', materialFee));
					$se_billing_info_Material.append($.createElement('billing_reason', billing_reason));
					$se_billing_info_Material.append($.createElement('billing_reason_title', billing_reason_title));

					// $se_billing_info_billItems.append($se_billing_info_Material);
					$(billingItemsParentNode).append($se_billing_info_Material);
				}
			}




			//RENDERING THE DISPLAY TABLE ROWS//
			//To Generate the billing info rows in the table.
			var totalLaborBillAmount = 0;
			var totalLaborPrice = 0;
			var totalLaborQty = 0;
			if (se_billing_info_xml != null) // && (typeof se_billing_info != "undefined"))
			{

				// To get the Labor row

				se_billing_info_xml.find('billingInfo').find('billingItems').find('labor').each(function () {
					var date = $(this).find("date").text();
					var quantity = $(this).find("quantity").text();
					if (isNaN(quantity)) {
						quantity = 1.00;
					}
					totalLaborQty += parseFloat(quantity);
					var quantity_unit = $(this).find("quantity_unit").text();
					var prod_number = $(this).find("prod_number").text();
					var name = $(this).find("name").text();
					var price = $(this).find("price").text();
					totalLaborPrice += parseFloat(price);

					var price_summ = $(this).find("price_summ").text();
					var billing_amount = $(this).find("billing_amount").text();
					//calcualte the total billing amount.
					totalLaborBillAmount += parseFloat(billing_amount);
					var billing_reason = $(this).find("billing_reason").text();
					var billing_reason_title = $(this).find("billing_reason_title").text();
					rowCount += 1;
					var classKey = "Qty_" + rowCount;
					var classBillingUndoKey = "BillingAmt_" + rowCount;
					var BillingReasonContainerclass = "BillingReasonContainer_" + rowCount
					var billAmtOrigValLink = "billing-amount-original-value-link-" + rowCount;
					var billReasonOriginalValContainer = "bill-reason-original-value-container-" + rowCount;
					// Start changes for CHG0069377-Service_Advantage_Billing
					var scopeValId = "scopeVallist" + rowCount;
					var scopeValHourId = "scopeValHour" + rowCount;
					var partialOutOfScopeId = "partialOutOfScope" + rowCount;
					var applyButtonId = "applyButton" + rowCount;
					var editButtonId = "editButton" + rowCount;
					var overrideReasonsId = "overrideReasons" + rowCount;
					var editButtonDivId = "editButtonDiv" + rowCount;
					var cpf_labor_row_class = "cpf_labor_row_" + rowCount;
					var quantityValClass = "quantityVal" + rowCount;
					var saBilliedflag = $(this).find('sa_billied_flag').text();

					var datefromXML = $(this).find("date").text();
					// var date = $(this).find("key").text();
					var dateKey = datefromXML.split(" ");
					var date = "2023-".concat(dateKey[0]);

					//check if system date is greater than 3 months from go live 20Aug2023
					var currDate = new Date();
					var checkDate = new Date('2023-11-20');
					if (currDate < checkDate) {
						var initialDate = new Date('2023-08-20');
						var visitDate = new Date(date);
						if (visitDate < initialDate) {
							inflightFlag = true;
						}
					}


					//Append the row( Quantity, Item,Ext Price,Bill Amt, Billing Reason, Date)
					var row = '<tr id="cpf_labor" class="billing-items-grid-row cpf_labor_row ' + cpf_labor_row_class + '">\
							               <td class=" cpf_0-0"> <div class="quantity-column-readonly quantityData "><span class="'+ quantityValClass + '">' + quantity + '</span> ' + quantity_unit + '</div>' +
						// '<div class="' + classKey + '">' + $("#QtyDDSection").html() + '</div>' +
						'</td>' +
						'<td class=" cpf_0-1"><div class="item_number">' + prod_number + '</div><div class="item_description">' + name + '</div></td>\
						<td class="ext-price-labor numeric-column cpf_0-2"><div id="std-labor-price" class ="ext-price-col">$ ' + price + '</div></td>\
						<td class="billing-amount cpf_labor_row_bill_Amt">\
                         <div class="billing-amount-original-value-container-1 numeric-column cpf_0-3-0">\
							<div rownumber="' + rowCount + '" id="std-labor-billamount" class="billing-amount-original-value-link-1">\
                               $ ' + billing_amount +
						'</div></div>' +
						'</td>' +
						'<td class="billing-reason cpf_0-4">\
							<div id="' + billReasonOriginalValContainer + '" class="billing-reason-original-value-container cpf_0-4-0">' +
						billing_reason_title +
						'</div>' + //'<div class="'+ BillingReasonContainerclass +'">'+$("#billingReasonDDSection").html()+'</div>'+
						'</td>' +
						'<td class="scopeColumn"> <div class="cp_field_row"><select id="' + scopeValId + '" class="cp_field_dropdown_component form-item sa-account-billing-scope">' + $('#SABillingScopeOptions select').html() + '</select></div>' +
						'<div class="cp_field_row cp_hidden" style="margin-top: 5px;" id="' + partialOutOfScopeId + '">' +
						'<input type="text" name="hours" id="' + scopeValHourId + '" class="form-item" maxlength="5" style="width: 60px;padding: 0 4px">&nbsp;&nbsp;' + quantity_unit + '&nbsp;&nbsp;' +
						'<input type="button" id="' + applyButtonId + '" value="Apply" class="button" style="min-width: 49px;line-height: 30px;height: 30px; ">' +
						'</div><div class="cp_field_row cp_hidden" style="margin-top: 5px;" id="' + editButtonDivId + '"><input type="button" id="' + editButtonId + '" value="Edit" class="button" style="min-width: 49px;line-height: 30px;height: 30px; ">' +
						'</div>' +
						'</td>' +
						'<td class="overrideReasonColumn"><div class="cp_field_row"><select id="' + overrideReasonsId + '" class="cp_field_dropdown_component form-item cp_hidden sa-account-billing-override-reason">' + $('#SABillingReasons select').html() + '</select></div></td>' +
						'<td class="dateColumn">' + datefromXML + '</td>\
						</tr>';

					$('#activity_billing_grid').append(row);
					$("#cpf_labor").attr("disabled", "disabled");
					if (saAccountFlag) {
						$('#cpf_labor .partialOutScopeRow').hide();
						if ('Y' == saBilliedflag) {
							$('.' + cpf_labor_row_class).addClass('saBilliedflag');
							$('.' + cpf_labor_row_class).find('select').attr('disabled', true);
						}
					}
					$('#' + scopeValId).on('change', function (e) {
						var selectedOption = $('#' + scopeValId + ' option:selected').val();
						$('#' + overrideReasonsId).addClass('cp_hidden');
						if ('PARTIAL_OUT_OF_SCOPE' == selectedOption) {
							$('#' + partialOutOfScopeId).removeClass('cp_hidden');
						} else if ('OUT_SCOPE' == selectedOption) {
							$('#' + overrideReasonsId).removeClass('cp_hidden');
							$('#' + partialOutOfScopeId).addClass('cp_hidden');
						} else {
							$('#' + partialOutOfScopeId).addClass('cp_hidden');
						}
					}.bind(this));

					$('#' + applyButtonId).on('click', function (e) {
						var hour = $('#' + scopeValHourId).val();
						if ("" == hour || hour == null || 'undefined' == hour) {
							alert('Please enter Partial Out of scope time in ' + quantity_unit);
							return;
						}
						hour = parseFloat(hour).toFixed(2);
						if (hour >= quantity) {
							alert('Please enter Partial Out of scope time in ' + quantity_unit + ' less than the Orginal labor line');
							return;
						}
						var userInputQuanVal = parseFloat(hour).toFixed(2);
						var quantity1 = (quantity - userInputQuanVal).toFixed(2);
						$('.' + quantityValClass).html(quantity1);
						$('#' + editButtonDivId).removeClass('cp_hidden');
						$('#' + partialOutOfScopeId).addClass('cp_hidden');
						rowCount = rowCount + 1;
						var scopeValId1 = "scopeVallist" + rowCount;
						var overrideReasonsId1 = "overrideReasons" + rowCount;
						var cpf_labor_row_class1 = "cpf_labor_row_" + rowCount;
						var row = '<tr id="cpf_labor" data-partial-val="' + userInputQuanVal + '" class="partialOutOfScopeSelected billing-items-grid-row cpf_labor_row ' + cpf_labor_row_class1 + '">\
				               <td class=" cpf_0-0"> <div class="quantity-column-readonly quantityData ">' + userInputQuanVal + ' ' + quantity_unit + '</div>' +
							'</td>' +
							'<td class=" cpf_0-1"><div class="item_number">Out of Scope labor</div></td>\
							  <td class="ext-price-labor numeric-column cpf_0-2"></td>\
							  <td class="billing-amount cpf_labor_row_bill_Amt"></td>' +
							'<td class="billing-reason cpf_0-4"></td>' +
							'<td class="scopeColumn"> <div class="cp_field_row"><select id="' + scopeValId1 + '" class="cp_field_dropdown_component form-item sa-account-billing-scope">' + $('#SABillingScopeOptions select').html() + '</select></div>' +
							'</td>' +
							'<td class="overrideReasonColumn"><div class="cp_field_row"><select id="' + overrideReasonsId1 + '" class="cp_field_dropdown_component form-item sa-account-billing-override-reason">' + $('#SABillingReasons select').html() + '</select></div></td>' +
							'<td class="dateColumn">' + datefromXML + '</td>\
								</tr>';
						$(row).insertAfter('.' + cpf_labor_row_class);
						$('.' + cpf_labor_row_class).addClass('partialOutOfScopeSelected').attr('data-partial-val', userInputQuanVal);
						$('#activity_billing_grid td:nth-child(3)').hide();
						$('#activity_billing_grid td:nth-child(4)').hide();
						$('#activity_billing_grid td:nth-child(5)').hide();
						$('#' + scopeValId1).val('OUT_SCOPE').attr('disabled', true);
						$('#' + scopeValId).val('IN_SCOPE');

						$('#' + editButtonId).on('click', function (e) {
							$('#' + scopeValId).val('PARTIAL_OUT_OF_SCOPE');
							$('#' + editButtonDivId).addClass('cp_hidden');
							$('#' + partialOutOfScopeId).removeClass('cp_hidden');
							$('.' + cpf_labor_row_class1).remove();
							$('.' + quantityValClass).html(quantity);
							$('.' + cpf_labor_row_class).removeClass('partialOutOfScopeSelected').attr('data-partial-val', '');
						}.bind(this));
					}.bind(this));
				}); // End changes for CHG0069377-Service_Advantage_Billing



				// To get the total_labor row
				se_billing_info_xml.find('billingInfo').find('billingItems').find('total_labor').each(function () {
					var date = $(this).find("date").text();
					var quantity = totalLaborQty.toFixed(2); //$(this).find("quantity").text(); // Modified for CHG0069377-Service_Advantage_Billing
					if (isNaN(quantity)) {
						quantity = 1.00;
					}
					var quantity_unit = $(this).find("quantity_unit").text();
					//var prod_number = $(this).find("prod_number").text();
					var name = $(this).find("name").text();
					var price;
					if (!isNaN(totalLaborPrice)) {
						price = parseFloat(totalLaborPrice).toFixed(2); //$(this).find("billing_amount").text();
					} else {
						price = "0.00";
					}
					var isOverriden = $(this).find("is_overriden").text();
					var price_summ = $(this).find("price_summ").text();
					var billing_amount;
					if (!isNaN(totalLaborBillAmount)) {
						billing_amount = parseFloat(totalLaborBillAmount).toFixed(2); //$(this).find("billing_amount").text();
					} else {
						billing_amount = "0.00";
					}
					var billing_reason = $(this).find("billing_reason").text();
					var billing_reason_title = $(this).find("billing_reason_title").text();

					if (isOverriden == 'Y') {

						billing_amount = $(this).find("billing_amount").text();
					}
					rowCount += 1;
					var classBillingUndoKey = "BillingAmt_" + rowCount;
					var BillingReasonContainerclass = "BillingReasonContainer_" + rowCount
					var billAmtOrigValLink = "billing-amount-original-value-link-" + rowCount;
					var billReasonOriginalValContainer = "bill-reason-original-value-container-" + rowCount;


					var activityStyle = "";
					/*if(a_status != 'CM')
						{
						  activityStyle = 'style="border-bottom: none;cursor: text;"';
						}*/

					var row = '<tr id="cpf_total_labor" class="billing-items-grid-row cpf_total_labor_row">\
							               <td class=" cpf_0-0"> <div id="total_labor_qty" class="quantity-column-readonly cpf_quantity ">' + quantity + ' ' + quantity_unit + '</div>' +
						'</td>' +
						'<td class=" cpf_0-1"><b class="item_description">' + name + '</b></td>\
										   <td class="ext-price numeric-column cpf_0-2"><div id="total-labor-price" class="ext-price-col">$ ' + price + '</div></td>\
										   <td class="billing-amount cpf_total_labor_bill_amt">\
                                              <div class="billing-amount-original-value-container numeric-column cpf_0-3-0">\ ' ;
					//start of CHG0076155 Remove the ability for billing to be possible on auto install calls
					if (isIntallCall) {
						row = row + '<p rownumber="' + rowCount + /* '" id="' + billAmtOrigValLink + */ '" >\
												  $ 0'  +
							'</p>'
						row = row + '</div>' +
							'<td class="billing-reason cpf_0-4">\
		<div id="' + billReasonOriginalValContainer + '" class="billing-reason-original-value-container cpf_0-4-0">' + '</div>' +
							'<div class="' + BillingReasonContainerclass + '">' + $("#billingReasonDDSectionParts").html() + '</div>'
						'<td> <div class="dateColumn">' + /* datefromXML + */ '</div>'
						//<div class="pass_count_Column" style="display:none;">' + pass_count + '</div>'
						row = row + '</td>'
					}
					else {
						row = row +
							'<a rownumber="' + rowCount + '" id="' + billAmtOrigValLink + '" \
												   class="billing-amount-original-value-link total-labor-billamount" ' + activityStyle + '  >\
                                                  $ ' + billing_amount +
							'</a>'

						row = row + '</div>' +
							'<div class="' + classBillingUndoKey + '">' + $("#billingAmountUndoSection").html() + '</div>' +
							'</td>' +
							'<td class="billing-reason cpf_0-4">\
												   <div id="' + billReasonOriginalValContainer + '" class="billing-reason-original-value-container cpf_0-4-0">' +
							billing_reason_title +
							'</div>' +
							'<div class="' + BillingReasonContainerclass + '">' + $("#billingReasonDDSection").html() + '</div>'
					}
					row = row +
						//End of CHG0076155 Remove the ability for billing to be possible on auto install calls			  
						'</td>' +
						'<td class="scopeColumn"></td>' +
						'<td class="overrideReasonColumn"></td>' +
						'<td class="dateColumn"></td>\
										 </tr>';

					$('#activity_billing_grid').append(row);
					//Add the new Id for Billing Amount.
					var BillAmtUndoCol_rowData = "BillAmtUndoCol_" + rowCount;
					var billAmtUndoLink_row = "billAmtUndoLink_" + rowCount;
					var inner_overriden_val = "inner_overriden_val_" + rowCount;
					var BillingReasonContainer_Id = "billing_reason_container_" + rowCount;

					$("div." + classBillingUndoKey + " > div#billAmtOverriddenContainer").attr('id', BillAmtUndoCol_rowData);
					$("div." + classBillingUndoKey).find("a#billAmtUndoLink").attr('id', billAmtUndoLink_row);
					$("div." + classBillingUndoKey).find("input#cpf_inner_overriden_val").attr('id', inner_overriden_val);
					$("div." + BillingReasonContainerclass).find("div#billreason-overriden-container").attr('id', BillingReasonContainer_Id);

					var selectedText = billing_reason_title;
					$("#" + BillingReasonContainer_Id).find("select#cpf_billingReasonDDSection option").map(function () {
						if ($(this).text() == selectedText) return this;
					}).attr('selected', 'selected');

					$("#" + inner_overriden_val).val(billing_amount);

					/*  if (aContractFlag) {
  
						  $('div.' + BillingReasonContainerclass).find('select option[value=""]').attr("selected", true);
					  }*/
					$('#' + billAmtOrigValLink).on('click', function (e) {

						$("#" + billAmtOrigValLink).addClass("cp_hidden");
						$("#" + billReasonOriginalValContainer).addClass("cp_hidden");

						$("#" + BillAmtUndoCol_rowData).removeClass("cp_hidden");
						$("#" + BillingReasonContainer_Id).removeClass("cp_hidden");

						//copy over the billAmt to the input box.
						var undoAmtOrig = $('#' + billAmtOrigValLink).text();
						undoAmtOrig = undoAmtOrig.replace("$", "");
						undoAmtOrig = $.trim(undoAmtOrig);
						$("#" + BillAmtUndoCol_rowData).find('.cpf_input_overriden_val').val(parseFloat(undoAmtOrig).toFixed(2));
						// $("#"+BillAmtUndoCol_rowData).find('.cpf_input_overriden_val').val('99.00');
					}.bind(this));

					$('#' + billAmtUndoLink_row).on('click', function (e) {

						$("#" + billAmtOrigValLink).removeClass("cp_hidden");
						$("#" + billReasonOriginalValContainer).removeClass("cp_hidden");

						$("#" + BillAmtUndoCol_rowData).addClass("cp_hidden");
						$("#" + BillingReasonContainer_Id).addClass("cp_hidden");

						//set the billingamount back to the Original Value.

						var undoAmtOrig = $('#' + billAmtOrigValLink).text();
						undoAmtOrig = undoAmtOrig.replace("$", "");
						undoAmtOrig = $.trim(undoAmtOrig);
						$("#" + BillAmtUndoCol_rowData).find('.cpf_input_overriden_val').val(parseFloat(undoAmtOrig).toFixed(2));
						//Recalculate the total:
						$.recalculateBillAmountTotal();



					}.bind(this));

					// On change of the input values recalculate the column total
					// On change of the input values recalculate the column total
					$('#' + inner_overriden_val).on("change paste keyup", function () {
						var enteredVal = $(this).val();

						if (isNaN(enteredVal) || enteredVal.indexOf(' ') >= 0) {
							$(this).val("");
						}
						enteredVal = $(this).val();

						if (enteredVal >= 1000000) {
							alert("Value too large, Please adjust the value to be less than 999999.99");
							$(this).val(0.00);
						}
						$.recalculateBillAmountTotal();
					});
					//check if Overridden flag is set to true: if yes then apply the hiding logic, and display the editable col vals for bill Amt and bill.reason--
					if (isOverriden == 'Y') {
						$("#" + billAmtOrigValLink).addClass("cp_hidden");
						$("#" + billReasonOriginalValContainer).addClass("cp_hidden");

						$("#" + BillAmtUndoCol_rowData).removeClass("cp_hidden");
						$("#" + BillingReasonContainer_Id).removeClass("cp_hidden");
					}

				});
				//To generate the Parts section:

				se_billing_info_xml.find('billingInfo').find('billingItems').find('part').each(function () {
					var date = $(this).find("date").text();
					var quantity = $(this).find("quantity").text();
					//var quantity_unit = $(this).find("quantity_unit").text();
					var prod_number = $(this).find("prod_number").text();
					var name = $(this).find("name").text();
					var price = $(this).find("price").text();
					if (isNaN(price)) { price = 0; }
					var price_summ = $(this).find("price_summ").text();
					if (isNaN(price_summ)) { price_summ = 0; }
					var billing_amount = $(this).find("billing_amount").text();
					if (isNaN(billing_amount)) { billing_amount = 0; }
					var billing_reason = $(this).find("billing_reason").text();
					var billing_reason_title = $(this).find("billing_reason_title").text();
					var isOverriden = $(this).find("is_overriden").text();
					rowCount += 1;
					var classBillingUndoKey = "BillingAmt_" + rowCount;
					var BillingReasonContainerclass = "BillingReasonContainer_" + rowCount
					var billAmtOrigValLink = "billing-amount-original-value-link-" + rowCount;
					var billReasonOriginalValContainer = "bill-reason-original-value-container-" + rowCount;
					var priceAmtOrigValLink = "price-amount-original-value-link-" + rowCount;
					var datefromXML = $(this).find("date").text();
					var pass_count = $(this).find("pass_count").text();
					var subinventory = $(this).find("subinventory").text();
					var LockRow;
					var isPresent = $.inArray(prod_number, prevInstalled); //CHG0080567- OFSC MPF Group 2B Change

					// start of CHG0080567- OFSC MPF Group 2B Change
					if (isOverriden == 'D') {
						LockRow = true;
					}
					else {
						LockRow = false;
					}
					// end of CHG0080567- OFSC MPF Group 2B Change
					// new change for CHG0080567
					var row = '<tr id="cpf_parts" class="billing-items-grid-row cpf_parts_row">\
							               <td class=" cpf_0-0"> <div class="quantity-column-readonly cpf_quantity ">' + quantity + '</div>' + //$("#QtyDDSection").html()+
						'</td>' +
						'<td class=" cpf_0-1"><div class="item_number">' + prod_number + '</div><div class="item_description">' + name + '</div></td>\
										   <td class="ext-price numeric-column cpf_0-2"><div class="ext-price-col" id="' + priceAmtOrigValLink + '">$ ' + price_summ + '</div></td>\
										   <td class="billing-amount cpf_0-3">\
                                              <div class="billing-amount-original-value-container numeric-column cpf_0-3-0">\ ' ;

					//start of CHG0076155 Remove the ability for billing to be possible on auto install calls
					if (isIntallCall) {
						row = row + '<p rownumber="' + rowCount + /* '" id="' + billAmtOrigValLink + */ '" >\
												  $ 0' +
							'</p>'
						row = row + '</div>' +
							'<td class="billing-reason cpf_0-4">\
		<div id="' + billReasonOriginalValContainer + '" class="billing-reason-original-value-container cpf_0-4-0">' + '</div>' +
							'<div class="' + BillingReasonContainerclass + '">' + $("#billingReasonDDSectionParts").html() + '</div>'
						'<td> <div class="dateColumn">' + datefromXML + '</div>'
						//<div class="pass_count_Column" style="display:none;">' + pass_count + '</div>'
						row = row + '</td>'

					}

					else {
						row = row +
							'<a rownumber="' + rowCount + '" id="' + billAmtOrigValLink + '"class="billing-amount-original-value-link">\
                                                  $ ' + billing_amount +
							'</a>'
						row = row + '</div>' +
							'<div class="' + classBillingUndoKey + '">' + $("#billingAmountUndoSection").html() + '</div>' +
							'</td>' +
							'<td class="billing-reason cpf_0-4">\
												  <div id="' + billReasonOriginalValContainer + '" class="billing-reason-original-value-container cpf_0-4-0">' +
							billing_reason_title +
							'</div>' +
							'<div class="' + BillingReasonContainerclass + '">' + $("#billingReasonDDSectionParts").html() + '</div>'
					}
					row = row +
						//End of CHG0076155 Remove the ability for billing to be possible on auto install calls
						'</td>' +
						'<td class="scopeColumn"></td>' +
						'<td class="overrideReasonColumn"></td>' +
						'<td> <div class="dateColumn">' + datefromXML + '</div><div class="pass_count_Column" style="display:none;">' + pass_count + '</div><div class="subInventory" style="display:none;">' + subinventory + '</div></td>\
										 </tr>';

					$('#activity_billing_grid').append(row);
					//Add the new Id for Billing Amount.
					var BillAmtUndoCol_rowData = "BillAmtUndoCol_" + rowCount;
					var billAmtUndoLink_row = "billAmtUndoLink_" + rowCount;
					var inner_overriden_val = "inner_overriden_val_" + rowCount;
					var BillingReasonContainer_Id = "billing_reason_container_" + rowCount;

					$("div." + classBillingUndoKey + " > div#billAmtOverriddenContainer").attr('id', BillAmtUndoCol_rowData);
					$("div." + classBillingUndoKey).find("a#billAmtUndoLink").attr('id', billAmtUndoLink_row);
					$("div." + classBillingUndoKey).find("input#cpf_inner_overriden_val").attr('id', inner_overriden_val);
					$("div." + BillingReasonContainerclass).find("div#billreason-overriden-container-parts").attr('id', BillingReasonContainer_Id);

					var selectedText = billing_reason_title;
					$("#" + BillingReasonContainer_Id).find("select#cpf_billingReasonDDSectionParts option").map(function () {
						if ($(this).text() == selectedText) return this;
						if ($(this).val() == selectedText) return this;
					}).attr('selected', 'selected');

					$("#" + inner_overriden_val).val(billing_amount);
					$('#' + billAmtOrigValLink).on('click', function (e) {
						$("#" + billAmtOrigValLink).addClass("cp_hidden");
						$("#" + billReasonOriginalValContainer).addClass("cp_hidden");

						$("#" + BillAmtUndoCol_rowData).removeClass("cp_hidden");
						$("#" + BillingReasonContainer_Id).removeClass("cp_hidden");

						//copy over the Price/billAmt to the input box.
						var undoAmtOrig = $('#' + billAmtOrigValLink).text();
						undoAmtOrig = undoAmtOrig.replace("$", "");
						undoAmtOrig = $.trim(undoAmtOrig);
						$("#" + BillAmtUndoCol_rowData).find('.cpf_input_overriden_val').val(parseFloat(undoAmtOrig).toFixed(2));

					}.bind(this));

					$('#' + billAmtUndoLink_row).on('click', function (e) {


						$("#" + billAmtOrigValLink).removeClass("cp_hidden");
						$("#" + billReasonOriginalValContainer).removeClass("cp_hidden");

						$("#" + BillAmtUndoCol_rowData).addClass("cp_hidden");
						$("#" + BillingReasonContainer_Id).addClass("cp_hidden");

						//set the billingamount back to the Original Value.
						var undoAmt = $('#' + priceAmtOrigValLink).text();

						var undoAmtOrig = $('#' + billAmtOrigValLink).text();
						undoAmtOrig = undoAmtOrig.replace("$", "");
						undoAmtOrig = $.trim(undoAmtOrig);
						$("#" + BillAmtUndoCol_rowData).find('.cpf_input_overriden_val').val(parseFloat(undoAmtOrig).toFixed(2));
						let reason = $("#" + BillingReasonContainer_Id).find("select#cpf_billingReasonDDSectionParts option:selected").val();
						$.autoSetBillAmoutReason(prod_number, undoAmtOrig, reason, quantity, datefromXML); //CHG0083631 changes
						//Recalculate the total:
						$.recalculateBillAmountTotal();




					}.bind(this));

					// On change of the input values recalculate the column total

					$('#' + inner_overriden_val).on("change paste keyup", function () {
						try {
							var enteredVal = $(this).val();

							if (isNaN(enteredVal) || enteredVal.indexOf(' ') >= 0) {
								$(this).val("");
							}
							enteredVal = $(this).val();

							if (enteredVal >= 1000000) {
								alert("Value too large, Please adjust the value to be less than 999999.99");
								$(this).val(0.00);
							}
							else {
								let reason = $("#" + BillingReasonContainer_Id).find("select#cpf_billingReasonDDSectionParts option:selected").val();
								if (quantity > 0) {
									$.autoSetBillAmoutReason(prod_number, enteredVal, reason, quantity, datefromXML); //CHG0083631 changes
								}
							}
							// start of CHG0080567- OFSC MPF Group 2B Change
							$("#" + billAmtOrigValLink).removeClass("error");
							$(row).removeClass("error-highlited");


							// end of CHG0080567- OFSC MPF Group 2B Change
							$.recalculateBillAmountTotal();
						} catch (err) {
							activityLog = activityLog + ';Exception in inner_overriden_val:' + err.message;
							console.log(" Exception in inner_overriden_val :" + err.message);
						}
					});
					$("#" + BillingReasonContainer_Id).find("select#cpf_billingReasonDDSectionParts").on("change", function () {
						let reason = $("#" + BillingReasonContainer_Id).find("select#cpf_billingReasonDDSectionParts option:selected").val();
						var billAmt = $('#' + inner_overriden_val).val();
						if (quantity > 0) {
							$.autoSetBillAmoutReason(prod_number, billAmt, reason, quantity, datefromXML); //CHG0083631 changes
						}
					});

					//check if Overridden flag is set to true: if yes then apply the hiding logic, and display the editable col vals for bill Amt and bill.reason--
					// if (isOverriden == 'Y' && !LockRow) {
					//     $("#" + billAmtOrigValLink).addClass("cp_hidden");
					//     $("#" + billReasonOriginalValContainer).addClass("cp_hidden");

					//     $("#" + BillAmtUndoCol_rowData).removeClass("cp_hidden");
					//     $("#" + BillingReasonContainer_Id).removeClass("cp_hidden");
					// }
					// commented out as a part of CHG0083631 changes req#4
					if (LockRow) {
						$("#" + billAmtOrigValLink).css({ "border-bottom": "none", "pointer-events": "none" });
					}
					//Recalculate the total:
					$.recalculateBillAmountTotal();

				});
			}

			//To Generate the outbound expenses rows in the table.
			se_billing_info_xml.find('billingInfo').find('billingItems').find('expense').each(function () {
				var date = $(this).find("date").text();
				var quantity = $(this).find("quantity").text();
				//var quantity_unit = $(this).find("quantity_unit").text();

				var prod_number = $(this).find("prod_number").text();
				var name = $(this).find("name").text();
				var price = $(this).find("price").text();
				if (isNaN(price)) { price = 0; }
				var price_summ = $(this).find("price_summ").text();
				if (isNaN(price_summ)) { price_summ = 0; }
				var billing_amount = $(this).find("billing_amount").text();
				if (isNaN(billing_amount)) { billing_amount = 0; }
				var billing_reason = $(this).find("billing_reason").text();
				var billing_reason_title = $(this).find("billing_reason_title").text();
				var isOverriden = $(this).find("is_overriden").text();

				var expenseTypeInfo = $(this).find("expense_type").text();
				rowCount += 1;
				var expenseSection = "";
				var activityStyle = "";
				if (expenseTypeInfo == "reimbursable") {

					expenseSection = "reimbursable_expenses_type";

				} else if (expenseTypeInfo == "activities") {
					expenseSection = "activities_type";

				} else if (expenseTypeInfo == "service advantage chargeable activities") {
					expenseSection = "service_advantage_chargeable_activities_type";

				} else if (expenseTypeInfo == "condition based maintainance") { //CHG0067765 Condition Based Maintenance
					expenseSection = "cbm_activities_type";

				} else {
					expenseSection = "chargeable_activities_type";
				}
				if ((price != "na" || billing_amount != "na") && (price != "0" || billing_amount != "0") && (price > 0 || billing_amount != "")) {
					price = '$ ' + price;
					billing_amount = '$ ' + billing_amount;
				} else {
					activityStyle = 'style="border-bottom: none;pointer-events: none;"';
					price = 'na';
					billing_amount = 'na';
					isOverriden = 'N';
				}


				var classBillingUndoKey = "BillingAmt_" + rowCount;
				var BillingReasonContainerclass = "BillingReasonContainer_" + rowCount
				var billAmtOrigValLink = "billing-amount-original-value-link-" + rowCount;
				var priceAmtOrigValLink = "price-amount-original-value-link-" + rowCount;
				var billReasonOriginalValContainer = "bill-reason-original-value-container-" + rowCount;
				var datefromXML = $(this).find("date").text();
				var pass_count = $(this).find("pass_count").text();
				var LockRow;
				if (pass_count && pass_count < g_current_pass_count) {
					LockRow = true;
				} else {
					LockRow = false;
				}

				var row = '<tr id="cpf_expenses" class="billing-items-grid-row cpf_expenses_row">';

				if (expenseSection == "cbm_activities_type") {
					row += '<td class=" cpf_0-0"> <div class="quantity-column-readonly"><span class="cpf_quantity">' + quantity + '</span>&nbsp;<span>Mins</span></div></td>';
				} else {
					row += '<td class=" cpf_0-0"> <div class="quantity-column-readonly cpf_quantity ">' + quantity + '</div></td>';
				}
				row += '<td class=" cpf_0-1"><div class="item_number">' + prod_number + '</div><div class="item_description">' + name + '</div></td>\
										   <td class="ext-price numeric-column ext-price-col" id="' + priceAmtOrigValLink + '">' + price + '</td>\
										   <td class="billing-amount cpf_0-3">\
                                              <div class="billing-amount-original-value-container numeric-column cpf_0-3-0">\ ' ;
				//start of CHG0076155 Remove the ability for billing to be possible on auto install calls
				if (isIntallCall) {
					row = row +
						'<p rownumber="' + rowCount + /* '" id="' + billAmtOrigValLink + */ '" >\
												  $ 0' +
						'</p>'
					row = row + '</div>' +
						'<td class="billing-reason cpf_0-4">\
		<div id="' + billReasonOriginalValContainer + '" class="billing-reason-original-value-container cpf_0-4-0">' + '</div>' +
						'<div class="' + BillingReasonContainerclass + '">' + $("#billingReasonDDSectionParts").html() + '</div>'
					'<td> <div class="dateColumn">' + datefromXML + '</div>'
					//<div class="pass_count_Column" style="display:none;">' + pass_count + '</div>'
					row = row + '</td>'
				}
				else {
					row = row +
						'<a rownumber="' + rowCount + '" id="' + billAmtOrigValLink + '" class="billing-amount-original-value-link billAmtOrigVal" ' + activityStyle + '>\
                                                  ' + billing_amount +
						'</a>'
					row = row + '</div>' +
						'<div class="' + classBillingUndoKey + '">' + $("#billingAmountUndoSection").html() + '</div>' +
						'</td>' +
						'<td class="billing-reason cpf_0-4">\
												   <div id="' + billReasonOriginalValContainer + '" class="billing-reason-original-value-container cpf_0-4-0">' +
						billing_reason_title +
						'</div><div class="expenseSection cp_hidden">' + expenseSection + '</div> <div class="expenseTypeInfo cp_hidden">' + expenseTypeInfo + '</div>' +
						'<div class="' + BillingReasonContainerclass + '">' + $("#billingReasonDDSectionExpenses").html() + '</div>'
				}
				row = row +
					//End of CHG0076155 Remove the ability for billing to be possible on auto install calls
					'</td>' +
					'<td class="scopeColumn"></td>' +
					'<td class="overrideReasonColumn"></td>' +
					'<td> <div class="dateColumn">' + datefromXML + '</div><div class="pass_count_Column" style="display:none;">' + pass_count + '</div></td>\
										 </tr>';
				$('#activity_billing_grid').append(row);

				//Add the new Id for Billing Amount.
				var BillAmtUndoCol_rowData = "BillAmtUndoCol_" + rowCount;
				var billAmtUndoLink_row = "billAmtUndoLink_" + rowCount;
				var inner_overriden_val = "inner_overriden_val_" + rowCount;
				var BillingReasonContainer_Id = "billing_reason_container_" + rowCount;

				$("div." + classBillingUndoKey + " > div#billAmtOverriddenContainer").attr('id', BillAmtUndoCol_rowData);
				$("div." + classBillingUndoKey).find("a#billAmtUndoLink").attr('id', billAmtUndoLink_row);
				$("div." + classBillingUndoKey).find("input#cpf_inner_overriden_val").attr('id', inner_overriden_val);
				$("div." + BillingReasonContainerclass).find("div#billreason-overriden-container-expenses").attr('id', BillingReasonContainer_Id);

				var selectedText = billing_reason_title;
				$("#" + BillingReasonContainer_Id).find("select#cpf_billingReasonDDSectionExpenses option").map(function () {
					if ($(this).text() == selectedText) return this;
				}).attr('selected', 'selected');

				billing_amount = billing_amount.replace("$", "");
				billing_amount = $.trim(billing_amount);
				billing_amount = parseFloat(billing_amount).toFixed(2);
				$("#" + inner_overriden_val).val(billing_amount);

				/* if (!aContractFlag) {
					 //set the billing reason dropdown:
					 $('div.' + BillingReasonContainerclass).find('select option:contains("' + billing_reason + '")').prop('selected', true);
				 } else {
 
					 $('div.' + BillingReasonContainerclass).find('select option[value=""]').attr("selected", true);
				 }
				 */

				$('#' + billAmtOrigValLink).on('click', function (e) {
					try {
						$("#" + billAmtOrigValLink).addClass("cp_hidden");
						$("#" + billReasonOriginalValContainer).addClass("cp_hidden");

						$("#" + BillAmtUndoCol_rowData).removeClass("cp_hidden");
						$("#" + BillingReasonContainer_Id).removeClass("cp_hidden");

						//copy over the Price/billAmt to the input box.
						var undoAmtOrig = $('#' + billAmtOrigValLink).text();
						undoAmtOrig = undoAmtOrig.replace("$", "");
						undoAmtOrig = $.trim(undoAmtOrig);
						$("#" + BillAmtUndoCol_rowData).find('.cpf_input_overriden_val').val(parseFloat(undoAmtOrig).toFixed(2));
					} catch (err) {
						activityLog = activityLog + ';Exception in billAmtOrigValLink:' + err.message;
						console.log(" Exception in billAmtOrigValLink :" + err.message);
					}

				}.bind(this));

				$('#' + billAmtUndoLink_row).on('click', function (e) {
					try {
						$("#" + billAmtOrigValLink).removeClass("cp_hidden");
						$("#" + billReasonOriginalValContainer).removeClass("cp_hidden");

						$("#" + BillAmtUndoCol_rowData).addClass("cp_hidden");
						$("#" + BillingReasonContainer_Id).addClass("cp_hidden");


						var undoAmt = $('#' + priceAmtOrigValLink).text();
						undoAmt = undoAmt.replace("$", "");
						undoAmt = $.trim(undoAmt);
						undoAmt = parseFloat(undoAmt).toFixed(2);
						//set the billingamount back to the Original Value.

						var undoAmtOrig = $('#' + billAmtOrigValLink).text();
						undoAmtOrig = undoAmtOrig.replace("$", "");
						undoAmtOrig = $.trim(undoAmtOrig);
						$("#" + BillAmtUndoCol_rowData).find('.cpf_input_overriden_val').val(parseFloat(undoAmtOrig).toFixed(2));

						//Recalculate the total:
						$.recalculateBillAmountTotal();
					} catch (err) {
						activityLog = activityLog + ';Exception in billAmtUndoLink_row:' + err.message;
						console.log(" Exception in billAmtUndoLink_row :" + err.message);
					}

				}.bind(this));

				// On change of the input values recalculate the column total

				$('#' + inner_overriden_val).on("change paste keyup", function () {
					try {
						var enteredVal = $(this).val();

						if (isNaN(enteredVal) || enteredVal.indexOf(' ') >= 0) {
							$(this).val("");
						}
						enteredVal = $(this).val();

						if (enteredVal >= 1000000) {
							alert("Value too large, Please adjust the value to be less than 999999.99");
							$(this).val(0.00);
						}
						$.recalculateBillAmountTotal();
					} catch (err) {
						activityLog = activityLog + ';Exception in inner_overriden_val:' + err.message;
						console.log(" Exception in inner_overriden_val :" + err.message);
					}

				});

				//check if Overridden flag is set to true: if yes then apply the hiding logic, and display the editable col vals for bill Amt and bill.reason--
				if (isOverriden == 'Y' && !LockRow) {
					$("#" + billAmtOrigValLink).addClass("cp_hidden");
					$("#" + billReasonOriginalValContainer).addClass("cp_hidden");

					$("#" + BillAmtUndoCol_rowData).removeClass("cp_hidden");
					$("#" + BillingReasonContainer_Id).removeClass("cp_hidden");
				}

				if (LockRow) {
					$("#" + billAmtOrigValLink).css({ "border-bottom": "none", "pointer-events": "none" });
				}


			});

			if (se_billing_info_xml != null) {

				//To get the Material Handling Fee Row

				se_billing_info_xml.find('billingInfo').find('billingItems').find('material_handling_fee').each(function () {
					var date = $(this).find("date").text();
					var quantity = 1;
					var prod_number = $(this).find("prod_number").text();
					var name = $(this).find("name").text();
					var price = '0.00',
						price_summ = '0.00',
						billing_amount = '0.00';
					var isOverriden = $(this).find("is_overriden").text();

					if (totalLaborPrice > 25) {
						price = $(this).find("price").text();
						price_summ = $(this).find("price_summ").text();
						if (!aContractFlag) {
							billing_amount = price_summ;//$(this).find("billing_amount").text();
						}

					} else {
						price = '0.00';
						price_summ = '0.00';
						billing_amount = '0.00';
					}
					var billing_reason = $(this).find("billing_reason").text();
					var billing_reason_title = $(this).find("billing_reason_title").text();

					if (isOverriden == 'Y') {

						billing_amount = $(this).find("billing_amount").text();
					}

					rowCount += 1;
					var classBillingUndoKey = "BillingAmt_" + rowCount;
					var BillingReasonContainerclass = "BillingReasonContainer_" + rowCount
					var billAmtOrigValLink = "billing-amount-original-value-link-" + rowCount;
					var billReasonOriginalValContainer = "bill-reason-original-value-container-" + rowCount;
					var datefromXML = $(this).find("date").text();

					var activityStyle = "";

					var row = '<tr id="cpf_material" class="billing-items-grid-row cpf_material_row">\
							               <td class=" cpf_0-0"> <div class="quantity-column-readonly cpf_quantity ">' + quantity + '</div>' + //$("#QtyDDSection").html()+
						'</td>' +
						'<td class=" cpf_0-1"><div class="item_number">' + prod_number + '</div><div class="item_description">' + name + '</div></td>\
										   <td id="materialHandlingPrice" class="ext-price numeric-column ext-price-col">$ ' + price_summ + '</td>\
										   <td class="billing-amount cpf_0-3 materialHandlingRow">\
                                              <div class="billing-amount-original-value-container numeric-column cpf_0-3-0">\ ' ;
					//start of CHG0076155 Remove the ability for billing to be possible on auto install calls
					if (isIntallCall) {
						row = row + '<p rownumber="' + rowCount + /* '" id="' + billAmtOrigValLink + */ '" >\
												  $ 0' +
							'</p>'
						row = row + '</div>' +
							'<td class="billing-reason cpf_0-4">\
		<div id="' + billReasonOriginalValContainer + '" class="billing-reason-original-value-container cpf_0-4-0">' + '</div>' +
							'<div class="' + BillingReasonContainerclass + '">' + $("#billingReasonDDSectionParts").html() + '</div>'
						'<td> <div class="dateColumn">' + datefromXML + '</div>'
						//<div class="pass_count_Column" style="display:none;">' + pass_count + '</div>'
						row = row + '</td>'
					}

					//  start CHG0084485
					else if (g_showMaterialRow) {
						var today = new Date()
						let day = today.getDate();
						let month = today.getMonth();
						let year = today.getFullYear();
						let currentDate = `${day}-${month}-${year}`;
						console.log(currentDate);
						if ((aContractFlag == "false" || aContractCoverage == "Chargeable" || aContractCoverage < currentDate) && (totalLaborBillAmount > 0 || totalLaborBillAmount == undefined)) {
							row = row + '<p rownumber="' + rowCount + /*  '" id="' + billAmtOrigValLink +  */ '"class="billing-amount-original-value-link_material materialHandlingBillAmt"  ' /* + activityStyle */ + '>\
												  $ ' + billing_amount +
								'</p>'

							row = row + '</div>' +
								/* '<td class="' + classBillingUndoKey + '">' + '</div>' $("#billingAmountUndoSection").html() + '</div>'  + */
								'</td>' +
								'<td class="billing-reason cpf_0-4">\
		<div id="' + billReasonOriginalValContainer + '" class="billing-reason-original-value-container cpf_0-4-0">' + billing_reason_title + '</div>' +
								'<div class="' + BillingReasonContainerclass + '">' + $("#billingReasonDDSection").html() + '</div>'
							'<td> <div class="dateColumn">' + datefromXML + '</div>'
							//<div class="pass_count_Column" style="display:none;">' + pass_count + '</div>'
							row = row + '</td>'
						}
					}
					//  end CHG0084485

					else {
						row = row +
							'<a rownumber="' + rowCount + '" id="' + billAmtOrigValLink + '" class="billing-amount-original-value-link materialHandlingBillAmt"  ' + activityStyle + '>\
                                                  $ ' + billing_amount +
							'</a>'
						row = row + '</div>' +
							'<div class="' + classBillingUndoKey + '">' + $("#billingAmountUndoSection").html() + '</div>' +
							'</td>' +
							'<td class="billing-reason cpf_0-4">\
												 <div id="' + billReasonOriginalValContainer + '" class="billing-reason-original-value-container cpf_0-4-0">' +
							billing_reason_title +
							'</div>' +
							'<div class="' + BillingReasonContainerclass + '">' + $("#billingReasonDDSection").html() + '</div>'
					}
					row = row +
						//End of CHG0076155 Remove the ability for billing to be possible on auto install calls
						'</td>' +
						'<td class="scopeColumn"></td>' +
						'<td class="overrideReasonColumn"></td>' +
						'<td class="dateColumn">' + datefromXML + '</td>\
										 </tr>';

					$('#activity_billing_grid').append(row);
					//Add the new Id for Billing Amount.
					var BillAmtUndoCol_rowData = "BillAmtUndoCol_" + rowCount;
					var billAmtUndoLink_row = "billAmtUndoLink_" + rowCount;
					var inner_overriden_val = "inner_overriden_val_" + rowCount;
					var BillingReasonContainer_Id = "billing_reason_container_" + rowCount;

					$("div." + classBillingUndoKey + " > div#billAmtOverriddenContainer").attr('id', BillAmtUndoCol_rowData);
					$("div." + classBillingUndoKey).find("a#billAmtUndoLink").attr('id', billAmtUndoLink_row);
					$("div." + classBillingUndoKey).find("input#cpf_inner_overriden_val").attr('id', inner_overriden_val);
					$("div." + BillingReasonContainerclass).find("div#billreason-overriden-container").attr('id', BillingReasonContainer_Id);

					var selectedText = billing_reason_title;
					$("#" + BillingReasonContainer_Id).find("select#cpf_billingReasonDDSection option").map(function () {
						if ($(this).text() == selectedText) return this;
					}).attr('selected', 'selected');

					$("#" + inner_overriden_val).val(billing_amount);


					$('#' + billAmtOrigValLink).on('click', function (e) {

						$("#" + billAmtOrigValLink).addClass("cp_hidden");
						$("#" + billReasonOriginalValContainer).addClass("cp_hidden");

						$("#" + BillAmtUndoCol_rowData).removeClass("cp_hidden");
						$("#" + BillingReasonContainer_Id).removeClass("cp_hidden");

						//copy over the billAmt to the input box.
						var undoAmtOrig = $('#' + billAmtOrigValLink).text();
						undoAmtOrig = undoAmtOrig.replace("$", "");
						undoAmtOrig = $.trim(undoAmtOrig);
						$("#" + BillAmtUndoCol_rowData).find('.cpf_input_overriden_val').val(parseFloat(undoAmtOrig).toFixed(2));

					}.bind(this));

					$('#' + billAmtUndoLink_row).on('click', function (e) {

						$("#" + billAmtOrigValLink).removeClass("cp_hidden");
						$("#" + billReasonOriginalValContainer).removeClass("cp_hidden");

						$("#" + BillAmtUndoCol_rowData).addClass("cp_hidden");
						$("#" + BillingReasonContainer_Id).addClass("cp_hidden");

						//set the billingamount back to the Original Value.

						var undoAmtOrig = $('#' + billAmtOrigValLink).text();
						undoAmtOrig = undoAmtOrig.replace("$", "");
						undoAmtOrig = $.trim(undoAmtOrig);
						$("#" + BillAmtUndoCol_rowData).find('.cpf_input_overriden_val').val(parseFloat(undoAmtOrig).toFixed(2));
						//Recalculate the total:
						$.recalculateBillAmountTotal();

					}.bind(this));

					// On change of the input values recalculate the column total
					$('#' + inner_overriden_val).on("change paste keyup", function () {
						var enteredVal = $(this).val();
						if (isNaN(enteredVal) || enteredVal.indexOf(' ') >= 0) {
							$(this).val("");
						}
						enteredVal = $(this).val();

						if (enteredVal >= 1000000) {
							alert("Value too large, Please adjust the value to be less than 999999.99");
							$(this).val(0.00);
						}
						$.recalculateBillAmountTotal();
					});

					if (isOverriden == 'Y') {
						$("#" + billAmtOrigValLink).addClass("cp_hidden");
						$("#" + billReasonOriginalValContainer).addClass("cp_hidden");

						$("#" + BillAmtUndoCol_rowData).removeClass("cp_hidden");
						$("#" + BillingReasonContainer_Id).removeClass("cp_hidden");
					}

				});
			}
			//Generate the total rows:
			var extOverPrice = 0;
			var billingAmt = 0;
			$('table tr.billing-items-grid-row').each(function () {

				$(this).find('.ext-price').each(function () {
					var extOverP = $(this).text();
					extOverP = extOverP.replace("$", "");
					extOverP = $.trim(extOverP);
					extOverP = parseFloat(extOverP);
					if (!isNaN(extOverP) && extOverP.length !== 0) {
						extOverPrice += extOverP;
					}
				});

				// start CHG0084485
				$(this).find('.billing-amount-original-value-link_material').each(function () {
					var billAmt = $(this).text();
					billAmt = billAmt.replace("$", "");
					billAmt = $.trim(billAmt);
					billAmt = parseFloat(billAmt);
					if (!isNaN(billAmt) && billAmt.length !== 0) {
						billingAmt += billAmt;
					}
				});

				//end  CHG0084485


				$(this).find('.billing-amount-original-value-link').each(function () {
					var billAmt = $(this).text();
					billAmt = billAmt.replace("$", "");
					billAmt = $.trim(billAmt);
					billAmt = parseFloat(billAmt);
					if (!isNaN(billAmt) && billAmt.length !== 0) {
						billingAmt += billAmt;
					}
				});
			});
			var ext_price_total = extOverPrice.toFixed(2);
			var billAmt_total = billingAmt.toFixed(2);
			var total_rowLast = '<tr id="cpf__unnamed_29_footer" class="billing-items-grid-footer">\
						                         <td class=" cpf_1-0" style=""></td>\
												 <td class="billing-items-grid-footer-title cpf_1-1" style="">Total excluding Taxes</td>\
												 <td id = "ext_price_Total" class="ext_price_total numeric-column cpf_1-2" style="">$ ' + ext_price_total + '</td>\
												 <td class="billAmt_total numeric-column cpf_1-3" style="">$ ' + billAmt_total + '</td>\
												 <td class="scopeColumn"></td>\
							                     <td class="overrideReasonColumn"></td>\
												 <td colspan="2" class=" cpf_1-4" style=""></td>\
												 </tr>';
			$('#activity_billing_grid').append(total_rowLast);

			// Update the total excluding the taxes.
			$("#cpf_TotalExcludingTaxes_inner").text("$ " + billAmt_total);

			//DocuSign changes Start CHG0066144
			if (billAmt_total > 0) {
				$("#serviceEmail").prop('checked', true);
				$("#mandatryEmail").removeClass("cp_hidden");
			}
			//Docusign changes End CHG0066144

			//View term checked:
			$("#cpf_viewTerms_Check ").change(function () {
				if (this.checked) {
					$("#termsAndConditions").removeClass("cp_hidden");
				} else {
					$("#termsAndConditions").addClass("cp_hidden");
				}
			});

			//CHG0060060 -Based on Email Service Ticket checkbox selection making contact email filed as mandatory
			$("#serviceEmail").change(function () {
				if (this.checked) {
					$("#mandatryEmail").removeClass("cp_hidden");
					$("#docuSignEmail").prop("disabled", true); // CHG0076924 start- if serviceEmail is checked disabling docuSignEmail
				} else {
					$("#mandatryEmail").addClass("cp_hidden");
					$("#docuSignEmail").prop("disabled", false); // CHG0076924 if serviceEmail is uncheked enabling docuSignEmail
				}

			});

			//---------------------------------------------------------------------
			//---------------- start changes by Girish -CHG0064490----------------------------

			//changes done for DOcuSign CHG0066144
			$("#docuSignEmail").change(function () {
				if (this.checked) {
					$("#mandatryEmail").removeClass("cp_hidden");
					$("#signature").signature('clear');
					$("canvas").addClass("cp_hidden"); //CHG0083631
					$("#signature").prop('disabled', true);
					$("#serviceEmail").prop("disabled", true); // CHG0076924 if docuSignEmail is checked disabling serviceEmail
				} else {
					$("#mandatryEmail").addClass("cp_hidden");
					$("#signature").signature('clear');
					$("canvas").removeClass("cp_hidden"); //CHG0083631
					$("#signature").prop('disabled', false);
					$("#serviceEmail").prop("disabled", false); // CHG0076924 end- if docuSignEmail is uncheked enabling serviceEmail
				}

			});
			$("#ccEmails").focusin(function () {
				$("#ccemailadd").removeClass("cp_hidden");
			});
			$("#ccEmails").focusout(function () {
				$("#ccemailadd").addClass("cp_hidden");
			});
			//Changes end for Docusign CHG0066144
			var hcFlag = receivedData.activity.A_HC_FLAG;

			if (hcFlag && hcFlag == 'Y') {
				hcFlag = true;
			} else {
				hcFlag = false;
			}

			if (hcFlag || saAccountFlag) {		// Added condition for CHG0069377-Service_Advantage_Billing
				if (hcFlag) {
					$("#hcFlag").val("Y");
				}

				//hide notes and signature blocks for technician view
				$('.temp').each(function () {
					if ($(this).css('display') == 'block') {
						$(this).addClass("cp_hidden");
					}
				});

				//hide original action buttons block 
				$('.submit-line-links').each(function () {
					if ($(this).css('display') == 'block') {
						$(this).addClass("cp_hidden");
					}
				});

				//make technician view action button block visible
				$("#techReview").removeClass("cp_hidden");

			} else {
				if (!hcFlag) { // Aded condition for CHG0069377-Service_Advantage_Billing
					$("#hcFlag").val("N");
				}
			}

			// Start changes for CHG0069377-Service_Advantage_Billing
			// Hide the in scope & override reason rows for all scenarios initially 
			$('#activity_billing_grid td:nth-child(6)').hide();
			$('#activity_billing_grid td:nth-child(7)').hide();
			if (saAccountFlag) {
				$('#cpf_labor #std-labor-price, #cpf_labor #std-labor-billamount, #cpf_total_labor #total-labor-price, #cpf_total_labor .cpf_total_labor_bill_amt, #cpf_total_labor .billing-reason-original-value-container, #cpf_total_labor #cpf_billingReasonDDSection').hide();//html('');
			} // End condition for CHG0069377-Service_Advantage_Billing

			//----------------------------------------------------------------------------
			$("#customerViewBtn").click(function () {
				var blnHC = $("#hcFlag").val();
				if (blnHC && blnHC == 'Y') {
					blnHC = true;
				} else {
					blnHC = false;
				}

				if (blnHC || saAccountFlag) { // Modifed to add SA Account Flag for CHG0069377-Service_Advantage_Billing
					//display notes and signature blocks for customer view
					$('.temp').each(function () {
						if ($(this).css('display') != 'block') {
							$(this).removeClass("cp_hidden");
						}
					});

					$("#custReview").removeClass("cp_hidden");

					$('#activity_billing_grid td:nth-child(3)').hide();
					$('#activity_billing_grid td:nth-child(4)').hide();
					$('#activity_billing_grid td:nth-child(5)').hide();
					$('.billing-items-grid-footer').hide();
					$('#cpf_TotalExcludingTaxes').hide();
				}
				// Added below condition for CHG0069377-Service_Advantage_Billing
				if (saAccountFlag) {
					$('#activity_billing_grid td:nth-child(6)').show();
					$('#activity_billing_grid td:nth-child(7)').show();
				}

				$("#techReview").addClass("cp_hidden");

			}.bind(this));
			//----------------------------------------------------------------------------			
			$("#techViewBtn").click(function () {
				var blnHC = $("#hcFlag").val();
				if (blnHC && blnHC == 'Y') {
					blnHC = true;
				} else {
					blnHC = false;
				}

				if (blnHC || saAccountFlag) { // Modified to add sa account flag for CHG0069377-Service_Advantage_Billing
					//hide notes and signature blocks for technician view
					$('.temp').each(function () {
						if ($(this).css('display') == 'block') {
							$(this).addClass("cp_hidden");
						}
					});

					$("#techReview").removeClass("cp_hidden");
					$("#custReview").addClass("cp_hidden");

					$('#activity_billing_grid td:nth-child(3)').show();
					$('#activity_billing_grid td:nth-child(4)').show();
					$('#activity_billing_grid td:nth-child(5)').show();
					$('.billing-items-grid-footer').show();
					$('#cpf_TotalExcludingTaxes').show();
				}
				// Added below condition for CHG0069377-Service_Advantage_Billing
				if (saAccountFlag) {
					$('#activity_billing_grid td:nth-child(6)').hide();
					$('#activity_billing_grid td:nth-child(7)').hide();
				}
			}.bind(this));

			$('#cancelBtn1').click(function () {

				this._sendPostMessageData({
					"apiVersion": 1,
					"method": "close",
					"backScreen": "default",
					"wakeupNeeded": false

				});
			}.bind(this));
			//---------------- end changes by Girish CHG0064490------------------------------
			//---------------------------------------------------------------------
			// Start changes for CHG0069377-Service_Advantage_Billing
			//Prevent EST Flag changes - CHG0070958
			if (preventEST) {
				if ($("#serviceEmail").is(':checked')) {
					$("#serviceEmail").prop('checked', false);
					$("#mandatryEmail").removeClass("cp_hidden");
				}
				$('#cpf_SigneeNameNEmail input').each(function () {
					$(this).prop('disabled', true);
				});
			} // End chagnes for CHG0069377-Service_Advantage_Billing



			Array.prototype.remove = function (x) {
				var i;
				for (i in this) {
					if (this[i].partNum.toString() == x.toString()) {
						this.splice(i, 1);
						return;
					}
				}
			}
			//Submit Button Function:
			$('.submit').click(function () {
				try {
					// var installed_parts_details = installed_parts_details_first; //CHG0080567- OFSC MPF Group 2B Change
					var installed_parts_details = ''; // change for CHG0083631
					var all_parts_details = ""; // CHG0080567- OFSC MPF Group 2B Change
					//Process the labor row
					var $se_billing_info_firstLoadXml = $('<XMLDocument />');

					var $se_billing_info_billInfo = $.createElement('billingInfo');
					var $se_billing_info_billItems = $.createElement('billingItems');

					var aSETotalExpenses = 0; // total of bill amount of expenses.
					var aSETotalParts = 0; // total of bill amount of Parts.
					var aSETotalLabour = 0;
					var aSETotal = 0; // Total
					var aBillingReason = ""; //A_BILLING_REASON : aBillingReason
					var aLabourOverridePrice = null;//A_LABOR_OVERRIDE_PRICE : aLabourOverridePrice
					var aMaterialFeeOverride = null;// A_MATERIAL_FEE_OVERRIDE : aMaterialFeeOverride
					var aMaterialFeeOverrideReason = null;// A_MATERIAL_FEE_OVERRIDE_REASON : aMaterialFeeOverrideReason, //Added for CHG0060060
					var strEmailServiceTckt = 'N';
					var strSignaturebyEmail = 'N'; //A_EMAIL_SERVICE_TICKET : strEmailServiceTckt; //Added for CHG0060060

					// CHG0079805 Change starts
					var problem_work_performed = $("#probWorkPerformed").val();
					if (problem_work_performed.length < 4) {
						console.log("problem_work_performed :" + problem_work_performed.length);
						alert("Please provide an explanation of the work performed.");
						return;
					}
					var laborCompleteComment = receivedData.activity.A_LABOR_COMPLETE_COMMENTS;
					var combinedComents = "";
					if (laborCompleteComment == null) {
						combinedComents = problem_work_performed;
					} else {
						combinedComents = laborCompleteComment + " " + problem_work_performed;
					}
					// CHG0079805 Change ends

					var $seExpensesPluginXml = $('<XMLDocument />');

					var proceedWithRest = true;
					var saLaborLines = '<DebriefTask>'; // Added for CHG0069377-Service_Advantage_Billing
					$('table tr.cpf_labor_row').each(function () {
						//alert("Inside bill items grid");
						/*  var selectedValue = $(this).find('.cpf_quantitydropdown').val();
						  var quantity = parseFloat(selectedValue).toFixed(2);
						  var selectedText = $(this).find('.cpf_quantitydropdown option:selected').text();*/
						var quantityData = $(this).find('.quantityData').text();
						quantityData = quantityData.replace("hrs", "");
						quantityData = quantityData.replace(" ", "");
						quantityData = $.trim(quantityData);
						var quantity = parseFloat(quantityData).toFixed(2);

						var prod_number = $(this).find('.item_number').text();
						var prod_description = $(this).find('.item_description').text();
						var ext_price_col = $(this).find('.ext-price-col').text();
						ext_price_col = ext_price_col.replace("$", "");
						ext_price_col = $.trim(ext_price_col);
						ext_price_col = parseFloat(ext_price_col).toFixed(2);

						var overridenPrice = $(this).find('#std-labor-billamount').text();
						overridenPrice = overridenPrice.replace("$", "");
						overridenPrice = $.trim(overridenPrice);
						if (overridenPrice == "") {
							overridenPrice = 0;
						} else {
							overridenPrice = parseFloat(overridenPrice).toFixed(2);
						}
						var selectedBillReasonCode = $(this).find('.billreasondropdown').val();
						var selectedBillReasonDesc = $(this).find('.billreasondropdown option:selected').text();
						// Start changes for CHG0069377-Service_Advantage_Billing
						var billingScope = $(this).find('.sa-account-billing-scope option:selected').val();
						var billingOverrideReason = $(this).find('.sa-account-billing-override-reason option:selected').val();
						if ('OUT_SCOPE' == billingScope && (billingOverrideReason == null || "" == billingOverrideReason
							|| 'undefined' == billingOverrideReason)) {
							$(this).addClass("error-highlited");
							alert("Override reason is not specified.");
							proceedWithRest = false;
							return false;
						}

						if ('PARTIAL_OUT_OF_SCOPE' == billingScope) {
							$(this).addClass("error-highlited");
							alert("Please enter / apply the partial out of scope labor hrs.");
							proceedWithRest = false;
							return false;
						}

						var dateCol = $(this).find('.dateColumn').text();

						if (!$(this).hasClass('saBilliedflag') && saAccountFlag) {
							saLaborLines += "<DebriefTasks>";
							var startDateofBilling = '';
							var endDateofBilling = '';
							if ($(this).hasClass('partialOutOfScopeSelected')) {
								var scopeTime = '';
								if (receivedData.activity.A_START_TIME_OVERRIDE && receivedData.activity.A_START_TIME_OVERRIDE != null) {
									startDateofBilling = receivedData.activity.A_START_TIME_OVERRIDE
								} else {
									startDateofBilling = receivedData.activity.A_START_TIME;
								}
								if (aScanOutTimeOverride && aScanOutTimeOverride != null && "" != aScanOutTimeOverride) {
									endDateofBilling = aScanOutTimeOverride;
								} else {
									endDateofBilling = aScanOutTime;
								}
								scopeTime = $(this).attr('data-partial-val');
								var scopeValArr = scopeTime.split('\.');
								var mins = "";
								if (scopeValArr[1] != 0 && scopeValArr[1] != undefined) {
									mins = (parseFloat(scopeValArr[1]) / 100) * 60;
								} else {
									mins = 0;
								}
								mins = mins.toFixed(2);
								if (scopeValArr[0] > 0) {
									mins += (parseInt(scopeValArr[0]) * 60);
								}
								if ('IN_SCOPE' == billingScope) {
									var inScopeEndDate = new Date(endDateofBilling);
									var MS_PER_MINUTE = 60000;
									var myStartDate = new Date(inScopeEndDate - mins * MS_PER_MINUTE);

									endDateofBilling = myStartDate.getFullYear() + '-' + $parentThis._checkSingleDigit(myStartDate.getMonth() + 1) + '-' + $parentThis._checkSingleDigit(myStartDate.getDate())
										+ 'T' + $parentThis._checkSingleDigit(myStartDate.getHours()) + ':' + $parentThis._checkSingleDigit(myStartDate.getMinutes()) + ":" + $parentThis._checkSingleDigit(myStartDate.getSeconds());
									if (receivedData.activity.A_DISPATCH_TIME_OVERRIDE && receivedData.activity.A_DISPATCH_TIME_OVERRIDE != null) {
										saLaborLines += "<DISPATCH_TIME>" + $parentThis._checkNull(receivedData.activity.A_DISPATCH_TIME_OVERRIDE) + "</DISPATCH_TIME>";
									} else {
										saLaborLines += "<DISPATCH_TIME>" + $parentThis._checkNull(receivedData.activity.A_DISPATCH_TIME) + "</DISPATCH_TIME>";
									}
									saLaborLines += "<activity_start_time>" + startDateofBilling + "</activity_start_time>";
									saLaborLines += "<activity_end_time>" + endDateofBilling + "</activity_end_time>";
								} else if ('OUT_SCOPE' == billingScope) {
									var inScopeEndDate = new Date(endDateofBilling);
									var MS_PER_MINUTE = 60000;
									var myStartDate = new Date(inScopeEndDate - mins * MS_PER_MINUTE);
									startDateofBilling = myStartDate.getFullYear() + '-' + $parentThis._checkSingleDigit(myStartDate.getMonth() + 1) + '-' + $parentThis._checkSingleDigit(myStartDate.getDate())
										+ 'T' + $parentThis._checkSingleDigit(myStartDate.getHours()) + ':' + $parentThis._checkSingleDigit(myStartDate.getMinutes()) + ":" + $parentThis._checkSingleDigit(myStartDate.getSeconds());
									saLaborLines += "<DISPATCH_TIME>" + startDateofBilling + "</DISPATCH_TIME>";
									saLaborLines += "<activity_start_time>" + startDateofBilling + "</activity_start_time>";
									saLaborLines += "<activity_end_time>" + endDateofBilling + "</activity_end_time>";
								}

							} else {
								if (receivedData.activity.A_DISPATCH_TIME_OVERRIDE && receivedData.activity.A_DISPATCH_TIME_OVERRIDE != null) {
									saLaborLines += "<DISPATCH_TIME>" + $parentThis._checkNull(receivedData.activity.A_DISPATCH_TIME_OVERRIDE) + "</DISPATCH_TIME>";
								} else {
									saLaborLines += "<DISPATCH_TIME>" + $parentThis._checkNull(receivedData.activity.A_DISPATCH_TIME) + "</DISPATCH_TIME>";
								}
								if (receivedData.activity.A_START_TIME_OVERRIDE && receivedData.activity.A_START_TIME_OVERRIDE != null) {
									saLaborLines += "<activity_start_time>" + $parentThis._checkNull(receivedData.activity.A_START_TIME_OVERRIDE) + "</activity_start_time>";
								} else {
									saLaborLines += "<activity_start_time>" + $parentThis._checkNull(receivedData.activity.A_START_TIME) + "</activity_start_time>";
								}
								if (aScanOutTimeOverride && aScanOutTimeOverride != null && "" != aScanOutTimeOverride) {
									saLaborLines += "<activity_end_time>" + $parentThis._checkNull(aScanOutTimeOverride) + "</activity_end_time>";
								} else {
									saLaborLines += "<activity_end_time>" + $parentThis._checkNull(aScanOutTime) + "</activity_end_time>";
								}
							}

							saLaborLines += "<A_SCOPE>" + $parentThis._checkNull(billingScope) + "</A_SCOPE>";
							if ('OUT_SCOPE' == billingScope) {
								saLaborLines += "<A_LABOR_OVERRIDE_REASON_CODE>" + $parentThis._checkNull(billingOverrideReason) + "</A_LABOR_OVERRIDE_REASON_CODE>";
							}

							// CHG0079805 Change Starts
							var combinedCommentsVal = "";
							if (receivedData.activity.A_COMBINED_COMMENTS != null) {
								combinedCommentsVal = $parentThis._checkNull(receivedData.activity.A_COMBINED_COMMENTS);
							} else {
								combinedCommentsVal = combinedComents;
							}
							// CHG0079805 Change Ends

							saLaborLines += "<A_START_MILEAGE>" + $parentThis._checkNull(receivedData.activity.A_ODOMETER_START) + "</A_START_MILEAGE>";
							saLaborLines += "<A_END_MILEAGE>" + $parentThis._checkNull(receivedData.activity.A_ODOMETER_END) + "</A_END_MILEAGE>";
							saLaborLines += "<A_CONNECTED_FLAG>" + $parentThis._checkNull(receivedData.activity.A_EQUIPMENT_CONNECTED) + "</A_CONNECTED_FLAG>";
							saLaborLines += "<A_RESOLUTION_CODE>" + $parentThis._checkNull(receivedData.activity.A_RESOLUTION_CODE) + "</A_RESOLUTION_CODE>";
							saLaborLines += "<A_LABOR_SUMMARY>" + combinedCommentsVal + "</A_LABOR_SUMMARY>";
							saLaborLines += "<A_AFTER_HRS_FLAG>" + $parentThis._checkNull(receivedData.activity.A_AFTERHOURS_FLAG) + "</A_AFTER_HRS_FLAG>";
							if (receivedData.activity.A_METER_RECONFIG && receivedData.activity.A_METER_RECONFIG != null) {
								saLaborLines += "<A_RECONFIG>" + $parentThis._checkNull(receivedData.activity.date) + "</A_RECONFIG>";
							}
							saLaborLines += "<A_SERVICE_LEVEL>" + $parentThis._checkNull(receivedData.activity.A_SERVICE_LEVEL) + "</A_SERVICE_LEVEL>";
							saLaborLines += "<SCALT><A_SCALT_TYPE>Symptom</A_SCALT_TYPE><A_SCALT_CODE>" + $parentThis._checkNull(receivedData.activity.A_SYMPTOM_MINOR)
								+ $parentThis._checkNull(receivedData.activity.A_SYMPTOM_ADD_1)
								+ $parentThis._checkNull(receivedData.activity.A_SYMPTOM_ADD_2) + "</A_SCALT_CODE><A_SCALT_COMMENTS>"
								+ $parentThis._checkNull(receivedData.activity.A_SYMPTOM_COMMENT) + "</A_SCALT_COMMENTS></SCALT>";
							saLaborLines += "<SCALT><A_SCALT_TYPE>Cause</A_SCALT_TYPE><A_SCALT_CODE>" + $parentThis._checkNull(receivedData.activity.A_CAUSE_MINOR) + "</A_SCALT_CODE></SCALT>";
							saLaborLines += "<SCALT><A_SCALT_TYPE>Action</A_SCALT_TYPE><A_SCALT_CODE>" + $parentThis._checkNull(receivedData.activity.A_ACTION_MINOR) + "</A_SCALT_CODE></SCALT>";
							saLaborLines += "<SCALT><A_SCALT_TYPE>Location</A_SCALT_TYPE><A_SCALT_CODE>" + $parentThis._checkNull(receivedData.activity.A_LOCATION_MINOR) + "</A_SCALT_CODE></SCALT>";
							saLaborLines += "<SCALT><A_SCALT_TYPE>Target</A_SCALT_TYPE><A_SCALT_CODE>" + $parentThis._checkNull(receivedData.activity.A_TARGET_MINOR) + "</A_SCALT_CODE></SCALT>";
							saLaborLines += "<A_IGNORE_FLAG>" + $parentThis._checkNull(receivedData.activity.A_IGNORE_FLAG) + "</A_IGNORE_FLAG>";
							saLaborLines += "<A_MACHINE_STATUS_IN>" + $parentThis._checkNull(receivedData.activity.A_MACHINE_STATUS_BEFORE) + "</A_MACHINE_STATUS_IN>";
							saLaborLines += "<A_MACHINE_STATUS_OUT>" + $parentThis._checkNull(receivedData.activity.A_MACHINE_STATUS_AFTER) + "</A_MACHINE_STATUS_OUT>";
							saLaborLines += "<CUST_NAME>" + $parentThis._checkNull(receivedData.activity.A_COMPANY_NAME) + "</CUST_NAME>";
							saLaborLines += "<P_IN_V_DEINST_CNFM>" + $parentThis._checkNull(receivedData.activity.A_DEINSTALL_CONFIRM) + "</P_IN_V_DEINST_CNFM>";
							saLaborLines += "</DebriefTasks>";
						}

						var $se_billing_info_labor = $.createElement('labor');
						$se_billing_info_labor.append($.createElement('key', currDateTimeFormat));
						$se_billing_info_labor.append($.createElement('date', dateCol));
						$se_billing_info_labor.append($.createElement('quantity', quantity));
						$se_billing_info_labor.append($.createElement('quantity_unit', "hrs"));
						$se_billing_info_labor.append($.createElement('prod_number', prod_number));
						$se_billing_info_labor.append($.createElement('name', prod_description));
						$se_billing_info_labor.append($.createElement('price', ext_price_col));
						$se_billing_info_labor.append($.createElement('price_summ', overridenPrice));
						$se_billing_info_labor.append($.createElement('is_overriden', 'N'));
						$se_billing_info_labor.append($.createElement('billing_amount', overridenPrice));
						$se_billing_info_labor.append($.createElement('billing_reason', selectedBillReasonCode));
						$se_billing_info_labor.append($.createElement('billing_reason_title', selectedBillReasonDesc));
						$se_billing_info_labor.append($.createElement('sa_billing_scope', billingScope));
						$se_billing_info_labor.append($.createElement('sa_billing_override_reason', billingOverrideReason));
						$se_billing_info_labor.append($.createElement('sa_billied_flag', 'Y'));
						$se_billing_info_billItems.append($se_billing_info_labor);

					});
					saLaborLines += '</DebriefTask>';

					if (!saAccountFlag) saLaborLines = "";

					if (!proceedWithRest) {
						return false;
					} // End changes for CHG0069377-Service_Advantage_Billing

					//Process the total labor row
					$('table tr.cpf_total_labor_row').each(function () {

						var quantity = $(this).find('.cpf_quantity').text();
						quantity = quantity.replace("hrs", "");
						quantity = $.trim(quantity);
						quantity = parseFloat(quantity).toFixed(2);
						//var selectedText=$(this).find('.cpf_quantitydropdown option:selected').text();

						var prod_number = $(this).find('.item_number').text();
						var prod_description = $(this).find('.item_description').text();
						var ext_price_col = $(this).find('.ext-price-col').text();
						ext_price_col = ext_price_col.replace("$", "");
						ext_price_col = $.trim(ext_price_col);
						ext_price_col = parseFloat(ext_price_col).toFixed(2);
						var overridenPrice = $(this).find('.cpf_input_overriden_val').val();
						if ((overridenPrice == "") || isNaN(parseFloat(overridenPrice))) {
							overridenPrice = 0;
						} else {
							overridenPrice = parseFloat(overridenPrice).toFixed(2);
						}
						var selectedBillReasonCode = $(this).find('.billreasondropdown').val();
						var selectedBillReasonDesc = $(this).find('.billreasondropdown option:selected').text();

						var dateCol = $(this).find('.dateColumn').text();
						var isOverriden;


						//commented for INC1520557
						/*if (ext_price_col != overridenPrice) {
							 if(aContractFlag && overridenPrice > 0 || !aContractFlag){
								   isOverriden = 'Y';
	
							  }else{
								   isOverriden = 'N';
							  }
	
							 if(aContractFlag && overridenPrice > 0 && selectedBillReasonCode == ""){
									$(this).addClass("error-highlited");
									alert(prod_description+" - Billing reason is not specified.");
									proceedWithRest = false;
									return false;
								}
	
							 if(!aContractFlag && selectedBillReasonCode == ""){
								$(this).addClass("error-highlited");
								alert(prod_description+" - Billing reason is not specified.");
								proceedWithRest = false;
								return false;
							}

						 if(!aContractFlag && selectedBillReasonCode == ""){
							$(this).addClass("error-highlited");
							alert(prod_description+" - Billing reason is not specified.");
							proceedWithRest = false;
							return false;
						}
					} else {
						isOverriden = 'N';
						$(this).removeClass("error-highlited");
					}*/
						// ended for INC1520557
						//added for INC1520557
						if (overridenPrice === 0) {
							isOverriden = 'N';
							$(this).removeClass("error-highlited");

						} else {
							if (aContractFlag && overridenPrice > 0 || !aContractFlag) {
								isOverriden = 'Y';
							} else {
								isOverriden = 'N';
							}
						}
						if (aContractFlag && overridenPrice > 0 && selectedBillReasonCode == "") {
							$(this).addClass("error-highlited");
							alert(prod_description + " - Billing reason is not specified.");
							proceedWithRest = false;
							return false;
						}

						if (!aContractFlag && overridenPrice > 0 && selectedBillReasonCode == "") {
							$(this).addClass("error-highlited");
							alert(prod_description + " - Billing reason is not specified.");
							proceedWithRest = false;
							return false;
						}
						//ended for INC1520557


						var $se_billing_info_labor = $.createElement('total_labor');
						$se_billing_info_labor.append($.createElement('key', 'total_labor'));
						$se_billing_info_labor.append($.createElement('date', dateCol));
						$se_billing_info_labor.append($.createElement('quantity', '0' + quantity));
						$se_billing_info_labor.append($.createElement('quantity_unit', "hrs"));
						$se_billing_info_labor.append($.createElement('prod_number', prod_number));
						$se_billing_info_labor.append($.createElement('name', prod_description));
						$se_billing_info_labor.append($.createElement('price', ext_price_col));
						$se_billing_info_labor.append($.createElement('price_summ', ext_price_col));
						$se_billing_info_labor.append($.createElement('is_overriden', isOverriden));
						$se_billing_info_labor.append($.createElement('billing_amount', overridenPrice));
						$se_billing_info_labor.append($.createElement('billing_reason', selectedBillReasonCode));
						$se_billing_info_labor.append($.createElement('billing_reason_title', selectedBillReasonDesc));

						$se_billing_info_billItems.append($se_billing_info_labor);

						// Navaz:14Mar18 - additional fields update.
						aSETotalLabour = overridenPrice;
						aBillingReason = selectedBillReasonCode;
						if (aContractFlag) {
							if (overridenPrice >= 0) {
								aLabourOverridePrice = aSETotalLabour;
							}
						} else {
							if ((ext_price_col != overridenPrice) && (overridenPrice >= 0)) { //modified for INC1520557 //CHG0070820
								aLabourOverridePrice = aSETotalLabour;
							}

						}
						// price
						/*if(receivedData.activity.A_PROBLEM_CODE== "Level 1 Helpdesk"
								|| receivedData.activity.A_PROBLEM_CODE== "Level 2 Workstation"
								|| receivedData.activity.A_PROBLEM_CODE== "Level 3 Server"
								|| receivedData.activity.A_PROBLEM_CODE== "Level 4 Network"){
							aLabourOverridePrice = aSETotalLabour;
						}*/

					});
					if (!proceedWithRest) {
						return false;
					}
					//Process the parts rows
					var $debrief_partLineXml = $('<XMLDocument />');
					var inventoryListJSONData = {};
					var actionsArr = [];
					var previousPartItemNumArr = [];
					var prod_number;
					// start of CHG0080567- OFSC MPF Group 2B Change
					// var duplicatePartItems = false;
					// var installed_parts_details = "";
					var visitedParts = [];
					var presentParts = [];
					// end of CHG0080567- OFSC MPF Group 2B Change

					$('table tr.cpf_parts_row').each(function () {
						try {
							var quantity = $(this).find('.cpf_quantity').text();
							//var selectedText=$(this).find('.cpf_quantitydropdown option:selected').text();

							prod_number = $(this).find('.item_number').text();
							var isPresent = $.inArray(prod_number, previousPartItemNumArr);

							if (isPresent == -1) {
								// no duplicates
								// duplicatePartItems = false; // CHG0080567- OFSC MPF Group 2B Change
								previousPartItemNumArr.push(prod_number);

							} else {
								// duplicate items exist.
								// duplicatePartItems = true; // CHG0080567- OFSC MPF Group 2B Change
							}



							var prod_description = $(this).find('.item_description').text();
							var ext_price_col = $(this).find('.ext-price-col').text();
							ext_price_col = ext_price_col.replace("$", "");
							ext_price_col = $.trim(ext_price_col);
							ext_price_col = parseFloat(ext_price_col).toFixed(2);
							var overridenPrice = $(this).find('.cpf_input_overriden_val').val();
							if ((overridenPrice == "") || isNaN(parseFloat(overridenPrice))) {
								overridenPrice = 0;
							} else {
								overridenPrice = parseFloat(overridenPrice).toFixed(2);
							}
							var selectedBillReasonCode = $(this).find('.billreasondropdownParts').val();
							var selectedBillReasonDesc = $(this).find('.billreasondropdownParts option:selected').text();

							var dateCol = $(this).find('.dateColumn').text();
							var passCountCol = $(this).find('.pass_count_Column').text();
							var subinventory = $(this).find('.subInventory').text(); // new change for CHG0080567

							var isOverriden;
							//commented for INC1520557
							/*if (ext_price_col != overridenPrice) {
								 if(aContractFlag && overridenPrice > 0 || !aContractFlag){
									   isOverriden = 'Y';
								  }else{
									   isOverriden = 'N';
								  }
		
								  if(aContractFlag && overridenPrice > 0 && selectedBillReasonCode == ""){
										$(this).addClass("error-highlited");
										alert(prod_description+" - Billing reason is not specified.");
										proceedWithRest = false;
										return false;
									}
		
								 if(!aContractFlag && selectedBillReasonCode == ""){
									$(this).addClass("error-highlited");
									alert(prod_description+" - Billing reason is not specified.");
									proceedWithRest = false;
									return false;
								}
							} else {
								isOverriden = 'N';
								$(this).removeClass("error-highlited");
							}*/
							//ended for INC1520557
							//added for INC1520557
							if (overridenPrice === 0) {
								isOverriden = 'N';
								$(this).removeClass("error-highlited");

							} else {
								if (aContractFlag && overridenPrice > 0 || !aContractFlag) {
									isOverriden = 'Y';
								} else {
									isOverriden = 'N';
								}
							}
							if (aContractFlag && overridenPrice > 0 && selectedBillReasonCode == "") {
								$(this).addClass("error-highlited");
								alert(prod_description + " - Billing reason is not specified.");
								proceedWithRest = false;
								return false;
							}

							if (!aContractFlag && selectedBillReasonCode == "") {
								$(this).addClass("error-highlited");
								alert(prod_description + " - Billing reason is not specified.");
								proceedWithRest = false;
								return false;
							}
							//ended for INC1520557

							var $se_billing_info_parts = $.createElement('part');
							$se_billing_info_parts.append($.createElement('key', currDateTimeFormat + ' ' + prod_number));
							$se_billing_info_parts.append($.createElement('date', dateCol));
							$se_billing_info_parts.append($.createElement('quantity', quantity));
							$se_billing_info_parts.append($.createElement('quantity_unit', ''));
							$se_billing_info_parts.append($.createElement('prod_number', prod_number));
							$se_billing_info_parts.append($.createElement('name', prod_description));
							$se_billing_info_parts.append($.createElement('price', ext_price_col));
							$se_billing_info_parts.append($.createElement('price_summ', ext_price_col));
							$se_billing_info_parts.append($.createElement('is_overriden', isOverriden));
							$se_billing_info_parts.append($.createElement('billing_amount', overridenPrice));
							$se_billing_info_parts.append($.createElement('billing_reason', selectedBillReasonCode));
							$se_billing_info_parts.append($.createElement('billing_reason_title', selectedBillReasonDesc));
							$se_billing_info_parts.append($.createElement('pass_count', passCountCol));

							// group 2b
							// Start of CHG0080567- OFSC MPF Group 2B Change
							if (isOverriden == 'Y' || quantity < 0) {
								all_parts_details = all_parts_details + prod_number + "~" + prod_description + "~" + quantity + "~" + overridenPrice + "~" + selectedBillReasonCode + "~" + ext_price_col + "~" + dateCol + "~" + subinventory + "|";
							} else {
								all_parts_details = all_parts_details + prod_number + "~" + prod_description + "~" + quantity + "~" + overridenPrice + "~" + '' + "~" + ext_price_col + "~" + dateCol + "~" + subinventory + "|";
							}
							var isTrue = $.inArray(prod_number, visitedParts);

							// if (receivedData.activity.A_INSTALLED_PARTS != null) {
							// 	$.each(inventoryList, function (index, val) {
							// 		if (val.inv_aid == receivedData.activity.aid && val.I_ITEM_NUMBER == prod_number && isTrue == -1) {
							// 			installed_parts_details = installed_parts_details + prod_number + "~" + prod_description + "~" + quantity + "~" + overridenPrice + "~" + selectedBillReasonCode + "~" + currDateTimeFormat + "|";
							// 			visitedParts.push(prod_number);
							// 		}

							// 	});

							// start of CHG0083631 changes
							var modified_flag = false;
							if (installed_parts_details_first.length > 0) {
								$.each(installed_parts_details_first, function (key, element) {
									if (element.partNum == prod_number) {
										modified_flag = true;
										let single_price = parseFloat(overridenPrice) / parseFloat(quantity);;
										let total_price = single_price * element.quant;
										total_price = parseFloat(total_price).toFixed(2);
										if (isOverriden == 'Y' || quantity < 0) {
											installed_parts_details = installed_parts_details + prod_number + "~" + prod_description + "~" + element.quant + "~" + total_price + "~" + selectedBillReasonCode + "~" + date_MM_DD_TT + "~" + subinventory + "|";
										}
										else {
											installed_parts_details = installed_parts_details + prod_number + "~" + prod_description + "~" + element.quant + "~" + total_price + "~" + '' + "~" + date_MM_DD_TT + "~" + subinventory + "|";
										}
									}


								});
							}
							if (modified_flag == true) {
								installed_parts_details_first.remove(prod_number);
							}

							// end of CHG0083631 changes


							var newPartFlag = false;
							var partPresent = false;

							if (dateCol == date_MM_DD_TT) {

								$.each(installedParts, function (key, part) {

									if (part.name == prod_number && part.subinventory == subinventory) { // new change for CHG0080567
										partPresent = true;
										if (quantity > 0) {


											let insQty = parseFloat(part.qty) + parseFloat(quantity);
											let single_qty_price = parseFloat(overridenPrice) / parseFloat(quantity);// changes of CHG0083631
											let billAmount = parseFloat(insQty) * parseFloat(single_qty_price);
											billAmount = parseFloat(billAmount).toFixed(2);
											// billAmount=(invItem.quantity*overridenPrice)/quantity;

											if (isOverriden == 'Y' || quantity < 0) { // changes of CHG0083631
												installed_parts_details = installed_parts_details + prod_number + "~" + prod_description + "~" + insQty + "~" + billAmount + "~" + selectedBillReasonCode + "~" + date_MM_DD_TT + "~" + subinventory + "|";
											}
											else {
												installed_parts_details = installed_parts_details + prod_number + "~" + prod_description + "~" + insQty + "~" + billAmount + "~" + '' + "~" + date_MM_DD_TT + "~" + subinventory + "|";
											} // new change for CHG0080567
										}
										//   if(quantity>0){

										// 	let billAmount =overridenPrice;
										// 	billAmount=(part.qty*overridenPrice)/quantity;


										// 	installed_parts_details = installed_parts_details + prod_number + "~" + prod_description + "~" + quantity + "~" + billAmount + "~" + selectedBillReasonCode + "~" + currDateTimeFormat + "|";
										//   }
										if (quantity < 0 && parseFloat(part.qty) + parseFloat(quantity) != 0) {
											let billAmount = overridenPrice;
											// (
											let temp = parseFloat(overridenPrice) / parseFloat(quantity);
											// let billAmount=(parseFloat(part.billAmount) + parseFloat(overridenPrice));
											let insQty = parseFloat(part.qty) + parseFloat(quantity);
											billAmount = temp * insQty;
											billAmount = parseFloat(billAmount).toFixed(2);
											if (isOverriden == 'Y' || quantity < 0) {
												installed_parts_details = installed_parts_details + prod_number + "~" + prod_description + "~" + insQty + "~" + billAmount + "~" + selectedBillReasonCode + "~" + date_MM_DD_TT + "~" + subinventory + "|"; // new change for CHG0080567

											} else {
												installed_parts_details = installed_parts_details + prod_number + "~" + prod_description + "~" + insQty + "~" + billAmount + "~" + '' + "~" + date_MM_DD_TT + "~" + subinventory + "|";
											}
										}
									}

								});
								if (partPresent == false) {
									if (isOverriden == 'Y' || quantity < 0) {// changes of CHG0083631
										installed_parts_details = installed_parts_details + prod_number + "~" + prod_description + "~" + quantity + "~" + overridenPrice + "~" + selectedBillReasonCode + "~" + date_MM_DD_TT + "~" + subinventory + "|";

									} else {
										installed_parts_details = installed_parts_details + prod_number + "~" + prod_description + "~" + quantity + "~" + overridenPrice + "~" + '' + "~" + date_MM_DD_TT + "~" + subinventory + "|";
									} // new change for CHG0080567
								}
								// installed_parts_details = installed_parts_details + prod_number + "~" + prod_description + "~" + quantity + "~" + overridenPrice + "~" + selectedBillReasonCode + "~" + currDateTimeFormat + "|";
								newPartFlag = true;

							}
							// end of CHG0080567- OFSC MPF Group 2B Change

							$se_billing_info_billItems.append($se_billing_info_parts);

							if (!isNaN(overridenPrice) && overridenPrice.length !== 0) {
								aSETotalParts += parseFloat(overridenPrice);
							}


							//build the A_PARTS XML File for all parts:

							/*<DebriefPartLine>
								<A_IN_SERVICE_DTS>2017-12-27</A_IN_SERVICE_DTS>
								<I_MATERIAL_PART_NUMBER>10R0336</I_MATERIAL_PART_NUMBER>
								<A_SUBINVENTORY_CODE>AMERISOUTE</A_SUBINVENTORY_CODE>
								<quantity>1</quantity>
								<I_MATERIAL_OVERRIDE_PRICE></I_MATERIAL_OVERRIDE_PRICE>
								<I_MATERIAL_OVERRIDE_REASON_CODE></I_MATERIAL_OVERRIDE_REASON_CODE>
								<A_IGNORE_FLAG></A_IGNORE_FLAG>
							</DebriefPartLine>*/
							let updatePart = false;
							$.each(allParts, function (key, part) {
								if (part.name == prod_number && part.date == dateCol && (part.billAmount != overridenPrice || part.billReason != selectedBillReasonCode)) {
									updatePart = true;
								}


							});

							let partCheck = false; // CHG0080567- OFSC MPF Group 2B Change
							$.each(inventoryList, function (key, invItem) {

								if (invItem.inv_aid == receivedData.activity.aid) {

									if (invItem.invpool == "install") { // || invItem.invpool == "deinstall") {

										if (invItem.I_ITEM_NUMBER == prod_number && invItem.I_SUBINVENTORY == subinventory) { // new change for CHG0080567

											partCheck = true; //CHG0080567- OFSC MPF Group 2B Change
											var invID = invItem.invid;
											var qty = invItem.quantity;
											var iSubInventory = invItem.I_SUBINVENTORY;

											var $debrief_partLine = $.createElement('DebriefPartLine');
											$debrief_partLine.append($.createElement('A_IN_SERVICE_DTS', date_YYYY_MM_DD));
											//Changes for req#4 CHG0083631 changes
											if (updatePart == true) {// changes of CHG0083631
												let prod_num = prod_number + "_UPDATE";
												$debrief_partLine.append($.createElement('I_MATERIAL_PART_NUMBER', prod_num));
											} else {
												$debrief_partLine.append($.createElement('I_MATERIAL_PART_NUMBER', prod_number));
											}

											$debrief_partLine.append($.createElement('A_SUBINVENTORY_CODE', iSubInventory));
											$debrief_partLine.append($.createElement('quantity', quantity));
											// Only if override is true then add the below two elements to the XML.
											if (isOverriden == 'Y' || quantity < 0) { //CHG0080567- OFSC MPF Group 2B Change
												$debrief_partLine.append($.createElement('I_MATERIAL_OVERRIDE_PRICE', overridenPrice));
												$debrief_partLine.append($.createElement('I_MATERIAL_OVERRIDE_REASON_CODE', selectedBillReasonCode));
											} else {
												$debrief_partLine.append($.createElement('I_MATERIAL_OVERRIDE_PRICE', ''));
												$debrief_partLine.append($.createElement('I_MATERIAL_OVERRIDE_REASON_CODE', ''));


											}
											// start of CHG0080567- OFSC MPF Group 2B Change
											if (newPartFlag == true && inflightFlag == false) {
												$debrief_partLine.append($.createElement('A_IGNORE_FLAG', ''));
											}
											else if (newPartFlag == false && inflightFlag == false) {
												//changes for req#4
												// changes of CHG0083631
												if (updatePart == true) {
													$debrief_partLine.append($.createElement('A_IGNORE_FLAG', ''));
												}
												else {
													$debrief_partLine.append($.createElement('A_IGNORE_FLAG', 'Ignore'));
												}
											}
											else if (inflightFlag == true && (receivedData.activity.A_INSTALLED_PARTS == null || receivedData.activity.A_INSTALLED_PARTS == undefined)) {
												if (invItem.I_IGNORE_FLAG == "Ignore") {
													$debrief_partLine.append($.createElement('A_IGNORE_FLAG', 'Ignore'));
												}
												else {
													$debrief_partLine.append($.createElement('A_IGNORE_FLAG', ''));
												}

											}

											else if (inflightFlag == true && receivedData.activity.A_INSTALLED_PARTS != null) {
												if (newPartFlag == true || updatePart == true) { // changes of CHG0083631 // changes for req#4
													$debrief_partLine.append($.createElement('A_IGNORE_FLAG', ''));
												}
												else {
													$debrief_partLine.append($.createElement('A_IGNORE_FLAG', 'Ignore'));
												}

											}
											else {
												$debrief_partLine.append($.createElement('A_IGNORE_FLAG', 'Ignore'));
											}
											// else if( inflightFlag == true && invItem.I_IGNORE_FLAG != "Ignore"){

											// }

											// if (isChanged == true || quantity < 0 || receivedData.activity.A_INSTALLED_PARTS == null || (isPresent == -1 && newPart == true)) {
											// 	$debrief_partLine.append($.createElement('A_IGNORE_FLAG', ''));
											// }

											// end of CHG0080567- OFSC MPF Group 2B Change

											if (isOverriden == 'Y') {
												$.extend(inventoryListJSONData, {
													[invID]: {
														I_ITEM_PRICE_OVERRIDE: overridenPrice + '',
														I_ITEM_PRICE_OVERRIDE_REASON: selectedBillReasonCode
													}
												});
											}
											//if quantity less than or equal to 0 then remove/delete the item.
											if (qty <= 0) {

												actionsArr.push({
													"action": "delete",
													"invid": invID,
													"entity": "inventory",
													"properties": {}
												});

											}

											$debrief_partLineXml.append($debrief_partLine);
										}
									}
								}
							});
							if (partCheck == false) {
								var iSubInventory = subinventory;

								var $debrief_partLine = $.createElement('DebriefPartLine');
								$debrief_partLine.append($.createElement('A_IN_SERVICE_DTS', date_YYYY_MM_DD));
								if (updatePart == true) {
									let prod_num = prod_number + "_UPDATE";
									$debrief_partLine.append($.createElement('I_MATERIAL_PART_NUMBER', prod_num));
								} else {
									$debrief_partLine.append($.createElement('I_MATERIAL_PART_NUMBER', prod_number));
								}
								// $debrief_partLine.append($.createElement('I_MATERIAL_PART_NUMBER', prod_number));
								$debrief_partLine.append($.createElement('A_SUBINVENTORY_CODE', iSubInventory));
								$debrief_partLine.append($.createElement('quantity', quantity));
								// Only if override is true then add the below two elements to the XML.
								if (isOverriden == 'Y' || quantity < 0) {
									$debrief_partLine.append($.createElement('I_MATERIAL_OVERRIDE_PRICE', overridenPrice));
									$debrief_partLine.append($.createElement('I_MATERIAL_OVERRIDE_REASON_CODE', selectedBillReasonCode));
								} else {
									$debrief_partLine.append($.createElement('I_MATERIAL_OVERRIDE_PRICE', ''));
									$debrief_partLine.append($.createElement('I_MATERIAL_OVERRIDE_REASON_CODE', ''));


								}
								//HM:07-May-2018 Def#1450
								if (newPartFlag == true || updatePart == true) {// changes of CHG0083631
									$debrief_partLine.append($.createElement('A_IGNORE_FLAG', ''));
								}
								else {
									$debrief_partLine.append($.createElement('A_IGNORE_FLAG', 'Ignore'));
								}


								// if (isOverriden == 'Y' || quantity<0) {
								// 	$.extend(inventoryListJSONData, {
								// 		[invID]: {
								// 			I_ITEM_PRICE_OVERRIDE: overridenPrice + '',
								// 			I_ITEM_PRICE_OVERRIDE_REASON: selectedBillReasonCode
								// 		}
								// 	});
								// }
								//if quantity less than or equal to 0 then remove/delete the item.
								// if (qty <= 0) {

								// 	actionsArr.push({
								// 		"action": "delete",
								// 		"invid": invID,
								// 		"entity": "inventory",
								// 		"properties": {}
								// 	});

								// }

								$debrief_partLineXml.append($debrief_partLine);

							}
							// end of CHG0080567- OFSC MPF Group 2B Change


						} catch (err) {
							activityLog = activityLog + ';Exception in cpf_parts_row:' + err.message;
							console.log(" Exception in cpf_parts_row :" + err.message);
						}

					});
					if (!proceedWithRest) {
						return false;
					}
					console.log("previousPartItemNum Arr" + JSON.stringify(previousPartItemNumArr));
					console.log("debrief_partLine " + $debrief_partLineXml.html());

					// Modified for CHG0080567- OFSC MPF Group 2B Change chnages
					// //check for duplicate items
					// if (duplicatePartItems) {
					//     if (confirm('There are multiple part lines with the same part number and date. Press \'Continue\' to submit Service Ticket or \'Cancel\' to go back to the screen.')) {
					//         //continue
					//     } else {
					//         // cancel clicked.
					//         return false;
					//     }
					// }
					// end of CHG0080567- OFSC MPF Group 2B Change
					//Process the expenses rows
					$('table tr.cpf_expenses_row').each(function () {


						var quantity = $(this).find('.cpf_quantity').text();
						//var selectedText=$(this).find('.cpf_quantitydropdown option:selected').text();
						var prod_number = $(this).find('.item_number').text();
						var prod_description = $(this).find('.item_description').text();
						//Begin modification for INC1540486
						var selectedBillReasonCode = $(this).find('.billreasondropdownExpenses').val();
						//End modification for INC1540486
						var ext_price_col = $(this).find('.ext-price-col').text();
						if (ext_price_col != 'na') {
							ext_price_col = ext_price_col.replace("$", "");
							ext_price_col = $.trim(ext_price_col);
							ext_price_col = parseFloat(ext_price_col).toFixed(2);
						} else {
							//Begin modification for INC1540486
							selectedBillReasonCode = 'na';
							//End modification for INC1540486
							ext_price_col = 0;
						}
						var overridenPrice = $(this).find('.cpf_input_overriden_val').val();
						if ((overridenPrice == "") || isNaN(parseFloat(overridenPrice))) {
							overridenPrice = 0;
						} else {
							overridenPrice = parseFloat(overridenPrice).toFixed(2);
						}
						//Begin modification for INC1540486
						//var selectedBillReasonCode = $(this).find('.billreasondropdownExpenses').val();
						//End modification for INC1540486
						var selectedBillReasonDesc = $(this).find('.billreasondropdownExpenses option:selected').text();
						var expenseSection = $(this).find('.expenseSection').text();
						var expenseTypeInfo = $(this).find('.expenseTypeInfo').text();
						var dateCol = $(this).find('.dateColumn').text();
						var passCountCol = $(this).find('.pass_count_Column').text();
						var isOverriden;
						// commented for INC1520557
						/*if (ext_price_col != overridenPrice) {
							if(aContractFlag && overridenPrice > 0 || !aContractFlag){
								   isOverriden = 'Y';
							  }else{
								   isOverriden = 'N';
							  }
	
							 if(aContractFlag && overridenPrice > 0 && selectedBillReasonCode == ""){
									$(this).addClass("error-highlited");
									alert(prod_description+" - Billing reason is not specified.");
									proceedWithRest = false;
									return false;
								}
	
							 if(!aContractFlag && selectedBillReasonCode == ""){
								$(this).addClass("error-highlited");
								alert(prod_description+" - Billing reason is not specified.");
								proceedWithRest = false;
								return false;
							}

						 if(!aContractFlag && selectedBillReasonCode == ""){
							$(this).addClass("error-highlited");
							alert(prod_description+" - Billing reason is not specified.");
							proceedWithRest = false;
							return false;
						}
					} else {
						isOverriden = 'N';
						$(this).removeClass("error-highlited");
					}*/
						// ended for INC1520557
						//added for INC1520557
						if (overridenPrice === 0) {
							isOverriden = 'N';
							$(this).removeClass("error-highlited");

						} else {
							if (aContractFlag && overridenPrice > 0 || !aContractFlag) {
								isOverriden = 'Y';
							} else {
								isOverriden = 'N';
							}
						}
						if (aContractFlag && overridenPrice > 0 && selectedBillReasonCode == "") {
							$(this).addClass("error-highlited");
							alert(prod_description + " - Billing reason is not specified.");
							proceedWithRest = false;
							return false;
						}

						if (!aContractFlag && selectedBillReasonCode == "") {
							$(this).addClass("error-highlited");
							alert(prod_description + " - Billing reason is not specified.");
							proceedWithRest = false;
							return false;
						}
						//ended for INC1520557
						//CHG0067765 Condition Based Maintenance
						if (expenseTypeInfo == "activities" || expenseTypeInfo == "condition based maintainance") {
							selectedBillReasonCode = "";
							selectedBillReasonDesc = "";
						}
						var $se_billing_info_expense = $.createElement('expense');
						$se_billing_info_expense.append($.createElement('key', currDateTimeFormat + ' ' + prod_number));
						$se_billing_info_expense.append($.createElement('date', dateCol));
						$se_billing_info_expense.append($.createElement('quantity', quantity));
						$se_billing_info_expense.append($.createElement('quantity_unit', ''));
						$se_billing_info_expense.append($.createElement('prod_number', prod_number));
						$se_billing_info_expense.append($.createElement('name', prod_description));
						$se_billing_info_expense.append($.createElement('price', ext_price_col));
						$se_billing_info_expense.append($.createElement('price_summ', ext_price_col));
						$se_billing_info_expense.append($.createElement('is_overriden', isOverriden));
						$se_billing_info_expense.append($.createElement('billing_amount', overridenPrice));
						$se_billing_info_expense.append($.createElement('billing_reason', selectedBillReasonCode));
						$se_billing_info_expense.append($.createElement('billing_reason_title', selectedBillReasonDesc));
						$se_billing_info_expense.append($.createElement('expense_type', expenseTypeInfo));
						$se_billing_info_expense.append($.createElement('pass_count', passCountCol));

						$se_billing_info_billItems.append($se_billing_info_expense);

						if (!isNaN(overridenPrice) && overridenPrice.length !== 0) {
							aSETotalExpenses += parseFloat(overridenPrice);
						}

						// Start INC1502678
						if (expenseTypeInfo == "activities") {
							ext_price_col = quantity;
						}
						// End INC1502678

						//CHG0067765 Condition Based Maintenance Start 
						if (expenseTypeInfo == "condition based maintainance") {
							ext_price_col = quantity;
						}
						//CHG0067765 Condition Based Maintenance End

						//build only current expenses.
						if (parseInt(passCountCol) == parseInt(g_current_pass_count)) {
							var $seExpensesPlugin = $.createElement('DebriefExpenseLine');
							$seExpensesPlugin.append($.createElement('A_EXPENSE_SECTION', expenseSection));
							$seExpensesPlugin.append($.createElement('A_EXPENSE_LABEL', prod_description));
							$seExpensesPlugin.append($.createElement('A_EXPENSE_TYPE', prod_number));
							//Begin modification for CHG0060060: Updated A_QUNTITY TO A_EXPENSE_QUANTITY as it was not accepted in SOA
							//$seExpensesPlugin.append($.createElement('A_QUANTITY', quantity));
							$seExpensesPlugin.append($.createElement('A_EXPENSE_QUANTITY', quantity));
							//End of changes for CHG0060060
							$seExpensesPlugin.append($.createElement('A_AMOUNT', ext_price_col));
							$seExpensesPlugin.append($.createElement('A_OVERRIDE_PRICE', overridenPrice));
							$seExpensesPlugin.append($.createElement('A_PRICE_OVERRIDE_REASON_CODE', selectedBillReasonCode));
							$seExpensesPluginXml.append($seExpensesPlugin);
						}
					});
					if (!proceedWithRest) {
						return false;
					}

					//Process the materialHandling rows
					$('table tr.cpf_material_row').each(function () {


						var quantity = $(this).find('.cpf_quantity').text();
						//var selectedText=$(this).find('.cpf_quantitydropdown option:selected').text();

						var prod_number = $(this).find('.item_number').text();
						var prod_description = $(this).find('.item_description').text();
						var ext_price_col = $(this).find('.ext-price-col').text();
						ext_price_col = ext_price_col.replace("$", "");
						ext_price_col = $.trim(ext_price_col);
						ext_price_col = parseFloat(ext_price_col);
						var overridenPrice = $(this).find('.cpf_input_overriden_val').val();
						if ((overridenPrice == "") || isNaN(parseFloat(overridenPrice))) {
							overridenPrice = 0;
						} else {
							overridenPrice = parseFloat(overridenPrice).toFixed(2);
						}
						var selectedBillReasonCode = $(this).find('.billreasondropdown').val();
						var selectedBillReasonDesc = $(this).find('.billreasondropdown option:selected').text();

						var dateCol = $(this).find('.dateColumn').text();
						var isOverriden;
						//commented for INC1520557
						/*if (ext_price_col != overridenPrice) {
							if(aContractFlag && overridenPrice > 0 || !aContractFlag){
								   isOverriden = 'Y';
							  }else{
								   isOverriden = 'N';
							  }
	
							 if(aContractFlag && overridenPrice > 0 && selectedBillReasonCode == ""){
									$(this).addClass("error-highlited");
									alert(prod_description+" - Billing reason is not specified.");
									proceedWithRest = false;
									return false;
								}
	
							 if(!aContractFlag && selectedBillReasonCode == ""){
								$(this).addClass("error-highlited");
								alert(prod_description+" - Billing reason is not specified.");
								proceedWithRest = false;
								return false;
							}
						} else {
							isOverriden = 'N';
							$(this).removeClass("error-highlited");
						}*/
						//ended for INC1520557
						//added for INC1520557
						if (overridenPrice === 0) {
							isOverriden = 'N';
							$(this).removeClass("error-highlited");

						} else {
							if (aContractFlag && overridenPrice > 0 || !aContractFlag) {
								isOverriden = 'Y';
							} else {
								isOverriden = 'N';
							}
						}
						if (aContractFlag && overridenPrice > 0 && selectedBillReasonCode == "") {
							$(this).addClass("error-highlited");
							alert(prod_description + " - Billing reason is not specified.");
							proceedWithRest = false;
							return false;
						}

						if (!aContractFlag && selectedBillReasonCode == "") {
							$(this).addClass("error-highlited");
							alert(prod_description + " - Billing reason is not specified.");
							proceedWithRest = false;
							return false;
						}
						//ended for INC1520557

						var $se_billing_info_materialFee = $.createElement('material_handling_fee');
						$se_billing_info_materialFee.append($.createElement('key', prod_number));
						$se_billing_info_materialFee.append($.createElement('date', dateCol));
						$se_billing_info_materialFee.append($.createElement('quantity', quantity));
						$se_billing_info_materialFee.append($.createElement('quantity_unit', ''));
						$se_billing_info_materialFee.append($.createElement('prod_number', prod_number));
						$se_billing_info_materialFee.append($.createElement('name', prod_description));
						$se_billing_info_materialFee.append($.createElement('price', ext_price_col));
						$se_billing_info_materialFee.append($.createElement('price_summ', ext_price_col));
						$se_billing_info_materialFee.append($.createElement('is_overriden', isOverriden));
						$se_billing_info_materialFee.append($.createElement('billing_amount', overridenPrice));
						$se_billing_info_materialFee.append($.createElement('billing_reason', selectedBillReasonCode));
						$se_billing_info_materialFee.append($.createElement('billing_reason_title', selectedBillReasonDesc));

						$se_billing_info_billItems.append($se_billing_info_materialFee);

						//update A_MATERIAL_FEE_OVERRIDE
						if (overridenPrice > 0) { //modified for INC1520557
							aMaterialFeeOverride = overridenPrice;
						}
						aMaterialFeeOverrideReason = selectedBillReasonDesc;//Added for CHG0060060
					});
					if (!proceedWithRest) {
						return false;
					}
					$se_billing_info_billInfo.append($se_billing_info_billItems);


					// aSETotalLabour = parseFloat(aSETotalExpenses) + parseFloat(aSETotalParts);

					var aSETotal = $("#cpf_TotalExcludingTaxes_inner").text();
					aSETotal = aSETotal.replace("$", "");
					aSETotal = $.trim(aSETotal);
					aSETotal = parseFloat(aSETotal).toFixed(2);

					//check for PO_Number.
					var po_number = $("#po_number").val();
					if (aSETotal > 0 || poRequiredFlag) {
						if (po_number == "" || po_number == null) {
							alert("Please Enter the PO# Number.");
							return;
						}

					}

					// Begin CHG0078154
					// check for Problem and work performed
					var problem_work_performed = $("#probWorkPerformed").val();
					if (problem_work_performed.length < 4) {
						console.log("problem_work_performed :" + problem_work_performed.length);
						alert("Please provide an explanation of the work performed.");
						return;
					}
					// End CHG0078154

					var ext_price_total = $(".ext_price_total").text();
					ext_price_total = ext_price_total.replace("$", "");
					ext_price_total = $.trim(ext_price_total);
					ext_price_total = parseFloat(ext_price_total).toFixed(2);
					var $se_info_summaries = $.createElement('summaries');
					$se_info_summaries.append($.createElement('price_summ', ext_price_total));
					$se_info_summaries.append($.createElement('billing_amount', aSETotal));


					$se_billing_info_billInfo.append($se_info_summaries);
					$se_billing_info_firstLoadXml.append($se_billing_info_billInfo);
					//console.log($se_billing_info_firstLoadXml.html());

					var se_BillingInfoHTML = this.generateSEBillingInfoHTML($se_billing_info_firstLoadXml);


					var billingComment = $("#probWorkPerformed").val();

					var total_labor_qty = $("#total_labor_qty").text();
					total_labor_qty = total_labor_qty.replace("hrs", "");
					total_labor_qty = $.trim(total_labor_qty);
					total_labor_qty = parseFloat(total_labor_qty).toFixed(2);
					console.log("total_labor_qty " + total_labor_qty);

					var n = total_labor_qty.indexOf(".");
					var total_labor_fh = total_labor_qty.substring(0, n);

					var len = total_labor_fh.length;
					/*if(len ==1 )
					{
						total_labor_qty = '0'+total_labor_qty;
					}
					*/
					console.log("total_labor_qty " + total_labor_qty);

					if (aSETotalParts) {
						aSETotalParts = parseFloat(aSETotalParts).toFixed(2);
					}
					if (aSETotalLabour) {
						aSETotalLabour = parseFloat(aSETotalLabour).toFixed(2);
					}
					if (aSETotalExpenses) {
						aSETotalExpenses = parseFloat(aSETotalExpenses).toFixed(2);
					}
					if (aSETotal) {
						aSETotal = parseFloat(aSETotal).toFixed(2);
					}

					if (receivedData.activity.A_ACTIVITY_LOG != null) {
						if (activityLog != null) {
							activityLog = receivedData.activity.A_ACTIVITY_LOG + ';' + activityLog;
						}
						else {
							activityLog = receivedData.activity.A_ACTIVITY_LOG;
						}
					}
					var serviceType = null;
					if (receivedData.activity.A_SERVICE_TYPE_LIST != null) {
						serviceType = receivedData.activity.A_SERVICE_TYPE_LIST;
					}
					/* end for OFSC Mobility Phase2 CHG0062368 */
					// Added below conditoin for CHG0069377-Service_Advantage_Billing
					if (saAccountFlag) {
						total_labor_qty = '';
					}
					var activityJSONData = {
						aid: activityId,
						A_TOTAL_PARTS: aSETotalParts + "",
						A_TOTAL_LABOR: aSETotalLabour + "",
						A_TOTAL_EXPENSES: aSETotalExpenses + "",
						A_TOTAL: aSETotal + "",
						A_LABOR_TIME: total_labor_qty, ///Need to convert this to drop down value.
						A_BILLING_COMMENT: billingComment,
						A_PO_NUMBER: po_number + '',
						A_PARTS: $debrief_partLineXml.html(),
						A_EXPENSES_PLUGIN: $seExpensesPluginXml.html(),
						A_EXPENSES_OUTBOUND: $seExpensesPluginXml.html(),
						A_BILLING_INFO: $se_billing_info_firstLoadXml.html(),
						A_BILLING_INFO_HTML: se_BillingInfoHTML,
						A_BILLING_REASON: aBillingReason,
						A_LABOR_OVERRIDE_PRICE: aLabourOverridePrice,
						A_MATERIAL_FEE_OVERRIDE: aMaterialFeeOverride,//Added for CHG0060060
						A_MATERIAL_FEE_OVERRIDE_REASON: aMaterialFeeOverrideReason, //Added for CHG0060060
						A_SHIFT_NAME: shiftLabel,  //Added for OFSC Mobility Phase2 CHG0062368
						A_SERVICE_TYPE: serviceType,
						A_SERVICE_TYPE_LIST: null,
						A_LABOR_LINES: saLaborLines, // Added for CHG0069377-Service_Advantage_Billing
						A_ACTIVITY_LOG: activityLog, //Added for OFSC Mobility Phase2 CHG0062368
						A_INSTALLED_PARTS: installed_parts_details,// Added for CHG0080567
						A_ITEM_TRACKING: all_parts_details // Added for CHG0080567
					};
					// Modification done for CHG0058936 INC1626356
					var futureSR = receivedData.activity.A_SERVICE_NOTES;
					if (futureSR) {
						if (futureSR.length > 240) {
							futureSR = futureSR.substring(0, 240); // end modification for CHG0058936 INC1626356
						}
					}


					if (a_status == 'CM') {


						var signeeName = $("#signeeName").val();
						var ccEmails = $('#ccEmails').val(); // Docusign changes CHG0066144
						//making contact name mandatory as part of Electronic Service Ticket enhancement - CHG0060060
						if (signeeName == "" || signeeName == null) {
							alert('Contact Name cannot be empty. Please enter Contact Name.');
							return false;
						}
						var signeeEmail = $("#signeeEmail").val();
						//making contact email mandatory as part of Electronic Service Ticket enhancement - CHG0060060
						var emailServiceTckt = $('#serviceEmail').prop('checked');
						var signatureByEmail = $('#docuSignEmail').prop('checked'); // DocuSign change CHG0066144
						if (emailServiceTckt || signatureByEmail) //Added validation for signatureByEmail for Docusign CHG0066144
						{
							if (signeeEmail == "" || signeeEmail == null) {
								alert('Contact Email cannot be empty. Please enter Contact Email.');
								return false;
							}
							if (emailServiceTckt)
								strEmailServiceTckt = 'Y';

							if (signatureByEmail) {
								strSignaturebyEmail = 'Y'; //changes done for DocuSign 22/09/2020 CHG0066144
								sigdiv.signature('clear');
							}
						}


						//checking valid email format entered by user in service ticket screen -- added for - CHG0060060
						var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,6})?$/;   // CHG0074725
						if (!(emailReg.test(signeeEmail))) {
							alert('Please enter Contact Email in valid format.');
							return false;
						}



						var signatureImageData = sigdiv.signature('toDataURL');
						//validation added for CHG0066144 if activity charge > 0 and no signature provided
						if (aSETotal > 0) {
							if (!signatureByEmail && onloadedEmptySignatureBlock == signatureImageData) {
								alert("This service request has charges that will be billed to customer. Please obtain valid ‘Contact Signature’ or choose ‘Signature by Email’ option.");
								return;
							}

						}

						//condition for signatureByEmail added for CHG0066144
						if (!signatureByEmail && onloadedEmptySignatureBlock == signatureImageData) {
							//empty block.
							//alert("Empty Block of signatureImageData "+signatureImageData);
							alert("Some fields were not filled correctly: \n \n Contact Signature - is not filled.");
							//console.log("IMAGE DATA "+ signatureImageData);
							return;
						}
						//docusign final pop-up chg0066144
						if (aSETotal > 0) {
							if (emailServiceTckt || signatureByEmail) {
								var retVal = confirm("This service request has charges that will be billed to customer. " +
									"Please confirm you have obtained a valid signature or using DocuSign for an electronic signature. " +
									"Click ‘Cancel’ to update the Service ticket or ‘OK’ to submit.");
								if (retVal == false) {
									return;
								}
							}
						}
						if (aSETotal <= 0) {
							if (emailServiceTckt) {
								var retVal = confirm("This signed Service Ticket will be emailed to the Customer Contact. Please confirm you have obtained a valid customer signature." +
									"Click ‘Cancel’ to update the Service ticket or ‘OK’ to submit.");
								if (retVal == false) {
									return;
								}
							}
						}
						//docusign final pop-up chg0066144

						// do a complete activity
						$.extend(activityJSONData, {
							astatus: "complete",
							A_STATUS: "CM",
							A_START_TIME_OVERRIDE: aStartTimeOverride,
							A_SCAN_IN_TIME_OVERRIDE: aScanInTimeOverride,
							A_SCAN_OUT_TIME_OVERRIDE: aScanOutTimeOverride,
							A_SCAN_OUT_TIME: aScanOutTime,
							A_SIGNEE_NAME: signeeName,
							A_SIGNEE_EMAIL: signeeEmail,
							A_SIGNATURE: signatureImageData,
							A_SERVICE_NOTES: futureSR,   // Modification done for CHG0058936 INC1626356
							A_EMAIL_SERVICE_TICKET: strEmailServiceTckt, // Modification done for Electronic Service Ticket enhancement - CHG0060060
							A_CC_EMAILS: ccEmails, //Modification done for DocuSign 22/9/2020 CHG0066144
							A_EMAIL_SIGN: strSignaturebyEmail //Modification done for DocuSign 22/9/2020 CHG0066144
						});

					} else {
						// do a suspend activity.
						$.extend(activityJSONData, {
							astatus: "suspended",
							A_SE_EXPENSES_PLUGIN: "",
							A_SERVICE_NOTES: futureSR  // Modification done for CHG0058936 INC1626356
							// Navaz:12MAR18- Blanking out of the A_SE_EXPENSES due to impact on SE.
						}); //A_STATUS: null, A_STATE: null, - Pritish:05/04 - Commented this as suspend reason needs this field value

						/* Navaz:Commented 09MAR18--The below fields are moved to Enroute Plugin. On the suspend retain these values in the Activity, Enroute wipe out these fields.
						$.extend(activityJSONData, {
							 astatus: "suspended",
							 A_STATE: null,
							 A_STATUS: null,
							 A_EXPENSES_PLUGIN: "",
							 A_EXPENSES_OUTBOUND: "",
							 A_NEW_EQUIPMENT_ID: "",
							 A_TIME_OVERNIGHT: "",
							 A_START_TIME: "",
							 A_START_TIME_OVERRIDE: "",
							 A_SCAN_IN_TIME: "",
							 A_SCAN_IN_TIME_OVERRIDE: "",
							 A_SCAN_OUT_TIME: "",
							 A_SCAN_OUT_TIME_OVERRIDE: "",
							 A_MACHINE_STATUS_BEFORE: "",
							 A_MACHINE_STATUS_AFTER: "",
							 A_ODOMETER_START: "",
							 A_ODOMETER_END: ""
							 //A_BILLING_INFO: ""
						 }); //A_ORDER_PARTS - pritish on 25/02. reverted changes as not required 25/02.
						 */

						//For a suspend activity you need to clean up the install and deinstall part items.
						// For a Install - set the I_IGNORE_FLAG to "Ignore" and for a deinstall item -- need to do a undo-deinstall action.
						console.log(JSON.stringify(inventoryListJSONData));
						$.each(inventoryList, function (key, invItem) {
							if (invItem.inv_aid == receivedData.activity.aid) {
								var invID = invItem.invid;
								var qty = invItem.quantity;

								if (invItem.invpool == "install" || invItem.invpool == "deinstall") {
									$.extend(inventoryListJSONData, {
										[invID]: {
											I_IGNORE_FLAG: "Ignore"
										}
									});

								}

							}
						});
					}
					console.log(JSON.stringify(activityJSONData));
					console.log(JSON.stringify(inventoryListJSONData));
					console.log(JSON.stringify(actionsArr));


					this._sendPostMessageData({
						"apiVersion": 1,
						"method": "close",
						"backScreen": "activity_list",
						"wakeupNeeded": false,
						"actions": actionsArr,
						"inventoryList": inventoryListJSONData,
						"activity": activityJSONData
					});
				} catch (err) {
					activityLog = activityLog + ';Exception in submit :' + err.message;
					console.log(" Exception in submit  :" + err.message);
				}
			}.bind(this));

			//Cancel Button Function:

			$('#cancelBtn').click(function () {

				this._sendPostMessageData({
					"apiVersion": 1,
					"method": "close",
					"backScreen": "default",
					"wakeupNeeded": false

				});
			}.bind(this));
		},

		/** Function to build the billing info html file>
		 */
		generateSEBillingInfoHTML: function (se_billing_info_xml) {

			var dataObject = '';
			//var xmlDoc = $.parseXML(xml);
			//  var xmlData = $(xmlDoc);
			se_billing_info_xml.find('billingInfo').find('billingItems').each(function () {

				$(this).children().each(function () {
					$(this).children().each(function () {
						if (this.tagName == 'date') {
							dataObject = dataObject.concat('Date: ' + $(this).text() + '; ');
						}
						if (this.tagName == 'quantity') {
							dataObject = dataObject.concat('Qty: ' + $(this).text() + ' ');

						}
						if (this.tagName == 'quantity_unit') {
							dataObject = dataObject.concat($(this).text() + '; ');

						}
						if (this.tagName == 'prod_number') {
							dataObject = dataObject.concat('Prod #: ' + $(this).text() + '; ');

						}
						if (this.tagName == 'name') {
							dataObject = dataObject.concat('Item: ' + $(this).text() + '; ');

						}
						if (this.tagName == 'billing_amount') {
							dataObject = dataObject.concat('Bill Amt: ' + $(this).text() + '; ');

						}
						if (this.tagName == 'billing_reason') {
							dataObject = dataObject.concat('Billing Reason: ' + $(this).text() + '; ');

						}
						if (this.tagName != 'quantity') {
							//dataObject = dataObject.concat(';');
						}

					});
					dataObject = dataObject.concat('\n');
				});

			});

			se_billing_info_xml.find('billingInfo').find('summaries').each(function () {
				$(this).children().each(function () {
					if (this.tagName == 'price_summ') {
						dataObject = dataObject.concat('Total: ' + $(this).text() + '; ');
					}

					if (this.tagName == 'billing_amount') {
						dataObject = dataObject.concat('Bill Amt: ' + $(this).text() + '; ');
					}
				});
			});
			//    console.log(dataObject);
			return dataObject;
		},

		/**
		 * Business login on plugin wakeup (background open for sync)
		 *
		 * @param {Object} receivedData - JSON object that contain data from OFSC
		 */
		pluginWakeup: function (receivedData) {
			this._log(window.location.host + ' WAKEUP', JSON.stringify(receivedData, null, 4));

			var wakeupData = {
				pluginWakeupCount: +localStorage.getItem('pluginWakeupCount'),
				pluginWakeupMaxCount: +localStorage.getItem('pluginWakeupMaxCount'),
				pluginWakeupDontRespondOn: +localStorage.getItem('pluginWakeupDontRespondOn')
			};

			wakeupData.pluginWakeupCount = wakeupData.pluginWakeupCount + 1;

			localStorage.setItem('pluginWakeupCount', wakeupData.pluginWakeupCount);
			localStorage.setItem('pluginWakeupMaxCount', wakeupData.pluginWakeupMaxCount);
			localStorage.setItem('pluginWakeupDontRespondOn', wakeupData.pluginWakeupDontRespondOn);

			this._log(window.location.host + ' SAVE WAKEUP DATA TO LOCAL STORAGE', JSON.stringify(wakeupData, null, 4));

			if (wakeupData.pluginWakeupDontRespondOn == wakeupData.pluginWakeupCount) {
				this._log(window.location.host + ' EMULATE NOT RESPONDING PLUGIN');

				return;
			}

			if (wakeupData.pluginWakeupCount < wakeupData.pluginWakeupMaxCount) {
				setTimeout(function () {
					this._log(window.location.host + ' SLEEP. RETRY NEEDED');

					this._sendPostMessageData({
						apiVersion: 1,
						method: 'sleep',
						wakeupNeeded: true
					});
				}.bind(this), 2000);
			} else {
				setTimeout(function () {
					this._log(window.location.host + ' SLEEP. NO RETRY');

					this._sendPostMessageData({
						apiVersion: 1,
						method: 'sleep',
						wakeupNeeded: false
					});
				}.bind(this), 12000);
			}
		},

		/**
		 * Save configuration of wakeup (background open for sync) behavior for Plugin
		 * to Local Storage
		 *
		 * @private
		 */
		_saveWakeupData: function () {
			var wakeupData = {
				pluginWakeupCount: 0,
				pluginWakeupMaxCount: 0,
				pluginWakeupDontRespondOn: 0
			};

			if ($('#wakeup').is(':checked')) {
				wakeupData.pluginWakeupMaxCount = parseInt($('#repeat_count').val());

				if ($('#dont_respond').is(':checked')) {
					wakeupData.pluginWakeupDontRespondOn = parseInt($('#dont_respond_on').val());
				}
			}

			localStorage.setItem('pluginWakeupCount', wakeupData.pluginWakeupCount);
			localStorage.setItem('pluginWakeupMaxCount', wakeupData.pluginWakeupMaxCount);
			localStorage.setItem('pluginWakeupDontRespondOn', wakeupData.pluginWakeupDontRespondOn);

			this._log(window.location.host + ' SAVE WAKEUP DATA TO LOCAL STORAGE', JSON.stringify(wakeupData, null, 4));
		},

		/**
		 * Clear previous configuration of wakeup (background open for sync) behavior for Plugin
		 * from the Local Storage
		 *
		 * @private
		 */
		_clearWakeupData: function () {
			localStorage.removeItem('pluginWakeupCount');
			localStorage.removeItem('pluginWakeupMaxCount');
			localStorage.removeItem('pluginWakeupDontRespondOn');

			this._log(window.location.host + ' CLEAR WAKEUP DATA FROM LOCAL STORAGE');
		},

		initChangeOfWakeup: function (element) {

			function onWakeupChange(elem) {
				var isChecked = $(elem).is(':checked');

				if (isChecked) {
					$(element).find('#repeat_count').prop('disabled', false);
					$(element).find('#dont_respond').prop('disabled', false);

					$(element).find('#wakeup_row').removeClass('wakeup-form-row--disabled');

					onDontRespondChange($(element).find('#dont_respond'));
				} else {
					$(element).find('#repeat_count').prop('disabled', true);
					$(element).find('#dont_respond').prop('disabled', true);
					$(element).find('#dont_respond_on').prop('disabled', true);

					$(element).find('#wakeup_row').addClass('wakeup-form-row--disabled');
					$(element).find('#dont_respond_row').addClass('wakeup-form-row--disabled');
				}
			}

			function onDontRespondChange(elem) {
				var isChecked = $(elem).is(':checked');

				if (isChecked) {
					$(element).find('#dont_respond_on').prop('disabled', false);
					$(element).find('#dont_respond_row').removeClass('wakeup-form-row--disabled');
				} else {
					$(element).find('#dont_respond_on').prop('disabled', true);
					$(element).find('#dont_respond_row').addClass('wakeup-form-row--disabled');
				}
			}

			$(element).find('#wakeup').change(function (e) {
				onWakeupChange(e.target);
			});

			$(element).find('#dont_respond').change(function (e) {
				onDontRespondChange(e.target);
			});

			onWakeupChange($(element).find('#wakeup'));
		},

		initChangeOfDataItems: function () {
			//set checkboxes from local storage
			if (localStorage.getItem('dataItems')) {
				$('.data-items').attr('checked', true);
				$('.data-items-holder').show();

				var dataItems = JSON.parse(localStorage.getItem('dataItems'));


				$('.data-items-holder input').each(function () {
					if (dataItems.indexOf(this.value) != -1) {
						$(this).attr('checked', true);
					}
				});
			}

			//init handlers
			$('.data-items').on('change', function (e) {
				$('.data-items-holder').toggle();
			});
		},

		initLocalStorageOption: function (localStorageKey) {
			if (localStorage.getItem(localStorageKey) === null) {
				localStorage.setItem(localStorageKey, 'true');
			}
		},

		/**
		 * Initialization function
		 */
		init: function () {
			if (navigator.serviceWorker) {
				this._log(window.location.host + ' Service Worker is supported');
				navigator.serviceWorker.register('serviceTicket-service-worker.js').then(function (registration) {
					this._log(window.location.host + ' Service Worker is registered with scope: ' + registration.scope);
					registration.addEventListener('updatefound', function () {
						this._log(window.location.host + ' Service Worker update is found');
						var newServiceWorker = registration.installing;
						newServiceWorker.addEventListener('statechange', function () {
							switch (newServiceWorker.state) {
								case "installed":
									this._log(window.location.host + ' New Service Worker is installed');
									break;
							}
						}.bind(this));
					}.bind(this));
					navigator.serviceWorker.addEventListener('controllerchange', function () {
						this.notifyAboutNewVersion();
					}.bind(this));
					this.startApplication();
				}.bind(this), function (err) {
					this._log(window.location.host + ' Service Worker registration failed: ' + err);
					this.startApplication();
				}.bind(this));
				return;
			} else {
				this._log(window.location.host + ' Service Worker is not supported');
			}
			this.startApplication();
		},
		startApplication: function () {
			this._log(window.location.host + ' PLUGIN HAS BEEN STARTED');
			$('.back_method_select').on('change', function () {
				var selectValue = $('.back_method_select').val();
				if (
					selectValue == 'activity_by_id' ||
					selectValue == 'end_activity' ||
					selectValue == 'cancel_activity' ||
					selectValue == 'notdone_activity' ||
					selectValue == 'start_activity' ||
					selectValue == 'suspend_activity' ||
					selectValue == 'delay_activity'
				) {
					$('.back_activity_id').show();
				} else {
					$('.back_activity_id').val('').hide();
				}
			});

			$('.json_local_storage_toggle').on('click', function () {
				$('.json__local-storage').toggle();
			});

			$('.json_request_toggle').on('click', function () {
				$('.column-item--request').toggle();
			});

			$('.json_response_toggle').on('click', function () {
				$('.column-item--response').toggle();
			}.bind(this));


			window.addEventListener("message", this._getPostMessageData.bind(this), false);

			this.initLocalStorageOption('showHeader');
			this.initLocalStorageOption('backNavigationFlag');

			var jsonToSend = {
				apiVersion: 1,
				method: 'ready',
				sendInitData: true,
				showHeader: !!localStorage.getItem('showHeader'),
				enableBackButton: !!localStorage.getItem('backNavigationFlag')
			};

			//parse data items
			//var dataItems = JSON.parse(localStorage.getItem('dataItems'));
			var dataItems = ['resource', 'installedInventories', 'deinstalledInventories'];

			if (dataItems) {
				$.extend(jsonToSend, {
					dataItems: dataItems
				});
			}

			this._sendPostMessageData(jsonToSend);
		},
		notifyAboutNewVersion: function () {
			this._log(window.location.host + ' New Service Worker is activated. Page refresh is needed');
			var footer = document.querySelector('.footer');
			var versionNotificationElement = document.createElement('div');
			versionNotificationElement.className = 'new-version-notification';
			versionNotificationElement.innerHTML = 'New version is detected. Please reopen the page';
			footer.appendChild(versionNotificationElement);
		}
	});
	window.OfscPlugin.getVersion = function () {
		return resourcesVersion;
	};

})(jQuery);