﻿"use strict";

(function($) {
    window.OfscPlugin = function(debugMode) {
        this.debugMode = debugMode || false;
    };
    
    var authorizationB64 = '' , activityLog = ''; //SOAP to REST API conversion	
	var pluginName = 'PI-ServiceEstimate';
	
    $.extend(window.OfscPlugin.prototype, {
        /**
         * Dictionary of enums
         */
        dictionary: {
            astatus: {
                pending: {
                    label: 'pending',
                    translation: 'Pending',
                    outs: ['started', 'cancelled', 'suspended'],
                    color: '#FFDE00'
                },
                started: {
                    label: 'started',
                    translation: 'Started',
                    outs: ['complete', 'suspended', 'notdone', 'cancelled'],
                    color: '#A2DE61'
                },
                complete: {
                    label: 'complete',
                    translation: 'Completed',
                    outs: [],
                    color: '#79B6EB'
                },
                suspended: {
                    label: 'suspended',
                    translation: 'Suspended',
                    outs: [],
                    color: '#9FF'
                },
                notdone: {
                    label: 'notdone',
                    translation: 'Not done',
                    outs: [],
                    color: '#60CECE'
                },
                cancelled: {
                    label: 'cancelled',
                    translation: 'Cancelled',
                    outs: [],
                    color: '#80FF80'
                }
            },
            invpool: {
                customer: {
                    label: 'customer',
                    translation: 'Customer',
                    outs: ['deinstall'],
                    color: '#04D330'
                },
                install: {
                    label: 'install',
                    translation: 'Installed',
                    outs: ['provider'],
                    color: '#00A6F0'
                },
                deinstall: {
                    label: 'deinstall',
                    translation: 'Deinstalled',
                    outs: ['customer'],
                    color: '#00F8E8'
                },
                provider: {
                    label: 'provider',
                    translation: 'Resource',
                    outs: ['install'],
                    color: '#FFE43B'
                }
            }
        },

        mandatoryActionProperties: {},

        /**
         * Which field shouldn't be editable
         *
         * format:
         *
         * parent: {
         *     key: true|false
         * }
         *
         */
        renderReadOnlyFieldsByParent: {
            data: {
                apiVersion: true,
                method: true,
                entity: true
            },
            resource: {
                pid: true,
                pname: true,
                gender: true
            }
        },

        /**
         * Check for string is valid JSON
         *
         * @param {*} str - String that should be validated
         *
         * @returns {boolean}
         *
         * @private
         */
        _isJson: function(str) {
            try {
                JSON.parse(str);
            } catch (e) {
                return false;
            }
            return true;
        },

        /**
         * Return origin of URL (protocol + domain)
         *
         * @param {String} url
         *
         * @returns {String}
         *
         * @private
         */
        _getOrigin: function(url) {
            if (url != '') {
                if (url.indexOf("://") > -1) {
                    return 'https://' + url.split('/')[2];
                } else {
                    return 'https://' + url.split('/')[0];
                }
            }

            return '';
        },

        /**
         * Return domain of URL
         *
         * @param {String} url
         *
         * @returns {String}
         *
         * @private
         */
        _getDomain: function(url) {
            if (url != '') {
                if (url.indexOf("://") > -1) {
                    return url.split('/')[2];
                } else {
                    return url.split('/')[0];
                }
            }

            return '';
        },
		//added for MPF Phase 4 - CHG0069304
		_getDomainURL: function() {
			//return document.referrer.match(/\:\/\/([^\/]+)\.etadirect\.com\//)[1];
			//Reg Ex modified to handle both etadirect.com and fs.ocs.oraclecloud.com URLs
			return document.referrer.match(/\:\/\/([^\/]+)\.(?:etadirect.com|fs.ocs.oraclecloud.com)/)[1];
		},
		//
        /**
         * Sends postMessage to document.referrer
         *
         * @param {Object} data - Data that will be sent
         *
         * @private
         */
        _sendPostMessageData: function(data) {
            var originUrl = document.referrer || (document.location.ancestorOrigins && document.location.ancestorOrigins[0]) || '';

            if (originUrl) {
                this._log(window.location.host + ' -> ' + data.method + ' ' + this._getDomain(originUrl), JSON.stringify(data, null, 4));

                parent.postMessage(data, this._getOrigin(originUrl));
            } else {
                this._log(window.location.host + ' -> ' + data.method + ' ERROR. UNABLE TO GET REFERRER');
            }
        },

        /**
         * Handles during receiving postMessage
         *
         * @param {MessageEvent} event - Javascript event
         *
         * @private
         */
        _getPostMessageData: function(event) {

            if (typeof event.data === 'undefined') {
                this._log(window.location.host + ' <- NO DATA ' + this._getDomain(event.origin), null, null, true);

                return false;
            }

            if (!this._isJson(event.data)) {
                this._log(window.location.host + ' <- NOT JSON ' + this._getDomain(event.origin), null, null, true);

                return false;
            }

            var data = JSON.parse(event.data);

            if (!data.method) {
                this._log(window.location.host + ' <- NO METHOD ' + this._getDomain(event.origin), null, null, true);

                return false;
            }

            this._log(window.location.host + ' <- ' + data.method + ' ' + this._getDomain(event.origin), JSON.stringify(data, null, 4));

            switch (data.method) {
                case 'init':
                    this.pluginInitEnd(data);
                    break;

                case 'open':
                    this.pluginOpen(data);
                    break;

                case 'wakeup':
                    this.pluginWakeup(data);
                    break;

                case 'error':
                    data.errors = data.errors || {
                        error: 'Unknown error'
                    };
                    this._showError(data.errors);
                    break;

                default:
                    this._log(window.location.host + ' <- UNKNOWN METHOD: ' + data.method + ' ' + this._getDomain(event.origin), null, null, true);
                    break;
            }
        },

        /**
         * Show alert with error
         *
         * @param {Object} errorData - Object with errors
         *
         * @private
         */
        _showError: function(errorData) {
            alert(JSON.stringify(errorData, null, 4));
        },

        /**
         * Logs to console
         *
         * @param {String} title - Message that will be log
         * @param {String} [data] - Formatted data that will be collapsed
         * @param {String} [color] - Color in Hex format
         * @param {Boolean} [warning] - Is it warning message?
         *
         * @private
         */
        _log: function(title, data, color, warning) {
            if (!this.debugMode) {
                return;
            }
            if (!color) {
                color = '#0066FF';
            }
            if (!!data) {
                console.groupCollapsed('%c[Plugin API] ' + title, 'color: ' + color + '; ' + (!!warning ? 'font-weight: bold;' : 'font-weight: normal;'));
                console.log('[Plugin API] ' + data);
                console.groupEnd();
            } else {
                console.log('%c[Plugin API] ' + title, 'color: ' + color + '; ' + (!!warning ? 'font-weight: bold;' : ''));
            }
        },

        /**
         * Business login on plugin init
         */
        saveToLocalStorage: function(data) {
            this._log(window.location.host + ' INIT. SET DATA TO LOCAL STORAGE', JSON.stringify(data, null, 4));

            if (data.attributeDescription) {
                localStorage.setItem('pluginInitData', JSON.stringify(data.attributeDescription));
            }
        },

        /**
         * Business login on plugin init end
         *
         * @param {Object} data - JSON object that contain data from OFSC
         */
        pluginInitEnd: function(data) {
            this.saveToLocalStorage(data);

            var messageData = {
                apiVersion: 1,
                method: 'initEnd'
            };

            if (localStorage.getItem('pluginWakeupCount') < localStorage.getItem('pluginWakeupMaxCount')) {
                this._log(window.location.host + ' UNFINISHED WAKEUP DATA FOUND IN LOCAL STORAGE');

                messageData.wakeupNeeded = true;
            }

            this._sendPostMessageData(messageData);
        },

        /**
         * Business login on plugin open
         *
         * @param {Object} receivedData - JSON object that contain data from OFSC
         */
        pluginOpen: function(receivedData) {
			
			//start of CHG0076763 Prevent billing updates on the Service Estimate
			//by Neha Singh
				var installTypeList = ["3PL Install", "3PL Install/Deinstall", "Assist - Install", "Delivery Install", "Delivery Install/Deinstall", "Tech Install", "Tech Install/Deinstall", "Remote Install", "Remote Install/Deinstall"];
				var IntallCallValue = receivedData.activity.A_TASK_TYPE;				
				var isIntallCall = installTypeList.indexOf(IntallCallValue)>-1;
				console.log("Activity Task type is "+ IntallCallValue);
				console.log("Activity Task Type value matches with array [installTypeList] or no "+ isIntallCall);
			//End of CHG0076763 Prevent billing updates on the Service Estimate

			// Changes start for CHG0069304
        	var domainName = this._getDomainURL();
        	console.log("Domain Name - "+domainName);
        	var errorLogs = receivedData.activity.A_PLUGIN_ERROR_LOG;
        	var activityId = receivedData.activity.aid;
			// Changes end for CHG0069304
            // Base 64 encryption for REST API calls
            var headers = {
				'Authorization':
					'Basic ' + btoa(receivedData.securedData.clientId + "@" + domainName + ":" + receivedData.securedData.clientSecret)
			};
            
			$.ErrorUpdate = function(activityId,sErrorLogs) {
				 
				this._sendPostMessageData({
						"apiVersion": 1,
						"method": "update",
						"activity": {
							"A_PLUGIN_ERROR_LOG": sErrorLogs,
							"aid": activityId
						}
						
				});
			 }.bind(this);

			var ultimateBind = this;
            this._clearWakeupData();
            if (localStorage.getItem('pluginInitData')) {
                this._log(window.location.host + ' OPEN. GET DATA FROM LOCAL STORAGE', JSON.stringify(JSON.parse(localStorage.getItem('pluginInitData')), null, 4));
                $('.json__local-storage').text(JSON.stringify(JSON.parse(localStorage.getItem('pluginInitData')), null, 4));
            }
            this.initChangeOfWakeup(document);
            this.initChangeOfDataItems();
			    // Get the content of the DD value Divs need to append to TD.
            this.QtyDDSection = $("#QtyDDSection").html();
            this.billingReasonDDSection = $("#billingReasonDDSection").html();
            this.billingAmountUndoSection = $("#billingAmountUndoSection").html();
            //inventoryList
            var inventoryList = receivedData.inventoryList;
            
			
            var g_totLbrPrice = 0;
            var g_LockRows = false;
            var g_current_pass_count = 1;
            
            // Current Date Time Section:
            var TodayDate = new Date();
            var year = TodayDate.getYear().toString().substr(-2);
            var day = TodayDate.getDate(); //it returns the date 
            day = ("0" + day).slice(-2);
            var month = TodayDate.getMonth() + 1;
            month = ("0" + month).slice(-2);
            var hours = TodayDate.getHours();
            hours = ("0" + hours).slice(-2);
            var minutes = TodayDate.getMinutes();
            minutes = ("0" + minutes).slice(-2);
            var date_MM_DD = month + "-" + day;
			
            var date_MM_DD_YY = month + "/" + day + "/" + year;
            var date_MM_DD_YY_hypen = month + "-" + day + "-" + year;
            var date_YYYY_MM_DD = TodayDate.getFullYear().toString() + "-" + month + "-" + day;
            var currDateTimeFormat = TodayDate.getFullYear().toString() + "-" + month + "-" + day + " " + hours + ":" + minutes;
            var currdateTime = date_MM_DD_YY + " " + hours + ":" + minutes;
            var currdateTime_hypen = date_MM_DD_YY_hypen + " " + hours + ":" + minutes;
            var showExtraLaborRow = false;
			
				// Timezone calculation based on user:
			// $.urlParam = function(name) {
			// 	try{
	        //         var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
	        //         return results[1] || 0;
			// 	}
			// 	catch(err){
			// 		activityLog = activityLog + ';Exception in urlParam:'+err.message;
			// 		console.log(" Exception in urlParam :"+err.message);
			// 		return '';
			// 	}
            // }
			var timeZoneName = receivedData.resource.time_zone; 
			//var timeZoneName = decodeURIComponent($.urlParam('timezone'));
                //console.log('timeZoneName:', timeZoneName);

				var TimeZoneMapping = {
					"19": "Alaska",
					"6": "Arizona",
					"4": "Central",
					"2": "Eastern",
					"15": "GMT",
					"17": "Hawaii (Adak)",
					"18": "Hawaii (Honolulu)",
					"5": "Mountain",
					"7": "Pacific"
				};
													
				var timeOffset = {
					'Alaska':9,
					'dAlaska':8,
					'Arizona':7,
					'dArizona':7,
					'Central':6,
					'dCentral':5,
					'Eastern':5,
					'dEastern':4,
					'GMT':0,
					'dGMT':0,
					'Hawaii(Adak)':10,
					'dHawaii(Adak)':10,
					'Hawaii(Honolulu)':10,
					'dHawaii(Honolulu)':10,
					'Mountain':7,
					'dMountain':6,
					'Pacific':8,
					'dPacific':7
				}
				

				var timeZone = TimeZoneMapping[timeZoneName];
				
				Date.prototype.stdTimezoneOffset = function() {
					var jan = new Date(this.getFullYear(), 0, 1);
					var jul = new Date(this.getFullYear(), 6, 1);
					return Math.max(jan.getTimezoneOffset(), jul.getTimezoneOffset());
				}
				
				Date.prototype.dst = function() {
					return this.getTimezoneOffset() < this.stdTimezoneOffset();
				}
				
				var today = new Date();
				if(today.dst()){
					var timeZoneId = timeOffset['d'+timeZone.replace(' ','')];
				}else{
					var timeZoneId = timeOffset[timeZone.replace(' ','')];
				}

				var indainDateObj = new Date();
				indainDateObj.setHours(indainDateObj.getHours() - timeZoneId);
				var aCurrTime = indainDateObj.toISOString();
				console.log("aCurrTime -"+aCurrTime);
			//
            // get the Billing Info XML field-           
            // set the Top section general Information:

            $("#sr_ref_num").text(receivedData.activity.A_SR_NUMBER);
            $("#model_number").text(receivedData.activity.A_MODEL);
            $("#serial_number").text(receivedData.activity.A_SERIAL);
            $("#equipment_number").text(receivedData.activity.A_EQUIPMENT_NUMBER);

            $("#employee_number").text(receivedData.resource.R_EMPLOYEE_NUMBER);
            $("#resource_name").text(receivedData.resource.pname);

            //Customer Section:
            $("#contact_name").text(receivedData.activity.cname);
            $("#contact_address").text(receivedData.activity.caddress);
            $("#a_contact").text(receivedData.activity.A_CONTACT);
            $("#contract_flag").text(receivedData.activity.A_CONTRACT_FLAG);
            $("#po_number").val(receivedData.activity.A_PO_NUMBER);
			
			var poRequiredFlag = receivedData.activity.A_PO_REQUIRED;
			
			if(poRequiredFlag && poRequiredFlag == 'Y' ){
				poRequiredFlag = true;
			}else{
				poRequiredFlag = false;
				
			}
			if(poRequiredFlag){
				
				// display asterik on page:
				$("#po_number_asterik").removeClass("cp_hidden");
			}
			
			$("#po_number").on("input",function(e){
				 
				  var enteredPONum = $(this).val();
				  var len = enteredPONum.length;
					
					if(len > 20){
						 enteredPONum = enteredPONum.slice(0, 20);
						// alert(enteredPONum+" value too large. Restricting to first 20 characters."); 
						  $(this).val(enteredPONum);
					} 
			});
			
			
            //Date Formatted #completion_date --11/20/17 00:19
           var arrival_date = receivedData.activity.A_DISPATCH_TIME;//A_START_TIME_OVERRIDE;
			var eta_Time = (receivedData.activity.ETA)?receivedData.activity.ETA:"";
			var completion_date = (receivedData.activity.A_SCAN_OUT_TIME_OVERRIDE)?receivedData.activity.A_SCAN_OUT_TIME_OVERRIDE:aCurrTime;//currdateTime;
			console.log("arrival_date " +arrival_date);
			var startTimeVal = receivedData.activity.A_START_TIME_OVERRIDE
			
            if((startTimeVal !== undefined) && startTimeVal != null && startTimeVal != ""){
				var mom = moment.utc(startTimeVal);
				$("#arrival_date").text(mom.format('MM/DD/YY HH:mm'));
				
			}else if ((arrival_date !== undefined) && arrival_date != null && arrival_date != "") {
                 arrival_date = arrival_date.substr(0,10);
				var mom = moment.utc(arrival_date);
			     console.log('format '+mom.format('MM/DD/YY'));
				 arrival_date = mom.format('MM/DD/YY');			
				 $("#arrival_date").text(arrival_date+" "+eta_Time);
				 
            }      
           var completion_date = "";
			if(receivedData.activity.A_SCAN_OUT_TIME_OVERRIDE)
			{
				completion_date = receivedData.activity.A_SCAN_OUT_TIME_OVERRIDE;
			    completion_date = completion_date.replace(/\.[0-9]+Z/g, '');
				completion_date = completion_date.replace(/T/g, ' ');
				var secondsPresent = completion_date.match(/\d{2}:\d{2}:\d{2}/g);
				if(secondsPresent){
				  
				  completion_date = completion_date.slice(0, -3);
				}
				
				var unformattedCompDate = completion_date.substr(0,10);
				var mom = moment.utc(formattedCompDate);			   
				var formattedCompDate = mom.format('MM/DD/YY');
			completion_date = completion_date.replace(unformattedCompDate,formattedCompDate);
			$("#completion_date").text(completion_date); 
			
			
			}else{
				var mom = moment.utc(aCurrTime);			   
				aCurrTime = mom.format('MM/DD/YY HH:mm');
			 
			$("#completion_date").text(aCurrTime);
			}          

            //MeterInformation
            var blacknwhitemeter = receivedData.activity.A_COUNTER_BLACK_WHITE;
            var colormeter = receivedData.activity.A_COUNTER_COLOR;
            var totalmeter = receivedData.activity.A_COUNTER_TOTAL;
            var scanning = receivedData.activity.A_COUNTER_SCANNING;

            //A_COUNTER_BLCK_WHITE IS NOT EMPTY AND A_COUNTER_BLCK_WHITE>0
            if (blacknwhitemeter != "" && blacknwhitemeter > 0) {
                $("#blacknwhitemeterSection").removeClass("cp_hidden");
                $("#blacknwhitemeter").text(blacknwhitemeter);
            }
            if (colormeter != "" && colormeter > 0) {
                $("#colormeterSection").removeClass("cp_hidden");
                $("#colormeter").text(colormeter);
            }
            if (totalmeter != "" && totalmeter > 0) {
                $("#totalmeterSection").removeClass("cp_hidden");
                $("#totalmeter").text(totalmeter);
            }
            if (scanning != "" && scanning > 0) {
                $("#scanningSection").removeClass("cp_hidden");
                $("#scanning").text(scanning);
            }

            // Signature Section.
            var sigdiv = $("#signature");
			
            sigdiv.signature();
            var onloadedEmptySignatureBlock = sigdiv.signature('toDataURL');
            $('#clear_btn').click(function() {
                //alert(sigdiv.signature('toDataURL'));
                // console.log('signature' + sigdiv.signature('toDataURL'));
                sigdiv.signature('clear');
            });
			var canvas = document.getElementsByTagName("canvas")[0];
			var ctx = canvas.getContext("2d");
			ctx.strokeStyle = "#222222";
			ctx.lineWith = 2;
			// Set up mouse events for drawing
			var drawing = false;
			var mousePos = { x:0, y:0 };
			var lastPos = mousePos;
			canvas.addEventListener("mousedown", function (e) {
					drawing = true;
					 jQuery(':focus').blur(); //Change done for INC1505018
			  lastPos = getMousePos(canvas, e);
			}, false);
			canvas.addEventListener("mouseup", function (e) {
			  drawing = false;
			}, false);
			canvas.addEventListener("mousemove", function (e) {
			  mousePos = getMousePos(canvas, e);
			}, false);

			// Get the position of the mouse relative to the canvas
			function getMousePos(canvasDom, mouseEvent) {
				try{
				  var rect = canvasDom.getBoundingClientRect();
				  return {
					x: mouseEvent.clientX - rect.left,
					y: mouseEvent.clientY - rect.top
				  };
				}
				catch(err){
					activityLog = activityLog + ';Exception in getMousePos:'+err.message;
					console.log(" Exception in getMousePos :"+err.message);
				} 
			}
			// Get a regular interval for drawing to the screen
			window.requestAnimFrame = (function (callback) {
				try{
					return window.requestAnimationFrame || 
					   window.webkitRequestAnimationFrame ||
					   window.mozRequestAnimationFrame ||
					   window.oRequestAnimationFrame ||
					   window.msRequestAnimaitonFrame ||
					   function (callback) {
					window.setTimeout(callback, 1000/60);
					   };
				}
				catch(err){
					activityLog = activityLog + ';Exception in window.requestAnimFrame callback:'+err.message;
					console.log(" Exception in window.requestAnimFrame callback :"+err.message);
				} 
			})();
			// Draw to the canvas
			function renderCanvas() {
				try{
					  if (drawing) {
						ctx.moveTo(lastPos.x, lastPos.y);
						ctx.lineTo(mousePos.x, mousePos.y);
						ctx.stroke();
						lastPos = mousePos;
					  }
				}
				catch(err){
					activityLog = activityLog + ';Exception in renderCanvas :'+err.message;
					console.log(" Exception in renderCanvas :"+err.message);
				} 
			}

			// Allow for animation
			(function drawLoop () {
			  requestAnimFrame(drawLoop);
			  renderCanvas();
			})();
			canvas.addEventListener("touchstart", function (e) {
				 jQuery(':focus').blur();    //Change done for INC1505018
			mousePos = getTouchPos(canvas, e);
			var touch = e.touches[0];
			var mouseEvent = new MouseEvent("mousedown", {
			clientX: touch.clientX,
			clientY: touch.clientY
			});
			canvas.dispatchEvent(mouseEvent);
			}, false);
			canvas.addEventListener("touchend", function (e) {
			var mouseEvent = new MouseEvent("mouseup", {});
			canvas.dispatchEvent(mouseEvent);
			}, false);
			canvas.addEventListener("touchmove", function (e) {
			var touch = e.touches[0];
			var mouseEvent = new MouseEvent("mousemove", {
			clientX: touch.clientX,
			clientY: touch.clientY
			});
			canvas.dispatchEvent(mouseEvent);
			}, false);

			// Get the position of a touch relative to the canvas
			function getTouchPos(canvasDom, touchEvent) {
				try{
					var rect = canvasDom.getBoundingClientRect();
					return {
					x: touchEvent.touches[0].clientX - rect.left,
					y: touchEvent.touches[0].clientY - rect.top
					};
				}
				catch(err){
					activityLog = activityLog + ';Exception in getTouchPos :'+err.message;
					console.log(" Exception in getTouchPos :"+err.message);
				} 
			}
			document.body.addEventListener("touchstart", function (e) {
				
				var canvas = document.getElementsByTagName("canvas")[0];
			  if (e.target == canvas) {
				e.preventDefault();
			  }
			}, false);
			document.body.addEventListener("touchend", function (e) {
				var canvas = document.getElementsByTagName("canvas")[0];
			  if (e.target == canvas) {
				e.preventDefault();
			  }
			}, false);
			document.body.addEventListener("touchmove", function (e) {
				var canvas = document.getElementsByTagName("canvas")[0];
			  if (e.target == canvas) {
				e.preventDefault();
			  }
			}, false);
			
			if(receivedData.activity.A_CONTACT){
				$("#signeeName").val(receivedData.activity.A_CONTACT); 
			}else{
				if(receivedData.activity.A_SE_SIGNEE_NAME){
					$("#signeeName").val(receivedData.activity.A_SE_SIGNEE_NAME); 
				}
			}
			
			if(receivedData.activity.A_CUSTOMER_CONTACT_EMAIL){
				$("#signeeEmail").val(receivedData.activity.A_CUSTOMER_CONTACT_EMAIL); 
			}else{
				if(receivedData.activity.A_SE_SIGNEE_EMAIL){
					$("#signeeEmail").val(receivedData.activity.A_SE_SIGNEE_EMAIL); 
				}
			}
			
			
			$("#signeeName").on("input",function(e){
				 try{
					  var enteredName = $(this).val();
					  var len = enteredName.length;
						
						if(len > 50){
							 enteredName = enteredName.slice(0, 50);
							 //alert(enteredName+" value too large. Restricting to first 50 characters."); 
							  $(this).val(enteredName);
						} 
				  }
				  catch(err){
					activityLog = activityLog + ';Exception in signeeName input:'+err.message;
					console.log(" Exception in signeeName input :"+err.message);
				  } 
			});
			$("#signeeEmail").on("input",function(e){
				  try{
					  var enteredEmail = $(this).val();
					  var len = enteredEmail.length;
						
						if(len > 50){
							 enteredEmail = enteredEmail.slice(0, 50);
							// alert(enteredEmail+" value too large. Restricting to first 50 characters."); 
							  $(this).val(enteredEmail);
						}
				    }
					catch(err){
						activityLog = activityLog + ';Exception in signeeEmail input:'+err.message;
						console.log(" Exception in signeeEmail input :"+err.message);
					} 
			});
			if(receivedData.activity.A_SE_BILLING_COMMENT){
			$("#probWorkPerformed").text(receivedData.activity.A_SE_BILLING_COMMENT);
			}

            var se_billing_info = receivedData.activity.A_SE_BILLING_INFO;
            var se_billing_info_xml = "";
			var a_billing_info = receivedData.activity.A_BILLING_INFO;
            var st_billing_info_xml = "";
			
			if(a_billing_info){
				a_billing_info = receivedData.activity.A_BILLING_INFO;
				
			}else{
				a_billing_info = false;
			}
			
			
            var se_expenses_plugin = receivedData.activity.A_SE_EXPENSES_PLUGIN; //A_se_expenses_plugin;
            var rowCount = 0;
            var aContractFlag = receivedData.activity.A_CONTRACT_FLAG;
            var aSElaborTime = receivedData.activity.A_SE_LABOR_TIME;
            if (!((aSElaborTime !== undefined) && aSElaborTime != null && aSElaborTime != "")) {
                aSElaborTime = 1;
            }
            var materialFee = parseFloat(receivedData.activity.A_MATERIAL_FEE).toFixed(2);
            if (isNaN(materialFee) || materialFee == "") {
                materialFee = "0.00";
            }
           /* if (aContractFlag) {
                materialFee = "0.00";
            }*/

            var isBillingInfohasValue = false;
            if (aContractFlag == 'Y') {
                aContractFlag = true;
            } else {
                aContractFlag = false;
            }

            var laborRate = parseFloat(receivedData.activity.A_LABOR_RATE);
			
			  if (isNaN(laborRate)) {
                            laborRate = 0;
            }
            var afterHrsLaborRate = parseFloat(receivedData.activity.A_AFTR_HRS_LABOR_RATE);
			  if (isNaN(afterHrsLaborRate)) {
                            afterHrsLaborRate = 0;
                        }
            //create XML elements:

            $.createElement = function(name, value) {
            	try{
	                var temp = document.createElementNS(name, name);
	                if (value !== undefined) {
	                    temp.innerHTML = value;
	                }
	                return temp;
            	}
				catch(err){
					activityLog = activityLog + ';Exception in createElement :'+err.message;
					console.log(" Exception in createElement :"+err.message);
				} 
            };

            var $se_billing_info_firstLoadXml = $('<XMLDocument />');
            var $se_billing_info_billInfo = $.createElement('billingInfo');
            var $se_billing_info_billItems = $.createElement('billingItems');


            $.recalculateBillAmountTotal = function() {
            	try{
	                var billingAmt = 0;
	               // console.log('billingAmt' + billingAmt);
	                $('table tr.billing-items-grid-row').each(function() {
	                    //  alert("row");											
	                    $(this).find('.cpf_inner_overriden_val').each(function() {
	                        var billAmt = $(this).val();
							billAmt = parseFloat(billAmt);
	                       // console.log('billAmt calc ' + billAmt);
	
	                        if (!isNaN(billAmt)) {
	                            billingAmt += parseFloat(billAmt);
	                         //   console.log('summed up-' + billingAmt);
	                        }
	                    });
	                });
	                // Update the total.
	                $(".billAmt_total").text("$ " + billingAmt.toFixed(2));
	                // Update the total excluding the taxes.
	                $("#cpf_TotalExcludingTaxes_inner").text("$ " + billingAmt.toFixed(2));
            	}
				catch(err){
					activityLog = activityLog + ';Exception in recalculateBillAmountTotal :'+err.message;
					console.log(" Exception in recalculateBillAmountTotal :"+err.message);
				} 
            };

            // calculate the ext Price column- 
            $.recalculateExtPriceTotal = function() {
            	try{
	                var extOverPrice = 0;
	
	                $('table tr.billing-items-grid-row').each(function() {
	
	                    $(this).find('.ext-price').each(function() {
	                        var extOverP = $(this).text();
	                        extOverP = extOverP.replace("$", "");
	                        extOverP = $.trim(extOverP);
	                        extOverP = parseFloat(extOverP);
	                        if (!isNaN(extOverP) && extOverP.length !== 0) {
	                            extOverPrice += extOverP;
	                        }
	                    });
	
	
	                });
	                var ext_price_total = extOverPrice.toFixed(2);
	
	                $("#ext_price_Total").text("$ " + ext_price_total);
	            }
				catch(err){
					activityLog = activityLog + ';Exception in recalculateExtPriceTotal :'+err.message;
					console.log(" Exception in recalculateExtPriceTotal :"+err.message);
				} 
            };

            $.generateExpenseRowsPlugin = function(se_expenses_plugin,expenseItemNumXMLArr,expenseDate,g_ShowDuplicateItems) {
            	try{
	                var $se_billing_expenseItems;
	                // To generate the expenses xml rows:begin
	                if ((se_expenses_plugin != null) && (se_expenses_plugin !== undefined )) {
	                    var findme = "&gt;";
	                    if (se_expenses_plugin.indexOf(findme) > -1) {
	                        se_expenses_plugin = $("<div />").html(se_expenses_plugin).text(); // to decode the lt gt;
	                    }
	
	
	                    se_expenses_pluginXml = '<ExpenseOutBound>' + se_expenses_plugin + '</ExpenseOutBound>';
	                    var se_expenses_plugin_xmlDoc = $.parseXML(se_expenses_pluginXml);
	                    var se_expenses_pluginXml = $(se_expenses_plugin_xmlDoc);
	                    var expenseType, quantity, origBillamount, OvrPrice, OvrPriceReason, isOverriden, date, expenseSection, expenseLabel, expenseTypeInfo;
						var  bill_reason_code = "";
	
	                    se_expenses_pluginXml.find('ExpenseOutBound').find('DebriefExpenseLine').each(function() {
	
	                        $(this).children().each(function() {
	                            var tagNam = this.tagName;
	
	                            if (tagNam == "A_EXPENSE_TYPE") {
	                                expenseType = $(this).text();
	                            }
	                            if (tagNam == "A_QUANTITY") {
	                                quantity = $(this).text();
	                            }
	                            if (tagNam == "A_AMOUNT") {
	                                origBillamount = $(this).text();
	                            }
	                            if (tagNam == "A_OVERRIDE_PRICE") {
	                                OvrPrice = $(this).text();
	                                if (OvrPrice == "" || parseFloat(OvrPrice) == 0) {
	                                    OvrPrice = origBillamount;
	                                }
	                            }
	                            if (tagNam == "A_PRICE_OVERRIDE_REASON_CODE") {
	                                OvrPriceReason = $(this).text();
	
	                            }
	
	                            if (tagNam == "A_EXPENSE_SECTION") {
	                                expenseSection = $(this).text(); // reimbursable_expenses_type, chargeable_activities_type, activities_type
	                            }
	
	                            if (tagNam == "A_EXPENSE_LABEL") {
	                                expenseLabel = $(this).text();
	                            }
	
	                            if (origBillamount != OvrPrice) {
									
									 if (aContractFlag && parseFloat(OvrPrice) > 0) {
	
	                                     isOverriden = "Y";
									 }else{
										  isOverriden = "N";
									 }
	                            } else {
	
	                                isOverriden = "N";
	                            }
	                        });
	                        // rowCount += 1;
	                        if (expenseSection == "reimbursable_expenses_type") {
	                            if (aContractFlag) {
	                                OvrPriceReason = "";
	                                OvrPrice = 0.00;
	                            } else {
									bill_reason_code = "Not Covered By Contract";
	                                OvrPriceReason = "Not Covered By Contract";
	                            }
	                            expenseTypeInfo = "reimbursable";
	
	                        } else if (expenseSection == "chargeable_activities_type") {
	                            if (aContractFlag) {
	                                OvrPriceReason = "";
	                                OvrPrice = 0.00;
	                            } else {
									bill_reason_code = "E01-Billable";
	                                OvrPriceReason = "Standard Billable";
	                            }
	                            expenseTypeInfo = "training";
	                        } else if (expenseSection == "service_advantage_chargeable_activities_type") { //service_advantage_chargeable_activities_type
	                            if (aContractFlag) {
	                                OvrPriceReason = "";
	                                OvrPrice = 0;
	                            } else {
									bill_reason_code = "E01-Billable";
	                                OvrPriceReason = "Standard Billable";
	                            }
	                            expenseTypeInfo = "service advantage chargeable activities";
	                        } else if (expenseSection == "cbm_activities_type") {  //CHG0067765 Condition Based Maintenance
	                        	/*if (aContractFlag) {
	                                OvrPriceReason = "";
	                                OvrPrice = 0;
	                            } else {
									bill_reason_code = "E01-Billable";
	                                OvrPriceReason = "Standard Billable";
	                            }*/
	                        	OvrPriceReason = "na";
	                        	expenseTypeInfo = "condition based maintainance";
	                        } else {
	                            OvrPriceReason = "na";
	                            expenseTypeInfo = "activities";
	                        }
							
							    var isPresent = $.inArray(expenseType, expenseItemNumXMLArr);
								/*var changeInDate = false;
								if(expenseDate != date_MM_DD){
									
									changeInDate = true;
									
								}*/
	
	                             if (expenseItemNumXMLArr.length > 0 && !(isPresent == -1) && !g_ShowDuplicateItems){
									// value present in XML dont do anything.
								}else{
									// This expense not present in XML -- process and add to table.
									var $se_billing_info_Expenses = $.createElement('expense');
									$se_billing_info_Expenses.append($.createElement('key', currDateTimeFormat + " " + expenseType));
									$se_billing_info_Expenses.append($.createElement('date',date_MM_DD));
									$se_billing_info_Expenses.append($.createElement('quantity', quantity));
									$se_billing_info_Expenses.append($.createElement('quantity_unit', 'hrs'));
									$se_billing_info_Expenses.append($.createElement('prod_number', expenseType));
									$se_billing_info_Expenses.append($.createElement('name', expenseLabel));
									$se_billing_info_Expenses.append($.createElement('price', origBillamount));
									$se_billing_info_Expenses.append($.createElement('price_summ', origBillamount));
									$se_billing_info_Expenses.append($.createElement('is_overriden', isOverriden));
									$se_billing_info_Expenses.append($.createElement('billing_amount', OvrPrice));
									$se_billing_info_Expenses.append($.createElement('billing_reason', bill_reason_code));
									$se_billing_info_Expenses.append($.createElement('billing_reason_title', OvrPriceReason));
									$se_billing_info_Expenses.append($.createElement('expense_type', expenseTypeInfo));
									$se_billing_info_Expenses.append($.createElement('pass_count', g_current_pass_count));
									$se_billing_info_billItems.append($se_billing_info_Expenses);
							}
	                    });
	                }
	                return $se_billing_info_billItems;
	            }
				catch(err){
					activityLog = activityLog + ';Exception in generateExpenseRowsPlugin :'+err.message;
					console.log(" Exception in generateExpenseRowsPlugin :"+err.message);
				} 
            };

            $.generateLaborRows = function(extraRow) {
            	try{
	                var payCode = receivedData.resource.P_PAYCODE;
	                var laborRate = parseFloat(receivedData.activity.A_LABOR_RATE);
					if(isNaN(laborRate)){
						laborRate = 0;
					}
	                var afterHrsLaborRate = parseFloat(receivedData.activity.A_AFTR_HRS_LABOR_RATE);
						if(isNaN(afterHrsLaborRate)){
						afterHrsLaborRate = 0;
					}
	                var name, quantity = aSElaborTime,
	                    quantity_unit = "hrs",
	                    prod_number = "standard",
	                    price = "",
	                    price_summ = "",
	                    billing_amount = "",
	                    billing_reason_title = "";
						
						if(extraRow){
							//additional row --
							quantity = 1;
							
						}else{
							//first row
							quantity = aSElaborTime;
						}
	                /*
	                "CLOCK": {
	                "text": "REGULAR SHIFT"
	                },
	                "CALL_IN_IO": {
	                "text": "ON CALL"
	                */
	                if (payCode == "CLOCK") { //"REGULAR SHIFT"
	                    name = "Labor – Regular Hours";
	                    if (laborRate != "" && !isNaN(laborRate) && laborRate != null) {
	                        price = parseFloat(quantity * laborRate).toFixed(2);
	
	                    } else {
	                        price = "0.00";
	                    }
	                } 
	                if (payCode == "CALL_IN_IO") { //ON CALL
	                    name = "Labor – After Hours";
	
	                    if (afterHrsLaborRate != "" && !isNaN(afterHrsLaborRate) && afterHrsLaborRate != null) {
	                        price = parseFloat(quantity * afterHrsLaborRate).toFixed(2);
	
	                    } else {
	                        price = "0.00";
	                    }
	                }
	                price_summ = price;
	                if (aContractFlag) {
	                    billing_amount = 0.00;
	                } else {
	                    billing_amount = price;
	                }
	                var $se_billing_info_labor = $.createElement('labor');
	                $se_billing_info_labor.append($.createElement('key'));
	                $se_billing_info_labor.append($.createElement('date',date_MM_DD));
	                $se_billing_info_labor.append($.createElement('quantity', quantity));
	                $se_billing_info_labor.append($.createElement('quantity_unit', quantity_unit));
	                $se_billing_info_labor.append($.createElement('prod_number', prod_number));
	                $se_billing_info_labor.append($.createElement('name', name));
	                $se_billing_info_labor.append($.createElement('price', price));
	                $se_billing_info_labor.append($.createElement('price_summ', price_summ));
	                $se_billing_info_labor.append($.createElement('is_overriden'));
	                $se_billing_info_labor.append($.createElement('billing_amount', billing_amount));
	                $se_billing_info_labor.append($.createElement('billing_reason'));
	                $se_billing_info_labor.append($.createElement('billing_reason_title'));
					
									
	
	                $se_billing_info_billItems.append($se_billing_info_labor);
	
	                return $se_billing_info_billItems;
	            }
				catch(err){
					activityLog = activityLog + ';Exception in generateLaborRows :'+err.message;
					console.log(" Exception in generateLaborRows :"+err.message);
				} 
            };

            //If se_billing_info is empty generate a same xml format with getting the values from different places.

            if (se_billing_info == null || se_billing_info == "" || (se_billing_info === undefined)) {
                //function call to generate labor row:

                var $genLaborRows = $.generateLaborRows(false);

                //Create the XML for Total Labour.
                var name, quantity = "1",
                    quantity_unit = "hrs",
                    prod_number = "standard",
                    price = "",
                    price_summ = "",
                    billing_amount = "",billing_reason ="";
                    billing_reason_title = "";			
					
					
				  if (!aContractFlag) {

					  billing_reason = 'L01';
					  billing_reason_title ='Standard Billable';
				  }

                var $se_billing_info_Totlabor = $.createElement('total_labor');
                $se_billing_info_Totlabor.append($.createElement('key'));
                $se_billing_info_Totlabor.append($.createElement('date'));
                $se_billing_info_Totlabor.append($.createElement('quantity', '1'));
                $se_billing_info_Totlabor.append($.createElement('quantity_unit', quantity_unit));
                $se_billing_info_Totlabor.append($.createElement('prod_number'));
                $se_billing_info_Totlabor.append($.createElement('name', 'Total Labor'));
                $se_billing_info_Totlabor.append($.createElement('price', price));
                $se_billing_info_Totlabor.append($.createElement('price_summ', price_summ));
                $se_billing_info_Totlabor.append($.createElement('is_overriden'));
                $se_billing_info_Totlabor.append($.createElement('billing_amount', billing_amount));
                $se_billing_info_Totlabor.append($.createElement('billing_reason',billing_reason ));
                $se_billing_info_Totlabor.append($.createElement('billing_reason_title', billing_reason_title));


                $se_billing_info_billItems.append($se_billing_info_Totlabor);


                //Create the XML for Material Handling fee:
				
				if (aContractFlag) {
                    billing_reason = "Contract";
					billing_reason_title = "Contract";
                } else {
                    billing_reason ="No_contract";
					billing_reason_title = "No contract";
                }



                var $se_billing_info_Material = $.createElement('material_handling_fee');
                $se_billing_info_Material.append($.createElement('key'));
                $se_billing_info_Material.append($.createElement('date',date_MM_DD));
                $se_billing_info_Material.append($.createElement('quantity', '1'));
                $se_billing_info_Material.append($.createElement('quantity_unit', quantity_unit));
                $se_billing_info_Material.append($.createElement('prod_number', 'eX2'));
                $se_billing_info_Material.append($.createElement('name', 'Material Handling fee'));
                $se_billing_info_Material.append($.createElement('price', materialFee));
                $se_billing_info_Material.append($.createElement('price_summ', materialFee));
                $se_billing_info_Material.append($.createElement('is_overriden','N'));
                $se_billing_info_Material.append($.createElement('billing_amount', materialFee));
                $se_billing_info_Material.append($.createElement('billing_reason', billing_reason));
                $se_billing_info_Material.append($.createElement('billing_reason_title', billing_reason_title));

                $se_billing_info_billItems.append($se_billing_info_Material);
                // To generate the Parts section XML :


                var invQty, itemPrice, itemNumber, itemDesc, extPrice;
                $.each(inventoryList, function(key, invItem) {

                    if (invItem.inv_aid == receivedData.activity.aid) {
                        if (invItem.invpool == "install" || invItem.invpool == "deinstall") {
                            if(parseInt(invItem.quantity) > 0){
                                invQty = invItem.quantity;
							
                            //itemPrice = parseFloat(invItem.I_ITEM_PRICE).toFixed(2);
							if(invItem.I_PRICE){
								itemPrice = parseFloat(invItem.I_PRICE).toFixed(2);
							}else{
                                itemPrice = 0.00;
							}
                            itemNumber = invItem.I_ITEM_NUMBER;
                            itemDesc = invItem.I_ITEM_DESCRIPTION;
                            //console.log(quantity +" "+itemPrice+" "+itemNumber+" "+itemDesc);
                            extPrice = parseFloat(invQty * itemPrice).toFixed(2);

                            if (aContractFlag) {
                                billing_amount = 0.00;
                                billing_reason_title = "";
                            } else {
                                billing_amount = extPrice;
                                billing_reason_title = 'Not Covered by Contract';
                            }

                            var $se_billing_info_Parts = $.createElement('part');
                            $se_billing_info_Parts.append($.createElement('key', currDateTimeFormat + " " + itemNumber));
                            $se_billing_info_Parts.append($.createElement('date',date_MM_DD));
                            $se_billing_info_Parts.append($.createElement('quantity', invQty));
                            $se_billing_info_Parts.append($.createElement('quantity_unit', ''));
                            $se_billing_info_Parts.append($.createElement('prod_number', itemNumber));
                            $se_billing_info_Parts.append($.createElement('name', itemDesc));
                            $se_billing_info_Parts.append($.createElement('price', itemPrice));
                            $se_billing_info_Parts.append($.createElement('price_summ', extPrice));
                            $se_billing_info_Parts.append($.createElement('is_overriden','N'));
                            $se_billing_info_Parts.append($.createElement('billing_amount', billing_amount));
                            $se_billing_info_Parts.append($.createElement('billing_reason', ''));
                            $se_billing_info_Parts.append($.createElement('billing_reason_title', billing_reason_title));
							$se_billing_info_Parts.append($.createElement('pass_count', g_current_pass_count));						

                            $se_billing_info_billItems.append($se_billing_info_Parts);
                        }
						
					   }
                    }

                });


                // expense rws 
                var $se_billing_expenses = $.generateExpenseRowsPlugin(se_expenses_plugin,[],"",false);
                //$se_billing_info_billItems.append($se_billing_expenses);
                //append labour, total labour, materialHandling fee:
                $se_billing_info_billInfo.append($se_billing_info_billItems);
                $se_billing_info_firstLoadXml.append($se_billing_info_billInfo);
                //set the xml
                se_billing_info_xml = $se_billing_info_firstLoadXml;
            } else {

                var findme = "&gt;";
                var partItemNumXMLArr = [];
                var partItemNumXMLJSON = {};
				var expenseItemNumXMLArr = [];
				var expenseDate = "";
				
                //if (se_billing_info.indexOf(findme) > -1) {
                  //  se_billing_info = $("<div />").html(se_billing_info).text(); // to decode the lt gt;
                //}
                var se_billing_info_xmlDoc = $.parseXML(se_billing_info);
                se_billing_info_xml = $(se_billing_info_xmlDoc);
				
				/// Check for if A_BILLING_INFO exist.///////
				var st_billing_info_xmlDoc = ""; 
                st_billing_info_xml = $(st_billing_info_xmlDoc);
				showExtraLaborRow = true;
				 var st_laborRowCount = 0;
				 var g_ShowDuplicateItems = false;
				if(a_billing_info){
					
				st_billing_info_xmlDoc = $.parseXML(a_billing_info);
				st_billing_info_xml = $(st_billing_info_xmlDoc);				
				st_billing_info_xml.find('billingInfo').find('billingItems').find('labor').each(function() {
			
				   st_laborRowCount++;

				});
				}
				
				
				
				// Number of labor rows in SE = A_billing  labor row count  + 1 ;
				//////////////////////////////               

                var billingItemsParentNode = se_billing_info_xml.find('billingInfo').find('billingItems');              
				
				//count the labor rows in SE 
				 var se_laborRowCount = 0;
				se_billing_info_xml.find('billingInfo').find('billingItems').find('labor').each(function() {
			
				   se_laborRowCount++;

				});
				g_current_pass_count = se_laborRowCount;
				//Generate labor Rows:
				if(se_laborRowCount == st_laborRowCount)
				{
					var $se_billing_extralaborRow = $.generateLaborRows(true);
					$(billingItemsParentNode).append($se_billing_extralaborRow);
					g_current_pass_count = se_laborRowCount+1;
					g_ShowDuplicateItems  = true;
				
				}
                var partsFoundInXML = false;
                //check for parts from billing info and compare with the inventory List of install and deinstall parts:

                //first loop through the parts xml and get the itemNumbers in a sep arr.
                se_billing_info_xml.find('billingInfo').find('billingItems').find('part').each(function() {
                	try{
			
				        var part_key = $(this).find("key").text();
						var part_date =$(this).find("date").text();
						var part_qty = $(this).find("quantity").text();
						var part_name =  $(this).find("name").text();
						var part_price = $(this).find("price").text();
						var part_priceSum =	$(this).find("price_summ").text();					
						var part_billReasonCode = $(this).find("billing_reason").text();
						var itemNumber_xml = $(this).find("prod_number").text();
						var overPrice = $(this).find("billing_amount").text();
						var billingReasonTitle = $(this).find("billing_reason_title").text();
						var isOverride = $(this).find("is_overriden").text();
						var passCount = $(this).find("pass_count").text();
	                    partItemNumXMLArr.push(itemNumber_xml);
						$.extend(partItemNumXMLJSON, {
							[itemNumber_xml]:{
								part_key:part_key,
								part_date:part_date,
								part_qty:part_qty,
								part_name:part_name,
								part_price:part_price,
								part_priceSum:part_priceSum,
								part_billReasonCode:part_billReasonCode,							
								overridenPrice: overPrice,
								billingReason: billingReasonTitle,
								isOverride : isOverride,
								passCount :passCount,
								matchFound:"N"
								
							}
						});
	                }
					catch(err){
						activityLog = activityLog + ';Exception in find part :'+err.message;
						console.log(" Exception in find part :"+err.message);
					} 
                });
				
			  // Remove the parts from the stored XML and regenerate every time from inventoryList:
			   var $billingItems = se_billing_info_xml.find('billingInfo').find('billingItems');
				$billingItems.each(function() {
				  $(this).find('part').remove();
				});


                var invQty, itemPrice, itemNumber, itemDesc, extPrice, billing_amount, billing_reason_title;
				
				
                $.each(inventoryList, function(key, invItem) {

                    if (invItem.inv_aid == receivedData.activity.aid) {
                        if (invItem.invpool == "install" || invItem.invpool == "deinstall") {
                            if(parseInt(invItem.quantity) > 0){
                               
        					   invQty = invItem.quantity;							
                            
							if(invItem.I_PRICE){
								itemPrice = parseFloat(invItem.I_PRICE).toFixed(2);
							}else{
                                itemPrice = 0;
							}
                            itemNumber = invItem.I_ITEM_NUMBER;
                            itemDesc = invItem.I_ITEM_DESCRIPTION;
                           
                            extPrice = parseFloat(invQty * itemPrice).toFixed(2);

                            if (aContractFlag) {
                                billing_amount = 0.00;
                                billing_reason_title = "";
                            } else {
                                billing_amount = extPrice;
                                billing_reason_title = 'Not Covered by Contract';
                            }


                            var isPresent = $.inArray(itemNumber, partItemNumXMLArr);
							
							
							var isoverRide = "N";
							var passCount = g_current_pass_count;
							if( !(isPresent == -1)){
								// value present in XML , so copy the override price, billing reason.
								 // duplicate items exist.
                                //do not process it., will get processed if g_ShowDuplicateItems == true;
								billing_amount = partItemNumXMLJSON[itemNumber].overridenPrice;
								billing_reason_title = partItemNumXMLJSON[itemNumber].billingReason;
								isoverRide = partItemNumXMLJSON[itemNumber].isOverride;
								passCount = partItemNumXMLJSON[itemNumber].passCount;
								partItemNumXMLJSON[itemNumber].matchFound = "Y";
								
								
							}//else{
                         
                                // no duplicates
                                var $se_billing_info_Parts = $.createElement('part');
                                $se_billing_info_Parts.append($.createElement('key', currDateTimeFormat + " " + itemNumber));
                                $se_billing_info_Parts.append($.createElement('date',date_MM_DD));
                                $se_billing_info_Parts.append($.createElement('quantity', invQty));
                                $se_billing_info_Parts.append($.createElement('quantity_unit', ''));
                                $se_billing_info_Parts.append($.createElement('prod_number', itemNumber));
                                $se_billing_info_Parts.append($.createElement('name', itemDesc));
                                $se_billing_info_Parts.append($.createElement('price', itemPrice));
                                $se_billing_info_Parts.append($.createElement('price_summ', extPrice));
                                $se_billing_info_Parts.append($.createElement('is_overriden',isoverRide));
                                $se_billing_info_Parts.append($.createElement('billing_amount', billing_amount));
                                $se_billing_info_Parts.append($.createElement('billing_reason', ''));
                                $se_billing_info_Parts.append($.createElement('billing_reason_title', billing_reason_title));
								$se_billing_info_Parts.append($.createElement('pass_count', passCount));
								
                                $(billingItemsParentNode).append($se_billing_info_Parts);

                           // } 

                        }
					  }
                    }

                });
				// if the parts match is not found in the inventory list for example -- deinstall parts -- construct it from the billing Info:
				 $.each(partItemNumXMLJSON, function(itemNumber, partsXML) {
					 
					 if(partsXML.matchFound == "N"){
					
						  var $se_billing_info_Parts = $.createElement('part');
                                $se_billing_info_Parts.append($.createElement('key', partsXML.part_key));
                                $se_billing_info_Parts.append($.createElement('date',partsXML.part_date));
                                $se_billing_info_Parts.append($.createElement('quantity', partsXML.part_qty));
                                $se_billing_info_Parts.append($.createElement('quantity_unit', ''));
                                $se_billing_info_Parts.append($.createElement('prod_number', itemNumber));
                                $se_billing_info_Parts.append($.createElement('name', partsXML.part_name));
                                $se_billing_info_Parts.append($.createElement('price', partsXML.part_price));
                                $se_billing_info_Parts.append($.createElement('price_summ', partsXML.part_priceSum));
                                $se_billing_info_Parts.append($.createElement('is_overriden',partsXML.isOverride));
                                $se_billing_info_Parts.append($.createElement('billing_amount', partsXML.overridenPrice));
                                $se_billing_info_Parts.append($.createElement('billing_reason',partsXML.part_billReasonCode));
                                $se_billing_info_Parts.append($.createElement('billing_reason_title', partsXML.billingReason));
								$se_billing_info_Parts.append($.createElement('pass_count', partsXML.passCount));
								
                                $(billingItemsParentNode).append($se_billing_info_Parts);
						 
						 
					 }
					 
					 
				 });
				
				// Generate new set of rows everytime from A_SE_EXPENSES_PLUGIN.
				var expenseFoundInXML = false;
				//check for expense from billing info and compare with the A_SE_EXPENSES_PLUGIN

				//first loop through the expense xml and get the itemNumbers in a sep arr.
				se_billing_info_xml.find('billingInfo').find('billingItems').find('expense').each(function() {
				var itemNumber_xml = $(this).find("prod_number").text();
				expenseItemNumXMLArr.push(itemNumber_xml);
				expenseDate = $(this).find("date").text();

				});
				
				var $se_billing_expenses = $.generateExpenseRowsPlugin(se_expenses_plugin,expenseItemNumXMLArr,expenseDate,g_ShowDuplicateItems);
				$(billingItemsParentNode).append($se_billing_expenses);
            		   

            }

            //RENDERING THE DISPLAY TABLE ROWS//
            //To Generate the billing info rows in the table.
            var totalLaborBillAmount = 0;
            var totalLaborPrice = 0;
            var totalLaborQty = 0;
            if (se_billing_info_xml != null) // && (typeof se_billing_info != "undefined"))	
            {

                // To get the Labor row

                se_billing_info_xml.find('billingInfo').find('billingItems').find('labor').each(function() {
                    var date = $(this).find("date").text();
                    var quantity = $(this).find("quantity").text();
					quantity = isNaN(parseFloat(quantity))?1:parseFloat(quantity);

                    var selQty = isNaN(parseFloat(quantity))?0:parseFloat(quantity);
					totalLaborQty = totalLaborQty + selQty;
                    var quantity_unit = $(this).find("quantity_unit").text();
                    var prod_number = $(this).find("prod_number").text();
                    var name = $(this).find("name").text();
                    var price = $(this).find("price").text();
					var selPrice =  isNaN(parseFloat(price))?0.00:parseFloat(price);
                   // totalLaborPrice += isNaN(parseFloat(price))?0.00:parseFloat(price);
				    totalLaborPrice = totalLaborPrice + selPrice;

                    var price_summ = $(this).find("price_summ").text();
                    var billing_amount = $(this).find("billing_amount").text();
                    //calcualte the total billing amount.
                    totalLaborBillAmount += parseFloat(billing_amount);
                    var billing_reason = $(this).find("billing_reason").text();
                    var billing_reason_title = $(this).find("billing_reason_title").text();
					var datefromXML =  $(this).find("date").text();
                    rowCount += 1;
                    var classKey = "Qty_" + rowCount;
                    var classBillingUndoKey = "BillingAmt_" + rowCount;
                    var BillingReasonContainerclass = "BillingReasonContainer_" + rowCount;
                    var billAmtOrigValLink = "billing-amount-original-value-link-" + rowCount;
                    var billReasonOriginalValContainer = "bill-reason-original-value-container-" + rowCount;
                    //Append the row( Quantity, Item,Ext Price,Bill Amt, Billing Reason, Date)
                    var row = '<tr id="cpf_labor_'+rowCount+'" class="billing-items-grid-row cpf_labor_row">\
							               <td class=" cpf_0-0"> <div class="quantity-column-readonly cpf_0-0-0 cp_hidden">' + quantity + ' ' + quantity_unit + '</div>' +
                        '<div class="' + classKey + '">' + $("#QtyDDSection").html() + '</div>' +
                        '</td>' +
                        '<td class=" cpf_0-1"><div class="item_number">' + prod_number + '</div><div class="item_description">' + name + '</div></td>\
						<td class="ext-price-labor numeric-column cpf_0-2"><div id="std-labor-price" class ="ext-price-col">$ ' + price + '</div></td>\
						<td class="billing-amount cpf_labor_row_bill_Amt">\
                         <div class="billing-amount-original-value-container-1 numeric-column cpf_0-3-0">\
							<div rownumber="' + rowCount + '" id="std-labor-billamount" class="billing-amount-original-value-link-1">\
                               $ ' + billing_amount +
                        '</div></div>' +
                        '</td>' +
                        '<td class="billing-reason cpf_0-4">\
							<div id="' + billReasonOriginalValContainer + '" class="billing-reason-original-value-container cpf_0-4-0">' +
                        billing_reason_title +
                        '</div>' + //'<div class="'+ BillingReasonContainerclass +'">'+$("#billingReasonDDSection").html()+'</div>'+
                        '</td>' +
                        '<td class="dateColumn">' + datefromXML + '</td>\
						</tr>';

                    $('#activity_billing_grid').append(row);
                    $("#cpf_labor_"+rowCount).attr("disabled", "disabled");
                    var newId_forQtyDD_rowData = "QtyCol_" + rowCount;
                    $("div.Qty_" + rowCount + " > div#QtyCol").attr('id', newId_forQtyDD_rowData);
                    $("#" + newId_forQtyDD_rowData).removeClass("cp_hidden");

                    var selectqtyID = "quantityDD_" + rowCount;
                    $("#" + newId_forQtyDD_rowData).find("select#cpf_qtyDD").attr('id', selectqtyID);

                    var defaultVal_qtyDD = parseFloat(quantity).toFixed(2);
                    //defaultVal_qtyDD = '0' + defaultVal_qtyDD;
                    $('#' + selectqtyID).val(defaultVal_qtyDD); //set the quantity DD with the value already populated.

                    // on change of the Quantity copy over the fields value:

                    $('#' + selectqtyID).on('change', function(e) {
                        var selectedValue = $('#' + selectqtyID).val();
                        //var selectedText = $('#'+selectqtyID+' option:selected').text();
						
						var currId = selectqtyID;
						var currRowId = currId.slice(-1);
                        //set to Total labor qty column
                      //  $("#total_labor_qty").text(selectedValue + " hrs");
                        // calcualte the ext. Price, billing amount for both labor column and Total labour column.
                        if (isNaN(laborRate)) {
                            laborRate = 0;
                        }
                        var newPrice = parseFloat(selectedValue * laborRate).toFixed(2);

                        if (isNaN(newPrice)) {
                            newPrice = "0.00";
                        }
                        $("#cpf_labor_"+currRowId).find("#std-labor-price").text("$ " + newPrice);
						
						 if (!aContractFlag) {
                              $("#cpf_labor_"+currRowId).find("#std-labor-billamount").text("$ " + newPrice);
						 }
                        //recalculate the total Labor sum and add material fee if tot.Labor > 25.
                        if (newPrice > 25 && !aContractFlag) {
                            $('#materialHandlingPrice').text("$ " + materialFee);
                            $('.materialHandlingBillAmt').text("$ " + materialFee);
                            $('.materialHandlingRow').find('.cpf_inner_overriden_val').val(materialFee);
                        }
						//////// calculate the total labor for each rows and update the aggregate.///////////
						
						var totLbrQty = 0, totLbrPrice = 0, totLbrBillAmt =0;
						$('table tr.cpf_labor_row').each(function() {

							   var selectedValue =  $(this).find('.cpf_quantitydropdown').val();
							  // totLbrQty = totLbrQty+ isNaN(parseFloat(selectedValue))?0:parseFloat(selectedValue);
							  var selValue = isNaN(parseFloat(selectedValue))?0.00:parseFloat(selectedValue);
							   totLbrQty = totLbrQty + selValue;
							   var LbrPrice = $(this).find("#std-labor-price").text();
							   
							    LbrPrice = LbrPrice.replace("$", "");
								LbrPrice = $.trim(LbrPrice);
								LbrPrice = parseFloat(LbrPrice);
								if (!isNaN(LbrPrice) && LbrPrice.length !== 0) {
										 totLbrPrice = totLbrPrice + LbrPrice;
								}
								
								var LbrBillAmt = $(this).find("#std-labor-billamount").text();
							   
							    LbrBillAmt = LbrBillAmt.replace("$", "");
								LbrBillAmt = $.trim(LbrBillAmt);
								LbrBillAmt = parseFloat(LbrBillAmt);
								if (!isNaN(LbrBillAmt) && LbrBillAmt.length !== 0) {
										 totLbrBillAmt = totLbrBillAmt + LbrBillAmt;
								}
							  
											 
						   });
							var totLbrQtyFinal = parseFloat(totLbrQty).toFixed(2);
							totLbrPrice = parseFloat(totLbrPrice).toFixed(2);
							totLbrBillAmt = parseFloat(totLbrBillAmt).toFixed(2);
							//set to Total labor qty column
							$("#total_labor_qty").text(totLbrQtyFinal + " hrs");
						
						$("#total-labor-price").text("$ " + totLbrPrice);
						g_totLbrPrice = totLbrPrice;
						 if (!aContractFlag) {
							$(".total-labor-billamount").text("$ " + totLbrBillAmt);
							$('#cpf_total_labor').find('.cpf_total_labor_bill_amt').find('.cpf_input_overriden_val').val(totLbrBillAmt);
						 }
					
						
						///////////////////////

                        $.recalculateBillAmountTotal();
                        //recalculate Ext price Column.

                        $.recalculateExtPriceTotal();


                    }.bind(this));




                });



                // To get the total_labor row
                se_billing_info_xml.find('billingInfo').find('billingItems').find('total_labor').each(function() {
                	try{
		                    var date = $(this).find("date").text();
		                    var quantity = parseFloat(totalLaborQty).toFixed(2); //$(this).find("quantity").text();
		                    var quantity_unit = $(this).find("quantity_unit").text();
		                    var isOverriden = $(this).find("is_overriden").text();
		                    var name = $(this).find("name").text();
		                    var price;
		                    if (!isNaN(totalLaborPrice)) {
		                        price = parseFloat(totalLaborPrice).toFixed(2); //$(this).find("billing_amount").text();
		                    } else {
		                        price = "0.00";
		                    }
							g_totLbrPrice = price;
		
		                    var price_summ = $(this).find("price_summ").text();
		                    var billing_amount;
		                    if (!isNaN(totalLaborBillAmount)) {
		                        billing_amount = parseFloat(totalLaborBillAmount).toFixed(2); //$(this).find("billing_amount").text();
		                    } else {
		                        billing_amount = "0.00";
		                    }
		                    var billing_reason = $(this).find("billing_reason").text();
		                    var billing_reason_title =$(this).find("billing_reason_title").text();
							
							 if (isOverriden == 'Y') {
								 
								 billing_amount = $(this).find("billing_amount").text();
							 }
		                    rowCount += 1;
		                    var classBillingUndoKey = "BillingAmt_" + rowCount;
		                    var BillingReasonContainerclass = "BillingReasonContainer_" + rowCount;
		                    var billAmtOrigValLink = "billing-amount-original-value-link-" + rowCount;
		                    var billReasonOriginalValContainer = "bill-reason-original-value-container-" + rowCount;
		
		
                    		var activityStyle = "";		// Change CHG0078726
                    
		                    var row = '<tr id="cpf_total_labor" class="billing-items-grid-row cpf_total_labor_row">\
									               <td class=" cpf_0-0"> <div id="total_labor_qty" class="quantity-column-readonly cpf_quantity ">' + quantity + ' ' + quantity_unit + '</div>' +
		                        '</td>' +
		                        '<td class=" cpf_0-1"><b class="item_description">' + name + '</b></td>\
												   <td class="ext-price numeric-column cpf_0-2"><div id="total-labor-price" class="ext-price-col">$ ' + price + '</div></td>\
												   <td class="billing-amount cpf_total_labor_bill_amt">\
		                                              <div class="billing-amount-original-value-container numeric-column cpf_0-3-0">\ ' ;
													  
//start of CHG0076763 Prevent billing updates on the Service Estimate
                                               if (isIntallCall)
				{
					row = row +'<p rownumber="' + rowCount + /* '" id="' + billAmtOrigValLink + */ '" >\
												  $ 0'  +
											   '</p>'
											   row = row + '</div>' +
'<td class="billing-reason cpf_0-4">\
		<div id="' + billReasonOriginalValContainer + '" class="billing-reason-original-value-container cpf_0-4-0">' + '</div>' +
				'<div class="' + BillingReasonContainerclass + '">' + $("#billingReasonDDSectionParts").html() + '</div>'
'<td> <div class="dateColumn">' + /* datefromXML + */ '</div>'
//<div class="pass_count_Column" style="display:none;">' + pass_count + '</div>'
row= row + '</td>'
				}	
											   else
											   {
												   row = row +
													'<a rownumber="' + rowCount + '" id="' + billAmtOrigValLink + '" \
												   class="billing-amount-original-value-link total-labor-billamount" ' + activityStyle + '  >\
                                                  $ ' + billing_amount +
                        '</a>'
											   
												row = row + '</div>' +
                        '<div class="' + classBillingUndoKey + '">' + $("#billingAmountUndoSection").html() + '</div>' +
                        '</td>' +
                        '<td class="billing-reason cpf_0-4">\
												   <div id="' + billReasonOriginalValContainer + '" class="billing-reason-original-value-container cpf_0-4-0">' +
                        billing_reason_title +
                        '</div>' +
											   '<div class="' + BillingReasonContainerclass + '">' + $("#billingReasonDDSection").html() + '</div>'}
row = row  +
//End of CHG0076763 Prevent billing updates on the Service Estimate
													  
		                                                   /* <a rownumber="' + rowCount + '" id="' + billAmtOrigValLink + '" class="billing-amount-original-value-link total-labor-billamount">\
		                                                  $ ' + billing_amount +
		                        '</a></div>' +
		                        '<div class="' + classBillingUndoKey + '">' + $("#billingAmountUndoSection").html() + '</div>' +
		                        '</td>' +
		                        '<td class="billing-reason cpf_0-4">\
														   <div id="' + billReasonOriginalValContainer + '" class="billing-reason-original-value-container cpf_0-4-0">' +
		                        billing_reason_title +
		                        '</div>' +
		                        '<div class="' + BillingReasonContainerclass + '">' + $("#billingReasonDDSection").html() + '</div>' + */
								
		                        '</td>' +
		                        '<td class="dateColumn"></td>\
												 </tr>';
		
		                    $('#activity_billing_grid').append(row);
		                    //Add the new Id for Billing Amount.
		                    var BillAmtUndoCol_rowData = "BillAmtUndoCol_" + rowCount;
		                    var billAmtUndoLink_row = "billAmtUndoLink_" + rowCount;
		                    var inner_overriden_val = "inner_overriden_val_" + rowCount;
		                    var BillingReasonContainer_Id = "billing_reason_container_" + rowCount;
		
		                    $("div." + classBillingUndoKey + " > div#billAmtOverriddenContainer").attr('id', BillAmtUndoCol_rowData);
		                    $("div." + classBillingUndoKey).find("a#billAmtUndoLink").attr('id', billAmtUndoLink_row);
		                    $("div." + classBillingUndoKey).find("input#cpf_inner_overriden_val").attr('id', inner_overriden_val);
		                    $("div." + BillingReasonContainerclass).find("div#billreason-overriden-container").attr('id', BillingReasonContainer_Id);
							  var selectedText = billing_reason_title;
		                        $("#" + BillingReasonContainer_Id).find("select#cpf_billingReasonDDSection option").map(function () {
										if ($(this).text() == selectedText) return this;
									}).attr('selected', 'selected');
		                    $("#" + inner_overriden_val).val(billing_amount);
		
		                   /* if (aContractFlag) {
		
		                        $('div.' + BillingReasonContainerclass).find('select option[value=""]').attr("selected", true);
		                    }*/
		                    $('#' + billAmtOrigValLink).on('click', function(e) {
		
		                        $("#" + billAmtOrigValLink).addClass("cp_hidden");
		                        $("#" + billReasonOriginalValContainer).addClass("cp_hidden");
		
		                        $("#" + BillAmtUndoCol_rowData).removeClass("cp_hidden");
		                        $("#" + BillingReasonContainer_Id).removeClass("cp_hidden");
								
								
		
		                        //copy over the billAmt to the input box.
		                        var undoAmtOrig = $('#' + billAmtOrigValLink).text();
		                        undoAmtOrig = undoAmtOrig.replace("$", "");
		                        undoAmtOrig = $.trim(undoAmtOrig);
		                        $("#" + BillAmtUndoCol_rowData).find('.cpf_input_overriden_val').val(parseFloat(undoAmtOrig).toFixed(2));
		                        // $("#"+BillAmtUndoCol_rowData).find('.cpf_input_overriden_val').val('99.00');					
		                    }.bind(this));
		
		                    $('#' + billAmtUndoLink_row).on('click', function(e) {
		
		                        $("#" + billAmtOrigValLink).removeClass("cp_hidden");
		                        $("#" + billReasonOriginalValContainer).removeClass("cp_hidden");
		
		                        $("#" + BillAmtUndoCol_rowData).addClass("cp_hidden");
		                        $("#" + BillingReasonContainer_Id).addClass("cp_hidden");						
								
		                       //set the billingamount back to the Original Value.
		                       // var undoAmt = $('#' + billAmtOrigValLink).text();
		                       // undoAmt = undoAmt.replace("$", "");
		                       // undoAmt = $.trim(undoAmt);
		                        
		                       // $("#" + BillAmtUndoCol_rowData).find('.cpf_input_overriden_val').val(parseFloat(undoAmt).toFixed(2));
								
								 var undoAmtOrig = $('#' + billAmtOrigValLink).text();
		                        undoAmtOrig = undoAmtOrig.replace("$", "");
		                        undoAmtOrig = $.trim(undoAmtOrig);
		                        $("#" + BillAmtUndoCol_rowData).find('.cpf_input_overriden_val').val(parseFloat(undoAmtOrig).toFixed(2));
								 //Recalculate the total:
		                        $.recalculateBillAmountTotal();
		
		
		
		                    }.bind(this));
		
		                    // On change of the input values recalculate the column total
							  $('#' + inner_overriden_val).on("change paste keyup", function() {
								var enteredVal = $(this).val();
								if(isNaN(enteredVal) || enteredVal.indexOf(' ') >=0 ) {   
									$(this).val("");
								}
								enteredVal = $(this).val();
								
								if(enteredVal >= 1000000){
									alert("Value too large, Please adjust the value to be less than 999999.99");
									$(this).val(0.00);
								}
		                        $.recalculateBillAmountTotal();
		                    });
							
							 //check if Overridden flag is set to true: if yes then apply the hiding logic, and display the editable col vals for bill Amt and bill.reason--
		                if (isOverriden == 'Y') {
		                    $("#" + billAmtOrigValLink).addClass("cp_hidden");
		                    $("#" + billReasonOriginalValContainer).addClass("cp_hidden");
		
		                    $("#" + BillAmtUndoCol_rowData).removeClass("cp_hidden");
		                    $("#" + BillingReasonContainer_Id).removeClass("cp_hidden");
		                }
                	}
    				catch(err){
    					activityLog = activityLog + ';Exception in find total_labor :'+err.message;
    					console.log(" Exception in find total_labor :"+err.message);
    				} 

                });
                //To generate the Parts section:

                se_billing_info_xml.find('billingInfo').find('billingItems').find('part').each(function() {
                	try{
	                    var date = $(this).find("date").text();
	                    var quantity = $(this).find("quantity").text();
	                    //var quantity_unit = $(this).find("quantity_unit").text();
	                    var prod_number = $(this).find("prod_number").text();
	                    var name = $(this).find("name").text();
	                    var price = $(this).find("price").text();
						if(isNaN(price)){price = 0;}
	                    var price_summ = $(this).find("price_summ").text();
						if(isNaN(price_summ)){price_summ = 0;}
	                    var billing_amount = $(this).find("billing_amount").text();
						if(isNaN(billing_amount)){billing_amount = 0;}
						
	                    var billing_reason = $(this).find("billing_reason").text();
	                    var billing_reason_title = $(this).find("billing_reason_title").text();
	                    var isOverriden = $(this).find("is_overriden").text();
						var pass_count = $(this).find("pass_count").text();
						var LockRow;
						if(pass_count && pass_count < g_current_pass_count){
							LockRow = true;
						}else{
							LockRow = false;
						}
	                    rowCount += 1;
	                    var classBillingUndoKey = "BillingAmt_" + rowCount;
	                    var BillingReasonContainerclass = "BillingReasonContainer_" + rowCount
	                    var billAmtOrigValLink = "billing-amount-original-value-link-" + rowCount;
	                    var billReasonOriginalValContainer = "bill-reason-original-value-container-" + rowCount;
	                    var priceAmtOrigValLink = "price-amount-original-value-link-" + rowCount;
						var datefromXML =  $(this).find("date").text();
	
	                    var row = '<tr id="cpf_parts" class="billing-items-grid-row cpf_parts_row">\
								               <td class=" cpf_0-0"> <div class="quantity-column-readonly cpf_quantity ">' + quantity + '</div>' + //$("#QtyDDSection").html()+
	                        '</td>' +
	                        '<td class=" cpf_0-1"><div class="item_number">' + prod_number + '</div><div class="item_description">' + name + '</div></td>\
											   <td class="ext-price numeric-column cpf_0-2"><div class="ext-price-col" id="' + priceAmtOrigValLink + '">$ ' + price_summ + '</div></td>\
											   <td class="billing-amount cpf_0-3">\
	                                              <div class="billing-amount-original-value-container numeric-column cpf_0-3-0">\ ' ;
												  
//start of CHG0076763 Prevent billing updates on the Service Estimate
                                               if (isIntallCall)
											   {
												   row = row +'<p rownumber="' + rowCount + /* '" id="' + billAmtOrigValLink + */ '" >\
												  $ 0' + 
												  '</p>'
												  row = row + '</div>' +
												  '<td class="billing-reason cpf_0-4">\
		<div id="' + billReasonOriginalValContainer + '" class="billing-reason-original-value-container cpf_0-4-0">' + '</div>' +
				'<div class="' + BillingReasonContainerclass + '">' + $("#billingReasonDDSectionParts").html() + '</div>'
												  '<td> <div class="dateColumn">' + datefromXML + '</div>'
												  //<div class="pass_count_Column" style="display:none;">' + pass_count + '</div>'
												  row= row + '</td>'
												  
											   }
                                               else
											   {
												   row = row + 
										'<a rownumber="' + rowCount + '" id="' + billAmtOrigValLink + '"class="billing-amount-original-value-link">\
                                                  $ ' + billing_amount +
                        '</a>' 
						row = row + '</div>' +
                        '<div class="' + classBillingUndoKey + '">' + $("#billingAmountUndoSection").html() + '</div>' +
                        '</td>' +
                        '<td class="billing-reason cpf_0-4">\
												  <div id="' + billReasonOriginalValContainer + '" class="billing-reason-original-value-container cpf_0-4-0">' +
                        billing_reason_title +
                        '</div>' +
				'<div class="' + BillingReasonContainerclass + '">' + $("#billingReasonDDSectionParts").html() + '</div>'} 
				row = row + 
//End of CHG0076763 Prevent billing updates on the Service Estimate
												  
	                                                   /* <a rownumber="' + rowCount + '" id="' + billAmtOrigValLink + '" class="billing-amount-original-value-link">\
	                                                  $ ' + billing_amount +
	                        '</a></div>' +
	                        '<div class="' + classBillingUndoKey + '">' + $("#billingAmountUndoSection").html() + '</div>' +
	                        '</td>' +
	                        '<td class="billing-reason cpf_0-4">\
													  <div id="' + billReasonOriginalValContainer + '" class="billing-reason-original-value-container cpf_0-4-0">' +
	                        billing_reason_title +
	                        '</div>' +
	                        '<div class="' + BillingReasonContainerclass + '">' + $("#billingReasonDDSectionParts").html() + '</div>' + */
							
	                        '</td>' +
	                       '<td> <div class="dateColumn">' + datefromXML + '</div><div class="pass_count_Column" style="display:none;">' + pass_count + '</div></td>\
											 </tr>';
	
	                    $('#activity_billing_grid').append(row);
	                    //Add the new Id for Billing Amount.
	                    var BillAmtUndoCol_rowData = "BillAmtUndoCol_" + rowCount;
	                    var billAmtUndoLink_row = "billAmtUndoLink_" + rowCount;
	                    var inner_overriden_val = "inner_overriden_val_" + rowCount;
	                    var BillingReasonContainer_Id = "billing_reason_container_" + rowCount;
	
	                    $("div." + classBillingUndoKey + " > div#billAmtOverriddenContainer").attr('id', BillAmtUndoCol_rowData);
	                    $("div." + classBillingUndoKey).find("a#billAmtUndoLink").attr('id', billAmtUndoLink_row);
	                    $("div." + classBillingUndoKey).find("input#cpf_inner_overriden_val").attr('id', inner_overriden_val);
	                    $("div." + BillingReasonContainerclass).find("div#billreason-overriden-container-parts").attr('id', BillingReasonContainer_Id);
							  var selectedText = billing_reason_title;
	                        $("#" + BillingReasonContainer_Id).find("select#cpf_billingReasonDDSectionParts option").map(function () {
									if ($(this).text() == selectedText) return this;
								}).attr('selected', 'selected');
	                    $("#" + inner_overriden_val).val(billing_amount);
	                    $('#' + billAmtOrigValLink).on('click', function(e) {
	
	                        $("#" + billAmtOrigValLink).addClass("cp_hidden");
	                        $("#" + billReasonOriginalValContainer).addClass("cp_hidden");
	
	                        $("#" + BillAmtUndoCol_rowData).removeClass("cp_hidden");
	                        $("#" + BillingReasonContainer_Id).removeClass("cp_hidden");
	
	                        //copy over the Price/billAmt to the input box.
	                        var undoAmtOrig = $('#' + billAmtOrigValLink).text();
	                        undoAmtOrig = undoAmtOrig.replace("$", "");
	                        undoAmtOrig = $.trim(undoAmtOrig);
	                        $("#" + BillAmtUndoCol_rowData).find('.cpf_input_overriden_val').val(parseFloat(undoAmtOrig).toFixed(2));
	                    }.bind(this));
	
	                    $('#' + billAmtUndoLink_row).on('click', function(e) {
	
	
	                        $("#" + billAmtOrigValLink).removeClass("cp_hidden");
	                        $("#" + billReasonOriginalValContainer).removeClass("cp_hidden");
	
	                        $("#" + BillAmtUndoCol_rowData).addClass("cp_hidden");
	                        $("#" + BillingReasonContainer_Id).addClass("cp_hidden");
	
	
	                        var undoAmt = $('#' + priceAmtOrigValLink).text();
	                        undoAmt = undoAmt.replace("$", "");
	                        undoAmt = $.trim(undoAmt);
	                        undoAmt = parseFloat(undoAmt).toFixed(2);
	                        //set the billingamount back to the Original Value.
	                        //$("#" + BillAmtUndoCol_rowData).find('.cpf_input_overriden_val').val(undoAmt);
	                        //$('#' + billAmtOrigValLink).text('$ ' + undoAmt);
							
							 var undoAmtOrig = $('#' + billAmtOrigValLink).text();
	                        undoAmtOrig = undoAmtOrig.replace("$", "");
	                        undoAmtOrig = $.trim(undoAmtOrig);
	                        $("#" + BillAmtUndoCol_rowData).find('.cpf_input_overriden_val').val(parseFloat(undoAmtOrig).toFixed(2));
	                   
	
	                        //Recalculate the total:
	                        $.recalculateBillAmountTotal();
	
	
	                    }.bind(this));
	
	                    // On change of the input values recalculate the column total
	
	                    $('#' + inner_overriden_val).on("change paste keyup", function() {
							var enteredVal = $(this).val();
							if(isNaN(enteredVal) || enteredVal.indexOf(' ') >=0) {   
								$(this).val("");
							}
							enteredVal = $(this).val();
							
							if(enteredVal >= 1000000){
								alert("Value too large, Please adjust the value to be less than 999999.99");
							$(this).val(0.00);
							}
							
	                        $.recalculateBillAmountTotal();
	                    });
	
	                    //check if Overridden flag is set to true: if yes then apply the hiding logic, and display the editable col vals for bill Amt and bill.reason--
	                    if (isOverriden == 'Y'){// && !LockRow) {
	                        $("#" + billAmtOrigValLink).addClass("cp_hidden");
	                        $("#" + billReasonOriginalValContainer).addClass("cp_hidden");
							
	                        $("#" + BillAmtUndoCol_rowData).removeClass("cp_hidden");
	                        $("#" + BillingReasonContainer_Id).removeClass("cp_hidden");
	                    }
						
						/*if(LockRow){
							 $("#" + billAmtOrigValLink).css({"border-bottom": "none","pointer-events": "none"});
						}*/
	                    //Recalculate the total:
	                    $.recalculateBillAmountTotal();
                	}
    				catch(err){
    					activityLog = activityLog + ';Exception in part find:'+err.message;
    					console.log(" Exception in part find :"+err.message);
    				} 
                });
            }

            //To Generate the outbound expenses rows in the table.
            se_billing_info_xml.find('billingInfo').find('billingItems').find('expense').each(function() {
            	try{
	                var date = $(this).find("date").text();
	                var quantity = $(this).find("quantity").text();
	                //var quantity_unit = $(this).find("quantity_unit").text();
	                var prod_number = $(this).find("prod_number").text();
	                var name = $(this).find("name").text();
					var price = $(this).find("price").text();
					if(isNaN(price)){price = 0;}
					var price_summ = $(this).find("price_summ").text();
					if(isNaN(price_summ)){price_summ = 0;}
					var billing_amount = $(this).find("billing_amount").text();
					if(isNaN(billing_amount)){billing_amount = 0;}
	                var billing_reason = $(this).find("billing_reason").text();
	                var billing_reason_title = $(this).find("billing_reason_title").text();
	                var isOverriden = $(this).find("is_overriden").text();
					var datefromXML =  $(this).find("date").text();
					var pass_count = $(this).find("pass_count").text();
					var LockRow;
					if(pass_count && pass_count < g_current_pass_count){
							LockRow = true;
						}else{
							LockRow = false;
						}
	
	                var expenseTypeInfo = $(this).find("expense_type").text();
	                rowCount += 1;
	                var expenseSection = "";
	                var activityStyle = "";
	                if (expenseTypeInfo == "reimbursable") {
	
	                    expenseSection = "reimbursable_expenses_type";
	
	                } else if (expenseTypeInfo == "activities") {
	                    expenseSection = "activities_type";
	
	                } else if (expenseTypeInfo == "service advantage chargeable activities") {
	                    expenseSection = "service_advantage_chargeable_activities_type";
	                    
	                } else if (expenseTypeInfo == "condition based maintainance") { //CHG0067765 Condition Based Maintenance
	                    expenseSection = "cbm_activities_type";

	                }else {
	                    expenseSection = "chargeable_activities_type";
	                }
	                if ((price != "na" || billing_amount != "na") && (price != "0" || billing_amount != "0") && (price > 0 || billing_amount != "")) {
	                    price = '$ ' + price;
	                    billing_amount = '$ ' + billing_amount;
	                } else {
	                    activityStyle = 'style="border-bottom: none;pointer-events: none;"';
	                    price = 'na';
	                    billing_amount = 'na';
						isOverriden = 'N';
	                }
	                var classBillingUndoKey = "BillingAmt_" + rowCount;
	                var BillingReasonContainerclass = "BillingReasonContainer_" + rowCount
	                var billAmtOrigValLink = "billing-amount-original-value-link-" + rowCount;
	                var priceAmtOrigValLink = "price-amount-original-value-link-" + rowCount;
	                var billReasonOriginalValContainer = "bill-reason-original-value-container-" + rowCount;
	
	                var row = '<tr id="cpf_expenses" class="billing-items-grid-row cpf_expenses_row">';
	                	
	                if(expenseSection == "cbm_activities_type"){
	                	 row += '<td class=" cpf_0-0"> <div class="quantity-column-readonly"><span class="cpf_quantity">' + quantity + '</span>&nbsp;<span>Mins</span></div></td>';
	                 } else  {
	                	 row += '<td class=" cpf_0-0"> <div class="quantity-column-readonly cpf_quantity ">' + quantity + '</div></td>';
	                 }
	                   
	                 row += '<td class=" cpf_0-1"><div class="item_number">' + prod_number + '</div><div class="item_description">' + name + '</div></td>\
											   <td class="ext-price numeric-column ext-price-col" id="' + priceAmtOrigValLink + '">' + price + '</td>\
											   <td class="billing-amount cpf_0-3">\
	                                              <div class="billing-amount-original-value-container numeric-column cpf_0-3-0">\ ' ;
												  
//start of CHG0076763 Prevent billing updates on the Service Estimate
											  if (isIntallCall)
											   {
												   row = row +
												   '<p rownumber="' + rowCount + /* '" id="' + billAmtOrigValLink + */ '" >\
												  $ 0' +
											   '</p>' 
											   row = row + '</div>' +
											   '<td class="billing-reason cpf_0-4">\
		<div id="' + billReasonOriginalValContainer + '" class="billing-reason-original-value-container cpf_0-4-0">' + '</div>' +
'<div class="' + BillingReasonContainerclass + '">' + $("#billingReasonDDSectionParts").html() + '</div>'		
												  '<td> <div class="dateColumn">' + datefromXML + '</div>'
												  //<div class="pass_count_Column" style="display:none;">' + pass_count + '</div>'
												  row= row + '</td>'
											   }
										else
											  {
												  row = row +
											  '<a rownumber="' + rowCount + '" id="' + billAmtOrigValLink + '" class="billing-amount-original-value-link billAmtOrigVal" ' + activityStyle + '>\
                                                  ' + billing_amount +
                    '</a>'
					row = row + '</div>' +
                    '<div class="' + classBillingUndoKey + '">' + $("#billingAmountUndoSection").html() + '</div>' +
                    '</td>' +
                    '<td class="billing-reason cpf_0-4">\
												   <div id="' + billReasonOriginalValContainer + '" class="billing-reason-original-value-container cpf_0-4-0">' +
                    billing_reason_title +
                    '</div><div class="expenseSection cp_hidden">' + expenseSection + '</div> <div class="expenseTypeInfo cp_hidden">' + expenseTypeInfo + '</div>' +
			'<div class="' + BillingReasonContainerclass + '">' + $("#billingReasonDDSectionExpenses").html() + '</div>' }
			row = row +
//End of CHG0076763 Prevent billing updates on the Service Estimate	
												  
												 /*  <a rownumber="' + rowCount + '" id="' + billAmtOrigValLink + '" class="billing-amount-original-value-link billAmtOrigVal" ' + activityStyle + '>\
	                                                  ' + billing_amount +
	                    '</a></div>' +
	                    '<div class="' + classBillingUndoKey + '">' + $("#billingAmountUndoSection").html() + '</div>' +
	                    '</td>' +
	                    '<td class="billing-reason cpf_0-4">\
													   <div id="' + billReasonOriginalValContainer + '" class="billing-reason-original-value-container cpf_0-4-0">' +
	                    billing_reason_title +
	                    '</div><div class="expenseSection cp_hidden">' + expenseSection + '</div> <div class="expenseTypeInfo cp_hidden">' + expenseTypeInfo + '</div>' +
	                    '<div class="' + BillingReasonContainerclass + '">' + $("#billingReasonDDSectionExpenses").html() + '</div>' + */
						
	                    '</td>' +
	                    '<td> <div class="dateColumn">' + datefromXML + '</div><div class="pass_count_Column" style="display:none;">' + pass_count + '</div></td>\
											 </tr>';
	                $('#activity_billing_grid').append(row);
	
	                //Add the new Id for Billing Amount.
	                var BillAmtUndoCol_rowData = "BillAmtUndoCol_" + rowCount;
	                var billAmtUndoLink_row = "billAmtUndoLink_" + rowCount;
	                var inner_overriden_val = "inner_overriden_val_" + rowCount;
	                var BillingReasonContainer_Id = "billing_reason_container_" + rowCount;
	
	                $("div." + classBillingUndoKey + " > div#billAmtOverriddenContainer").attr('id', BillAmtUndoCol_rowData);
	                $("div." + classBillingUndoKey).find("a#billAmtUndoLink").attr('id', billAmtUndoLink_row);
	                $("div." + classBillingUndoKey).find("input#cpf_inner_overriden_val").attr('id', inner_overriden_val);
	                $("div." + BillingReasonContainerclass).find("div#billreason-overriden-container-expenses").attr('id', BillingReasonContainer_Id);
					
					  var selectedText = billing_reason_title;
	                        $("#" + BillingReasonContainer_Id).find("select#cpf_billingReasonDDSectionExpenses option").map(function () {
									if ($(this).text() == selectedText) return this;
								}).attr('selected', 'selected');
								
	                billing_amount = billing_amount.replace("$", "");
	                billing_amount = $.trim(billing_amount);
	                billing_amount = parseFloat(billing_amount).toFixed(2);
	                $("#" + inner_overriden_val).val(billing_amount);
	
	              /*  if (!aContractFlag) {
	                    //set the billing reason dropdown:
	                    $('div.' + BillingReasonContainerclass).find('select option:contains("' + billing_reason + '")').prop('selected', true);
	                } else {
	
	                    $('div.' + BillingReasonContainerclass).find('select option[value=""]').attr("selected", true);
	                }
					*/
	
	                $('#' + billAmtOrigValLink).on('click', function(e) {
	
	                    $("#" + billAmtOrigValLink).addClass("cp_hidden");
	                    $("#" + billReasonOriginalValContainer).addClass("cp_hidden");
	
	                    $("#" + BillAmtUndoCol_rowData).removeClass("cp_hidden");
	                    $("#" + BillingReasonContainer_Id).removeClass("cp_hidden");
						
	
	                    //copy over the Price/billAmt to the input box.
	                    var undoAmtOrig = $('#' + billAmtOrigValLink).text();
	                    undoAmtOrig = undoAmtOrig.replace("$", "");
	                    undoAmtOrig = $.trim(undoAmtOrig);
	                    $("#" + BillAmtUndoCol_rowData).find('.cpf_input_overriden_val').val(parseFloat(undoAmtOrig).toFixed(2));
	                    // $("#"+BillAmtUndoCol_rowData).find('.cpf_input_overriden_val').val('99.00');					
	                }.bind(this));
	
	                $('#' + billAmtUndoLink_row).on('click', function(e) {
	
	                    $("#" + billAmtOrigValLink).removeClass("cp_hidden");
	                    $("#" + billReasonOriginalValContainer).removeClass("cp_hidden");
	
	                    $("#" + BillAmtUndoCol_rowData).addClass("cp_hidden");
	                    $("#" + BillingReasonContainer_Id).addClass("cp_hidden");
	
	
	                    var undoAmt = $('#' + priceAmtOrigValLink).text();
	                    undoAmt = undoAmt.replace("$", "");
	                    undoAmt = $.trim(undoAmt);
	                    undoAmt = parseFloat(undoAmt).toFixed(2);
	                    //set the billingamount back to the Original Value.
	                    //$("#" + BillAmtUndoCol_rowData).find('.cpf_input_overriden_val').val(undoAmt);
	                   // $('#' + billAmtOrigValLink).text('$ ' + undoAmt);
					    var undoAmtOrig = $('#' + billAmtOrigValLink).text();
	                        undoAmtOrig = undoAmtOrig.replace("$", "");
	                        undoAmtOrig = $.trim(undoAmtOrig);
	                        $("#" + BillAmtUndoCol_rowData).find('.cpf_input_overriden_val').val(parseFloat(undoAmtOrig).toFixed(2));
	
	                    //Recalculate the total:
	                    $.recalculateBillAmountTotal();
	
	                }.bind(this));
	
	                // On change of the input values recalculate the column total
	
	                $('#' + inner_overriden_val).on("change paste keyup", function() {
							var enteredVal = $(this).val();
							
							if(isNaN(enteredVal) || enteredVal.indexOf(' ') >=0) {   
								$(this).val("");
							}
							enteredVal = $(this).val();
							
							if(enteredVal >= 1000000){
								alert("Value too large, Please adjust the value to be less than 999999.99");
								$(this).val(0.00);
							}
							
	                    $.recalculateBillAmountTotal();
	
	                });
	
	                //check if Overridden flag is set to true: if yes then apply the hiding logic, and display the editable col vals for bill Amt and bill.reason--
	                if (isOverriden == 'Y'){// && !LockRow) {
	                    $("#" + billAmtOrigValLink).addClass("cp_hidden");
	                    $("#" + billReasonOriginalValContainer).addClass("cp_hidden");
	
	                    $("#" + BillAmtUndoCol_rowData).removeClass("cp_hidden");
	                    $("#" + BillingReasonContainer_Id).removeClass("cp_hidden");
	                }
					
					/*if(LockRow){
							 $("#" + billAmtOrigValLink).css({"border-bottom": "none","pointer-events": "none"});
					}*/
            	}
				catch(err){
					activityLog = activityLog + ';Exception in find expense :'+err.message;
					console.log(" Exception in find expense :"+err.message);
				} 

            });

            if (se_billing_info_xml != null) {
            	try{
	                //To get the Material Handling Fee Row
	
	                se_billing_info_xml.find('billingInfo').find('billingItems').find('material_handling_fee').each(function() {
	                    var date = $(this).find("date").text();
	                    var quantity = 1;
	                    var prod_number = $(this).find("prod_number").text();
	                    var name = $(this).find("name").text();
						var datefromXML =  $(this).find("date").text();
	                    var price, price_summ, billing_amount = '0.00';
						var isOverriden = $(this).find("is_overriden").text();
	                 //
	                    if (totalLaborPrice > 25) {
							 price = $(this).find("price").text();
	                        price_summ = $(this).find("price_summ").text();
							if (!aContractFlag) {
	                          billing_amount = price_summ;//$(this).find("billing_amount").text();
							}
	                      
	                    } else {
	                         price = '0.00';
	                        price_summ = '0.00';
	                        billing_amount = '0.00';
	                    }
	                    var billing_reason = $(this).find("billing_reason").text();
	                    var billing_reason_title = $(this).find("billing_reason_title").text();
						
						 if (isOverriden == 'Y') {
	
						        billing_amount = $(this).find("billing_amount").text();
						  }
	                    rowCount += 1;
	                    var classBillingUndoKey = "BillingAmt_" + rowCount;
	                    var BillingReasonContainerclass = "BillingReasonContainer_" + rowCount
	                    var billAmtOrigValLink = "billing-amount-original-value-link-" + rowCount;
	                    var billReasonOriginalValContainer = "bill-reason-original-value-container-" + rowCount;
	
	                    var activityStyle = "";
	                   /* if (!aContractFlag) {
	                        activityStyle = 'style="border-bottom: none;cursor: text;"';
	                    }*/
	                    var row = '<tr id="cpf_material" class="billing-items-grid-row cpf_material_row">\
								               <td class=" cpf_0-0"> <div class="quantity-column-readonly cpf_quantity ">' + quantity + '</div>' + //$("#QtyDDSection").html()+
	                        '</td>' +
	                        '<td class=" cpf_0-1"><div class="item_number">' + prod_number + '</div><div class="item_description">' + name + '</div></td>\
											   <td id="materialHandlingPrice" class="ext-price numeric-column ext-price-col">$ ' + price_summ + '</td>\
											   <td class="billing-amount cpf_0-3 materialHandlingRow">\
	                                              <div class="billing-amount-original-value-container numeric-column cpf_0-3-0">\ ' ;
												  
//start of CHG0076763 Prevent billing updates on the Service Estimate
                              if (isIntallCall)
											   {row = row +'<p rownumber="' + rowCount + /* '" id="' + billAmtOrigValLink + */ '" >\
												  $ 0' +
											   '</p>'
											    row = row + '</div>' +
											   '<td class="billing-reason cpf_0-4">\
		<div id="' + billReasonOriginalValContainer + '" class="billing-reason-original-value-container cpf_0-4-0">' + '</div>' +	
'<div class="' + BillingReasonContainerclass + '">' + $("#billingReasonDDSectionParts").html() + '</div>'			
												  '<td> <div class="dateColumn">' + datefromXML + '</div>'
												  //<div class="pass_count_Column" style="display:none;">' + pass_count + '</div>'
												  row= row + '</td>'
											   }
									else
											  {
												  row = row +
												'<a rownumber="' + rowCount + '" id="' + billAmtOrigValLink + '" class="billing-amount-original-value-link materialHandlingBillAmt"  ' + activityStyle + '>\
                                                  $ ' + billing_amount +
                        '</a>' 
						row = row + '</div>' +
                        '<div class="' + classBillingUndoKey + '">' + $("#billingAmountUndoSection").html() + '</div>' +
                        '</td>' +
                        '<td class="billing-reason cpf_0-4">\
												 <div id="' + billReasonOriginalValContainer + '" class="billing-reason-original-value-container cpf_0-4-0">' +
                        billing_reason_title +
                        '</div>' +
				'<div class="' + BillingReasonContainerclass + '">' + $("#billingReasonDDSection").html() + '</div>'}
				row = row +
//End of CHG0076763 Prevent billing updates on the Service Estimate
												  
	                                                  /* <a rownumber="' + rowCount + '" id="' + billAmtOrigValLink + '" class="billing-amount-original-value-link materialHandlingBillAmt"  ' + activityStyle + '>\
	                                                  $ ' + billing_amount +
	                        '</a></div>' +
	                        '<div class="' + classBillingUndoKey + '">' + $("#billingAmountUndoSection").html() + '</div>' +
	                        '</td>' +
	                        '<td class="billing-reason cpf_0-4">\
													 <div id="' + billReasonOriginalValContainer + '" class="billing-reason-original-value-container cpf_0-4-0">' +
	                        billing_reason_title +
	                        '</div>' +
	                        '<div class="' + BillingReasonContainerclass + '">' + $("#billingReasonDDSection").html() + '</div>' + */
							
	                        '</td>' +
	                        '<td class="dateColumn">' + datefromXML + '</td>\
											 </tr>';
	
	                    $('#activity_billing_grid').append(row);
	                    //Add the new Id for Billing Amount.
	                    var BillAmtUndoCol_rowData = "BillAmtUndoCol_" + rowCount;
	                    var billAmtUndoLink_row = "billAmtUndoLink_" + rowCount;
	                    var inner_overriden_val = "inner_overriden_val_" + rowCount;
	                    var BillingReasonContainer_Id = "billing_reason_container_" + rowCount;
	
	                    $("div." + classBillingUndoKey + " > div#billAmtOverriddenContainer").attr('id', BillAmtUndoCol_rowData);
	                    $("div." + classBillingUndoKey).find("a#billAmtUndoLink").attr('id', billAmtUndoLink_row);
	                    $("div." + classBillingUndoKey).find("input#cpf_inner_overriden_val").attr('id', inner_overriden_val);
	                    $("div." + BillingReasonContainerclass).find("div#billreason-overriden-container").attr('id', BillingReasonContainer_Id);
						  var selectedText = billing_reason_title;
	                        $("#" + BillingReasonContainer_Id).find("select#cpf_billingReasonDDSection option").map(function () {
									if ($(this).text() == selectedText) return this;
								}).attr('selected', 'selected');
	                    $("#" + inner_overriden_val).val(billing_amount);
	
	
	                    $('#' + billAmtOrigValLink).on('click', function(e) {
	
	                        $("#" + billAmtOrigValLink).addClass("cp_hidden");
	                        $("#" + billReasonOriginalValContainer).addClass("cp_hidden");
	
	                        $("#" + BillAmtUndoCol_rowData).removeClass("cp_hidden");
	                        $("#" + BillingReasonContainer_Id).removeClass("cp_hidden");
							 
						
	
	                        //copy over the billAmt to the input box.
	                        var undoAmtOrig = $('#' + billAmtOrigValLink).text();
	                        undoAmtOrig = undoAmtOrig.replace("$", "");
	                        undoAmtOrig = $.trim(undoAmtOrig);
	                        $("#" + BillAmtUndoCol_rowData).find('.cpf_input_overriden_val').val(parseFloat(undoAmtOrig).toFixed(2));
	                        // $("#"+BillAmtUndoCol_rowData).find('.cpf_input_overriden_val').val('99.00');					
	                    }.bind(this));
	
	                    $('#' + billAmtUndoLink_row).on('click', function(e) {
	
	                        $("#" + billAmtOrigValLink).removeClass("cp_hidden");
	                        $("#" + billReasonOriginalValContainer).removeClass("cp_hidden");
	
	                        $("#" + BillAmtUndoCol_rowData).addClass("cp_hidden");
	                        $("#" + BillingReasonContainer_Id).addClass("cp_hidden");
	
							 //set the billingamount back to the Original Value.
	                         
	
	                        
							 var undoAmtOrig = $('#' + billAmtOrigValLink).text();
	                        undoAmtOrig = undoAmtOrig.replace("$", "");
	                        undoAmtOrig = $.trim(undoAmtOrig);
	                        $("#" + BillAmtUndoCol_rowData).find('.cpf_input_overriden_val').val(parseFloat(undoAmtOrig).toFixed(2));
							 //Recalculate the total:
	                        $.recalculateBillAmountTotal();
	
	                    }.bind(this));
	
	                    // On change of the input values recalculate the column total
						 $('#' + inner_overriden_val).on("change paste keyup", function() {
								var enteredVal = $(this).val();
							
							if(isNaN(enteredVal) || enteredVal.indexOf(' ') >=0) {   
								$(this).val("");
							}
							enteredVal = $(this).val();
							
							if(enteredVal >= 1000000){
								alert("Value too large, Please adjust the value to be less than 999999.99");
								$(this).val(0.00);
							}						
							
	                        $.recalculateBillAmountTotal();
	                    });
						
						 //check if Overridden flag is set to true: if yes then apply the hiding logic, and display the editable col vals for bill Amt and bill.reason--
	                if (isOverriden == 'Y') {
	                    $("#" + billAmtOrigValLink).addClass("cp_hidden");
	                    $("#" + billReasonOriginalValContainer).addClass("cp_hidden");
	
	                    $("#" + BillAmtUndoCol_rowData).removeClass("cp_hidden");
	                    $("#" + BillingReasonContainer_Id).removeClass("cp_hidden");
	                }
	
	                 
	                });
            	}
				catch(err){
					activityLog = activityLog + ';Exception in find material_handling_fee :'+err.message;
					console.log(" Exception in find material_handling_fee :"+err.message);
				} 
            }
            //Generate the total rows:
            var extOverPrice = 0;
            var billingAmt = 0;
            $('table tr.billing-items-grid-row').each(function() {
            	try{
	                $(this).find('.ext-price').each(function() {
	                    var extOverP = $(this).text();
	                    extOverP = extOverP.replace("$", "");
	                    extOverP = $.trim(extOverP);
	                    extOverP = parseFloat(extOverP);
	                    if (!isNaN(extOverP) && extOverP.length !== 0) {
	                        extOverPrice += extOverP;
	                    }
	                });
	
	                $(this).find('.billing-amount-original-value-link').each(function() {
	                    var billAmt = $(this).text();
	                    billAmt = billAmt.replace("$", "");
	                    billAmt = $.trim(billAmt);
	                    billAmt = parseFloat(billAmt);
	                    if (!isNaN(billAmt) && billAmt.length !== 0) {
	                        billingAmt += billAmt;
	                    }
	                });
            	}
				catch(err){
					activityLog = activityLog + ';Exception in table tr.billing-items-grid-row :'+err.message;
					console.log(" Exception in table tr.billing-items-grid-row :"+err.message);
				} 
            });
            var ext_price_total = extOverPrice.toFixed(2);
            var billAmt_total = billingAmt.toFixed(2);
            var total_rowLast = '<tr id="cpf__unnamed_29_footer" class="billing-items-grid-footer">\
						                         <td class=" cpf_1-0" style=""></td>\
												 <td class="billing-items-grid-footer-title cpf_1-1" style="">Total excluding Taxes</td>\
												 <td id = "ext_price_Total" class="ext_price_total numeric-column cpf_1-2" style="">$ ' + ext_price_total + '</td>\
												 <td class="billAmt_total numeric-column cpf_1-3" style="">$ ' + billAmt_total + '</td>\
												 <td colspan="2" class=" cpf_1-4" style=""></td>\
												 </tr>';
            $('#activity_billing_grid').append(total_rowLast);

            // Update the total excluding the taxes.
            $("#cpf_TotalExcludingTaxes_inner").text("$ " + billAmt_total);

            //CHG0068179 --
            if (billAmt_total>0){
            	$("#serviceEstEmail").prop('checked', true);
            	$("#mandatryEmail").removeClass("cp_hidden");
            }
            
            //View term checked:
            $("#cpf_viewTerms_Check ").change(function() {
                if (this.checked) {
                    $("#termsAndConditions").removeClass("cp_hidden");
                } else {
                    $("#termsAndConditions").addClass("cp_hidden");
                }
            });
            
          //CHG0068179 --
            $("#serviceEstEmail").change(function() {
                if (this.checked) {
                	 $("#mandatryEmail").removeClass("cp_hidden");
                } else {
                    $("#mandatryEmail").addClass("cp_hidden");
                }

            });
            
            
            //Submit Button Function:

            $('.submit').click(function() {
                //Process the labor row
				var proceedWithRest = true;
                var $se_billing_info_firstLoadXml = $('<XMLDocument />');

                var $se_billing_info_billInfo = $.createElement('billingInfo');
                var $se_billing_info_billItems = $.createElement('billingItems');

                var aSETotalExpenses = 0; // total of bill amount of expenses.
                var aSETotalParts = 0; // total of bill amount of Parts.
                var aSETotalLabour = 0; // Total of Bill Amt for A_SE_TOTAL_EXPENSES + A_SE_TOTAL_PARTS
                var aSETotal = 0; // Total 
				
				var aBillingReason = ""; //A_BILLING_REASON : aBillingReason
				var aLabourOverridePrice = null;//A_LABOR_OVERRIDE_PRICE : aLabourOverridePrice 
				var aMaterialFeeOverride = null;// A_MATERIAL_FEE_OVERRIDE : aMaterialFeeOverride
				var strEmailServiceEst = 'N'; //A_EMAIL_SERVICE_ESTIMATE

                var $seExpensesPluginXml = $('<XMLDocument />');

                $('table tr.cpf_labor_row').each(function() {
                    //alert("Inside bill items grid");
                    var selectedValue = $(this).find('.cpf_quantitydropdown').val();
                    var quantity = parseFloat(selectedValue).toFixed(2);
					if(isNaN(quantity)){
						quantity = "";
						
					}
                    var selectedText = $(this).find('.cpf_quantitydropdown option:selected').text();

                    var prod_number = $(this).find('.item_number').text();
                    var prod_description = $(this).find('.item_description').text();
                    var ext_price_col = $(this).find('.ext-price-col').text();
                    ext_price_col = ext_price_col.replace("$", "");
                    ext_price_col = $.trim(ext_price_col);
                    ext_price_col = parseFloat(ext_price_col).toFixed(2);

                    var overridenPrice = $(this).find('#std-labor-billamount').text();
                    overridenPrice = overridenPrice.replace("$", "");
                    overridenPrice = $.trim(overridenPrice);
					if(overridenPrice == ""){
						overridenPrice = 0;
					}else{
					overridenPrice = parseFloat(overridenPrice).toFixed(2);
					}
                    var selectedBillReasonCode = $(this).find('.billreasondropdown').val();
                    var selectedBillReasonDesc = $(this).find('.billreasondropdown option:selected').text();

                    var dateCol = $(this).find('.dateColumn').text();

                    var $se_billing_info_labor = $.createElement('labor');
                    $se_billing_info_labor.append($.createElement('key', currDateTimeFormat));
                    $se_billing_info_labor.append($.createElement('date', dateCol));
                    $se_billing_info_labor.append($.createElement('quantity', quantity));
                    $se_billing_info_labor.append($.createElement('quantity_unit', "hrs"));
                    $se_billing_info_labor.append($.createElement('prod_number', prod_number));
                    $se_billing_info_labor.append($.createElement('name', prod_description));
                    $se_billing_info_labor.append($.createElement('price', ext_price_col));
                    $se_billing_info_labor.append($.createElement('price_summ', overridenPrice));
                    $se_billing_info_labor.append($.createElement('is_overriden', 'N'));
                    $se_billing_info_labor.append($.createElement('billing_amount', overridenPrice));
                    $se_billing_info_labor.append($.createElement('billing_reason', selectedBillReasonCode));
                    $se_billing_info_labor.append($.createElement('billing_reason_title', selectedBillReasonDesc));

                    $se_billing_info_billItems.append($se_billing_info_labor);

                });


                //Process the total labor row
                $('table tr.cpf_total_labor_row').each(function() {
                	
                	try{

	                    var quantity = $(this).find('.cpf_quantity').text();
	                    quantity = quantity.replace("$", "");
	                    quantity = $.trim(quantity);
	                    quantity = parseFloat(quantity).toFixed(2);
	                    //var selectedText=$(this).find('.cpf_quantitydropdown option:selected').text();
	
	                    var prod_number = $(this).find('.item_number').text();
	                    var prod_description = $(this).find('.item_description').text();
	                    var ext_price_col = $(this).find('.ext-price-col').text();
	                    ext_price_col = ext_price_col.replace("$", "");
	                    ext_price_col = $.trim(ext_price_col);
						ext_price_col = parseFloat(ext_price_col).toFixed(2);
	                    var overridenPrice = $(this).find('.cpf_input_overriden_val').val();
						if((overridenPrice == "")|| isNaN(parseFloat(overridenPrice))){
							overridenPrice = 0;
						}else{
						overridenPrice = parseFloat(overridenPrice).toFixed(2);
						}
	                    var selectedBillReasonCode = $(this).find('.billreasondropdown').val();
	                    var selectedBillReasonDesc = $(this).find('.billreasondropdown option:selected').text();
	
	                    var dateCol = $(this).find('.dateColumn').text();
	                    var isOverriden ="";
	
	                    if (ext_price_col != overridenPrice) {
	                       
							
							  if(aContractFlag && overridenPrice > 0 || !aContractFlag){
								   isOverriden = 'Y';
							  }else{
								   isOverriden = 'N';
							  }
							 if(aContractFlag && overridenPrice > 0 && selectedBillReasonCode == ""){
								 
									$(this).addClass("error-highlited");
									alert(prod_description+" - Billing reason is not specified.");
									proceedWithRest = false;
									return false;
								}
								
							 if(!aContractFlag && selectedBillReasonCode == ""){
								  
								$(this).addClass("error-highlited");
								alert(prod_description+" - Billing reason is not specified.");
								proceedWithRest = false;
								return false;
							}
							
	                    } else {
	                        isOverriden = 'N';
							$(this).removeClass("error-highlited");
	                    }
	
	
	                    var $se_billing_info_labor = $.createElement('total_labor');
	                    $se_billing_info_labor.append($.createElement('key', 'total_labor'));
	                    $se_billing_info_labor.append($.createElement('date', dateCol));
	                    $se_billing_info_labor.append($.createElement('quantity', '0' + quantity));
	                    $se_billing_info_labor.append($.createElement('quantity_unit', "hrs"));
	                    $se_billing_info_labor.append($.createElement('prod_number', prod_number));
	                    $se_billing_info_labor.append($.createElement('name', prod_description));
	                    $se_billing_info_labor.append($.createElement('price', ext_price_col));
	                    $se_billing_info_labor.append($.createElement('price_summ', ext_price_col));
	                    $se_billing_info_labor.append($.createElement('is_overriden', isOverriden));
	                    $se_billing_info_labor.append($.createElement('billing_amount', overridenPrice));
	                    $se_billing_info_labor.append($.createElement('billing_reason', selectedBillReasonCode));
	                    $se_billing_info_labor.append($.createElement('billing_reason_title', selectedBillReasonDesc));
	
	                    $se_billing_info_billItems.append($se_billing_info_labor);
						
						// Navaz:14Mar18 - additional fields update.
						aSETotalLabour = overridenPrice;
						aBillingReason = selectedBillReasonCode;
						 if(aContractFlag)
						 {
							 if(overridenPrice > 0){
						         aLabourOverridePrice = aSETotalLabour;
							 }
						 }else{
							 if (ext_price_col != overridenPrice){
								  aLabourOverridePrice = aSETotalLabour;
							 }
							 
						 }
	                }
					catch(err){
						activityLog = activityLog + ';Exception in table tr.cpf_total_labor_row :'+err.message;
						console.log(" Exception in table tr.cpf_total_labor_row :"+err.message);
					} 
                });
				
				if(!proceedWithRest){
					return false;
				}
                //Process the parts rows

                var $debrief_partLineXml = $('<XMLDocument />');
                var previousPartItemNumArr = [];
                var prod_number;
                var duplicatePartItems = false;
                $('table tr.cpf_parts_row').each(function() {

                	try{
	                    var quantity = $(this).find('.cpf_quantity').text();
	                    //var selectedText=$(this).find('.cpf_quantitydropdown option:selected').text();
	
	                    var prod_number = $(this).find('.item_number').text();
	                    var prod_description = $(this).find('.item_description').text();
	                    var ext_price_col = $(this).find('.ext-price-col').text();
	                    ext_price_col = ext_price_col.replace("$", "");
	                    ext_price_col = $.trim(ext_price_col);
	                    ext_price_col = parseFloat(ext_price_col).toFixed(2);
	                    var overridenPrice = $(this).find('.cpf_input_overriden_val').val();
	                    if((overridenPrice == "")|| isNaN(parseFloat(overridenPrice))){
							overridenPrice = 0;
						}else{
						overridenPrice = parseFloat(overridenPrice).toFixed(2);
						}
	                    var selectedBillReasonCode = $(this).find('.billreasondropdownParts').val();
	                    var selectedBillReasonDesc = $(this).find('.billreasondropdownParts option:selected').text();
	
	                    var dateCol = $(this).find('.dateColumn').text();
	                    var passCountCol = $(this).find('.pass_count_Column').text();
	                    var isOverriden;
	
	                    if (ext_price_col != overridenPrice) {
	                          if(aContractFlag && overridenPrice > 0 || !aContractFlag){
								   isOverriden = 'Y';
							  }else{
								   isOverriden = 'N';
							  }
							
							 if(aContractFlag && overridenPrice > 0 && selectedBillReasonCode == ""){
									$(this).addClass("error-highlited");
									alert(prod_description+" - Billing reason is not specified.");
									proceedWithRest = false;
									return false;
								}
								
							 if(!aContractFlag && selectedBillReasonCode == ""){
								$(this).addClass("error-highlited");
								alert(prod_description+" - Billing reason is not specified.");
								proceedWithRest = false;
								return false;
							}
	                    } else {
	                        isOverriden = 'N';
							$(this).removeClass("error-highlited");
	                    }
	
	                    var $se_billing_info_parts = $.createElement('part');
	                    $se_billing_info_parts.append($.createElement('key', currDateTimeFormat + ' ' + prod_number));
	                    $se_billing_info_parts.append($.createElement('date', dateCol));
	                    $se_billing_info_parts.append($.createElement('quantity', quantity));
	                    $se_billing_info_parts.append($.createElement('quantity_unit', ''));
	                    $se_billing_info_parts.append($.createElement('prod_number', prod_number));
	                    $se_billing_info_parts.append($.createElement('name', prod_description));
	                    $se_billing_info_parts.append($.createElement('price', ext_price_col));
	                    $se_billing_info_parts.append($.createElement('price_summ', ext_price_col));
	                    $se_billing_info_parts.append($.createElement('is_overriden', isOverriden));
	                    $se_billing_info_parts.append($.createElement('billing_amount', overridenPrice));
	                    $se_billing_info_parts.append($.createElement('billing_reason', selectedBillReasonCode));
	                    $se_billing_info_parts.append($.createElement('billing_reason_title', selectedBillReasonDesc));
						$se_billing_info_parts.append($.createElement('pass_count', passCountCol));
	
	                    $se_billing_info_billItems.append($se_billing_info_parts);
	
	                    if (!isNaN(overridenPrice) && overridenPrice.length !== 0) {
	                        aSETotalParts += parseFloat(overridenPrice);
	                    }
	
	                    //build the A_PARTS XML File for all parts:
	
	                    /*<DebriefPartLine>
	                    	<A_IN_SERVICE_DTS>2017-12-27</A_IN_SERVICE_DTS>
	                    	<I_MATERIAL_PART_NUMBER>10R0336</I_MATERIAL_PART_NUMBER>
	                    	<A_SUBINVENTORY_CODE>AMERISOUTE</A_SUBINVENTORY_CODE>
	                    	<quantity>1</quantity>
	                    	<I_MATERIAL_OVERRIDE_PRICE></I_MATERIAL_OVERRIDE_PRICE>
	                    	<I_MATERIAL_OVERRIDE_REASON_CODE></I_MATERIAL_OVERRIDE_REASON_CODE>
	                    	<A_IGNORE_FLAG></A_IGNORE_FLAG>
	                    </DebriefPartLine>*/
	
	                    var $debrief_partLine =
	
	                        $.each(inventoryList, function(key, invItem) {
	
	                            if (invItem.inv_aid == receivedData.activity.aid) {
	
	                                if (invItem.invpool == "install") { // || invItem.invpool == "deinstall") {
	
	                                    if (invItem.I_ITEM_NUMBER == prod_number) {
	                                        var invID = invItem.invid;
	                                        var qty = invItem.quantity;
	                                        var iSubInventory = invItem.I_SUBINVENTORY;
	
	                                        var $debrief_partLine = $.createElement('DebriefPartLine');
	                                        $debrief_partLine.append($.createElement('A_IN_SERVICE_DTS', date_YYYY_MM_DD));
	                                        $debrief_partLine.append($.createElement('I_MATERIAL_PART_NUMBER', prod_number));
	                                        $debrief_partLine.append($.createElement('A_SUBINVENTORY_CODE', iSubInventory));
	                                        $debrief_partLine.append($.createElement('quantity', quantity));
	                                        // Only if override is true then add the below two elements to the XML.
	                                        if (isOverriden == 'Y') {
	                                            $debrief_partLine.append($.createElement('I_MATERIAL_OVERRIDE_PRICE', overridenPrice));
	                                            $debrief_partLine.append($.createElement('I_MATERIAL_OVERRIDE_REASON_CODE', selectedBillReasonCode));
	                                        } else {
	                                            $debrief_partLine.append($.createElement('I_MATERIAL_OVERRIDE_PRICE', ''));
	                                            $debrief_partLine.append($.createElement('I_MATERIAL_OVERRIDE_REASON_CODE', ''));
	
	
	                                        }
	                                        $debrief_partLine.append($.createElement('A_IGNORE_FLAG', ''));
	
	                                        $debrief_partLineXml.append($debrief_partLine);
	                                    }
	
	                                }
	                            }
	                        });
                	}
    				catch(err){
    					activityLog = activityLog + ';Exception in table tr.cpf_parts_row :'+err.message;
    					console.log(" Exception in table tr.cpf_parts_row :"+err.message);
    				} 


                });
				if(!proceedWithRest){
					return false;
				}

                //console.log("previousPartItemNum Arr"+ JSON.stringify(previousPartItemNum));
                // console.log("debrief_partLine "+$debrief_partLineXml.html());


                //check for duplicate items
                if (duplicatePartItems) {
                    if (confirm('There are multiple part lines with the same part number and date. Press \'Continue\' to submit Service Ticket or \'Cancel\' to go back to the screen.')) {
                        return false;
                    } else {
                        // Do nothing
                    }
                }
                //Process the expenses rows
                $('table tr.cpf_expenses_row').each(function() {
                	
                	try{

	                    var quantity = $(this).find('.cpf_quantity').text();
	                    //var selectedText=$(this).find('.cpf_quantitydropdown option:selected').text();
	
	                    var prod_number = $(this).find('.item_number').text();
	                    var prod_description = $(this).find('.item_description').text();
	                    var ext_price_col = $(this).find('.ext-price-col').text();
	                    if (ext_price_col != 'na') {
	                        ext_price_col = ext_price_col.replace("$", "");
	                        ext_price_col = $.trim(ext_price_col);
	                        ext_price_col = parseFloat(ext_price_col).toFixed(2);
	                    } else {
	                        ext_price_col = 0;
	                    }
	                    var overridenPrice = $(this).find('.cpf_input_overriden_val').val();
						if((overridenPrice == "")|| isNaN(parseFloat(overridenPrice))){
							overridenPrice = 0;
						}else{
						overridenPrice = parseFloat(overridenPrice).toFixed(2);
						}
	                    if (isNaN(overridenPrice)) {
	                        overridenPrice = 0;
	                    }
	                    var selectedBillReasonCode = $(this).find('.billreasondropdownExpenses').val();
	                    var selectedBillReasonDesc = $(this).find('.billreasondropdownExpenses option:selected').text();
	                    var expenseSection = $(this).find('.expenseSection').text();
	                    var expenseTypeInfo = $(this).find('.expenseTypeInfo').text();
	                    var dateCol = $(this).find('.dateColumn').text();
						var passCountCol = $(this).find('.pass_count_Column').text();
	                    var isOverriden;
	
	                    if (ext_price_col != overridenPrice) {
	                          if(aContractFlag && overridenPrice > 0 || !aContractFlag){
								   isOverriden = 'Y';
							  }else{
								   isOverriden = 'N';
							  }
							 
							 if(aContractFlag && overridenPrice > 0 && selectedBillReasonCode == ""){
									$(this).addClass("error-highlited");
									alert(prod_description+" - Billing reason is not specified.");
									proceedWithRest = false;
									return false;
								}
								
							 if(!aContractFlag && selectedBillReasonCode == ""){
								$(this).addClass("error-highlited");
								alert(prod_description+" - Billing reason is not specified.");
								proceedWithRest = false;
								return false;
							}
							 
	                    } else {
	                        isOverriden = 'N';
							$(this).removeClass("error-highlited");
	                    }
						
	                  //CHG0067765 Condition Based Maintenance
						if(expenseTypeInfo =="activities" || expenseTypeInfo == "condition based maintainance"){
							selectedBillReasonCode = "";
							selectedBillReasonDesc = "";
						}
	                    var $se_billing_info_expense = $.createElement('expense');
	                    $se_billing_info_expense.append($.createElement('key', currDateTimeFormat + ' ' + prod_number));
	                    $se_billing_info_expense.append($.createElement('date', dateCol));
	                    $se_billing_info_expense.append($.createElement('quantity', quantity));
	                    $se_billing_info_expense.append($.createElement('quantity_unit', ''));
	                    $se_billing_info_expense.append($.createElement('prod_number', prod_number));
	                    $se_billing_info_expense.append($.createElement('name', prod_description));
	                    $se_billing_info_expense.append($.createElement('price', ext_price_col));
	                    $se_billing_info_expense.append($.createElement('price_summ', ext_price_col));
	                    $se_billing_info_expense.append($.createElement('is_overriden', isOverriden));
	                    $se_billing_info_expense.append($.createElement('billing_amount', overridenPrice));
	                    $se_billing_info_expense.append($.createElement('billing_reason', selectedBillReasonCode));
	                    $se_billing_info_expense.append($.createElement('billing_reason_title', selectedBillReasonDesc));
	                    $se_billing_info_expense.append($.createElement('expense_type', expenseTypeInfo));
						$se_billing_info_expense.append($.createElement('pass_count', passCountCol));
	
	                    $se_billing_info_billItems.append($se_billing_info_expense);
	
	                    if (!isNaN(overridenPrice) && overridenPrice.length !== 0) {
	                        aSETotalExpenses += parseFloat(overridenPrice);
	                    }
	
							// Start INC1502678	  
							if(expenseTypeInfo =="activities"){
								ext_price_col = quantity;
							}		  
							// End INC1502678						  
							
							//CHG0067765 Condition Based Maintenance Start 
							if(expenseTypeInfo =="condition based maintainance"){
								ext_price_col = quantity;
							}
							//CHG0067765 Condition Based Maintenance End
							  
							  
	                    var $seExpensesPlugin = $.createElement('DebriefExpenseLine');
	                    $seExpensesPlugin.append($.createElement('A_EXPENSE_SECTION', expenseSection));
	                    $seExpensesPlugin.append($.createElement('A_EXPENSE_LABEL', prod_description));
	                    $seExpensesPlugin.append($.createElement('A_EXPENSE_TYPE', prod_number));
	                    //$seExpensesPlugin.append($.createElement('A_QUANTITY', quantity));
	                    $seExpensesPlugin.append($.createElement('A_EXPENSE_QUANTITY', quantity));
	                    $seExpensesPlugin.append($.createElement('A_AMOUNT', ext_price_col));
	                    $seExpensesPlugin.append($.createElement('A_OVERRIDE_PRICE', overridenPrice));
	                    $seExpensesPlugin.append($.createElement('A_PRICE_OVERRIDE_REASON_CODE', selectedBillReasonCode));
	                    $seExpensesPluginXml.append($seExpensesPlugin);
                	}
    				catch(err){
    					activityLog = activityLog + ';Exception in tr.cpf_expenses_row :'+err.message;
    					console.log(" Exception in tr.cpf_expenses_row :"+err.message);
    				} 
                });
				if(!proceedWithRest){
					return false;
				}
                //Process the materialHandling rows
                $('table tr.cpf_material_row').each(function() {

                	try{

	                    var quantity = $(this).find('.cpf_quantity').text();
	                    //var selectedText=$(this).find('.cpf_quantitydropdown option:selected').text();
	
	                    var prod_number = $(this).find('.item_number').text();
	                    var prod_description = $(this).find('.item_description').text();
	                    var ext_price_col = $(this).find('.ext-price-col').text();
	                    ext_price_col = ext_price_col.replace("$", "");
	                    ext_price_col = $.trim(ext_price_col);
	                    ext_price_col = parseFloat(ext_price_col).toFixed(2);
	                    var overridenPrice = $(this).find('.cpf_input_overriden_val').val();
						if((overridenPrice == "")|| isNaN(parseFloat(overridenPrice))){
							overridenPrice = 0;
						}else{
						overridenPrice = parseFloat(overridenPrice).toFixed(2);
						}
	                    var selectedBillReasonCode = $(this).find('.billreasondropdown').val();
	                    var selectedBillReasonDesc = $(this).find('.billreasondropdown option:selected').text();
	
	                    var dateCol = $(this).find('.dateColumn').text();
	                    var isOverriden;
	
	                    if (ext_price_col != overridenPrice) {
	                          if(aContractFlag && overridenPrice > 0 || !aContractFlag){
								   isOverriden = 'Y';
							  }else{
								   isOverriden = 'N';
							  }
							
							 if(aContractFlag && overridenPrice > 0 && selectedBillReasonCode == ""){
									$(this).addClass("error-highlited");
									alert(prod_description+" - Billing reason is not specified.");
									proceedWithRest = false;
									return false;
								}
								
							 if(!aContractFlag && selectedBillReasonCode == ""){
								$(this).addClass("error-highlited");
								alert(prod_description+" - Billing reason is not specified.");
								proceedWithRest = false;
								return false;
							}
	                    } else {
	                        isOverriden = 'N';
							$(this).removeClass("error-highlited");
	                    }
	
	                    var $se_billing_info_materialFee = $.createElement('material_handling_fee');
	                    $se_billing_info_materialFee.append($.createElement('key', prod_number));
	                    $se_billing_info_materialFee.append($.createElement('date', dateCol));
	                    $se_billing_info_materialFee.append($.createElement('quantity', quantity));
	                    $se_billing_info_materialFee.append($.createElement('quantity_unit', ''));
	                    $se_billing_info_materialFee.append($.createElement('prod_number', prod_number));
	                    $se_billing_info_materialFee.append($.createElement('name', prod_description));
	                    $se_billing_info_materialFee.append($.createElement('price', ext_price_col));
	                    $se_billing_info_materialFee.append($.createElement('price_summ', ext_price_col));
	                    $se_billing_info_materialFee.append($.createElement('is_overriden', isOverriden));
	                    $se_billing_info_materialFee.append($.createElement('billing_amount', overridenPrice));
	                    $se_billing_info_materialFee.append($.createElement('billing_reason', selectedBillReasonCode));
	                    $se_billing_info_materialFee.append($.createElement('billing_reason_title', selectedBillReasonDesc));
	
	                    $se_billing_info_billItems.append($se_billing_info_materialFee);
						
						//update A_MATERIAL_FEE_OVERRIDE
						if (ext_price_col != overridenPrice) {
						   aMaterialFeeOverride = overridenPrice;
						}

                	}
    				catch(err){
    					activityLog = activityLog + ';Exception in  tr.cpf_material_row :'+err.message;
    					console.log(" Exception in  tr.cpf_material_row :"+err.message);
    				} 


                });
				if(!proceedWithRest){
					return false;
				}

                $se_billing_info_billInfo.append($se_billing_info_billItems);


               // aSETotalLabour = parseFloat(aSETotalExpenses) + parseFloat(aSETotalParts);

                var aSETotal = $("#cpf_TotalExcludingTaxes_inner").text();
                aSETotal = aSETotal.replace("$", "");
                aSETotal = $.trim(aSETotal);
                aSETotal = parseFloat(aSETotal).toFixed(2);

                //check for PO_Number.
                var po_number = $("#po_number").val();
                if (aSETotal > 0 || poRequiredFlag) {

                    if (po_number == "" || po_number == null) {
						
                        alert("Please Enter the PO# Number.");
                        return;
                    }

                }
				
				// Begin CHG0078154
				// check for Problem and work performed
				var problem_work_performed = $("#probWorkPerformed").val();
				if (problem_work_performed.length < 4) {
					console.log("problem_work_performed :" + problem_work_performed.length);
					alert("Please provide an explanation of the work performed.");
					return;
				}
				// End CHG0078154
				
                var ext_price_total = $(".ext_price_total").text();
                ext_price_total = ext_price_total.replace("$", "");
                ext_price_total = $.trim(ext_price_total);
                ext_price_total = parseFloat(ext_price_total).toFixed(2);
                var $se_info_summaries = $.createElement('summaries');
                $se_info_summaries.append($.createElement('price_summ', ext_price_total));
                $se_info_summaries.append($.createElement('billing_amount', aSETotal));


                $se_billing_info_billInfo.append($se_info_summaries);
                $se_billing_info_firstLoadXml.append($se_billing_info_billInfo);
              //  console.log($se_billing_info_firstLoadXml.html());

                var se_BillingInfoHTML = this.generateSEBillingInfoHTML($se_billing_info_firstLoadXml);

                var signeeName = $("#signeeName").val();
                var signeeEmail = $("#signeeEmail").val();
                var billingComment = $("#probWorkPerformed").val();

                var total_labor_qty = $("#total_labor_qty").text();
              
                total_labor_qty = total_labor_qty.replace("hrs", "");               
                total_labor_qty = $.trim(total_labor_qty);
                total_labor_qty = '0' + total_labor_qty;                
                
                //CHG0068179 -- start change 
                var signeeName = $("#signeeName").val();
                if (signeeName =="" || signeeName == null){
                	alert ('Contact Name cannot be empty. Please enter Contact Name.');
                	return false;
                }
                var signeeEmail = $("#signeeEmail").val();
                var emailServiceEst = $('#serviceEstEmail').prop('checked');
                if(emailServiceEst){
                if (signeeEmail =="" || signeeEmail == null){
                		alert ('Contact Email cannot be empty. Please enter Contact Email.');
                		return false;
                	}
                	strEmailServiceEst = 'Y';

                }
                
                var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
            	if (!(emailReg.test(signeeEmail))) {
            		alert ('Please enter Contact Email in valid format.');
                	return false;
            	}
                //CHG0068179 -- End change
                
                var signatureImageData = sigdiv.signature('toDataURL');

                if (onloadedEmptySignatureBlock == signatureImageData) {
                    //empty block.
                    alert("Some fields were not filled correctly: \n \n Contact Signature - is not filled.");                  
                    return;
                }
                if(aSETotalParts){
				   aSETotalParts = parseFloat(aSETotalParts).toFixed(2);
				}
				 if(aSETotalLabour){
				   aSETotalLabour = parseFloat(aSETotalLabour).toFixed(2);
				}
				 if(aSETotalExpenses){
				   aSETotalExpenses = parseFloat(aSETotalExpenses).toFixed(2);
				} 
				if(aSETotal){
				   aSETotal = parseFloat(aSETotal).toFixed(2);
				}
				
				//SOAP to REST conversion. Adding activity log message
				if(activityLog != null && activityLog != ''){					
					activityLog = pluginName+' :-' + activityLog;	
					if(receivedData.activity.A_ACTIVITY_LOG != null){		
						activityLog = receivedData.activity.A_ACTIVITY_LOG + ';' + activityLog;
					}
				}
				else{
					if(receivedData.activity.A_ACTIVITY_LOG != null){		
						activityLog = receivedData.activity.A_ACTIVITY_LOG;
					}
					else{
						activityLog = null;
					}
				}

                var activityJSONData = {
                    aid: receivedData.activity.aid,
                    A_SE_TOTAL_PARTS: aSETotalParts+'',
                    A_SE_TOTAL_LABOR: aSETotalLabour+'',
                    A_SE_TOTAL_EXPENSES: aSETotalExpenses+'',
                    A_SE_TOTAL: aSETotal+'',
                    A_SE_SIGNEE_NAME: signeeName,
					A_SIGNEE_NAME:signeeName,
					A_SIGNEE_EMAIL: signeeEmail,
                    A_SE_SIGNEE_EMAIL: signeeEmail,
                    A_SE_SIGNATURE: signatureImageData,
                    A_SE_EXPENSES_OUTBOUND: $seExpensesPluginXml.html(),
                    A_SE_BILLING_INFO: $se_billing_info_firstLoadXml.html(),
                    A_SE_BILLING_COMMENT: billingComment,
					A_BILLING_COMMENT: billingComment,
                    A_SE_BILLING_INFO_HTML: se_BillingInfoHTML,
                    A_SE_LABOR_RATE: laborRate+'',
                    A_SE_MATERIAL_FEE: materialFee+'',
                    A_SE_EXPENSES_PLUGIN: $seExpensesPluginXml.html(),
                    A_PO_NUMBER: po_number+'',
                    A_ACTIVITY_LOG : activityLog, //Activity Log. SOAP to REST Conversion changes
                    A_SE_PARTS: $debrief_partLineXml.html()					
                };
                console.log(JSON.stringify(activityJSONData));
				
				//changes done for MPF Phase 4 -CHG0069304
			  var srcreationRESTServiceURL = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/serviceRequests";
				//
			  var nowDate = new Date();
			  var date = nowDate.toISOString().split('T')[0];
              var srCreationPayload ={
		            		"instanceName": receivedData.securedData.company,
		  					"date": date,  
		  					"activityId": parseInt(receivedData.activity.aid),
		  					"requestType": receivedData.securedData.serviceEstimateSRType,
		  					"requestEntity": "ACTIVITY",
		  					"pluginName": pluginName
			   };

			   
			   $.closeMethod = function(activityJSONData){

					ultimateBind._sendPostMessageData({
								"apiVersion": 1,
								"method": "close",
								"backScreen": "default",
								"wakeupNeeded": false,
								"activity": activityJSONData
							});
			};
     
                 console.log("SR creation API  -:srcreationRESTServiceURL" +srcreationRESTServiceURL);							
                 console.log("SR creation API - input JSON Payload:" + JSON.stringify(srCreationPayload));
                $.ajax({
                    url: srcreationRESTServiceURL,
                    data: JSON.stringify(srCreationPayload),
					dataType: 'json',
					processData: false,
					async: false,
                    crossDomain: true,
					headers: headers,
                    contentType: 'application/json; charset=utf-8',
					method: "POST",
					timeout: 15000,
                    success: function(data) {
                      
                        console.log('REST CALL FOR - SR creation API-call - success:' + JSON.stringify(data));
						$.closeMethod(activityJSONData);

                   }.bind(this),
                    error: function(response) {
						//changes done for MPF Phase 4 -CHG0069304
						var now = new Date(Date.now());
                        //var errorTime = now.getHours() + ":" + now.getMinutes() + ":" + now.getSeconds();
                        var errorDetails = response.responseJSON;
                        
                        var eDetail = errorDetails.detail.replace(/(\r\n|\n|\r)/gm," ");
                        var eStatus = errorDetails.status;
                        if (errorLogs == null){
                            errorLogs= "";
                        }
                        errorLogs = errorLogs+"||"+now.toString()+"|Plugin:Service Estimate "+"|URL:"+srcreationRESTServiceURL.toString()+"|Error Status:"+eStatus+"|Error Details:"+eDetail;
                        console.log(errorLogs);
                        $.ErrorUpdate(activityId,errorLogs);
                        //var errorMessage = now.toString()+"|Plugin:Service Estimate "+"| URL:"+srcreationRESTServiceURL+"| Payload:"+srCreationPayload+"|Error Details:"+JSON.stringify(response);
                        
                        
                        //console.log("Error Message:"+errorMessage)
						
                    
                        console.log('REST CALL FOR - SR creation API - failure:' + JSON.stringify(response));
						
						$.closeMethod(activityJSONData);
					


                    }
                   
                });
				
				
				
				
                

            }.bind(this));

            //Cancel Button Function:

            $('#cancelBtn').click(function() {

                this._sendPostMessageData({
                    "apiVersion": 1,
                    "method": "close",
                    "backScreen": "default",
                    "wakeupNeeded": false

                });
            }.bind(this));




        },        
        /** Function to build the billing info html file>
         */
        generateSEBillingInfoHTML: function(se_billing_info_xml) {

            var dataObject = '';
            //var xmlDoc = $.parseXML(xml);
            //  var xmlData = $(xmlDoc);
            se_billing_info_xml.find('billingInfo').find('billingItems').each(function() {

                $(this).children().each(function() {
                    $(this).children().each(function() {
                        if (this.tagName == 'date') {
                            dataObject = dataObject.concat('Date: ' + $(this).text() + '; ');
                        }
                        if (this.tagName == 'quantity') {
                            dataObject = dataObject.concat('Qty: ' + $(this).text() + ' ');

                        }

                        if (this.tagName == 'quantity_unit') {
                            dataObject = dataObject.concat($(this).text() + '; ');

                        }
                        if (this.tagName == 'prod_number') {
                            dataObject = dataObject.concat('Prod #: ' + $(this).text() + '; ');

                        }
                        if (this.tagName == 'name') {
                            dataObject = dataObject.concat('Item: ' + $(this).text() + '; ');

                        }
                        if (this.tagName == 'billing_amount') {
                            dataObject = dataObject.concat('Bill Amt: ' + $(this).text() + '; ');

                        }
                        if (this.tagName == 'billing_reason') {
                            dataObject = dataObject.concat('Billing Reason: ' + $(this).text() + '; ');

                        }
                        if (this.tagName != 'quantity') {
                            //dataObject = dataObject.concat(';');
                        }

                    });
                    dataObject = dataObject.concat('\n');
                });

            });

            se_billing_info_xml.find('billingInfo').find('summaries').each(function() {
                $(this).children().each(function() {
                    if (this.tagName == 'price_summ') {
                        dataObject = dataObject.concat('Total: ' + $(this).text() + '; ');
                    }

                    if (this.tagName == 'billing_amount') {
                        dataObject = dataObject.concat('Bill Amt: ' + $(this).text() + '; ');
                    }
                });
            });
            console.log(dataObject);
            return dataObject;
        },
               /**
         * Business login on plugin wakeup (background open for sync)
         *
         * @param {Object} receivedData - JSON object that contain data from OFSC
         */
        pluginWakeup: function(receivedData) {
            this._log(window.location.host + ' WAKEUP', JSON.stringify(receivedData, null, 4));

            var wakeupData = {
                pluginWakeupCount: +localStorage.getItem('pluginWakeupCount'),
                pluginWakeupMaxCount: +localStorage.getItem('pluginWakeupMaxCount'),
                pluginWakeupDontRespondOn: +localStorage.getItem('pluginWakeupDontRespondOn')
            };

            wakeupData.pluginWakeupCount = wakeupData.pluginWakeupCount + 1;

            localStorage.setItem('pluginWakeupCount', wakeupData.pluginWakeupCount);
            localStorage.setItem('pluginWakeupMaxCount', wakeupData.pluginWakeupMaxCount);
            localStorage.setItem('pluginWakeupDontRespondOn', wakeupData.pluginWakeupDontRespondOn);

            this._log(window.location.host + ' SAVE WAKEUP DATA TO LOCAL STORAGE', JSON.stringify(wakeupData, null, 4));

            if (wakeupData.pluginWakeupDontRespondOn == wakeupData.pluginWakeupCount) {
                this._log(window.location.host + ' EMULATE NOT RESPONDING PLUGIN');

                return;
            }

            if (wakeupData.pluginWakeupCount < wakeupData.pluginWakeupMaxCount) {
                setTimeout(function() {
                    this._log(window.location.host + ' SLEEP. RETRY NEEDED');

                    this._sendPostMessageData({
                        apiVersion: 1,
                        method: 'sleep',
                        wakeupNeeded: true
                    });
                }.bind(this), 2000);
            } else {
                setTimeout(function() {
                    this._log(window.location.host + ' SLEEP. NO RETRY');

                    this._sendPostMessageData({
                        apiVersion: 1,
                        method: 'sleep',
                        wakeupNeeded: false
                    });
                }.bind(this), 12000);
            }
        },

        /**
         * Save configuration of wakeup (background open for sync) behavior for Plugin
         * to Local Storage
         *
         * @private
         */
        _saveWakeupData: function() {
            var wakeupData = {
                pluginWakeupCount: 0,
                pluginWakeupMaxCount: 0,
                pluginWakeupDontRespondOn: 0
            };

            if ($('#wakeup').is(':checked')) {
                wakeupData.pluginWakeupMaxCount = parseInt($('#repeat_count').val());

                if ($('#dont_respond').is(':checked')) {
                    wakeupData.pluginWakeupDontRespondOn = parseInt($('#dont_respond_on').val());
                }
            }

            localStorage.setItem('pluginWakeupCount', wakeupData.pluginWakeupCount);
            localStorage.setItem('pluginWakeupMaxCount', wakeupData.pluginWakeupMaxCount);
            localStorage.setItem('pluginWakeupDontRespondOn', wakeupData.pluginWakeupDontRespondOn);

            this._log(window.location.host + ' SAVE WAKEUP DATA TO LOCAL STORAGE', JSON.stringify(wakeupData, null, 4));
        },

        /**
         * Clear previous configuration of wakeup (background open for sync) behavior for Plugin
         * from the Local Storage
         *
         * @private
         */
        _clearWakeupData: function() {
            localStorage.removeItem('pluginWakeupCount');
            localStorage.removeItem('pluginWakeupMaxCount');
            localStorage.removeItem('pluginWakeupDontRespondOn');

            this._log(window.location.host + ' CLEAR WAKEUP DATA FROM LOCAL STORAGE');
        },



        initChangeOfWakeup: function(element) {

            function onWakeupChange(elem) {
                var isChecked = $(elem).is(':checked');

                if (isChecked) {
                    $(element).find('#repeat_count').prop('disabled', false);
                    $(element).find('#dont_respond').prop('disabled', false);

                    $(element).find('#wakeup_row').removeClass('wakeup-form-row--disabled');

                    onDontRespondChange($(element).find('#dont_respond'));
                } else {
                    $(element).find('#repeat_count').prop('disabled', true);
                    $(element).find('#dont_respond').prop('disabled', true);
                    $(element).find('#dont_respond_on').prop('disabled', true);

                    $(element).find('#wakeup_row').addClass('wakeup-form-row--disabled');
                    $(element).find('#dont_respond_row').addClass('wakeup-form-row--disabled');
                }
            }

            function onDontRespondChange(elem) {
                var isChecked = $(elem).is(':checked');

                if (isChecked) {
                    $(element).find('#dont_respond_on').prop('disabled', false);
                    $(element).find('#dont_respond_row').removeClass('wakeup-form-row--disabled');
                } else {
                    $(element).find('#dont_respond_on').prop('disabled', true);
                    $(element).find('#dont_respond_row').addClass('wakeup-form-row--disabled');
                }
            }

            $(element).find('#wakeup').change(function(e) {
                onWakeupChange(e.target);
            });

            $(element).find('#dont_respond').change(function(e) {
                onDontRespondChange(e.target);
            });

            onWakeupChange($(element).find('#wakeup'));
        },



        initChangeOfDataItems: function() {
            //set checkboxes from local storage
            if (localStorage.getItem('dataItems')) {
                $('.data-items').attr('checked', true);
                $('.data-items-holder').show();

                var dataItems = JSON.parse(localStorage.getItem('dataItems'));
				
                $('.data-items-holder input').each(function() {
                    if (dataItems.indexOf(this.value) != -1) {
                        $(this).attr('checked', true);
                    }
                });
            }

            //init handlers
            $('.data-items').on('change', function(e) {
                $('.data-items-holder').toggle();
            });
        },


        initLocalStorageOption: function(localStorageKey) {
            if (localStorage.getItem(localStorageKey) === null) {
                localStorage.setItem(localStorageKey, 'true');
            }
        },



        /**
         * Initialization function
         */
        init: function() {
			if (navigator.serviceWorker) {
				this._log(window.location.host + ' Service Worker is supported');
				navigator.serviceWorker.register('serviceEstimate-service-worker.js').then(function(registration) {
					this._log(window.location.host + ' Service Worker is registered with scope: ' + registration.scope);
					registration.addEventListener('updatefound', function() {
						this._log(window.location.host + ' Service Worker update is found');
						var newServiceWorker = registration.installing;
						newServiceWorker.addEventListener('statechange', function() {
							switch (newServiceWorker.state) {
								case "installed":
									this._log(window.location.host + ' New Service Worker is installed');
									break;
							}
						}.bind(this));
					}.bind(this));
					navigator.serviceWorker.addEventListener('controllerchange', function() {
						this.notifyAboutNewVersion();
					}.bind(this));
					this.startApplication();
				}.bind(this), function(err) {
					this._log(window.location.host + ' Service Worker registration failed: ' + err);
					this.startApplication();
				}.bind(this));
				return;
			} else {
				this._log(window.location.host + ' Service Worker is not supported');
			}
			this.startApplication();
		},
		startApplication: function() {	
			
            this._log(window.location.host + ' PLUGIN HAS BEEN STARTED');
            $('.back_method_select').on('change', function() {
                var selectValue = $('.back_method_select').val();
                if (
                    selectValue == 'activity_by_id' ||
                    selectValue == 'end_activity' ||
                    selectValue == 'cancel_activity' ||
                    selectValue == 'notdone_activity' ||
                    selectValue == 'start_activity' ||
                    selectValue == 'suspend_activity' ||
                    selectValue == 'delay_activity'
                ) {
                    $('.back_activity_id').show();
                } else {
                    $('.back_activity_id').val('').hide();
                }
            });

            $('.json_local_storage_toggle').on('click', function() {
                $('.json__local-storage').toggle();
            });

            $('.json_request_toggle').on('click', function() {
                $('.column-item--request').toggle();
            });

            $('.json_response_toggle').on('click', function() {
                $('.column-item--response').toggle();
            }.bind(this));


            window.addEventListener("message", this._getPostMessageData.bind(this), false);

            this.initLocalStorageOption('showHeader');
            this.initLocalStorageOption('backNavigationFlag');

            var jsonToSend = {
                apiVersion: 1,
                method: 'ready',
                sendInitData: true,
                showHeader: !!localStorage.getItem('showHeader'),
                enableBackButton: !!localStorage.getItem('backNavigationFlag')
            };

            //parse data items
            //var dataItems = JSON.parse(localStorage.getItem('dataItems'));
			//var dataItems = ['resource','installedInventories'];
			var dataItems = ['resource','installedInventories','deinstalledInventories'];

            if (dataItems) {
                $.extend(jsonToSend, {
                    dataItems: dataItems
                });
            }

            this._sendPostMessageData(jsonToSend);
        },
		notifyAboutNewVersion: function() {
			this._log(window.location.host + ' New Service Worker is activated. Page refresh is needed');
			var footer = document.querySelector('.footer');
			var versionNotificationElement = document.createElement('div');
			versionNotificationElement.className = 'new-version-notification';
			versionNotificationElement.innerHTML = 'New version is detected. Please reopen the page';
			footer.appendChild(versionNotificationElement);
		}
		
    });
	window.OfscPlugin.getVersion = function() {
		return resourcesVersion;
	};

})(jQuery);