"use strict";

(function($) {
    window.OfscPlugin = function(debugMode) {
        this.debugMode = debugMode || false;
    };

    $.extend(window.OfscPlugin.prototype, {
        /**
         * Dictionary of enums
         */
        dictionary: {
            astatus: {
                pending: {
                    label: 'pending',
                    translation: 'Pending',
                    outs: ['started', 'cancelled', 'suspended'],
                    color: '#FFDE00'
                },
                started: {
                    label: 'started',
                    translation: 'Started',
                    outs: ['complete', 'suspended', 'notdone', 'cancelled'],
                    color: '#A2DE61'
                },
                complete: {
                    label: 'complete',
                    translation: 'Completed',
                    outs: [],
                    color: '#79B6EB'
                },
                suspended: {
                    label: 'suspended',
                    translation: 'Suspended',
                    outs: [],
                    color: '#9FF'
                },
                notdone: {
                    label: 'notdone',
                    translation: 'Not done',
                    outs: [],
                    color: '#60CECE'
                },
                cancelled: {
                    label: 'cancelled',
                    translation: 'Cancelled',
                    outs: [],
                    color: '#80FF80'
                }
            },
            invpool: {
                customer: {
                    label: 'customer',
                    translation: 'Customer',
                    outs: ['deinstall'],
                    color: '#04D330'
                },
                install: {
                    label: 'install',
                    translation: 'Installed',
                    outs: ['provider'],
                    color: '#00A6F0'
                },
                deinstall: {
                    label: 'deinstall',
                    translation: 'Deinstalled',
                    outs: ['customer'],
                    color: '#00F8E8'
                },
                provider: {
                    label: 'provider',
                    translation: 'Resource',
                    outs: ['install'],
                    color: '#FFE43B'
                }
            }
        },

        mandatoryActionProperties: {},

        /**
         * Which field shouldn't be editable
         *
         * format:
         *
         * parent: {
         *     key: true|false
         * }
         *
         */
        renderReadOnlyFieldsByParent: {
            data: {
                apiVersion: true,
                method: true,
                entity: true
            },
            resource: {
                pid: true,
                pname: true,
                gender: true
            }
        },

        /**
         * Check for string is valid JSON
         *
         * @param {*} str - String that should be validated
         *
         * @returns {boolean}
         *
         * @private
         */
        _isJson: function(str) {
            try {
                JSON.parse(str);
            } catch (e) {
                return false;
            }
            return true;
        },

        /**
         * Return origin of URL (protocol + domain)
         *
         * @param {String} url
         *
         * @returns {String}
         *
         * @private
         */
        _getOrigin: function(url) {
            if (url != '') {
                if (url.indexOf("://") > -1) {
                    return 'https://' + url.split('/')[2];
                } else {
                    return 'https://' + url.split('/')[0];
                }
            }

            return '';
        },

        /**
         * Return domain of URL
         *
         * @param {String} url
         *
         * @returns {String}
         *
         * @private
         */
        _getDomain: function(url) {
            if (url != '') {
                if (url.indexOf("://") > -1) {
                    return url.split('/')[2];
                } else {
                    return url.split('/')[0];
                }
            }

            return '';
        },

        _getDomainURL: function() {
			//return document.referrer.match(/\:\/\/([^\/]+)\.etadirect\.com\//)[1];
			//Reg Ex modified to handle both etadirect.com and fs.ocs.oraclecloud.com URLs
			return document.referrer.match(/\:\/\/([^\/]+)\.(?:etadirect.com|fs.ocs.oraclecloud.com)/)[1];
		},

        /**
         * Sends postMessage to document.referrer
         *
         * @param {Object} data - Data that will be sent
         *
         * @private
         */
        _sendPostMessageData: function(data) {
            var originUrl = document.referrer || (document.location.ancestorOrigins && document.location.ancestorOrigins[0]) || '';

            if (originUrl) {
                this._log(window.location.host + ' -> ' + data.method + ' ' + this._getDomain(originUrl), JSON.stringify(data, null, 4));

                parent.postMessage(data, this._getOrigin(originUrl));
            } else {
                this._log(window.location.host + ' -> ' + data.method + ' ERROR. UNABLE TO GET REFERRER');
            }
        },

        /**
         * Handles during receiving postMessage
         *
         * @param {MessageEvent} event - Javascript event
         *
         * @private
         */
        _getPostMessageData: function(event) {

            if (typeof event.data === 'undefined') {
                this._log(window.location.host + ' <- NO DATA ' + this._getDomain(event.origin), null, null, true);

                return false;
            }

            if (!this._isJson(event.data)) {
                this._log(window.location.host + ' <- NOT JSON ' + this._getDomain(event.origin), null, null, true);

                return false;
            }

            var data = JSON.parse(event.data);

            if (!data.method) {
                this._log(window.location.host + ' <- NO METHOD ' + this._getDomain(event.origin), null, null, true);

                return false;
            }

            this._log(window.location.host + ' <- ' + data.method + ' ' + this._getDomain(event.origin), JSON.stringify(data, null, 4));

            switch (data.method) {
                case 'init':
                    this.pluginInitEnd(data);
                    break;

                case 'open':
                    this.pluginOpen(data);
                    break;

                case 'wakeup':
                    this.pluginWakeup(data);
                    break;

                case 'error':
                    data.errors = data.errors || {
                        error: 'Unknown error'
                    };
                    this._showError(data.errors);
                    break;

                default:
                    this._log(window.location.host + ' <- UNKNOWN METHOD: ' + data.method + ' ' + this._getDomain(event.origin), null, null, true);
                    break;
            }
        },

        /**
         * Show alert with error
         *
         * @param {Object} errorData - Object with errors
         *
         * @private
         */
        _showError: function(errorData) {
            alert(JSON.stringify(errorData, null, 4));
        },

        /**
         * Logs to console
         *
         * @param {String} title - Message that will be log
         * @param {String} [data] - Formatted data that will be collapsed
         * @param {String} [color] - Color in Hex format
         * @param {Boolean} [warning] - Is it warning message?
         *
         * @private
         */
        _log: function(title, data, color, warning) {
            if (!this.debugMode) {
                return;
            }
            if (!color) {
                color = '#0066FF';
            }
            if (!!data) {
                console.groupCollapsed('%c[Plugin API] ' + title, 'color: ' + color + '; ' + (!!warning ? 'font-weight: bold;' : 'font-weight: normal;'));
                console.log('[Plugin API] ' + data);
                console.groupEnd();
            } else {
                console.log('%c[Plugin API] ' + title, 'color: ' + color + '; ' + (!!warning ? 'font-weight: bold;' : ''));
            }
        },

        /**
         * Business login on plugin init
         */
        saveToLocalStorage: function(data) {
            this._log(window.location.host + ' INIT. SET DATA TO LOCAL STORAGE', JSON.stringify(data, null, 4));

            if (data.attributeDescription) {
                localStorage.setItem('pluginInitData', JSON.stringify(data.attributeDescription));
            }
        },

        /**
         * Business login on plugin init end
         *
         * @param {Object} data - JSON object that contain data from OFSC
         */
        pluginInitEnd: function(data) {
            this.saveToLocalStorage(data);

            var messageData = {
                apiVersion: 1,
                method: 'initEnd'
            };

            if (localStorage.getItem('pluginWakeupCount') < localStorage.getItem('pluginWakeupMaxCount')) {
                this._log(window.location.host + ' UNFINISHED WAKEUP DATA FOUND IN LOCAL STORAGE');

                messageData.wakeupNeeded = true;
            }

            this._sendPostMessageData(messageData);
        },

        /**
         * Business login on plugin open
         *
         * @param {Object} receivedData - JSON object that contain data from OFSC
         */
        pluginOpen: function(receivedData) {
			console.log(receivedData);
			var domainName = this._getDomainURL();  //Hosted plugin change CHG0069304
			var ultimateBind = this;
			
			var activityId = receivedData.activity.aid;
			var errorCount = 0;
		
			//----- added for CHG0083631 ------		
			var blnIsTechOnline = false;
			checkIfTechIsOnline();
			//---------------------------------
				
			var errorLogs = receivedData.activity.A_PLUGIN_ERROR_LOG;
            
			var inventoryList;
			inventoryList = receivedData.inventoryList;
			var consignmentList = [];
			var consignPartsCount = 0;

			//var serverURL = window.location.origin;

            var headers = {
				'Authorization':
					'Basic ' + btoa(receivedData.securedData.clientid + "@" + domainName + ":" + receivedData.securedData.clientSecret)
			};

            //Hosted plugin change CHG0069304
            $.ErrorUpdate = function(activityId,sErrorLogs) {
				 
				this._sendPostMessageData({
						"apiVersion": 1,
						"method": "update",
						"activity": {
							"A_PLUGIN_ERROR_LOG": sErrorLogs,
							"aid": activityId
						}
						
				});
			 }.bind(this);
             // end change Hosted plugin CHG0069304
			if(inventoryList !== undefined || inventoryList !== null || inventoryList !== {}){
				$.each(inventoryList, function (i, v) {
					console.log(v.invtype);
					if(v.inv_aid != null && v.inv_aid == activityId){
						if(v.invtype != undefined && v.invtype != null && v.invtype === "Consignment"){ //&& v.inv_aid === parseInt(receivedData.activity.aid)){
							if(v.I_ITEM_NUMBER != undefined && v.I_ITEM_NUMBER != null && v.I_ITEM_NUMBER.length > 0){
								consignmentList.push(v);
								consignPartsCount++;
							}
						}
					}
				});
				
				$("#completionPluginWrapper").html("");
				
				var inv_id 			 = "";
				var part_number 	 = "";				
				var part_description = "";
				var part_disposition = "";
				var part_ship_reason = "";
				var part_tracking_no = "";
				var partIndex 		 = 0;
				// CHanges start CHG0067033
				
				if (consignPartsCount<=0){

                   $('.submit').addClass("cp_custom_hidden");
                   $( "<p>No Consignment Parts on activity</p>" ).appendTo("#completionPluginWrapper");

                }
				//Changes end CHG0067033
				$.each(consignmentList, function (i, part) {
					console.log(part.I_ITEM_NUMBER);		

					var partRow = "";

					inv_id 			 = "";
					part_number 	 = "";
					part_description = "";
					part_disposition = "";
					part_ship_reason = "";
					part_tracking_no = "";

					inv_id = part.invid;
					
					part_number = part.I_ITEM_NUMBER;

					if(part.I_ITEM_DESCRIPTION != undefined && part.I_ITEM_DESCRIPTION != null && part.I_ITEM_DESCRIPTION.length > 0){
						part_description = part.I_ITEM_DESCRIPTION.trim();
					}

					if(part.I_DISPOSITION != undefined && part.I_DISPOSITION != null && part.I_DISPOSITION.length > 0){
						var part_disposition = part.I_DISPOSITION.trim().toLowerCase();
					}

					if(part.i_shipping_rea != undefined && part.i_shipping_rea != null && part.i_shipping_rea.length > 0){
						part_ship_reason = part.i_shipping_rea.trim().toLowerCase();
					}
					
					if (part.I_CONSUMABLE == "false" && part.I_CONSUMABLE.length > 0)    //CHG0076764 start
					{
						part_ship_reason = "returned" ;
															
					}
					else
					{
						part_ship_reason = "not returned" ;
					}                                                                    //CHG0076764 end

					if(part.I_TRACKING_NUMBER != undefined && part.I_TRACKING_NUMBER !=
					 null && part.I_TRACKING_NUMBER.length > 0){
						part_tracking_no = (part.I_TRACKING_NUMBER.replace(/[^0-9a-z]/gi, '')).trim();//CHG0072497
					}
					
					partIndex++;

					partRow = " " +
					" 	<div id=\"cpf_ConsignmentPart_" + i +"\" class=\"cp_section\"> " +
					"  " +
					"  		<input id=\"cpf_inv_id_" + i +"\" type=\"hidden\" value=\"" + inv_id + "\"> " +
					"  " +
					"  		<div id=\"cpf_PartIndex_0\" class=\"cp_field cp_part_block_header\"> " +
					"  			<span class=\"cp_field_label_text\"> " + "Part " + partIndex + ": " +
					"  			</span> " +
					"  		</div> " +
					"  " +
					" 		<div id=\"cpf_PartNumber_" + i +"\" class=\"cp_field\"> " +
					" 			<div class=\"cp_field_row\"> " +
					" 				<div class=\"cp_field_label\"><span class=\"cp_field_label_text\">Part Number:</span></div> " +
					" 				<div class=\"cp_field_value\"> " +
					" 					<div class=\"cp_field_value_inner_wrapper\"> " +
					"  						<input id=\"cpf_PartNumber_inner_" + i +"\" type=\"text\" class=\"cp_field_text_component form-item cp_custom_field\" value=\"" + part_number + "\" disabled> " +
					" 					</div> " +
					" 				</div> " +
					"  			</div> " +
					" 		</div> " +
					"  " +
					" 		<div id=\"cpf_PartDescription_" + i +"\" class=\"cp_field\"> " +
					" 			<div class=\"cp_field_row\"> " +
					" 				<div class=\"cp_field_label\"><span class=\"cp_field_label_text\">Part Description:</span></div> " +
					" 				<div class=\"cp_field_value\"> " +
					" 					<div class=\"cp_field_value_inner_wrapper\"> " +
					"  						<textarea id=\"cpf_PartDescription_inner_" + i +"\" class=\"cp_field_text_component form-item cp_custom_field cp_custom_textarea\" rows=\"3\" disabled>" + part_description + "</textarea> " +
					" 					</div> " +
					" 				</div> " +
					"  			</div> " +
					" 		</div> " +
					"  " +
					" 		<div id=\"cpf_PartQuantity_" + i +"\" class=\"cp_field\"> " +
					" 			<div class=\"cp_field_row\"> " +
					" 				<div class=\"cp_field_label\"><span class=\"cp_field_label_text\">Quantity:</span></div> " +
					" 				<div class=\"cp_field_value\"> " +
					" 					<div class=\"cp_field_value_inner_wrapper\"> " +
					"  						<input id=\"cpf_PartQuantity_inner_" + i +"\" type=\"text\" class=\"cp_field_text_component form-item cp_custom_field\" value=\"1\" disabled> " +
					" 					</div> " +
					" 				</div> " +
					"  			</div> " +
					" 		</div> " +
					"  " +
					" 		<div id=\"cpf_DispositionLOV_" + i +"\" class=\"cp_field\"> " +
					" 			<div class=\"cp_field_row\"> " +
					" 				<div class=\"cp_field_label\"><span class=\"cp_field_label_text\">Disposition:</span></div> " +
					" 				<div class=\"cp_field_value\"> " +
					" 					<div class=\"cp_field_value_inner_wrapper\"> " +
					"  						<select id=\"cpf_DispositionList_inner_" + i +"\" class=\"cp_field_dropdown_component form-item cp_custom_field\"> " +
					"							<option value=\"\">Select disposition</option> " +
					"							<option value=\"used\"" + 		  (part_disposition == 'used' ? 'selected' : '') + "		>Used</option> " +
					"							<option value=\"unused\"" + 	  (part_disposition == 'unused' ? 'selected' : '') + "		>Not Used</option> " +
					"							<option value=\"doa\"" + 		  (part_disposition == 'doa' ? 'selected' : '') + "			>DOA</option> " +
					"							<option value=\"open box\"" + 	  (part_disposition == 'open box' ? 'selected' : '') + "	>Open Box</option> " +
					"							<option value=\"wrong part\"" +	  (part_disposition == 'wrong part' ? 'selected' : '') + "	>Wrong Part Received (Tidel)</option> " +
					"							<option value=\"not received\"" + (part_disposition == 'not received' ? 'selected' : '') + ">Not Received (Tidel)</option> " +
					"							<option value=\"abused\"" + 	  (part_disposition == 'abused' ? 'selected' : '') + "		>Abused (Tidel)</option> " +
					"						</select> " +
					" 					</div> " +
					" 				</div> " +
					"  			</div> " +
					" 		</div> " +
					"  " +
					" 		<div id=\"cpf_PartShipReason_" + i +"\" class=\"cp_field\"> " +
					" 			<div class=\"cp_field_row\"> " +
					" 				<div class=\"cp_field_label\"><span class=\"cp_field_label_text\">Shipping Reason:</span></div> " +
					" 				<div class=\"cp_field_value\"> " +
					" 					<div class=\"cp_field_value_inner_wrapper\"> " +
					"  						<select id=\"cpf_PartShipReason_inner_" + i +"\" class=\"cp_field_dropdown_component form-item cp_custom_field cp_ddl_ship_reason\"> " +
					"							<option value=\"\">Select shipping reason</option> " +
					"							<option value=\"Returned\"" + 	  (part_ship_reason == 'returned' ? 'selected' : '') + "	>Returned</option> " +
					"							<option value=\"Not Returned\"" + (part_ship_reason == 'not returned' ? 'selected' : '') + ">Not Returned</option> " +
					"						</select> " +
					" 					</div> " +
					" 				</div> " +
					"  			</div> " +
					" 		</div> " +
					"  " +				
					" 		<div id=\"cpf_TrackingNumber_" + i +"\" class=\"cp_field " + (part_ship_reason == 'returned' ? '' : 'cp_custom_hidden') + "\"> " +
					" 			<div class=\"cp_field_row\"> " +
					" 				<div class=\"cp_field_label\"><span class=\"cp_field_label_text\">Tracking Number:</span></div> " +
					" 				<div class=\"cp_field_value\"> " +
					" 					<div class=\"cp_field_value_inner_wrapper\"> " +
					"  						<input id=\"cpf_TrackingNumber_inner_" + i +"\" type=\"text\" class=\"cp_field_text_component form-item cp_custom_field\" value=\"" + part_tracking_no + "\"> " +
					" 					</div> " +
					" 				</div> " +
					"  			</div> " +
					" 		</div> " +
					"  " +
					" 	</div> ";
					
					$("#completionPluginWrapper").append(partRow);
					
					     //shipping_reason = part_ship_reason;   //CHG0076764
				});
				
			}else {
				console.log("No consignment parts available.");
			}
			//------------------------------------------------------------------------------------------------------------------
			$('.cp_ddl_ship_reason').change(function(element){
				
				var ddlId = element.target.id;
				var partIndex = ddlId.substr(ddlId.lastIndexOf("_")+1);
				
				if(element.target.value.trim().toLowerCase() == 'returned'){
					$("#cpf_TrackingNumber_"+partIndex).removeClass("cp_custom_hidden");
					$("#cpf_TrackingNumber_inner_"+partIndex).val("");
				}else{
					$("#cpf_TrackingNumber_"+partIndex).addClass("cp_custom_hidden");
					$("#cpf_TrackingNumber_inner_"+partIndex).removeClass("cp_custom_error");
				}
				
			}.bind(this));			
			//------------------------------------------------------------------------------------------------------------------
			$('.dismiss').click(function() {
                this._sendPostMessageData({
                    "apiVersion": 1,
                    "method": "close",
                    "backScreen": "default",
                    "wakeupNeeded": false
                });
            }.bind(this));
			//allow only alphanumeric values in input field CHG0072497
			$('[id^=cpf_TrackingNumber_inner]').bind("change keyup input",function (e) {
			   $(this).val($(this).val().replace(/[^0-9a-z]/gi, ''));  
			  });  
			//------------------------------------------------------------------------------------------------------------------
			$('.submit').click(function(){
				 
				var partCount = $('.cp_section').length;
				var validPartCount = 0;
				
				//----- added for CHG0083631 ----
				checkIfTechIsOnline();
				
				var blnIsOfflineDataSet = false;
				var consignItemsList = {};
				
				//----- end for CHG0083631 ------
				
				for(var i=0; i < partCount; i++){
					
					//----------------------------------------------------------------------------------------------------------
					var disposition = $("#cpf_DispositionList_inner_"+i).val().trim();
					var shipping_reason = "";
					var trackingNumber  = "";
					var inv_id = "";
					
					if(disposition != undefined && disposition != null && disposition.length > 0){
						
						validPartCount++;

						//------------------------------------------------------------------------------------------------------
						shipping_reason = $("#cpf_PartShipReason_inner_"+i).val().trim();						
						
						if(shipping_reason == undefined || shipping_reason == null || shipping_reason.trim().length == 0){
							alert("Please select shipping reason.");
							$("#cpf_PartShipReason_inner_"+i).addClass("cp_custom_error");
							$("#cpf_PartShipReason_inner_"+i).focus();
							return;
						}else {
							$("#cpf_PartShipReason_inner_"+i).removeClass("cp_custom_error");
							if(shipping_reason == "Returned"){
								trackingNumber = $("#cpf_TrackingNumber_inner_"+i).val().trim();
								
								if(trackingNumber == undefined || trackingNumber == null || trackingNumber.trim().length == 0){
									alert("For returned shipping, tracking number should be entered.");
									$("#cpf_TrackingNumber_inner_"+i).addClass("cp_custom_error");
									$("#cpf_TrackingNumber_inner_"+i).focus();
									return;
								}else if(trackingNumber.substr(0,2).trim().toUpperCase() === "1Z" && trackingNumber.length != 18){ //CHG0072835
									alert("Wrong tracking number format entered.");
									$("#cpf_TrackingNumber_inner_"+i).addClass("cp_custom_error");
									$("#cpf_TrackingNumber_inner_"+i).focus();
									return;
								}else if(trackingNumber.substr(0,2).trim().toUpperCase() != "1Z" && !(trackingNumber.length >= 12 && isNaN(trackingNumber) === false)){ //CHG0072835
									alert("Non-UPS tracking number should be numeric & minimum length is 12.");
									$("#cpf_TrackingNumber_inner_"+i).addClass("cp_custom_error");
									$("#cpf_TrackingNumber_inner_"+i).focus();
									return;
								}else{
									$("#cpf_TrackingNumber_inner_"+i).removeClass("cp_custom_error");
								}
							}
						}
						
						inv_id = $("#cpf_inv_id_"+i).val().trim();
						var createInventoriesArr = []; 
						
						createInventoriesArr.push(
							{
								"inventoryId": inv_id,
								"i_shipping_rea": shipping_reason,  
								//"i_shipping_rea": part_ship_reason,    //CHG0076764
								"I_DISPOSITION": disposition,
								"I_TRACKING_NUMBER": trackingNumber
							}
						);
						
						var updateInventoryPayload = {
							
							"inventories": createInventoriesArr,
							//CHG0069299 - Added below for Domain change request
							
						};
						
						//---- added condition for checking if tech is online or offline - CHG0083631
						if(blnIsTechOnline == true){
							$.processUpdateInventoryMethod(updateInventoryPayload, inv_id);
						}else{

							$.extend(consignItemsList, {
								[inv_id]: {
									"i_shipping_rea": shipping_reason,
									"I_DISPOSITION": disposition,
									"I_TRACKING_NUMBER": trackingNumber
								 }
							});
							
							blnIsOfflineDataSet = true;
						}
						//------------------------------------------------------------------------------------------------------
					}
				}

				if(validPartCount == 0){
					alert("Please provide disposition for at least one part.");
					$("#cpf_DispositionList_inner_0").focus();
				}else{
					var activityJSONData;
					var successCount = 0;
					
					if (validPartCount == partCount){
						
						if(errorCount == 0){
							successCount = validPartCount;
							
							activityJSONData = {
								"A_CONSIGNMENT_COMPLETE": "true",
								"aid": activityId
							};
						}else{
							successCount = validPartCount - errorCount;
							
							activityJSONData = {
								"A_CONSIGNMENT_COMPLETE": "false",
								"aid": activityId
							};
						}
					}else{
						
						successCount = validPartCount - errorCount;
						
						activityJSONData = {
							"A_CONSIGNMENT_COMPLETE": "false",
							"aid": activityId
						};
					}
					
					if(successCount > 0 && errorCount == 0){
						alert("All parts with disposition provided were updated successfully.");
					}
					if(successCount > 0 && errorCount > 0){
						alert("The " + successCount + "parts with disposition provided were updated successfully. The " + errorCount + " parts were not updated.");
					}
					
					errorCount = 0;
					
					//---- added condition for checking if tech is online or offline - CHG0083631
					if(blnIsTechOnline == false && blnIsOfflineDataSet == true){

						var offlineJsonToSend = {
							"apiVersion": 1,
							"method": "close",
							"backScreen": "default",
							"wakeupNeeded": false,
							"activity": activityJSONData
						};
						
						$.extend(offlineJsonToSend, {"inventoryList": consignItemsList});
						
						ultimateBind._sendPostMessageData(offlineJsonToSend);
					}else{					
						$.processCloseMethodFnCallBck(activityJSONData);
					}
				}
				 
			}.bind(this));
			//------------------------------------------------------------------------------------------------------------------
			
			 $.processUpdateInventoryMethod = function(updateInventoryPayload, inv_id) {
				console.log("Update consignment inventory call started.");


				var updateInventoryRestServiceURL = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/inventories/"+ updateInventoryPayload.inventories[0].inventoryId;
               //added for logging mechanism
               //var updateErrorURL = "https://" + domainName + ".etadirect.com/rest/ofscCore/v1/activities/"+ activityId+"/A_ERROR_LOGS";
               //console.log("update error logs property updateErrorURL: "+updateErrorURL);
               //
				console.log("Update consignment inventory call updateInventoryRestServiceURL -" + updateInventoryRestServiceURL);
				console.log("Update consignment inventory updateInventoryPayload -" + JSON.stringify(updateInventoryPayload));
                 
				
				$.ajax({
					dataType: "json",
					url: updateInventoryRestServiceURL,
					data: JSON.stringify(updateInventoryPayload.inventories[0]),
					processData: false,
					async: false,
                    crossDomain: true,
					headers: headers,
					contentType: 'application/json; charset=utf-8',
					method: "PATCH",
					timeout: 15000,
					success: function(responseData) {

						console.log("Update consignment inventory webservice success response:" + JSON.stringify(responseData));

					}.bind(this),
					error: function(errorData) {
						console.log("Update consignment inventory webservice error:" + JSON.stringify(errorData));
                        //CHnages done for MPF phase 4 Logging Mechanism
                        var now = new Date(Date.now());
                        var errorTime = now.getHours() + ":" + now.getMinutes() + ":" + now.getSeconds();
                        var errorDetails = errorData.responseJSON;
                        
                        var eDetail = errorDetails.detail.replace(/(\r\n|\n|\r)/gm," ");
                        var eStatus = errorDetails.status;
                        if (errorLogs == null){
                            errorLogs= "";
                        }
                        errorLogs = errorLogs+"||"+now.toString()+"|Plugin :Consignment "+"| URL:"+updateInventoryRestServiceURL.toString()+"|Error Status:"+eStatus+"|Error Details:"+eDetail;
                        console.log("Error Log:"+errorLogs);
                        
                        $.ErrorUpdate(activityId,errorLogs);
                        //var errorMessage = now.toString()+"|Plugin :Consignment "+"| URL:"+updateInventoryRestServiceURL+"| Payload:"+updateInventoryPayload.inventories[0]+"|Error Details:"+JSON.stringify(errorData);
                        
                        //changes end for hosting CHG0069304
                      
    
                        
                       
						errorCount++;
						var responseData = {
							"status": 404,
							"message": "error",
							"data": {}
						}
					}
				});
			};
			
			$.processCloseMethodFnCallBck = function(activityJSONData) {
				/*if(dataItemsToProcess.indexOf('resourceInventories') !== -1){
					dataItemsToProcess.splice(dataItemsToProcess.indexOf('resourceInventories'), 1);
				}
				localStorage.storageDataItems = dataItemsToProcess;*/

				// close method.
               
                 
                
				var closeJsonToSend = {
					"apiVersion": 1,
					"method": "close",
					"backScreen": "default",
					"wakeupNeeded": false,
					"activity": activityJSONData
				};
			
				console.log("closeJsonToSend " + JSON.stringify(closeJsonToSend));
				
				ultimateBind._sendPostMessageData(closeJsonToSend);

			};
			
			//----- Added for CHG0083631 -----------------
			function checkIfTechIsOnline() {
				
				var domainLink = window.location.href;// + '&rand=' + Math.random();
				
				$.ajax({
					url : domainLink,
					timeout : 2000,	
					cache: false,				
					type : 'GET', 
					async: false,
					tryCount : 0,
					retryLimit : 3,
					success: function(response)	{
						console.log(' online');
						blnIsTechOnline = true;
						return true;
					}.bind(this),
					error : function(xhr, textStatus, errorThrown )	{
						if (textStatus == 'timeout') {
							this.tryCount++;
							if (this.tryCount <= this.retryLimit) {
								//try again
								$.ajax(this);
								console.log(' offline');
								blnIsTechOnline = false;
								return false;
							}            
						}
						if(xhr.status == 500){
							console.log(' offline');
							blnIsTechOnline = false;
							return false;
						}else {
							console.log(' offline');
							blnIsTechOnline = false;
							return false;
						}
					}
				});
			}
			//-----------------------------------------
		},

        /**
         * Business login on plugin wakeup (background open for sync)
         *
         * @param {Object} receivedData - JSON object that contain data from OFSC
         */
        pluginWakeup: function(receivedData) {
            this._log(window.location.host + ' WAKEUP', JSON.stringify(receivedData, null, 4));

            var wakeupData = {
                pluginWakeupCount: +localStorage.getItem('pluginWakeupCount'),
                pluginWakeupMaxCount: +localStorage.getItem('pluginWakeupMaxCount'),
                pluginWakeupDontRespondOn: +localStorage.getItem('pluginWakeupDontRespondOn')
            };
			
            wakeupData.pluginWakeupCount = wakeupData.pluginWakeupCount + 1;

            localStorage.setItem('pluginWakeupCount', wakeupData.pluginWakeupCount);
            localStorage.setItem('pluginWakeupMaxCount', wakeupData.pluginWakeupMaxCount);
            localStorage.setItem('pluginWakeupDontRespondOn', wakeupData.pluginWakeupDontRespondOn);

            this._log(window.location.host + ' SAVE WAKEUP DATA TO LOCAL STORAGE', JSON.stringify(wakeupData, null, 4));

            if (wakeupData.pluginWakeupDontRespondOn == wakeupData.pluginWakeupCount) {
                this._log(window.location.host + ' EMULATE NOT RESPONDING PLUGIN');

                return;
            }

            if (wakeupData.pluginWakeupCount < wakeupData.pluginWakeupMaxCount) {
                setTimeout(function() {
                    this._log(window.location.host + ' SLEEP. RETRY NEEDED');

                    this._sendPostMessageData({
                        apiVersion: 1,
                        method: 'sleep',
                        wakeupNeeded: true
                    });
                }.bind(this), 2000);
            } else {
                setTimeout(function() {
                    this._log(window.location.host + ' SLEEP. NO RETRY');

                    this._sendPostMessageData({
                        apiVersion: 1,
                        method: 'sleep',
                        wakeupNeeded: false
                    });
                }.bind(this), 12000);
            }
        },

        /**
         * Save configuration of wakeup (background open for sync) behavior for Plugin
         * to Local Storage
         *
         * @private
         */
        _saveWakeupData: function() {
            var wakeupData = {
                pluginWakeupCount: 0,
                pluginWakeupMaxCount: 0,
                pluginWakeupDontRespondOn: 0
            };

            if ($('#wakeup').is(':checked')) {
                wakeupData.pluginWakeupMaxCount = parseInt($('#repeat_count').val());

                if ($('#dont_respond').is(':checked')) {
                    wakeupData.pluginWakeupDontRespondOn = parseInt($('#dont_respond_on').val());
                }
            }

            localStorage.setItem('pluginWakeupCount', wakeupData.pluginWakeupCount);
            localStorage.setItem('pluginWakeupMaxCount', wakeupData.pluginWakeupMaxCount);
            localStorage.setItem('pluginWakeupDontRespondOn', wakeupData.pluginWakeupDontRespondOn);

            this._log(window.location.host + ' SAVE WAKEUP DATA TO LOCAL STORAGE', JSON.stringify(wakeupData, null, 4));
        },

        /**
         * Clear previous configuration of wakeup (background open for sync) behavior for Plugin
         * from the Local Storage
         *
         * @private
         */
        _clearWakeupData: function() {
            localStorage.removeItem('pluginWakeupCount');
            localStorage.removeItem('pluginWakeupMaxCount');
            localStorage.removeItem('pluginWakeupDontRespondOn');

            this._log(window.location.host + ' CLEAR WAKEUP DATA FROM LOCAL STORAGE');
        },
        
        initChangeOfWakeup: function(element) {

            function onWakeupChange(elem) {
                var isChecked = $(elem).is(':checked');

                if (isChecked) {
                    $(element).find('#repeat_count').prop('disabled', false);
                    $(element).find('#dont_respond').prop('disabled', false);

                    $(element).find('#wakeup_row').removeClass('wakeup-form-row--disabled');

                    onDontRespondChange($(element).find('#dont_respond'));
                } else {
                    $(element).find('#repeat_count').prop('disabled', true);
                    $(element).find('#dont_respond').prop('disabled', true);
                    $(element).find('#dont_respond_on').prop('disabled', true);

                    $(element).find('#wakeup_row').addClass('wakeup-form-row--disabled');
                    $(element).find('#dont_respond_row').addClass('wakeup-form-row--disabled');
                }
            }

            function onDontRespondChange(elem) {
                var isChecked = $(elem).is(':checked');

                if (isChecked) {
                    $(element).find('#dont_respond_on').prop('disabled', false);
                    $(element).find('#dont_respond_row').removeClass('wakeup-form-row--disabled');
                } else {
                    $(element).find('#dont_respond_on').prop('disabled', true);
                    $(element).find('#dont_respond_row').addClass('wakeup-form-row--disabled');
                }
            }

            $(element).find('#wakeup').change(function(e) {
                onWakeupChange(e.target);
            });

            $(element).find('#dont_respond').change(function(e) {
                onDontRespondChange(e.target);
            });

            onWakeupChange($(element).find('#wakeup'));
        },

        initChangeOfDataItems: function() {
            //set checkboxes from local storage
            if (localStorage.getItem('dataItems')) {
                $('.data-items').attr('checked', true);
                $('.data-items-holder').show();

                var dataItems = JSON.parse(localStorage.getItem('dataItems'));

                $('.data-items-holder input').each(function() {
                    if (dataItems.indexOf(this.value) != -1) {
                        $(this).attr('checked', true);
                    }
                });
            }

            //init handlers
            $('.data-items').on('change', function(e) {
                $('.data-items-holder').toggle();
            });
        },

        initLocalStorageOption: function(localStorageKey) {
            if (localStorage.getItem(localStorageKey) === null) {
                localStorage.setItem(localStorageKey, 'true');
            }
        },
        
        /**
         * Initialization function
         */
        init: function() {
			if (navigator.serviceWorker) {
				this._log(window.location.host + ' Service Worker is supported');
				navigator.serviceWorker.register('consignment-service-worker.js').then(function(registration) {
					this._log(window.location.host + ' Service Worker is registered with scope: ' + registration.scope);
					registration.addEventListener('updatefound', function() {
						this._log(window.location.host + ' Service Worker update is found');
						var newServiceWorker = registration.installing;
						newServiceWorker.addEventListener('statechange', function() {
							switch (newServiceWorker.state) {
								case "installed":
									this._log(window.location.host + ' New Service Worker is installed');
									break;
							}
						}.bind(this));
					}.bind(this));
					navigator.serviceWorker.addEventListener('controllerchange', function() {
						this.notifyAboutNewVersion();
					}.bind(this));
					this.startApplication();
				}.bind(this), function(err) {
					this._log(window.location.host + ' Service Worker registration failed: ' + err);
					this.startApplication();
				}.bind(this));
				return;
			} else {
				this._log(window.location.host + ' Service Worker is not supported');
			}
			this.startApplication();
		},
		startApplication: function() {
			this._log(window.location.host + ' PLUGIN HAS BEEN STARTED');
            $('.back_method_select').on('change', function() {
                var selectValue = $('.back_method_select').val();
                if (
                    selectValue == 'activity_by_id' ||
                    selectValue == 'end_activity' ||
                    selectValue == 'cancel_activity' ||
                    selectValue == 'notdone_activity' ||
                    selectValue == 'start_activity' ||
                    selectValue == 'suspend_activity' ||
                    selectValue == 'delay_activity'
                ) {
                    $('.back_activity_id').show();
                } else {
                    $('.back_activity_id').val('').hide();
                }
            });

            $('.json_local_storage_toggle').on('click', function() {
                $('.json__local-storage').toggle();
            });

            $('.json_request_toggle').on('click', function() {
                $('.column-item--request').toggle();
            });

            $('.json_response_toggle').on('click', function() {
                $('.column-item--response').toggle();
            }.bind(this));


            window.addEventListener("message", this._getPostMessageData.bind(this), false);

            this.initLocalStorageOption('showHeader');
            this.initLocalStorageOption('backNavigationFlag');

            var jsonToSend = {
                apiVersion: 1,
                method: 'ready',
                sendInitData: true,
                showHeader: !!localStorage.getItem('showHeader'),
                enableBackButton: !!localStorage.getItem('backNavigationFlag')
            };

       
			  //parse data items
           // var dataItems = JSON.parse(localStorage.getItem('dataItems'));
			var dataItems = ['resource','resourceInventories','customerInventories'];

            if (dataItems) {
                $.extend(jsonToSend, {
                    dataItems: dataItems
                });
            }

            this._sendPostMessageData(jsonToSend);
        },
		notifyAboutNewVersion: function() {
			this._log(window.location.host + ' New Service Worker is activated. Page refresh is needed');
			var footer = document.querySelector('.footer');
			var versionNotificationElement = document.createElement('div');
			versionNotificationElement.className = 'new-version-notification';
			versionNotificationElement.innerHTML = 'New version is detected. Please reopen the page';
			footer.appendChild(versionNotificationElement);
		}	
    });
	window.OfscPlugin.getVersion = function() {
		return resourcesVersion;
	};

})(jQuery);