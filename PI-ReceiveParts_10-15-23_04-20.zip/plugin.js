"use strict";

(function($) {
    window.OfscPlugin = function(debugMode) {
        this.debugMode = debugMode || false;
    };

    //Nov 21st 2019, simplified the configuration details fetching and usage as part of 19c upgrade
    //removed all unwanted code in between and moved here to reuse everywhere
    //******** Get Data from config.json**********//
    var company = '', clientId = '', clientSecret = '', icsauthorizationB64 ='', icsBaseURL = '', authorizationB64 = '';

	
	// End 19C upgrade
    
    $.extend(window.OfscPlugin.prototype, {
        /**
         * Dictionary of enums
         */
        dictionary: {
            astatus: {
                pending: {
                    label: 'pending',
                    translation: 'Pending',
                    outs: ['started', 'cancelled', 'suspended'],
                    color: '#FFDE00'
                },
                started: {
                    label: 'started',
                    translation: 'Started',
                    outs: ['complete', 'suspended', 'notdone', 'cancelled'],
                    color: '#A2DE61'
                },
                complete: {
                    label: 'complete',
                    translation: 'Completed',
                    outs: [],
                    color: '#79B6EB'
                },
                suspended: {
                    label: 'suspended',
                    translation: 'Suspended',
                    outs: [],
                    color: '#9FF'
                },
                notdone: {
                    label: 'notdone',
                    translation: 'Not done',
                    outs: [],
                    color: '#60CECE'
                },
                cancelled: {
                    label: 'cancelled',
                    translation: 'Cancelled',
                    outs: [],
                    color: '#80FF80'
                }
            },
            invpool: {
                customer: {
                    label: 'customer',
                    translation: 'Customer',
                    outs: ['deinstall'],
                    color: '#04D330'
                },
                install: {
                    label: 'install',
                    translation: 'Installed',
                    outs: ['provider'],
                    color: '#00A6F0'
                },
                deinstall: {
                    label: 'deinstall',
                    translation: 'Deinstalled',
                    outs: ['customer'],
                    color: '#00F8E8'
                },
                provider: {
                    label: 'provider',
                    translation: 'Resource',
                    outs: ['install'],
                    color: '#FFE43B'
                }
            }
        },

        mandatoryActionProperties: {},

        /**
         * Which field shouldn't be editable
         *
         * format:
         *
         * parent: {
         *     key: true|false
         * }
         *
         */
        renderReadOnlyFieldsByParent: {
            data: {
                apiVersion: true,
                method: true,
                entity: true
            },
            resource: {
                pid: true,
                pname: true,
                gender: true
            }
        },

        /**
         * Check for string is valid JSON
         *
         * @param {*} str - String that should be validated
         *
         * @returns {boolean}
         *
         * @private
         */
        _isJson: function(str) {
            try {
                JSON.parse(str);
            } catch (e) {
                return false;
            }
            return true;
        },
        /**
         * Return origin of URL (protocol + domain)
         *
         * @param {String} url
         *
         * @returns {String}
         *
         * @private
         */
        _getOrigin: function(url) {
            if (url != '') {
                if (url.indexOf("://") > -1) {
                    return 'https://' + url.split('/')[2];
                } else {
                    return 'https://' + url.split('/')[0];
                }
            }

            return '';
        },

        /**
         * Return domain of URL
         *
         * @param {String} url
         *
         * @returns {String}
         *
         * @private
         */
        _getDomain: function(url) {
            if (url != '') {
                if (url.indexOf("://") > -1) {
                    return url.split('/')[2];
                } else {
                    return url.split('/')[0];
                }
            }

            return '';
        },

      

        /**
         * Sends postMessage to document.referrer
         *
         * @param {Object} data - Data that will be sent
         *
         * @private
         */
        _sendPostMessageData: function(data) {
            var originUrl = document.referrer || (document.location.ancestorOrigins && document.location.ancestorOrigins[0]) || '';

            if (originUrl) {
                this._log(window.location.host + ' -> ' + data.method + ' ' + this._getDomain(originUrl), JSON.stringify(data, null, 4));

                parent.postMessage(data, this._getOrigin(originUrl));
            } else {
                this._log(window.location.host + ' -> ' + data.method + ' ERROR. UNABLE TO GET REFERRER');
            }
        },

        /**
         * Handles during receiving postMessage
         *
         * @param {MessageEvent} event - Javascript event
         *
         * @private
         */
        _getPostMessageData: function(event) {
            var d1 = new Date();
            console.log('Time in _getPostMessageData:' + d1);
            if (typeof event.data === 'undefined') {
                this._log(window.location.host + ' <- NO DATA ' + this._getDomain(event.origin), null, null, true);

                return false;
            }

            if (!this._isJson(event.data)) {
                this._log(window.location.host + ' <- NOT JSON ' + this._getDomain(event.origin), null, null, true);

                return false;
            }

            var data = JSON.parse(event.data);

            if (!data.method) {
                this._log(window.location.host + ' <- NO METHOD ' + this._getDomain(event.origin), null, null, true);

                return false;
            }

            this._log(window.location.host + ' <- ' + data.method + ' ' + this._getDomain(event.origin), JSON.stringify(data, null, 4));

            switch (data.method) {
                case 'init':
                    this.pluginInitEnd(data);
                    break;

                case 'open':
                    this.pluginOpen(data);
                    break;

                case 'wakeup':
                    this.pluginWakeup(data);
                    break;

                case 'error':
                    data.errors = data.errors || {
                        error: 'Unknown error'
                    };
                    this._showError(data.errors);
                
                    break;
                case 'updateResult':
                    console.log(" Manual Inventory Updated");
                    break;
                
                case 'callProcedureResult':
                    this.finishCallIdCallbacks(event.data);
                    break;

                default:
                    this._log(window.location.host + ' <- UNKNOWN METHOD: ' + data.method + ' ' + this._getDomain(event.origin), null, null, true);
                    break;
            }
        },

        /**
         * Show alert with error
         *
         * @param {Object} errorData - Object with errors
         *
         * @private
         */
        _showError: function(errorData) {
            alert(JSON.stringify(errorData, null, 4));
        },

        /**
         * Logs to console
         *
         * @param {String} title - Message that will be log
         * @param {String} [data] - Formatted data that will be collapsed
         * @param {String} [color] - Color in Hex format
         * @param {Boolean} [warning] - Is it warning message?
         *
         * @private
         */
        _log: function(title, data, color, warning) {
            if (!this.debugMode) {
                return;
            }
            if (!color) {
                color = '#0066FF';
            }
            if (!!data) {
                console.groupCollapsed('%c[Plugin API] ' + title, 'color: ' + color + '; ' + (!!warning ? 'font-weight: bold;' : 'font-weight: normal;'));
                console.log('[Plugin API] ' + data);
                console.groupEnd();
            } else {
                console.log('%c[Plugin API] ' + title, 'color: ' + color + '; ' + (!!warning ? 'font-weight: bold;' : ''));
            }
        },

        /**
         * Business login on plugin init
         */
        saveToLocalStorage: function(data) {
            this._log(window.location.host + ' INIT. SET DATA TO LOCAL STORAGE', JSON.stringify(data, null, 4));

            if (data.attributeDescription) {
                localStorage.setItem('pluginInitData', JSON.stringify(data.attributeDescription));
            }
        },

        /**
         * Business login on plugin init end
         *
         * @param {Object} data - JSON object that contain data from OFSC
         */
        pluginInitEnd: function(data) {
            this.saveToLocalStorage(data);

            var messageData = {
                apiVersion: 1,
                method: 'initEnd'
            };

            if (localStorage.getItem('pluginWakeupCount') < localStorage.getItem('pluginWakeupMaxCount')) {
                this._log(window.location.host + ' UNFINISHED WAKEUP DATA FOUND IN LOCAL STORAGE');

                messageData.wakeupNeeded = true;
            }

            this._sendPostMessageData(messageData);
        },

        /**
         * Business login on plugin open
         *
         * @param {Object} receivedData - JSON object that contain data from OFSC
         */
        pluginOpen: function(receivedData) {
			var dataItemsToProcess = [];
            var errorLogs = receivedData.activity.A_PLUGIN_ERROR_LOG;

			if(localStorage.storageDataItems){
				dataItemsToProcess = localStorage.storageDataItems.split(',');
			}
			var ultimateBind = this;
            var actID = receivedData.activity.aid;
            $.ErrorUpdate = function (activityId, sErrorLogs) {

				this._sendPostMessageData({
					"apiVersion": 1,
					"method": "update",
					"activity": {
						"A_PLUGIN_ERROR_LOG": sErrorLogs,
						"aid": activityId
					}

				});
			}.bind(this);

            //functions:
            $.recalculateOverShipToNEnableBtns = function(dynamicInvIDItemNumber, bindVar) {
                var packedQty = $('#cpf_shiped_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find("#cpf_shiped_entered_qty").val(); //modification done for CHG0059205
                var receivedQty = $('#cpf_quantity_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find("#cpf_entered_qty").val(); //modification done for CHG0059205
                /*if (isNaN(parseInt(receivedQty))) {
				    receivedQty = 0;
                }
                if (isNaN(parseInt(packedQty))) {
                    packedQty = 0;
                }*/

				if(isNaN(receivedQty) || receivedQty.indexOf(' ') >=0 || receivedQty === "") {
					receivedQty = 0;
				}
				receivedQty = parseInt(receivedQty);

				if(isNaN(packedQty) || packedQty.indexOf(' ') >=0 || packedQty === "") {
					packedQty = 0;
				}
				packedQty = parseInt(packedQty);


                if (isNaN(packedQty) || packedQty == "") {
                    packedQty = parseInt(bindVar.quantity);
                }
                var soQty = parseInt(receivedQty) - parseInt(packedQty);

                $('#' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find("#iSoQty").text(soQty); //modification done for CHG0059205

                if (receivedQty >= 0) {

                    $('#' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find('#cpf_exception').removeClass("cp_hidden"); //modification done for CHG0059205
                    $('#' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find('#cpf_confirm_line_Btn').removeClass("cp_hidden"); //modification done for CHG0059205
                }
                
                /* OFSC Mobility For Highlighting Over Ship/Short Ship */
                if(parseInt(receivedQty) > parseInt(packedQty)){
                	//Over ship
                	$('#cpf_over_ship_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).addClass("cp_label_text_highlight_red");
                	$('#cpf_short_ship_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).removeClass("cp_label_text_highlight_red");
                	$('#' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find("#iSoQty").addClass("cp_label_text_highlight_red");
                }
                else if(parseInt(receivedQty) < parseInt(packedQty)){
                	$('#cpf_over_ship_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).removeClass("cp_label_text_highlight_red");
                	$('#cpf_short_ship_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).addClass("cp_label_text_highlight_red");
                	$('#' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find("#iSoQty").addClass("cp_label_text_highlight_red");
                }
                else{
                	$('#cpf_over_ship_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).removeClass("cp_label_text_highlight_red");
                	$('#cpf_short_ship_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).removeClass("cp_label_text_highlight_red");
                	$('#' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find("#iSoQty").removeClass("cp_label_text_highlight_red");
                }              
                /* OFSC Mobility end */
                

            };

			 $.recalculateProcessedCount = function(dynamicInvIDItemNumber) {

				  //if processed count and line items count match then enable the Submit All lines button.
				 // $('#' + dynamicInvIDItemNumber).find('#processedCountSwitch').text("ON");
                                var lineItemsCount = $("#cpf_lineItemsCount").text();
                                lineItemsCount = parseInt(lineItemsCount);
                                var processedCount = $("#cpf_processedCount").text();
                                processedCount = parseInt(processedCount) + 1;

									//set the on/ off switch
								 var onCounter = 0;
								  $("div#processedCountSwitch").each(function() {
									   var processedON = $(this).text();
									    if(processedON == "ON"){
									       onCounter ++;
										 }

								  });

								  //set processed count:
								$("#cpf_processedCount").text(onCounter);

                                if (lineItemsCount == onCounter) {
                                    $("#submitAllLinesBtn").removeAttr("disabled");
                                } else {
                                    $("#submitAllLinesBtn").attr("disabled", true);
                                }

			 };
			 
			 /*
			  OFSC Mobility Damaged Label display
			  */
			 $.damgedLabelDisplay = function(dynamicInvIDItemNumber) {
				 var excDamagedQty = $('#cpf_damaged_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find("#cpf_damaged_entered_qty").val();
				 var excUsedQty    = $('#cpf_used_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find("#cpf_used_entered_qty").val();
					
				 if(parseInt(excDamagedQty) > 0){
                	 //If the exception Qty is more than 0, add redButton and show Damaged Label
                 	$('#cpf_damaged_qty_label_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find("#iDamgeQty").text(excDamagedQty);
                 	$('#cpf_damaged_qty_label_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).removeClass("cp_hidden"); 
                 }
                 else{
                	 //If the exception Qty is less than or 0, remove redButton and remove Damaged Label
                 	$('#cpf_damaged_qty_label_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find("#iDamgeQty").text('');
                 	$('#cpf_damaged_qty_label_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).addClass("cp_hidden");                 	                 	
                 }
				 //show used quantity
				 if(parseInt(excUsedQty) > 0){
                	 //If the exception Qty is more than 0, add redButton and show Used Label
                 	$('#cpf_used_qty_label_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find("#iUsedQty").text(excUsedQty);
                 	$('#cpf_used_qty_label_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).removeClass("cp_hidden"); 
                 }
                 else{
                	 //If the exception Qty is less than or 0, remove redButton and remove Used Label
                 	$('#cpf_used_qty_label_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find("#iUsedQty").text('');
                 	$('#cpf_used_qty_label_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).addClass("cp_hidden");                 	                 	
                 }
				 
				//Show exception redButton if the qty in damaged or used entry is more than 0
				 if((parseInt(excDamagedQty) > 0) || (parseInt(excUsedQty) > 0)){
	                 /* Moved from Exception submit Part */
	                 $('#' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find('#cpf_exception').removeClass("submit");
	                 $('#' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find('#cpf_exception').addClass("redButton");
					 isExceptionEntered = true;
				 }
				 else{
					 $('#' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find('#cpf_exception').addClass("submit");
	                 $('#' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find('#cpf_exception').removeClass("redButton");
					 isExceptionEntered = false;
				 }
			 };
			/* OFSC Mobility end */

            //Fields Data from OFSC:
            //Resource fields:

			 var resourceExtID = receivedData.resource.external_id;

            var subInventoryNames = receivedData.resource.R_SUBINVENTORY_NAME;
			var subInventoryNamesArr = [], subInventoryListArr =[], subInventoryOwnerArr =[];
             if(subInventoryNames){
				 subInventoryNamesArr = subInventoryNames.split(";");
				console.log('subInventoryNamesArr ' + JSON.stringify(subInventoryNamesArr));
			 }

            var subInventoryList = receivedData.resource.R_SUBINVENTORY_LIST;
			if(subInventoryList){
             subInventoryListArr = subInventoryList.split(",");
            console.log('subInventoryListArr ' + JSON.stringify(subInventoryListArr));
			}

            var subInventoryOwner = receivedData.resource.R_SUBINVENTORY_OWNER;
			if(subInventoryOwner){
             subInventoryOwnerArr = subInventoryOwner.split(",");
            console.log('subInventoryOwnerArr ' + JSON.stringify(subInventoryOwnerArr));
			}

            var resourcePID = receivedData.resource.pid;
			var isExceptionEntered = false;


            // var subInventoryName = receivedData.activity.A_SUBINVENTORY_NAME;
            var aSubInventory = receivedData.activity.A_SUBINVENTORY;
            var aContainerNumber = receivedData.activity.A_CONTAINER_NUMBER;

            var trackingNumbers = "";
            var trackingNumberArr;


            var inventoryList = receivedData.inventoryList;
            //var activityId = receivedData.activity.aid;		// Commented for INC1591517
			var activityId = receivedData.activity.aid.toString();	// Added for INC1591517
			// Start added for CHG0075456 - Bin Locations for Field Service
			var subInventoryList = [];
			var subInventoryOwner = [];
			if(receivedData.resource.R_SUBINVENTORY_LIST != null)
				subInventoryList = receivedData.resource.R_SUBINVENTORY_LIST.split(",");
			if(receivedData.resource.R_SUBINVENTORY_OWNER != null)
			subInventoryOwner = receivedData.resource.R_SUBINVENTORY_OWNER.split(",");
			var resourceId = receivedData.resource.external_id;
			var primaryOwnedSubInventories = {};
			primaryOwnedSubInventories["CAR_STOCK"] = resourceId;
			primaryOwnedSubInventories["Car Stock"] = resourceId;
			for(var i = 0; i < subInventoryOwner.length ; i++){
				if(subInventoryOwner[i] == resourceId){
					primaryOwnedSubInventories[subInventoryList[i]] = subInventoryOwner[i];
				} 
			} // End added for CHG0075456 - Bin Locations for Field Service
			
			var packedOrderType ="I";
			var serverURL = window.location.origin;
			console.log("WindLocatOrigin - serverURL: "+serverURL);

            var rowCount = 0,
                iReferenceNumArr = [],
                receivedPartsListArr = [],
				 virtualInventoryList ={};
            $.dynamicBuildReceivedPartsElementFunction = function(inventoryList) {
                $.each(inventoryList, function(key, invItem) {
                    var bindVar = this;
                    var dynamicInvIDItemNumber = invItem.invid + "_" + invItem.I_ITEM_NUMBER;
					var isPresent = null,iSubName ='';
                    if (invItem.inv_aid == activityId) {

                        var iReceivingDocReferenceNum = invItem.I_RECEIVING_DOCUMENT_NUMBER;
						if(iReceivingDocReferenceNum ||  iReceivingDocReferenceNum == "0"){
                           isPresent = $.inArray(iReceivingDocReferenceNum, iReferenceNumArr);
						}

						if(invItem.I_SUBINVENTORY_NAME){
						     iSubName  = invItem.I_SUBINVENTORY_NAME ;
						}
						else{
							iSubName = 'Car Stock';
						}



                        if (isPresent == -1) {
                            // no duplicates
                            iReferenceNumArr.push(iReceivingDocReferenceNum);
							var hiddenClass = "";
							if(iReceivingDocReferenceNum == 0){
								hiddenClass = "cp_hidden";
							}else{
									hiddenClass = "";
							}
                            $("#cpf_ReceivePartsGridWrapper").append('<div id="cpf_' + iReceivingDocReferenceNum + '" class="inventory_lifecycle-outer_grid">\
							<div class=" cpf_3-0">\
							   <div id="cpf__unnamed_4" class="cp_section scrollable-overflow">\
								  <div id="cpf__unnamed_4_header" class="cp_section_header">Reference: <span id="cpf_containerNumber" >' + iReceivingDocReferenceNum + '</span> (subinventory: '+iSubName+')</div>\
								  <div id="cpf__unnamed_4_body" class="cp_section_body">\
									 <div id="displayReceiveInventoryPartsSectionMain_' + iReceivingDocReferenceNum + '" class="cpf_grid_wrapper inventory_lifecycle-grid inventory_lifecycle-table_receive">\
										<div id="cpf__unnamed_5_header" class="inventory_lifecycle-header ">\
										   <div class="inventory_lifecycle-header_left inventory_line_processed '+hiddenClass+'" style="">Processed: <span id="cpf_processedCount" >0</span></div>\
										   <div class="inventory_lifecycle-header_right inventory_line_items '+hiddenClass+'" style="">Line Items: <span id="cpf_lineItemsCount" >0</span></div>\
										   <div class="inventory_lifecycle-clear cpf_4-2" style=""></div>\
										   <div class="inventory_lifecycle-align_center col-part inventory_lifecycle-no_left_border cpf_4-3" style="">PARTS</div>\
										</div>\
									 </div>\
								  </div>\
							   </div>\
							</div>\
						 </div>');
                        } else {
                            // duplicate entry do nothing.
                        }

                        if (invItem.invpool == "customer" && invItem.invtype == "EXPECTED") {
                            rowCount += 1;
              // Start added for CHG0075456 - Bin Locations for Field Service
                            var binNames = "";
							if(invItem.I_PRIMARY_BIN_NAME != null){
								binNames += invItem.I_PRIMARY_BIN_NAME;
							}
							if(invItem.I_PRIMARY_BIN_QTY != null){
								binNames +='('+invItem.I_PRIMARY_BIN_QTY+')';
							}
							if("" != binNames){
								binNames +=',';
							}
							if(invItem.I_SECONDARY_BIN_NAME != null){
								binNames += invItem.I_SECONDARY_BIN_NAME;
							}
							if(invItem.I_SECONDARY_BIN_QTY != null){
								binNames +='('+invItem.I_SECONDARY_BIN_QTY+')';
							}
							if(binNames.endsWith(",")){
								binNames = binNames.substring(0,binNames.length-1);
							}
							if("" != binNames){
								binNames = 'Bin Mgt - ' +binNames;
							}
              // End added for CHG0075456 - Bin Locations for Field Service
							receivedPartsListArr.push(invItem.I_ITEM_NUMBER); // add the item number to the list array for computing in add button function.  //modification of .replace done for CHG0059205
              // Modified to add bin details for CHG0075456 - Bin Locations for Field Service
                            $("#displayReceiveInventoryPartsSectionMain_" + iReceivingDocReferenceNum).append('<div id="' + dynamicInvIDItemNumber.replace(/[/]/g,"") + '" class="inventory_lifecycle-grid-row inventory_lifecycle-grid-row-'+invItem.I_ITEM_NUMBER.replace(/[/]/g,"")+'">\
                           <div class="inventory_lifecycle_pack_list inventory_lifecycle-partnumber cpf_4-0">' + invItem.I_ITEM_NUMBER + " " + invItem.I_ITEM_DESCRIPTION + '</div>\
                           '+('' != binNames ? '<div class="inventory_lifecycle_pack_list">'+binNames+'</div>':'')+'\
                           '+(primaryOwnedSubInventories.hasOwnProperty(invItem.I_SUBINVENTORY) || primaryOwnedSubInventories.hasOwnProperty(iSubName)?'<div class="inventory_lifecycle_pack_list inventory_lifecycle_bin_mgt">Bin mgt flag: <input type="checkbox" name="inventory_lifecycle_bin_mgt_chk" id="bin_mgt_chk_'+ dynamicInvIDItemNumber.replace(/[/]/g,"") +'" '+('Y' == invItem.I_BIN_MANAGEMENT ? 'checked':'')+'/><div/>':'')+'\
                           <div id="cpf_ship_Block_lbl_' + dynamicInvIDItemNumber + '" class="inventory_lifecycle_pack_list inventory_lifecycle-general cpf_4-1" style="display: none;">Pack List Qty:</div>\
                           <div id="cpf_ship_Block_' + dynamicInvIDItemNumber + '" class="ship_order_Z7483587 inventory_lifecycle-spinner inventory_lifecycle-general inventory_lifecycle_main_spinner cpf_4-2" style="display: none;">\
                              <div id="cpf_shiped_' + dynamicInvIDItemNumber + '" class="cp_field inventory_lifecycle-inline-spinner small-spinner">\
                                 <div class="cp_field_row">\
                                    <div class="cp_field_value cp_fullsize">\
                                       <div class="cp_field_value_inner_wrapper">\
                                          <input id="cpf_shiped_button_decrease" type="button" class="cpf-spinner-button-decrease button" value="-">\
										  <input id="cpf_shiped_entered_qty" type="text" class="cp_field_text_component cp_field_spinner_component form-item" value="">\
										  <input id="cpf_shiped_button_increase" type="button" class="cpf-spinner-button-increase button" value="+">\
										  <span id="cpf_shiped__inner_read_only" class="cp_aux_hide"></span><span class="cp_measure_unit" id=""> </span>\
										  <span class="cp_min_max" id="cpf_shiped__min_max"></span>\
                                          <div class="cp_error_label" id="cpf_shiped__error"></div>\
                                       </div>\
                                    </div>\
                                 </div>\
                              </div>\
                           </div>\
                           <div class="inventory_lifecycle-expected inventory_lifecycle-general cpf_4-3">Expected: ' + invItem.quantity + '</div>\
                           <div class="inventory_lifecycle-clear cpf_4-4"></div>\
                           <div class="inventory_lifecycle_pack_list inventory_lifecycle-general cpf_4-5">Received:</div>\
                           <div class="inventory_lifecycle-spinner inventory_lifecycle-general inventory_lifecycle_main_spinner cpf_4-6">\
                              <div id="cpf_quantity_' + dynamicInvIDItemNumber.replace(/[/]/g,"") + '" class="cp_field inventory_lifecycle-inline-spinner small-spinner">\
                                 <div class="cp_field_row">\
                                    <div class="cp_field_value cp_fullsize cp_no_left_margin">\
                                       <div id="' + invItem.I_ITEM_NUMBER.replace(/[/]/g,"") + '" class="cp_field_value_inner_wrapper cp_six_left_padding">\
                                          <input id="cpf_quantity_button_decrease" type="button" class="cpf-spinner-button-decrease button" value="-">\
										  <input id="cpf_entered_qty" type="text" class="cp_field_text_component cp_field_spinner_component form-item" value="">\
										  <input id="cpf_quantity_button_increase" type="button" class="cpf-spinner-button-increase button" value="+">\
										  <span id="cpf_quantity__inner_read_only" class="cp_aux_hide"></span>\
										  <span class="cp_measure_unit" id=""> </span><span class="cp_min_max" id="cpf_quantity__min_max"></span>\
                                          <div class="cp_error_label" id="cpf_quantity__error"></div>\
                                       </div>\
                                    </div>\
                                 </div>\
                              </div>\
                           </div>\
                           <div id="itemProcessGreen" class="inventory_lifecycle-expected inventory_lifecycle-general inventory_lifecycle_green cpf_4-7"></div>\
                           <div class="inventory_lifecycle-clear cpf_4-8"></div>\
                           <div class="inventory_lifecycle-expected inventory_lifecycle-ship cpf_4-9"><span id="cpf_over_ship_' + dynamicInvIDItemNumber.replace(/[/]/g,"") + '">Over Ship </span>/ <span id="cpf_short_ship_' + dynamicInvIDItemNumber.replace(/[/]/g,"") + '"> Short Ship</span>: <span id="iSoQty"></span></div>\
                           <div id="cpf_damaged_qty_label_' + dynamicInvIDItemNumber.replace(/[/]/g,"") + '" class="inventory_lifecycle-expected inventory_lifecycle-ship cpf_4-9 cp_label_text_highlight_red cp_hidden">Damaged: <span id="iDamgeQty"></span></div>\
                           <div id="cpf_used_qty_label_' + dynamicInvIDItemNumber.replace(/[/]/g,"") + '" class="inventory_lifecycle-expected inventory_lifecycle-ship cpf_4-9 cp_label_text_highlight_red cp_hidden">Used: <span id="iUsedQty"></span></div>\
                           <div class="inventory_lifecycle-clear cpf_4-10">\</div>\
                           <div class="cp_exception_confirm_btn_section">\
                           <div class="inventory_lifecycle_subbutton_left cpf_4-11 cp_fix_left_margin"><input id="cpf_exception" type="button" class="cp_plugin_button button submit cp_hidden" value="Exception"> </div>\
                           <div class="confirmBtn_marginLeft inventory_lifecycle_subbutton_right cpf_4-12"><input id="cpf_confirm_line_Btn" type="button" class="cp_plugin_button button submit cp_hidden" value="Confirm Line"> </div>\</div>\
						   <div id="processedCountSwitch" class="inventory_lifecycle-clear cpf_4-2 cp_hidden" style="">OFF</div>\
                        </div>');

                            if (invItem.I_ORDER_TYPE == "P") {

								packedOrderType = "P";

                                //.removeAttr("style");
                                $('#cpf_ship_Block_lbl_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).removeAttr("style"); //modification of .replace done for INC1578541
                                $('#cpf_ship_Block_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).removeAttr("style");  //modification of .replace done for INC1578541

                                $('#cpf_shiped_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).on('click', '#cpf_shiped_button_decrease', function() {     //modification of .replace done for INC1578541
                                    var itemNumber = bindVar.I_ITEM_NUMBER;
                                    var invID = bindVar.invid;
                                    var totalQty = bindVar.quantity;

                                    var dynamicInvIDItemNumber = invID + "_" + itemNumber;

                                    var cpfEnteredQty = $(this).next();
                                    var prevValue = cpfEnteredQty.val();

									if(isNaN(prevValue) || prevValue.indexOf(' ') >=0 || prevValue === "") {
										cpfEnteredQty.val(0);
										//alert('Only Numeric Values Are Allowed');
									}else{
										cpfEnteredQty.val(parseInt(prevValue));
									}

									var incCount = parseInt(cpfEnteredQty.val());

                                    if (incCount <= 0) {
                                        cpfEnteredQty.val(0);
                                    } else {
                                        incCount -= 1;
                                        cpfEnteredQty.val(incCount);
                                    }

                                    $.recalculateOverShipToNEnableBtns(dynamicInvIDItemNumber, bindVar);
                                });

                                $('#cpf_shiped_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).on('click', '#cpf_shiped_button_increase', function() {  //modification of .replace done for INC1578541
                                    var totalQty = bindVar.quantity;
                                    var itemNumber = bindVar.I_ITEM_NUMBER;
                                    var invID = bindVar.invid;

                                    var dynamicInvIDItemNumber = invID + "_" + itemNumber;

                                    var cpfEnteredQty = $(this).prev();

                                    var prevValue = cpfEnteredQty.val();

									if(isNaN(prevValue) || prevValue.indexOf(' ') >=0 || prevValue === "") {
										cpfEnteredQty.val(0);
										//alert('Only Numeric Values Are Allowed');
									}else{
										cpfEnteredQty.val(parseInt(prevValue));
									}

									var incCount = parseInt(cpfEnteredQty.val());

                                    if (incCount <= 0) {
                                        cpfEnteredQty.val(1);
                                    } else {
                                        incCount += 1;
                                        cpfEnteredQty.val(incCount);

                                    }

                                    //calculate the Over or Short Ship to:
                                    // package qty if available - received qty.

                                    $.recalculateOverShipToNEnableBtns(dynamicInvIDItemNumber, bindVar);

                                });

                                $('#cpf_shiped_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).on("change paste keyup", "#cpf_shiped_entered_qty", function() {  //modification of .replace done for INC1578541

									var enteredVal = $(this).val();
									if(enteredVal.length > 20)
									{
										$(this).val(0);
									}

									if(isNaN(enteredVal) || enteredVal.indexOf(' ') >=0 || enteredVal === "") {
										$(this).val(0);
										//alert('Only Numeric Values Are Allowed');
									}else{
										$(this).val(parseInt(enteredVal));
									}

                                    var currentQty = parseInt($(this).val());
                                    var totalQty = bindVar.quantity;
                                    var itemNumber = bindVar.I_ITEM_NUMBER;
                                    var invID = bindVar.invid;

                                    var dynamicInvIDItemNumber = invID + "_" + itemNumber;

                                    $(this).val(currentQty);

                                    $.recalculateOverShipToNEnableBtns(dynamicInvIDItemNumber, bindVar);
                                });
                            }


                            //Exception button click.

                            $('#' + dynamicInvIDItemNumber.replace(/[/]/g,"")).on('click', '#cpf_exception', function() {   //modification of .replace done for INC1578541
                                var itemNumber = bindVar.I_ITEM_NUMBER;
                                var invID = bindVar.invid;

                                var dynamicInvIDItemNumber = invID + "_" + itemNumber;
                                var itemElement = $('#exception_grid_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).length;  //modification of .replace done for INC1578541
                                if (itemElement != 0) {
                                    //item already exists then do not create a new element and do not append.

                                } else {
                                    $("#cpf_exception_grid_Section").append('<div id="exception_grid_' + dynamicInvIDItemNumber.replace(/[/]/g,"") + '" class="inventory_lifecycle-outer_grid cp_hidden">\
								 <div class=" cpf_10-0">\
									<div id="cpf__unnamed_10" class="cp_section scrollable-overflow">\
									   <div id="cpf__unnamed_10_header" class="cp_section_header cp_aux_hide"></div>\
									   <div id="cpf__unnamed_10_body" class="cp_section_body">\
										  <div id="cpf__unnamed_11" class="cpf_grid_wrapper inventory_lifecycle-grid inventory_lifecycle-table_receive">\
											 <div id="cpf__unnamed_11_header" class="inventory_lifecycle-header ">\
												<div class="inventory_lifecycle-header_left cpf_11-0" style="">' + invItem.I_ITEM_NUMBER + ' </div>\
											 </div>\
											 <div id="cpf_11-0" class="inventory_lifecycle-grid-row">\
												<div class="inventory_lifecycle_pack_list inventory_lifecycle-partnumber cpf_11-0"></div>\
												<div class="inventory_lifecycle_pack_list inventory_lifecycle-general cpf_11-1">Damaged:</div>\
												<div class="ship_order inventory_lifecycle-spinner inventory_lifecycle-general cpf_11-2">\
												   <div id="cpf_damaged_' + dynamicInvIDItemNumber.replace(/[/]/g,"") + '" class="cp_field inventory_lifecycle-inline-spinner small-spinner">\
													  <div class="cp_field_row">\
														 <div class="cp_field_value cp_fullsize">\
															<div class="cp_field_value_inner_wrapper">\
															   <input id="cpf_damaged_button_decrease" type="button" class="cpf-spinner-button-decrease button" value="-">\
															   <input id="cpf_damaged_entered_qty" type="text" class="cp_field_text_component cp_field_spinner_component form-item" value="0">\
															   <input id="cpf_damaged_button_increase" type="button" class="cpf-spinner-button-increase button" value="+">\
															   </div>\
														 </div>\
													  </div>\
												   </div>\
												</div>\
												<div class="inventory_lifecycle-clear cpf_11-3"></div>\
												<div class="inventory_lifecycle-expected inventory_lifecycle-general cpf_11-4">Used:</div>\
												<div class="ship_order inventory_lifecycle-spinner inventory_lifecycle-general cpf_11-5">\
												   <div id="cpf_used_' + dynamicInvIDItemNumber.replace(/[/]/g,"") + '" class="cp_field inventory_lifecycle-inline-spinner small-spinner">\
													  <div class="cp_field_row">\
														 <div class="cp_field_value cp_fullsize">\
															<div class="cp_field_value_inner_wrapper">\
															   <input id="cpf_used_button_decrease" type="button" class="cpf-spinner-button-decrease button" value="-">\
															   <input id="cpf_used_entered_qty" type="text" class="cp_field_text_component cp_field_spinner_component form-item" value="0">\
															   <input id="cpf_used_button_increase" type="button" class="cpf-spinner-button-increase button" value="+">\
															   </div>\
														 </div>\
													  </div>\
												   </div>\
												</div>\
												<div class="inventory_lifecycle-clear cpf_11-6"></div>\
												<div class="inventory_lifecycle_subbutton_left cpf_11-7"><input id="cancelExcep" type="button" class="cp_plugin_button button submit" value="Cancel"> </div>\
												<div class="inventory_lifecycle_subbutton_right cpf_11-8"><input id="submitExcep" type="button" class="cp_plugin_button button submit" value="Submit"> </div>\
											 </div>\
										  </div>\
									   </div>\
									</div>\
								 </div>\
							  </div>');

							  $('#cpf_damaged_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).on('click', '#cpf_damaged_button_decrease', function() {  //modification of .replace done for INC1578541



                                    var cpfEnteredQty = $(this).next();
                                    var prevValue = cpfEnteredQty.val();

									if(isNaN(prevValue) || prevValue.indexOf(' ') >=0 || prevValue === "") {
										cpfEnteredQty.val(0);
										//alert('Only Numeric Values Are Allowed');
									}else{
										cpfEnteredQty.val(parseInt(prevValue));
									}

									var incCount = parseInt(cpfEnteredQty.val());

                                    if (incCount <= 0) {
                                        cpfEnteredQty.val(0);
                                    } else {
                                        incCount -= 1;
                                        cpfEnteredQty.val(incCount);
                                    }

                                });

                                $('#cpf_damaged_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).on('click', '#cpf_damaged_button_increase', function() {  //modification of .replace done for INC1578541


                                    var cpfEnteredQty = $(this).prev();

                                    var prevValue = cpfEnteredQty.val();

									if(isNaN(prevValue) || prevValue.indexOf(' ') >=0 || prevValue === "") {
										cpfEnteredQty.val(0);
										//alert('Only Numeric Values Are Allowed');
									}else{
										cpfEnteredQty.val(parseInt(prevValue));
									}

									var incCount = parseInt(cpfEnteredQty.val());

									// have a count of the max received qty.
									  var itemNumber = bindVar.I_ITEM_NUMBER;
									 var itemReceivedQty = $("#" + itemNumber.replace(/[/]/g,"")).find("#cpf_entered_qty").val();  //modification of .replace done for INC1578541
									  itemReceivedQty = parseInt(itemReceivedQty);

                                    if (incCount <= 0) {
                                        cpfEnteredQty.val(1);
                                    } else {
                                        incCount += 1;

										if( incCount >= itemReceivedQty)
										{
											incCount = itemReceivedQty;
										}
                                        cpfEnteredQty.val(incCount);

                                    }


                                });

                                $('#cpf_damaged_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).on("change paste keyup", "#cpf_damaged_entered_qty", function() {  //modification of .replace done for INC1578541

									var enteredVal = $(this).val();
									if(enteredVal.length > 20)
									{
										$(this).val(0);
									}

									if(isNaN(enteredVal) || enteredVal.indexOf(' ') >=0 || enteredVal === "") {
										$(this).val(0);
										//alert('Only Numeric Values Are Allowed');
									}else{
										$(this).val(parseInt(enteredVal));
									}

							        var currentQty = parseInt($(this).val());
                                    var totalQty = bindVar.quantity;
                                    var itemNumber = bindVar.I_ITEM_NUMBER;
                                    var invID = bindVar.invid;

                                    var dynamicInvIDItemNumber = invID + "_" + itemNumber;

									$(this).val(currentQty);
                                });


                                $('#cpf_used_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).on('click', '#cpf_used_button_decrease', function() {

                                    var cpfEnteredQty = $(this).next();
                                    var prevValue = cpfEnteredQty.val();

									if(isNaN(prevValue) || prevValue.indexOf(' ') >=0 || prevValue === "") {
										cpfEnteredQty.val(0);
										//alert('Only Numeric Values Are Allowed');
									}else{
										cpfEnteredQty.val(parseInt(prevValue));
									}

									var incCount = parseInt(cpfEnteredQty.val());

                                    if (incCount <= 0) {
                                        cpfEnteredQty.val(0);
                                    } else {
                                        incCount -= 1;
                                        cpfEnteredQty.val(incCount);
                                    }

                                });

                                $('#cpf_used_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).on('click', '#cpf_used_button_increase', function() {

                                    var cpfEnteredQty = $(this).prev();
                                    var prevValue = cpfEnteredQty.val();

									if(isNaN(prevValue) || prevValue.indexOf(' ') >=0 || prevValue === "") {
										cpfEnteredQty.val(0);
										//alert('Only Numeric Values Are Allowed');
									}else{
										cpfEnteredQty.val(parseInt(prevValue));
									}

									var incCount = parseInt(cpfEnteredQty.val());

                                     var itemNumber = bindVar.I_ITEM_NUMBER;
									 var itemReceivedQty = $("#" + itemNumber.replace(/[/]/g,"")).find("#cpf_entered_qty").val();
									 itemReceivedQty = parseInt(itemReceivedQty);

                                    if (incCount <= 0) {
                                        cpfEnteredQty.val(1);
                                    } else {
                                        incCount += 1;
										if( incCount >= itemReceivedQty)
										{
											incCount = itemReceivedQty;
										}
                                        cpfEnteredQty.val(incCount);

                                    }

                                });

                                $('#cpf_used_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).on("change paste keyup", "#cpf_used_entered_qty", function() {

									var enteredVal = $(this).val();
									if(enteredVal.length > 20)
									{
										$(this).val(0);

									}
                                    var currentQty = parseInt($(this).val());
                                    var totalQty = bindVar.quantity;
                                    var itemNumber = bindVar.I_ITEM_NUMBER;
                                    var invID = bindVar.invid;

                                    var dynamicInvIDItemNumber = invID + "_" + itemNumber;

									if(isNaN(enteredVal) || enteredVal.indexOf(' ') >=0 || enteredVal === "") {
										$(this).val(0);
										//alert('Only Numeric Values Are Allowed');
									}else{
										$(this).val(parseInt(currentQty));
									}

									currentQty = parseInt($(this).val());
                                    $(this).val(currentQty);
                                });


                                // on click of the cancel and submit buttons on the Exception page.

                                $('#exception_grid_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).on('click', '#cancelExcep', function() {

                                    //show hide the other blocks.
                                    //submitExcep.
                                    // show hide. // retain the values entered in damage and used qty.
                                    //unHide the main block.
                                    $('#cpf_ReceivePartsMainBlock').removeClass("cp_hidden");

                                    //Hide the exception block.
                                    $('#cpf_exception_Section').addClass("cp_hidden");

                                    $('#exception_grid_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).addClass("cp_hidden");

                                    // add the red color to the Exception button.
                                    //remove class submit, add class redButton.

                                    $('#' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find('#cpf_exception').removeClass("redButton");
                                    $('#' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find('#cpf_exception').addClass("submit");
                                    // clear the fields values to zero.
                                    $('#exception_grid_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find('#cpf_used_entered_qty').val(0);
                                    $('#exception_grid_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find('#cpf_damaged_entered_qty').val(0);

                                    /*OFSC Mobility. Call function to manage Damaged label, since the entered damaged qty is reset by above code*/
                                    $.damgedLabelDisplay(dynamicInvIDItemNumber);
                                    /* OFSC Mobility end */
                                });

                                $('#exception_grid_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).on('click', '#submitExcep', function() {

                                    //submitExcep.
                                    // show hide. // retain the values entered in damage and used qty.
                                    //unHide the main block.
                                    $('#cpf_ReceivePartsMainBlock').removeClass("cp_hidden");
                                    //Hide the exception block.
                                    $('#cpf_exception_Section').addClass("cp_hidden");
                                    $('#exception_grid_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).addClass("cp_hidden");

                                    // add the red color to the Exception button.
                                    //remove class submit, add class redButton.
                                    /* OFSC Mobility - Add Damaged qty label */                                    
                                    $.damgedLabelDisplay(dynamicInvIDItemNumber);
                                    
                                    /* Moved below 3 lines to $.damgedLabelDisplay function ----
                                    $('#' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find('#cpf_exception').removeClass("submit");
                                    $('#' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find('#cpf_exception').addClass("redButton");
									isExceptionEntered = true;
									*/
									/* OFSC Mobility end */

                                });

                                }

                                //Hide the main block.
                                $('#cpf_ReceivePartsMainBlock').addClass("cp_hidden");
                                //Un Hide the exception block.
                                $('#cpf_exception_Section').removeClass("cp_hidden");
                                $('#exception_grid_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).removeClass("cp_hidden");



                            });

                            $('#' + dynamicInvIDItemNumber.replace(/[/]/g,"")).on('click', '#cpf_confirm_line_Btn', function() {
                                //disable the exception and confirm line buttons.
								var itemNumber = bindVar.I_ITEM_NUMBER;

                                var invID = bindVar.invid;

                                var dynamicInvIDItemNumber = invID + "_" + itemNumber;
                                $(this).attr("disabled", true);

                                $('#' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find('#cpf_exception').attr("disabled", true);
                                // Add the item Processed
                                $('#' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find('#itemProcessGreen').text('Item Processed');
                                // increment the processed count.
								$('#' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find('#processedCountSwitch').text("ON");

                               $.recalculateProcessedCount(dynamicInvIDItemNumber);
                            });

                            //Increase and decrease qty.


                            $('#cpf_quantity_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).on('click', '#cpf_quantity_button_decrease', function() {

                                var itemNumber = bindVar.I_ITEM_NUMBER;
                                var totalQty = bindVar.quantity;
                                var invID = bindVar.invid;

                                var dynamicInvIDItemNumber = invID + "_" + itemNumber;

                                var cpfEnteredQty = $(this).next();
                                var prevValue = cpfEnteredQty.val();

								if(isNaN(prevValue) || prevValue.indexOf(' ') >=0 || prevValue === "") {
									cpfEnteredQty.val(0);
									//alert('Only Numeric Values Are Allowed');
								}else{
									cpfEnteredQty.val(parseInt(prevValue));
								}

								var incCount = parseInt(cpfEnteredQty.val());

                                if (incCount <= 0) {
                                    cpfEnteredQty.val(0);
                                } else {
                                    incCount -= 1;
                                    cpfEnteredQty.val(incCount);
                                }

                                $.recalculateOverShipToNEnableBtns(dynamicInvIDItemNumber, bindVar);
                                // Remove the disable attribute for exception and confirm buttons.
                                $('#' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find('#cpf_exception').removeAttr("disabled");
                                $('#' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find('#cpf_confirm_line_Btn').removeAttr("disabled");
                                $('#' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find('#itemProcessGreen').text('');

								//set the on/ off/intermediate switch

								$('#' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find('#processedCountSwitch').text("INTERMEDIATE");

								$.recalculateProcessedCount(dynamicInvIDItemNumber);


                            });

                            $('#cpf_quantity_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).on('click', '#cpf_quantity_button_increase', function() {
                                var totalQty = bindVar.quantity;
                                var itemNumber = bindVar.I_ITEM_NUMBER;
                                var invID = bindVar.invid;
                                var iReceivingDocReferenceNum = bindVar.I_RECEIVING_DOCUMENT_NUMBER;

                                var dynamicInvIDItemNumber = invID + "_" + itemNumber;

                                var cpfEnteredQty = $(this).prev();

                                var prevValue = cpfEnteredQty.val();

								if(isNaN(prevValue) || prevValue.indexOf(' ') >=0 || prevValue === "") {
									cpfEnteredQty.val(0);
									//alert('Only Numeric Values Are Allowed');
								}else{
									cpfEnteredQty.val(parseInt(prevValue));
								}

								var incCount = parseInt(cpfEnteredQty.val());

                                if (incCount <= 0) {
                                    cpfEnteredQty.val(1);
                                } else {
                                    incCount += 1;
                                    cpfEnteredQty.val(incCount);

                                }

                                //calculate the Over or Short Ship to:
                                // package qty if available - received qty.
                                $.recalculateOverShipToNEnableBtns(dynamicInvIDItemNumber, bindVar);

                                // Remove the disable attribute for exception and confirm buttons.
                                $('#' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find('#cpf_exception').removeAttr("disabled");
                                $('#' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find('#cpf_confirm_line_Btn').removeAttr("disabled");
                                $('#' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find('#itemProcessGreen').text('');

								//set the on/ off switch
								$('#' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find('#processedCountSwitch').text("INTERMEDIATE");

                                 $.recalculateProcessedCount(dynamicInvIDItemNumber);

                            });

                            $('#cpf_quantity_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).on("change paste keyup", "#cpf_entered_qty", function() {

								var enteredVal = $(this).val();
								if(enteredVal.length > 20)
								{
									$(this).val(0);

								}

                                var currentQty = parseInt($(this).val());
                                var totalQty = bindVar.quantity;
                                var itemNumber = bindVar.I_ITEM_NUMBER;
                                var invID = bindVar.invid;
                                var iReceivingDocReferenceNum = bindVar.I_RECEIVING_DOCUMENT_NUMBER;

                                var dynamicInvIDItemNumber = invID + "_" + itemNumber;

                                if(isNaN(enteredVal) || enteredVal.indexOf(' ') >=0 || enteredVal === "") {
									$(this).val(0);
									//alert('Only Numeric Values Are Allowed');
								}else{
									$(this).val(parseInt(currentQty));
								}

								currentQty = parseInt($(this).val());

								$(this).val(currentQty);

								$.recalculateOverShipToNEnableBtns(dynamicInvIDItemNumber, bindVar);

                                // Remove the disable attribute for exception and confirm buttons.
                                $('#' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find('#cpf_exception').removeAttr("disabled");
                                $('#' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find('#cpf_confirm_line_Btn').removeAttr("disabled");
                                $('#' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find('#itemProcessGreen').text('');
                                //reset the processed count.

                                	//set the on/ off switch
								$('#' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find('#processedCountSwitch').text("INTERMEDIATE");

								 $.recalculateProcessedCount(dynamicInvIDItemNumber);

                            });

                        }
                    }

                });

            };

            $.dynamicBuildReceivedPartsElementFunction(inventoryList);

            //set the found parts count
            $("#cpf_lineItemsCount").text(rowCount);

            //Main section cancel Button.

            $('#mainSectionCancelBtn').click(function() {

                this._sendPostMessageData({
                    "apiVersion": 1,
                    "method": "close",
                    "backScreen": "activity_list",
                    "wakeupNeeded": false
                });



            }.bind(this));

            $.generateCallId = function () {
                return btoa(String.fromCharCode.apply(null, window.crypto.getRandomValues(new Uint8Array(16))));
            },

            // On click of ADD button.
            $('#recInventoryAddButton').click(function() {

                var vPartNumber = $("#vpartNumber").val();

				if (vPartNumber != "") {

				// *******GET PARTS CATALOG REST CALL****/

				 $.getPartsCatalog = function() {
					try{
                    //Parts Catalog Call started
                    console.log("Parts Catalog call started");
                    var uniquecallid = $.generateCallId();
                    var jsonSearchToSend = {
                        "apiVersion": 1,
                        "method": "callProcedure",
                        "callId": uniquecallid,
                        "procedure": "searchParts",
                        "params": {
                            "limit": 100,
                            "query": vPartNumber,
                            "cacheOnly": false
                        }
                    }
                    console.log("Searching Parts JSON: " + JSON.stringify(jsonSearchToSend));
                    ultimateBind._sendPostMessageData(jsonSearchToSend);
                }
                catch(e)
                {
                    var now = new Date(Date.now());
                    if (errorLogs == null) {
                        errorLogs = "";
                    }
                    errorLogs = errorLogs + "||" + now.toString() + "|Plugin :Receive Inventory " + "| Error Details:" + e;
                    console.log(errorLogs);

                    $.ErrorUpdate(actID, errorLogs);
                }
					
                     //$.processSearchResultsFnCallBck(partsCatalogResponseData);

                }.bind(this);

				$.getPartsCatalog();

				$.processSearchResultsFnCallBck = function(partsCatalogResponseData) {

                var fieldsArray=[];
                $.each(partsCatalogResponseData.resultData.items, function (i, a) {
                     
                    console.log(a.fields);
                    fieldsArray.push(a.fields);
                });

                console.log("Fields Array: "+ fieldsArray);
                  // var elementArray = elementJSON.element;
                    var elementArray = fieldsArray;
                    var partsCatalogJSON = {};
					if(elementArray){
						for (var i = 0; i < elementArray.length; i++) {

							var obj = elementArray[i];
							console.log(obj.ITEM_NUMBER);
							var partsCatKey = "partsCatalog_"+obj.ITEM_NUMBER;

                             partsCatalogJSON[partsCatKey] = {
															"inv_aid": activityId,
															"I_RECEIVING_DOCUMENT_NUMBER": 0,
															"I_ORDER_TYPE": packedOrderType,
															"I_RECEIVED_QUANTITY": null,
															"I_ITEM_DAMAGED_QUANTITY": null,
															"I_RECEIPT_OVERRIDE": null,
															"I_REASON_CODE": null,
															"I_USED_QUANTITY": null,
															"I_SHIP_QUANTITY": null,
															"I_GOOD_QUANTITY": null,
															"I_SO_QUANTITY": null,
															"I_IGNORE_FLAG": null,
															"I_RETURN_QUANTITY": null,
															"invid": "newVirtualInvID",
															"invpool": "customer",
															"invtype": "EXPECTED",
															"quantity": 0,
															"inv_pid": null,
															"invsn": null,
															"I_SUBINVENTORY": "CAR_STOCK",
															"I_ITEM_NUMBER": obj.ITEM_NUMBER,
															"I_ITEM_DESCRIPTION": obj.ITEM_DESCRIPTION,
                                                            "I_ITEM_DISPOSITION": obj.ITEM_DISPOSITION,
															"I_PRICE": obj.ITEM_PRICE,
															"I_ITEM_PRICE": obj.ITEM_PRICE,
															"I_ITEM_COST": obj.ITEM_COST,
															"I_RETURN_VENDOR" : obj.VENDOR
															};
						}
					}

                    //console.log(JSON.stringify(partsCatalogJSON));
					var exactMatchFoundPartsCatalog = false;


					 var isPartNumPresentSI = $.inArray(vPartNumber, receivedPartsListArr);

                    if (isPartNumPresentSI == -1) {
                        // no duplicates

                        if (confirm('This part number is absent in received parts list.\n Add detail to parts list?')) {

                            // build the virtual inventoryList and invoke the dynamicBuildReceivedPartsElementFunction.
							//var virtualInvID ="";


					    $.processVirtualInvList = function(vPartNumber,itemDesc,itemDisposition,iPrice,iCost,iReturnVendor) {
							var vPartNumber_InvID = "virtualInvID_"+vPartNumber;
							    $.extend(virtualInventoryList, {[vPartNumber_InvID]: {
																	"inv_aid": activityId,
																	"I_RECEIVING_DOCUMENT_NUMBER": "0",
																	"I_ORDER_TYPE": packedOrderType,
																	"I_RECEIVED_QUANTITY": null,
																	"I_ITEM_DAMAGED_QUANTITY": null,
																	"I_RECEIPT_OVERRIDE": null,
																	"I_REASON_CODE": null,
																	"I_USED_QUANTITY": null,
																	"I_SHIP_QUANTITY": null,
																	"I_GOOD_QUANTITY": null,
																	"I_SO_QUANTITY": null,
																	"I_IGNORE_FLAG": null,
																	"I_RETURN_QUANTITY": null,
																	"invid": "newVirtualInvID",
																	"invpool": "customer",
																	"invtype": "EXPECTED",
																	"quantity": "0",
																	"inv_pid": null,
																	"invsn": null,
																	"I_SUBINVENTORY": "CAR_STOCK",
																	"I_ITEM_NUMBER": vPartNumber,
																	"I_ITEM_DESCRIPTION":itemDesc,
                                                                     "I_ITEM_DISPOSITION":itemDisposition,
                                                                     "I_PRICE": iPrice,
																	"I_ITEM_PRICE": iPrice,
																	"I_ITEM_COST": iCost,
																	"I_RETURN_VENDOR" : iReturnVendor
																	}
													   });
                             var tempVirtualInventoryList = {[vPartNumber_InvID]: {
																	"inv_aid": activityId,
																	"I_RECEIVING_DOCUMENT_NUMBER": "0",
																	"I_ORDER_TYPE": packedOrderType,
																	"I_RECEIVED_QUANTITY": null,
																	"I_ITEM_DAMAGED_QUANTITY": null,
																	"I_RECEIPT_OVERRIDE": null,
																	"I_REASON_CODE": null,
																	"I_USED_QUANTITY": null,
																	"I_SHIP_QUANTITY": null,
																	"I_GOOD_QUANTITY": null,
																	"I_SO_QUANTITY": null,
																	"I_IGNORE_FLAG": null,
																	"I_RETURN_QUANTITY": null,
																	"invid": "newVirtualInvID",
																	"invpool": "customer",
																	"invtype": "EXPECTED",
																	"quantity": "0",
																	"inv_pid": null,
																	"invsn": null,
																	"I_SUBINVENTORY": "CAR_STOCK",
																	"I_ITEM_NUMBER": vPartNumber,
																	"I_ITEM_DESCRIPTION":itemDesc,
                                                                     "I_ITEM_DISPOSITION":itemDisposition,
                                                                    "I_PRICE": iPrice,
																	"I_ITEM_PRICE": iPrice,
																	"I_ITEM_COST": iCost,
																	"I_RETURN_VENDOR" : iReturnVendor
																	}
													   };
								$.dynamicBuildReceivedPartsElementFunction(tempVirtualInventoryList);

								var lineItemsCount = $("#cpf_lineItemsCount").text();
								lineItemsCount = parseInt(lineItemsCount) + 1;
								//$("#cpf_lineItemsCount").text(lineItemsCount);

								$("#cpf_lineItemsCount").each(function() {
									$(this).text(lineItemsCount);
								});
								 $('#newVirtualInvID_' + vPartNumber.replace(/[/]/g,"")).find('#cpf_exception').removeClass("cp_hidden");
                                 $('#newVirtualInvID_' + vPartNumber.replace(/[/]/g,"")).find('#cpf_confirm_line_Btn').removeClass("cp_hidden");

								  var itemReceivedQty = $("#" + vPartNumber.replace(/[/]/g,"")).find("#cpf_entered_qty").val();
								  itemReceivedQty = parseInt(itemReceivedQty);
								  if(isNaN(itemReceivedQty)){
									itemReceivedQty = 0;
								  }
								 itemReceivedQty = itemReceivedQty + 1;
								 $("#" + vPartNumber.replace(/[/]/g,"")).find("#cpf_entered_qty").val(itemReceivedQty);
					     };

							 if(partsCatalogJSON["partsCatalog_"+vPartNumber]){
								exactMatchFoundPartsCatalog = true;
								$.processVirtualInvList(vPartNumber,partsCatalogJSON["partsCatalog_"+vPartNumber].I_ITEM_DESCRIPTION,partsCatalogJSON["partsCatalog_"+vPartNumber].I_ITEM_DISPOSITION,partsCatalogJSON["partsCatalog_"+vPartNumber].I_PRICE, partsCatalogJSON["partsCatalog_"+vPartNumber].I_ITEM_COST,partsCatalogJSON["partsCatalog_"+vPartNumber].I_RETURN_VENDOR);
							}
							if(exactMatchFoundPartsCatalog){

							}else{
						 	$.processVirtualInvList(vPartNumber,"","","","","");
							}


                        } else {
                            // Do nothing
							return false;
                        }
                    } else {

                        // item Number already found in part so increase the qty.

                        var itemReceivedQty = $("#" + vPartNumber.replace(/[/]/g,"")).find("#cpf_entered_qty").val();
						  itemReceivedQty = parseInt(itemReceivedQty);
							  if(isNaN(itemReceivedQty)){
								itemReceivedQty = 0;
							  }
                             itemReceivedQty = itemReceivedQty + 1;
                        $("#" + vPartNumber.replace(/[/]/g,"")).find("#cpf_entered_qty").val(itemReceivedQty);

						$(".inventory_lifecycle-grid-row-"+vPartNumber.replace(/[/]/g,"")).find('#cpf_exception').removeClass("cp_hidden");
						$(".inventory_lifecycle-grid-row-"+vPartNumber.replace(/[/]/g,"")).find('#cpf_confirm_line_Btn').removeClass("cp_hidden");
                    }


				  };





                }//vpartNumber not empty if close
            }); // Add button close.




            $('#submitAllLinesBtn').click(function() {


                var inventoryListJSONData = {}; // inventoryListJSONData contains json of each inventory item.
                var actionsArr = [];
                var itemNumberCarStockList = {};
                var itemNumberProviderSubInvList = {};
				var proceedwithRest = true;
				var zeroQtyPresent = false;
				// Added for CHG0075456 - Bin Locations for Field Service
				var activityBinManagement = "";
				
				//Loop for entered qty >0  Validation:
				   $.each(receivedPartsListArr, function(ky, itemNo){
					   var recQty=0;
					 //  '+invItem.I_ITEM_NUMBER+'
					     $('.inventory_lifecycle-grid-row-' + itemNo.replace(/[/]/g,"")).each(function() {
                                //receieved qty
                                recQty = $(this).find("#cpf_entered_qty").val();
						 });

						 if(recQty == ""){

							 proceedwithRest = false;
							 //return false;

						 }

						 if(recQty == 0){

							 zeroQtyPresent = true;
							 //return false;

						 }


					});

					if(!proceedwithRest)
					{
						alert("Fill quantities in Total column for all parts in the document");
						return false;
					}
					if(zeroQtyPresent){
						//changes start for INC1582974/CHG0060233
						var k=false; 
						//alert (A few items have quantity values entered as 0.Please Note); commented for INC1582974
						k=confirm("A few items have quantity values entered as 0. Please validate.Press OK to submit or Cancel to update the entries.");
						if (k== false){
						   return false;
						
						}
						
						//changes end for INC1582974/CHG0060233
						
					}
					if(isExceptionEntered){
				            	alert("A few items has exception values entered. Please note.");

					}

                //Loop through and take the car stock items.
                $.each(inventoryList, function(key, invItem) {

                    //take the provider, subinventory - car stock item as well.
                    if (invItem.invpool == "provider" && invItem.invtype == "CAR_STOCK") {

                        var carstockItemNum = invItem.I_ITEM_NUMBER;
                        $.extend(itemNumberCarStockList, {
                            [carstockItemNum]: {
                                I_ITEM_NUMBER: carstockItemNum,
                                I_ITEM_DESCRIPTION: invItem.I_ITEM_DESCRIPTION,
                                I_ITEM_DISPOSITION: invItem.I_ITEM_DISPOSITION,         //CHG0083744
                                I_ITEM_PRICE: invItem.I_PRICE,
                                I_SUBINVENTORY_NAME: invItem.I_SUBINVENTORY_NAME,
                                I_SUBINVENTORY: invItem.I_SUBINVENTORY,
                                inv_aid: invItem.inv_aid,
                                invtype: invItem.invtype,
                                invpool: invItem.invpool,
                                invid: invItem.invid,
                                inv_pid: invItem.inv_pid,
                                quantity: invItem.quantity,
								I_PRICE: invItem.I_PRICE,
								I_ITEM_PRICE: invItem.I_ITEM_PRICE,
								I_ITEM_COST: invItem.I_ITEM_COST,
								I_RETURN_VENDOR : invItem.I_RETURN_VENDOR
                            }
                        });
                    }

                    //take the provider, SUBINVENTORY, subinventory - car stock item as well.
                    if (invItem.invpool == "provider" && invItem.invtype == "SUBINVENTORY"){

                        var providerSubInvItemNum = invItem.I_ITEM_NUMBER;
                        $.extend(itemNumberProviderSubInvList, {
                            [providerSubInvItemNum]: {
                                I_ITEM_NUMBER: providerSubInvItemNum,
                                I_ITEM_DESCRIPTION: invItem.I_ITEM_DESCRIPTION,
                                I_ITEM_DISPOSITION: invItem.I_ITEM_DISPOSITION,       //CHG0083744
                                I_ITEM_PRICE: invItem.I_PRICE,
                                I_SUBINVENTORY_NAME: invItem.I_SUBINVENTORY_NAME,
                                I_SUBINVENTORY: invItem.I_SUBINVENTORY,
                                inv_aid: invItem.inv_aid,
                                invtype: invItem.invtype,
                                invpool: invItem.invpool,
                                invid: invItem.invid,
                                inv_pid: invItem.inv_pid,
                                quantity: invItem.quantity,
								I_PRICE: invItem.I_PRICE,
								I_ITEM_PRICE: invItem.I_ITEM_PRICE,
								I_ITEM_COST: invItem.I_ITEM_COST,
								I_RETURN_VENDOR : invItem.I_RETURN_VENDOR
                            }
                        });
                    }
                });
               // console.log("itemNumberProviderSubInvList " + JSON.stringify(itemNumberProviderSubInvList));
             //   console.log("itemNumberCarStockList " + JSON.stringify(itemNumberCarStockList));
                $.each(inventoryList, function(key, invItem) {
                    if (invItem.inv_aid == activityId) {
                        if (invItem.invpool == "customer" && invItem.invtype == "EXPECTED") {

                            var itemNumber = invItem.I_ITEM_NUMBER;
                            var invID = invItem.invid;

                            var dynamicInvIDItemNumber = invID + "_" + itemNumber;

                            var icustExpectedSubInventory = invItem.I_SUBINVENTORY;

							var icustExpectedSubInventoryName = invItem.I_SUBINVENTORY_NAME;

                            // loop thru the items in the Received parts UI.


                            // get the received qty , so_qty, [I_SHIP_QUANTITY -- if order type is P]

                            var receivedQty = 0,
                                shippedQty = 0,
                                soQty = 0,
                                usedQty = 0,
                                damagedQty = 0,
                                goodQty = 0,
                                reasonCode = invItem.I_REASON_CODE;
                            var binManagementFlag = ""; // Added for CHG0075456 - Bin Locations for Field Service
                            $('div#' + dynamicInvIDItemNumber.replace(/[/]/g,"")).each(function() {
                            // Start added for CHG0075456 - Bin Locations for Field Service
                            	binManagementFlag = $('#bin_mgt_chk_'+dynamicInvIDItemNumber.replace(/[/]/g,"")).is(':checked')?"Y":"N";
                                
                            	if(binManagementFlag != invItem.I_BIN_MANAGEMENT){
                            		activityBinManagement += "<UpdateBinLocation>" +
									"<subinventory>"+invItem.I_SUBINVENTORY+"</subinventory>"+
									"<item>"+invItem.I_ITEM_NUMBER+"</item>"+
									"<quantity>"+(invItem.quantity == null ? 0 : invItem.quantity)+"</quantity>"+
									"<binmgt>"+binManagementFlag+"</binmgt>"+
									"<action>RI</action></UpdateBinLocation>";
                            	} // End added for CHG0075456 - Bin Locations for Field Service
                            	
                            	//rece
                                receivedQty = $(this).find('#cpf_quantity_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find("#cpf_entered_qty").val();

                                //packed qty
                                shippedQty = $(this).find('#cpf_shiped_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find("#cpf_shiped_entered_qty").val();

                               /* if (shippedQty == "") {
                                    shippedQty = null;
                                }*/

                                // so qty.
                                soQty = $(this).find("#iSoQty").text();


                                // get the used and damaged qty from here:
                                $('div#exception_grid_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).each(function() {

                                    usedQty = $(this).find('#cpf_used_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find("#cpf_used_entered_qty").val();
                                    damagedQty = $(this).find('#cpf_damaged_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find("#cpf_damaged_entered_qty").val();


                                });


                                //compute -  good qty,  I_REASON_CODE
                                goodQty = parseInt(receivedQty) - parseInt(usedQty) - parseInt(damagedQty);
                                //build the list.
                                // 1.	I_REASON_CODE :=IF(I_SO_QUANTITY>0,?Over ship?,??) 2.	I_REASON_CODE :=IF(I_SO_QUANTITY<0, IF(I_REASON_CODE IS NOT EMPTY,?Multiple?,?Under Ship?),I_REASON_CODE)
                                if (parseInt(soQty) > 0) {
                                    reasonCode = "Over ship";

                                } else {
                                    if (reasonCode != "" && reasonCode != null && typeof reasonCode != 'undefined') {
                                        reasonCode = "Multiple";
                                    } else {
                                        reasonCode = "Under Ship";
                                    }

                                }
                                //3.	I_REASON_CODE :=IF(I_ITEM_DAMAGED_QUANTITY>0, IF(I_REASON_CODE IS NOT EMPTY,?Multiple?,?Defective?),I_REASON_CODE )
                                if (damagedQty > 0) {
                                    if (reasonCode != "" && reasonCode != null && typeof reasonCode != 'undefined') {
                                        reasonCode = "Multiple";
                                    } else {
                                        reasonCode = "Defective";
                                    }

                                }
                                //4.	I_REASON_CODE :=IF(I_USED_QUANTITY>0, IF(I_REASON_CODE IS NOT EMPTY,?Multiple?,?Used?),I_REASON_CODE)
                                if (usedQty > 0) {
                                    if (reasonCode != "" && reasonCode != null && typeof reasonCode != 'undefined') {
                                        reasonCode = "Multiple";
                                    } else {
                                        reasonCode = "Used";
                                    }

                                }

                                //Update the existing Customer Expected item.
                                // Added for CHG0075456 - Bin Locations for Field Service
                                $.extend(inventoryListJSONData, {
                                    [invID]: {
                                        I_RECEIVED_QUANTITY: receivedQty+"",
                                        I_ITEM_DAMAGED_QUANTITY: damagedQty+"",
                                        I_USED_QUANTITY: usedQty+"",
                                        I_SHIP_QUANTITY: shippedQty+"",
                                        I_GOOD_QUANTITY: goodQty+"",
                                        I_SO_QUANTITY: soQty+"",
                                        I_REASON_CODE: reasonCode,
                                        I_BIN_MANAGEMENT: binManagementFlag
                                    }
                                });


							if(parseInt(receivedQty) > 0){

                                if (icustExpectedSubInventory == "CAR_STOCK") {
                                    // Update the provider expected carStock quantity if match found or else create a new item.
                                    if (itemNumberCarStockList[itemNumber]) {
                                        var carStockITEM = itemNumberCarStockList[itemNumber];

                                        //updateCarStockItem = true;
                                        var carStockInvID = carStockITEM.invid;
                                        //Defaulting the qunatity to 0 if it is not a number(NaN)
										if (carStockITEM.quantity === "" || carStockITEM.quantity === null || isNaN(carStockITEM.quantity))
										{
											carStockITEM.quantity=0;
										}
                                        var itemCarStockQty = carStockITEM.quantity;
                                        var iSubInventory = carStockITEM.I_SUBINVENTORY;
                                        if (iSubInventory == "CAR_STOCK") {
                                            var newCarstockQty = parseInt(itemCarStockQty) + parseInt(receivedQty); //  parseInt(totalEnteredQuantity);
                                            // Added for CHG0075456 - Bin Locations for Field Service
                                            $.extend(inventoryListJSONData, {
                                                [carStockInvID]: {
                                                    quantity: newCarstockQty+"",
                                                    I_BIN_MANAGEMENT: binManagementFlag
                                                }
                                            });
                                        }

                                    } else {
                     // Added for CHG0075456 - Bin Locations for Field Service
										 var invKey = resourceExtID+itemNumber+"CAR_STOCK";
                                        actionsArr.push({
                                            "action": "create",
                                            "invtype": "CAR_STOCK",
                                            "inv_pid": resourcePID,
                                            "quantity": receivedQty+"",
                                            "invpool": "provider",
                                            "entity": "inventory",
                                            "properties": {
                                                "I_ITEM_NUMBER": itemNumber,
												"I_ITEM_DESCRIPTION": invItem.I_ITEM_DESCRIPTION,
                                                "I_ITEM_DISPOSITION": invItem.I_ITEM_DISPOSITION,         //CHG0083744
                                                "I_SUBINVENTORY": "CAR_STOCK",
												"I_INVENTORY_KEY":invKey,
												"I_PRICE": invItem.I_PRICE,
												"I_ITEM_PRICE": invItem.I_ITEM_PRICE,
												"I_ITEM_COST": invItem.I_ITEM_COST,
												"I_RETURN_VENDOR": invItem.I_RETURN_VENDOR,
												"I_BIN_MANAGEMENT": binManagementFlag
												}
                                        });

                                    }
                                } else {
                                    // Search for Provider , SUBINVENTORY.

                                    // verify the iSubInventory - subInventoryListArr

                                    var iSubInvPosition = subInventoryListArr.indexOf(icustExpectedSubInventory);

                                    var externalSubInventoryOwnerId = subInventoryOwnerArr[iSubInvPosition];
									var invKey = '';

                                    if (resourceExtID == externalSubInventoryOwnerId) {

										// If external Id matches then it is a Owned SubInventory.
										invKey = resourceExtID+itemNumber+icustExpectedSubInventory;

                                    } else {

										// it is a mapped subinventory case:
										invKey = externalSubInventoryOwnerId+itemNumber+icustExpectedSubInventory;
                                    }

									 var providerSubInvID = "";
										var itemproviderSubInvQty = "";
										var iSubInventory ="";
										var providerSubInvITEM ='';
										var itemFoundinOwnedSubInv = false;

                                        if (itemNumberProviderSubInvList[itemNumber]) {
											 providerSubInvITEM = itemNumberProviderSubInvList[itemNumber];
											 providerSubInvID = providerSubInvITEM.invid;
                                        //Defaulting the qunatity to 0 if it is not a number(NaN)
											if (providerSubInvITEM.quantity === "" || providerSubInvITEM.quantity === null || isNaN(providerSubInvITEM.quantity))
										    {
											providerSubInvITEM.quantity=0;
									        }
                                             itemproviderSubInvQty = providerSubInvITEM.quantity;
                                             iSubInventory = providerSubInvITEM.I_SUBINVENTORY;

											if(iSubInventory == icustExpectedSubInventory ){
												itemFoundinOwnedSubInv = true;
											}

										}else{
											itemFoundinOwnedSubInv = false;
										}


                                       if(itemFoundinOwnedSubInv){

                                            var newproviderSubInvQty = parseInt(itemproviderSubInvQty) + parseInt(receivedQty); //  parseInt(totalEnteredQuantity);
                                            // Added for CHG0075456 - Bin Locations for Field Service
                                            $.extend(inventoryListJSONData, {
                                                [providerSubInvID]: {
                                                    quantity: newproviderSubInvQty+"",
                                                    I_BIN_MANAGEMENT: binManagementFlag
                                                }
                                            });
                                          //  console.log("itemNumberProviderSubInvList " + JSON.stringify(itemNumberProviderSubInvList));
                                        }else{
                            // Added for CHG0075456 - Bin Locations for Field Service
											     actionsArr.push({
														"action": "create",
														"invtype": "SUBINVENTORY",
														"quantity": receivedQty+"",
														"inv_pid": resourcePID,
														"invpool": "provider",
														"entity": "inventory",
														"properties": {
															"I_ITEM_NUMBER": itemNumber,
															"I_ITEM_DESCRIPTION": invItem.I_ITEM_DESCRIPTION,
                                                            "I_ITEM_DISPOSITION": invItem.I_ITEM_DISPOSITION,         //CHG0083744
															"I_SUBINVENTORY": icustExpectedSubInventory,
															"I_SUBINVENTORY_NAME": icustExpectedSubInventoryName,
															"I_INVENTORY_KEY":invKey,
															"I_PRICE": invItem.I_PRICE,
															"I_ITEM_PRICE": invItem.I_ITEM_PRICE,
															"I_ITEM_COST": invItem.I_ITEM_COST,
															"I_RETURN_VENDOR": invItem.I_RETURN_VENDOR,
															"I_BIN_MANAGEMENT": binManagementFlag
														}
													});
										}



                                }

							}// close if for receivedQty > 0

                            });
                        }
                    }
                });

				//check and loop for any new items added.
				var proceedwithRest = true;
				 var createInventoriesArr = [];
				 /////////////////
				 // Added for CHG0075456 - Bin Locations for Field Service
				 if("" != activityBinManagement){
					 activityBinManagement = "<UpdateBinLocations>"+activityBinManagement+"</UpdateBinLocations>";
				 }

				  $.processCreateInventoryMethod = function(createInventoriesArr) {

                    var updateJsonToSend = {
						"apiVersion": 1,
						"method": "update",
						"wakeupNeeded": false,
						"actions": createInventoriesArr,
                    };

					
                    console.log("updateJsonToSend " + JSON.stringify(updateJsonToSend));
                    ultimateBind._sendPostMessageData(updateJsonToSend);       

                    $.processCloseMethodFnCallBck();      
                    

                };

				$.processCloseMethodFnCallBck = function() {

                    // close method.
                    // Start added for CHG0075456 - Bin Locations for Field Service
                    var closeJsonToSend = {
						"apiVersion": 1,
						"method": "close",
						"backScreen": "activity_list",
						"wakeupNeeded": false,
						"inventoryList": inventoryListJSONData,
						"actions": actionsArr,
						"activity": {
									"astatus": "complete",
									"A_STATUS": "CM",
									"aid": activityId,
									"A_BIN_MGT":activityBinManagement
									}
                    };

					if(dataItemsToProcess.indexOf('resourceInventories') !== -1){
						dataItemsToProcess.splice(dataItemsToProcess.indexOf('resourceInventories'), 1);
					}
					localStorage.storageDataItems = dataItemsToProcess;
                    console.log("closeJsonToSend " + JSON.stringify(closeJsonToSend));
                    ultimateBind._sendPostMessageData(closeJsonToSend);

                };
				 ////////////////
				 $.each(virtualInventoryList, function(key, invItem) {

					  var dynamicInvIDItemNumber = invItem.invid + "_" + invItem.I_ITEM_NUMBER;

					  var itemReceivedQty = $("#" + invItem.I_ITEM_NUMBER.replace(/[/]/g,"")).find("#cpf_entered_qty").val(); // modification done for CHG0059205 
					  //may have to get the damage and used qty and update to this item as well.
					  var invKey = resourceExtID+invItem.I_ITEM_NUMBER+"EXPECTED";
					  var usedQty = $('div#exception_grid_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find('#cpf_used_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find("#cpf_used_entered_qty").val();
                      var damagedQty = $('div#exception_grid_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find('#cpf_damaged_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find("#cpf_damaged_entered_qty").val();
					  
			// Begin Modification for INC1591517 - Receive Parts - SOA Issue
					  
					  if (usedQty != "" && usedQty == null && typeof usedQty == 'undefined')
					  {
					  	usedQty = "0";
					  }

					  if (damagedQty != "" && damagedQty == null && typeof damagedQty == 'undefined')
					  {
					  	damagedQty = "0";
					  }
					  
			// End Modification for INC1591517 - Receive Parts - SOA Issue
					  
					  //packed qty
					  // modification of "replace(/[/]/g,"")" done for CHG0059205
					  var shippedQty = $('#' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find('#cpf_shiped_' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find("#cpf_shiped_entered_qty").val();
					  var goodQty = parseInt(itemReceivedQty) - parseInt(usedQty) - parseInt(damagedQty);
					  if(isNaN(goodQty)){
						  goodQty = 0;
					  }
					  var soQty = $('#' + dynamicInvIDItemNumber.replace(/[/]/g,"")).find("#iSoQty").text();

					  if(parseInt(itemReceivedQty) > 0){

					    /*  actionsArr.push({
                                            "action": "create",
                                            "invtype": "CAR_STOCK",
                                            "quantity": itemReceivedQty+"",
                                            "inv_pid": resourcePID+'',
                                            "invpool": "provider",
                                            "entity": "inventory",
                                            "properties": {
                                                "I_ITEM_NUMBER": invItem.I_ITEM_NUMBER,
                                                "I_SUBINVENTORY": "CAR_STOCK",
												"I_INVENTORY_KEY":invKey,
												"I_PRICE": invItem.I_PRICE,
												"I_ITEM_PRICE": invItem.I_ITEM_PRICE,
												"I_ITEM_COST": invItem.I_ITEM_COST,
												"I_RETURN_VENDOR": invItem.I_RETURN_VENDOR,
												"I_RECEIVED_QUANTITY": itemReceivedQty+"",
												"I_ITEM_DAMAGED_QUANTITY": damagedQty+"",
												"I_USED_QUANTITY": usedQty+"",
												"I_SHIP_QUANTITY": shippedQty+"",
												"I_GOOD_QUANTITY": goodQty+"",
												"I_SO_QUANTITY": soQty+""
												 }
                                        });
										*/

										 createInventoriesArr.push({
														"invpool": "customer",
                                                        "action": "create",
														"invtype": "EXPECTED",
														"inv_aid": activityId,
														"entity": "inventory",
														"quantity":  parseInt(itemReceivedQty),
                                                        "properties":{
														"I_ITEM_NUMBER":  invItem.I_ITEM_NUMBER,
														"I_INVENTORY_KEY": invKey,
														"I_ITEM_DESCRIPTION": invItem.I_ITEM_DESCRIPTION,
                                                        "I_ITEM_DISPOSITION": invItem.I_ITEM_DISPOSITION,         //CHG0083744
														"I_PRICE": invItem.I_PRICE,
														"I_ITEM_PRICE": invItem.I_ITEM_PRICE,
														"I_ITEM_COST": invItem.I_ITEM_COST,
														"I_RETURN_VENDOR": invItem.I_RETURN_VENDOR,
														"I_RECEIVED_QUANTITY": itemReceivedQty+"",
														"I_ITEM_DAMAGED_QUANTITY": damagedQty+"",
														"I_USED_QUANTITY": usedQty+"",
														"I_SHIP_QUANTITY": shippedQty+"",
														"I_GOOD_QUANTITY": goodQty+"",
														"I_SO_QUANTITY": soQty+""
                                                        }

													});
					  }
					  if(parseInt(itemReceivedQty) == 0){
						if (confirm('Some of the manually added parts have quantity entered as 0.\n Manual addition items with 0 quantity will be skipped. \n Would you like to Continue?')) {
						 // ok pressed continue;
                        } else {
                            // Do nothing
							proceedwithRest = false;
							return false;
                        }
					  }

					  //////////////////////Check the item Number is present in CarStock list or sub Inventory list////////////////////////
					  var itemNumber =  invItem.I_ITEM_NUMBER;
					  var itemFoundInCarStock = false;
					  var itemFoundInSubInventoryList = false;
					  if(itemNumberCarStockList[itemNumber]){
					      itemFoundInCarStock = true;
					   }
					   if (itemNumberProviderSubInvList[itemNumber]) {
					       itemFoundInSubInventoryList = true;
					   }
					if(itemFoundInCarStock){
					 if (itemNumberCarStockList[itemNumber]) {
                                        var carStockITEM = itemNumberCarStockList[itemNumber];

                                        //updateCarStockItem = true;
                                        var carStockInvID = carStockITEM.invid;
                                        //Defaulting the qunatity to 0 if it is not a number(NaN)
										if (carStockITEM.quantity === "" || carStockITEM.quantity === null || isNaN(carStockITEM.quantity))
										{
											carStockITEM.quantity=0;
										}
                                        var itemCarStockQty = carStockITEM.quantity;
                                        var iSubInventory = carStockITEM.I_SUBINVENTORY;
                                        if (iSubInventory == "CAR_STOCK") {
                                           // var newCarstockQty = parseInt(itemCarStockQty) + parseInt(receivedQty); //  parseInt(totalEnteredQuantity); Commented for INC1591517
											var newCarstockQty = parseInt(itemCarStockQty) + parseInt(itemReceivedQty); //  Added for INC1591517
                                            $.extend(inventoryListJSONData, {
                                                [carStockInvID]: {
                                                    quantity: newCarstockQty+""
                                                }
                                            });
                                        }

                                    } else {
										 var invKey = resourceExtID+itemNumber+"CAR_STOCK";
                                        actionsArr.push({
                                            "action": "create",
                                            "invtype": "CAR_STOCK",
                                            "inv_pid": resourcePID,
                                            //"quantity": receivedQty+"",	// Commented for INC1591517
											"quantity": itemReceivedQty+"",	//  Added for INC1591517
                                            "invpool": "provider",
                                            "entity": "inventory",
                                            "properties": {
                                                "I_ITEM_NUMBER": itemNumber,
												"I_ITEM_DESCRIPTION": invItem.I_ITEM_DESCRIPTION,
                                                "I_ITEM_DISPOSITION": invItem.I_ITEM_DISPOSITION,             //CHG0083744
                                                "I_SUBINVENTORY": "CAR_STOCK",
												"I_INVENTORY_KEY":invKey,
												"I_PRICE": invItem.I_PRICE,
												"I_ITEM_PRICE": invItem.I_ITEM_PRICE,
												"I_ITEM_COST": invItem.I_ITEM_COST,
												"I_RETURN_VENDOR": invItem.I_RETURN_VENDOR
												}
                                        });

                                    }

                                }

								if(itemFoundInSubInventoryList){
									var icustExpectedSubInventory = "SUBINVENTORY";
								   var iSubInvPosition = subInventoryListArr.indexOf(icustExpectedSubInventory);

                                    var externalSubInventoryOwnerId = subInventoryOwnerArr[iSubInvPosition];
									var invKey = '';

                                    if (resourceExtID == externalSubInventoryOwnerId) {

										// If external Id matches then it is a Owned SubInventory.
										invKey = resourceExtID+itemNumber+icustExpectedSubInventory;

                                    } else {

										// it is a mapped subinventory case:
										invKey = externalSubInventoryOwnerId+itemNumber+icustExpectedSubInventory;
                                    }

									 var providerSubInvID = "";
										var itemproviderSubInvQty = "";
										var iSubInventory ="";
										var providerSubInvITEM ='';
										var itemFoundinOwnedSubInv = false;

                                        if (itemNumberProviderSubInvList[itemNumber]) {
											 providerSubInvITEM = itemNumberProviderSubInvList[itemNumber];
											 providerSubInvID = providerSubInvITEM.invid;
                                        //Defaulting the qunatity to 0 if it is not a number(NaN)
											 if (providerSubInvITEM.quantity === "" || providerSubInvITEM.quantity === null || isNaN(providerSubInvITEM.quantity))
										     {
											  providerSubInvITEM.quantity=0;
										     }
                                             itemproviderSubInvQty = providerSubInvITEM.quantity;
                                             iSubInventory = providerSubInvITEM.I_SUBINVENTORY;

											if(iSubInventory == icustExpectedSubInventory ){
												itemFoundinOwnedSubInv = true;
											}

										}else{
											itemFoundinOwnedSubInv = false;
										}


                                       if(itemFoundinOwnedSubInv){

                                           // var newproviderSubInvQty = parseInt(itemproviderSubInvQty) + parseInt(receivedQty); //  parseInt(totalEnteredQuantity); Commented for INC1591517
											var newproviderSubInvQty = parseInt(itemproviderSubInvQty) + parseInt(itemReceivedQty); //  Added for INC1591517
                                            $.extend(inventoryListJSONData, {
                                                [providerSubInvID]: {
                                                    quantity: newproviderSubInvQty+""
                                                }
                                            });
                                          //  console.log("itemNumberProviderSubInvList " + JSON.stringify(itemNumberProviderSubInvList));
                                        }else{
											     actionsArr.push({
														"action": "create",
														"invtype": "SUBINVENTORY",
														// "quantity": receivedQty+"",	// Commented for INC1591517
														"quantity": itemReceivedQty+"",	//  Added for INC1591517
														"inv_pid": resourcePID,
														"invpool": "provider",
														"entity": "inventory",
														"properties": {
															"I_ITEM_NUMBER": itemNumber,
															"I_ITEM_DESCRIPTION": invItem.I_ITEM_DESCRIPTION,
                                                            "I_ITEM_DISPOSITION": invItem.I_ITEM_DISPOSITION,             //CHG0083744
															//"I_SUBINVENTORY": icustExpectedSubInventory,
															//"I_SUBINVENTORY_NAME": icustExpectedSubInventoryName,
															"I_INVENTORY_KEY":invKey,
															"I_PRICE": invItem.I_PRICE,
															"I_ITEM_PRICE": invItem.I_ITEM_PRICE,
															"I_ITEM_COST": invItem.I_ITEM_COST,
															"I_RETURN_VENDOR": invItem.I_RETURN_VENDOR
														}
													});
										}

                               }
					  /////////////////////////////////////////////////////////////////////////////////////



				 });

				 if(!proceedwithRest){
					 return false;
				 }

                console.log("inventoryListJSONData " + JSON.stringify(inventoryListJSONData));
                console.log("actionsArr " + JSON.stringify(actionsArr));

				 if (createInventoriesArr && createInventoriesArr.length > 0) {
					$.processCreateInventoryMethod(createInventoriesArr);
				} else {
					$.processCloseMethodFnCallBck();
				}

              /*  var closeJsonToSend = {
                    "apiVersion": 1,
                    "method": "close",
                    "backScreen": "default",
                    "wakeupNeeded": false,
                    "inventoryList": inventoryListJSONData,
                    "actions": actionsArr
                };


				$.extend(closeJsonToSend, { "activity": {
														"astatus": "complete",
														"A_STATUS": "CM",
														"aid": activityId
													}
											});

				console.log("closeJsonToSend  " + JSON.stringify(closeJsonToSend));
				this._sendPostMessageData(closeJsonToSend);*/




            }.bind(this));

            this._clearWakeupData();
            if (localStorage.getItem('pluginInitData')) {
                this._log(window.location.host + ' OPEN. GET DATA FROM LOCAL STORAGE', JSON.stringify(JSON.parse(localStorage.getItem('pluginInitData')), null, 4));
                $('.json__local-storage').text(JSON.stringify(JSON.parse(localStorage.getItem('pluginInitData')), null, 4));
            }
            // this.initChangeOfWakeup(document);
            //this.initChangeOfDataItems();
            //this.initAddButtons(document);
        },

        /**
         * Business login on plugin wakeup (background open for sync)
         *
         * @param {Object} receivedData - JSON object that contain data from OFSC
         */
        pluginWakeup: function(receivedData) {
            this._log(window.location.host + ' WAKEUP', JSON.stringify(receivedData, null, 4));

            var wakeupData = {
                pluginWakeupCount: +localStorage.getItem('pluginWakeupCount'),
                pluginWakeupMaxCount: +localStorage.getItem('pluginWakeupMaxCount'),
                pluginWakeupDontRespondOn: +localStorage.getItem('pluginWakeupDontRespondOn')
            };

            wakeupData.pluginWakeupCount = wakeupData.pluginWakeupCount + 1;

            localStorage.setItem('pluginWakeupCount', wakeupData.pluginWakeupCount);
            localStorage.setItem('pluginWakeupMaxCount', wakeupData.pluginWakeupMaxCount);
            localStorage.setItem('pluginWakeupDontRespondOn', wakeupData.pluginWakeupDontRespondOn);

            this._log(window.location.host + ' SAVE WAKEUP DATA TO LOCAL STORAGE', JSON.stringify(wakeupData, null, 4));

            if (wakeupData.pluginWakeupDontRespondOn == wakeupData.pluginWakeupCount) {
                this._log(window.location.host + ' EMULATE NOT RESPONDING PLUGIN');

                return;
            }

            if (wakeupData.pluginWakeupCount < wakeupData.pluginWakeupMaxCount) {
                setTimeout(function() {
                    this._log(window.location.host + ' SLEEP. RETRY NEEDED');

                    this._sendPostMessageData({
                        apiVersion: 1,
                        method: 'sleep',
                        wakeupNeeded: true
                    });
                }.bind(this), 2000);
            } else {
                setTimeout(function() {
                    this._log(window.location.host + ' SLEEP. NO RETRY');

                    this._sendPostMessageData({
                        apiVersion: 1,
                        method: 'sleep',
                        wakeupNeeded: false
                    });
                }.bind(this), 12000);
            }
        },

        /**
         * Save configuration of wakeup (background open for sync) behavior for Plugin
         * to Local Storage
         *
         * @private
         */
        _saveWakeupData: function() {
            var wakeupData = {
                pluginWakeupCount: 0,
                pluginWakeupMaxCount: 0,
                pluginWakeupDontRespondOn: 0
            };

            if ($('#wakeup').is(':checked')) {
                wakeupData.pluginWakeupMaxCount = parseInt($('#repeat_count').val());

                if ($('#dont_respond').is(':checked')) {
                    wakeupData.pluginWakeupDontRespondOn = parseInt($('#dont_respond_on').val());
                }
            }

            localStorage.setItem('pluginWakeupCount', wakeupData.pluginWakeupCount);
            localStorage.setItem('pluginWakeupMaxCount', wakeupData.pluginWakeupMaxCount);
            localStorage.setItem('pluginWakeupDontRespondOn', wakeupData.pluginWakeupDontRespondOn);

            this._log(window.location.host + ' SAVE WAKEUP DATA TO LOCAL STORAGE', JSON.stringify(wakeupData, null, 4));
        },

        /**
         * Clear previous configuration of wakeup (background open for sync) behavior for Plugin
         * from the Local Storage
         *
         * @private
         */
        _clearWakeupData: function() {
            localStorage.removeItem('pluginWakeupCount');
            localStorage.removeItem('pluginWakeupMaxCount');
            localStorage.removeItem('pluginWakeupDontRespondOn');

            this._log(window.location.host + ' CLEAR WAKEUP DATA FROM LOCAL STORAGE');
        },

        initChangeOfWakeup: function(element) {

            function onWakeupChange(elem) {
                var isChecked = $(elem).is(':checked');

                if (isChecked) {
                    $(element).find('#repeat_count').prop('disabled', false);
                    $(element).find('#dont_respond').prop('disabled', false);

                    $(element).find('#wakeup_row').removeClass('wakeup-form-row--disabled');

                    onDontRespondChange($(element).find('#dont_respond'));
                } else {
                    $(element).find('#repeat_count').prop('disabled', true);
                    $(element).find('#dont_respond').prop('disabled', true);
                    $(element).find('#dont_respond_on').prop('disabled', true);

                    $(element).find('#wakeup_row').addClass('wakeup-form-row--disabled');
                    $(element).find('#dont_respond_row').addClass('wakeup-form-row--disabled');
                }
            }

            function onDontRespondChange(elem) {
                var isChecked = $(elem).is(':checked');

                if (isChecked) {
                    $(element).find('#dont_respond_on').prop('disabled', false);
                    $(element).find('#dont_respond_row').removeClass('wakeup-form-row--disabled');
                } else {
                    $(element).find('#dont_respond_on').prop('disabled', true);
                    $(element).find('#dont_respond_row').addClass('wakeup-form-row--disabled');
                }
            }

            $(element).find('#wakeup').change(function(e) {
                onWakeupChange(e.target);
            });

            $(element).find('#dont_respond').change(function(e) {
                onDontRespondChange(e.target);
            });

            onWakeupChange($(element).find('#wakeup'));
        },

        initChangeOfDataItems: function() {
            //set checkboxes from local storage
            if (localStorage.getItem('dataItems')) {
                $('.data-items').attr('checked', true);
                $('.data-items-holder').show();

                var dataItems = JSON.parse(localStorage.getItem('dataItems'));

                $('.data-items-holder input').each(function() {
                    if (dataItems.indexOf(this.value) != -1) {
                        $(this).attr('checked', true);
                    }
                });
            }

            //init handlers
            $('.data-items').on('change', function(e) {
                $('.data-items-holder').toggle();
            });
        },

        initLocalStorageOption: function(localStorageKey) {
            if (localStorage.getItem(localStorageKey) === null) {
                localStorage.setItem(localStorageKey, 'true');
            }
        },


        finishCallIdCallbacks: function (receivedJson) {
            let jsonObject = null;
                console.log("Call procedure:"+receivedJson);
                jsonObject = JSON.parse(receivedJson);
                console.log("Call Procedure JSONobject"+jsonObject);
        
                $.processSearchResultsFnCallBck(jsonObject);
        },



        /**
         * Initialization function
         */
		init: function() {
			if (navigator.serviceWorker) {
				this._log(window.location.host + ' Service Worker is supported');
				navigator.serviceWorker.register('receiveparts-service-worker.js').then(function(registration) {
					this._log(window.location.host + ' Service Worker is registered with scope: ' + registration.scope);
					registration.addEventListener('updatefound', function() {
						this._log(window.location.host + ' Service Worker update is found');
						var newServiceWorker = registration.installing;
						newServiceWorker.addEventListener('statechange', function() {
							switch (newServiceWorker.state) {
								case "installed":
									this._log(window.location.host + ' New Service Worker is installed');
									break;
							}
						}.bind(this));
					}.bind(this));
					navigator.serviceWorker.addEventListener('controllerchange', function() {
						this.notifyAboutNewVersion();
					}.bind(this));
					this.startApplication();
				}.bind(this), function(err) {
					this._log(window.location.host + ' Service Worker registration failed: ' + err);
					this.startApplication();
				}.bind(this));
				return;
			} else {
				this._log(window.location.host + ' Service Worker is not supported');
			}
			this.startApplication();
		},
		startApplication: function() {

			
		    var d = new Date();
            console.log('Time Started init:' + d);
            this._log(window.location.host + ' PLUGIN HAS BEEN STARTED');
            $('.back_method_select').on('change', function() {
                var selectValue = $('.back_method_select').val();
                if (
                    selectValue == 'activity_by_id' ||
                    selectValue == 'end_activity' ||
                    selectValue == 'cancel_activity' ||
                    selectValue == 'notdone_activity' ||
                    selectValue == 'start_activity' ||
                    selectValue == 'suspend_activity' ||
                    selectValue == 'delay_activity'
                ) {
                    $('.back_activity_id').show();
                } else {
                    $('.back_activity_id').val('').hide();
                }
            });

            $('.json_local_storage_toggle').on('click', function() {
                $('.json__local-storage').toggle();
            });

            $('.json_request_toggle').on('click', function() {
                $('.column-item--request').toggle();
            });

            $('.json_response_toggle').on('click', function() {
                $('.column-item--response').toggle();
            }.bind(this));
            window.addEventListener("message", this._getPostMessageData.bind(this), false);

            

            this.initLocalStorageOption('showHeader');
            this.initLocalStorageOption('backNavigationFlag');

            var jsonToSend = {
                apiVersion: 1,
                method: 'ready',
                sendInitData: true,
                showHeader: !!localStorage.getItem('showHeader'),
                enableBackButton: !!localStorage.getItem('backNavigationFlag')
            };

            //parse data items
            //var dataItems = JSON.parse(localStorage.getItem('dataItems'));
			var dataItems = ['resource','customerInventories','resourceInventories'];


            if (dataItems) {
                $.extend(jsonToSend, {
                    dataItems: dataItems
                });
            }
			this._sendPostMessageData(jsonToSend);
		},
		notifyAboutNewVersion: function() {
			this._log(window.location.host + ' New Service Worker is activated. Page refresh is needed');
			var footer = document.querySelector('.footer');
			var versionNotificationElement = document.createElement('div');
			versionNotificationElement.className = 'new-version-notification';
			versionNotificationElement.innerHTML = 'New version is detected. Please reopen the page';
			footer.appendChild(versionNotificationElement);
		}		
    });
	window.OfscPlugin.getVersion = function() {
		return resourcesVersion;
	};
})(jQuery);
