"use strict";

(function ($) {
    window.OfscPlugin = function (debugMode) {
        this.debugMode = debugMode || false;
    };

    var activityLog = '';
    var pluginName = 'PI-PhysicalInventory';

    $.extend(window.OfscPlugin.prototype, {
        /**
         * Dictionary of enums
         */
        dictionary: {
            astatus: {
                pending: {
                    label: 'pending',
                    translation: 'Pending',
                    outs: ['started', 'cancelled', 'suspended'],
                    color: '#FFDE00'
                },
                started: {
                    label: 'started',
                    translation: 'Started',
                    outs: ['complete', 'suspended', 'notdone', 'cancelled'],
                    color: '#A2DE61'
                },
                complete: {
                    label: 'complete',
                    translation: 'Completed',
                    outs: [],
                    color: '#79B6EB'
                },
                suspended: {
                    label: 'suspended',
                    translation: 'Suspended',
                    outs: [],
                    color: '#9FF'
                },
                notdone: {
                    label: 'notdone',
                    translation: 'Not done',
                    outs: [],
                    color: '#60CECE'
                },
                cancelled: {
                    label: 'cancelled',
                    translation: 'Cancelled',
                    outs: [],
                    color: '#80FF80'
                }
            },
            invpool: {
                customer: {
                    label: 'customer',
                    translation: 'Customer',
                    outs: ['deinstall'],
                    color: '#04D330'
                },
                install: {
                    label: 'install',
                    translation: 'Installed',
                    outs: ['provider'],
                    color: '#00A6F0'
                },
                deinstall: {
                    label: 'deinstall',
                    translation: 'Deinstalled',
                    outs: ['customer'],
                    color: '#00F8E8'
                },
                provider: {
                    label: 'provider',
                    translation: 'Resource',
                    outs: ['install'],
                    color: '#FFE43B'
                }
            }
        },

        mandatoryActionProperties: {},

        /**
         * Which field shouldn't be editable
         *
         * format:
         *
         * parent: {
         *     key: true|false
         * }
         *
         */
        renderReadOnlyFieldsByParent: {
            data: {
                apiVersion: true,
                method: true,
                entity: true
            },
            resource: {
                pid: true,
                pname: true,
                gender: true
            }
        },

        /**
         * Check for string is valid JSON
         *
         * @param {*} str - String that should be validated
         *
         * @returns {boolean}
         *
         * @private
         */
        _isJson: function (str) {
            try {
                JSON.parse(str);
            }
            catch (e) {
                return false;
            }
            return true;
        },

        /**
         * Return origin of URL (protocol + domain)
         *
         * @param {String} url
         *
         * @returns {String}
         *
         * @private
         */
        _getOrigin: function (url) {
            if (url != '') {
                if (url.indexOf("://") > -1) {
                    return 'https://' + url.split('/')[2];
                } else {
                    return 'https://' + url.split('/')[0];
                }
            }

            return '';
        },

        /**
         * Return domain of URL
         *
         * @param {String} url
         *
         * @returns {String}
         *
         * @private
         */
        _getDomain: function (url) {
            if (url != '') {
                if (url.indexOf("://") > -1) {
                    return url.split('/')[2];
                } else {
                    return url.split('/')[0];
                }
            }

            return '';
        },

        _getDomainURL: function () {
            return document.referrer.match(/\:\/\/([^\/]+)\.(?:etadirect.com|fs.ocs.oraclecloud.com)/)[1];
        },

        /**
         * Sends postMessage to document.referrer
         *
         * @param {Object} data - Data that will be sent
         *
         * @private
         */
        _sendPostMessageData: function (data) {
            var originUrl = document.referrer || (document.location.ancestorOrigins && document.location.ancestorOrigins[0]) || '';

            if (originUrl) {
                this._log(window.location.host + ' -> ' + data.method + ' ' + this._getDomain(originUrl), JSON.stringify(data, null, 4));

                parent.postMessage(data, this._getOrigin(originUrl));
            } else {
                this._log(window.location.host + ' -> ' + data.method + ' ERROR. UNABLE TO GET REFERRER');
            }
        },

        /**
         * Handles during receiving postMessage
         *
         * @param {MessageEvent} event - Javascript event
         *
         * @private
         */
        _getPostMessageData: function (event) {

            if (typeof event.data === 'undefined') {
                this._log(window.location.host + ' <- NO DATA ' + this._getDomain(event.origin), null, null, true);

                return false;
            }

            if (!this._isJson(event.data)) {
                this._log(window.location.host + ' <- NOT JSON ' + this._getDomain(event.origin), null, null, true);

                return false;
            }

            var data = JSON.parse(event.data);

            if (!data.method) {
                this._log(window.location.host + ' <- NO METHOD ' + this._getDomain(event.origin), null, null, true);

                return false;
            }

            this._log(window.location.host + ' <- ' + data.method + ' ' + this._getDomain(event.origin), JSON.stringify(data, null, 4));

            switch (data.method) {
                case 'init':
                    this.pluginInitEnd(data);
                    break;

                case 'open':
                    this.pluginOpen(data);
                    break;

                case 'wakeup':
                    this.pluginWakeup(data);
                    break;

                case 'error':
                    data.errors = data.errors || { error: 'Unknown error' };
                    this._showError(data.errors);
                    break;

                case 'callProcedureResult':
                    this.finishCallIdCallbacks(event.data);
                    break;

                default:
                    this._log(window.location.host + ' <- UNKNOWN METHOD: ' + data.method + ' ' + this._getDomain(event.origin), null, null, true);
                    break;
            }
        },

        /**
         * Show alert with error
         *
         * @param {Object} errorData - Object with errors
         *
         * @private
         */
        _showError: function (errorData) {
            alert(JSON.stringify(errorData, null, 4));
        },

        /**
         * Logs to console
         *
         * @param {String} title - Message that will be log
         * @param {String} [data] - Formatted data that will be collapsed
         * @param {String} [color] - Color in Hex format
         * @param {Boolean} [warning] - Is it warning message?
         *
         * @private
         */
        _log: function (title, data, color, warning) {
            if (!this.debugMode) {
                return;
            }
            if (!color) {
                color = '#0066FF';
            }
            if (!!data) {
                console.groupCollapsed('%c[Plugin API] ' + title, 'color: ' + color + '; ' + (!!warning ? 'font-weight: bold;' : 'font-weight: normal;'));
                console.log('[Plugin API] ' + data);
                console.groupEnd();
            } else {
                console.log('%c[Plugin API] ' + title, 'color: ' + color + '; ' + (!!warning ? 'font-weight: bold;' : ''));
            }
        },

        /**
         * Business login on plugin init
         */
        saveToLocalStorage: function (data) {
            this._log(window.location.host + ' INIT. SET DATA TO LOCAL STORAGE', JSON.stringify(data, null, 4));

            if (data.attributeDescription) {
                localStorage.setItem('pluginInitData', JSON.stringify(data.attributeDescription));
            }
        },

        /**
         * Business login on plugin init end
         *
         * @param {Object} data - JSON object that contain data from OFSC
         */
        pluginInitEnd: function (data) {
            this.saveToLocalStorage(data);

            var messageData = {
                apiVersion: 1,
                method: 'initEnd'
            };

            if (localStorage.getItem('pluginWakeupCount') < localStorage.getItem('pluginWakeupMaxCount')) {
                this._log(window.location.host + ' UNFINISHED WAKEUP DATA FOUND IN LOCAL STORAGE');

                messageData.wakeupNeeded = true;
            }

            this._sendPostMessageData(messageData);
        },

        /**
         * Business login on plugin open
         *
         * @param {Object} receivedData - JSON object that contain data from OFSC
         */
        pluginOpen: function (receivedData) {
            //changes start for MPF Phase 5
            var domainName = this._getDomainURL();
            var activityId = receivedData.activity.aid;
            var errorLogs = receivedData.activity.A_PLUGIN_ERROR_LOG;
            var parser = new DOMParser();
            
           // Modified for INC2343370  - Added for CHG0075456 - Bin Locations for Field Service
               
                var values = [];

            var headers = {
                'Authorization':
                    'Basic ' + btoa(receivedData.securedData.clientId + "@" + domainName + ":" + receivedData.securedData.clientSecret)
            };

            $.ErrorUpdate = function (activityId, sErrorLogs) {

                this._sendPostMessageData({
                    "apiVersion": 1,
                    "method": "update",
                    "activity": {
                        "A_PLUGIN_ERROR_LOG": sErrorLogs,
                        "aid": activityId
                    }

                });
            }.bind(this);


            var timeZoneName = receivedData.resource.time_zone;
            //var ofscDate = decodeURIComponent($.urlParam('date'));
            var TimeZoneMapping = {
                "19": "Alaska",
                "6": "Arizona",
                "4": "Central",
                "2": "Eastern",
                "15": "GMT",
                "17": "Hawaii (Adak)",
                "18": "Hawaii (Honolulu)",
                "5": "Mountain",
                "7": "Pacific"
            };


            var timeOffset = {
                'Alaska': 9,
                'dAlaska': 8,
                'Arizona': 7,
                'dArizona': 7,
                'Central': 6,
                'dCentral': 5,
                'Eastern': 5,
                'dEastern': 4,
                'GMT': 0,
                'dGMT': 0,
                'Hawaii(Adak)': 10,
                'dHawaii(Adak)': 10,
                'Hawaii(Honolulu)': 10,
                'dHawaii(Honolulu)': 10,
                'Mountain': 7,
                'dMountain': 6,
                'Pacific': 8,
                'dPacific': 7
            }

            var timeZone = TimeZoneMapping[timeZoneName];

            Date.prototype.stdTimezoneOffset = function () {
                var jan = new Date(this.getFullYear(), 0, 1);
                var jul = new Date(this.getFullYear(), 6, 1);
                return Math.max(jan.getTimezoneOffset(), jul.getTimezoneOffset());
            }

            Date.prototype.dst = function () {
                return this.getTimezoneOffset() < this.stdTimezoneOffset();
            }

            var today = new Date();
            if (today.dst()) {
                var timeZoneId = timeOffset['d' + timeZone.replace(' ', '')];
            } else {
                var timeZoneId = timeOffset[timeZone.replace(' ', '')];
            }

            var indainDateObj = new Date();
            indainDateObj.setHours(indainDateObj.getHours() - timeZoneId);
            var dispatchTime = indainDateObj.toISOString();

            var todayDate = dispatchTime.substring(0, 10);

            // changes end for MPF phase 5
            //global variables          
            var receivedDataJson = receivedData;
            var inventorycollection = receivedData.inventoryList;
            var g_activityId = receivedDataJson.activity.aid.toString();	// Added .toString to convert to text for PI Variance issue
            var activitytype = receivedDataJson.activity.A_PHYSICAL_INVENTORY_STAGE;
            var g_externalid = receivedDataJson.resource.external_id;
            var g_pid = receivedDataJson.resource.pid;
            var g_subinventory = receivedDataJson.activity.A_SUBINVENTORY;
            var g_subinventoryname = receivedDataJson.activity.A_SUBINVENTORY_NAME;
            var g_partscategory_collection = [];
            var g_selectedcategorytotalcount = 0;
            //pagination
            var g_page_count = 0;
            var PER_PAGE_COUNT = 10;
            var sub_inventoryname_collection = [];
            var currentselectedinventory = null;
            var unique_inventory_names = [];
            
           


            //Added A_ACTIVITY_LOG for log messages             
            if (receivedData.activity.A_ACTIVITY_LOG != null) {
                activityLog = receivedData.activity.A_ACTIVITY_LOG;
            }
            var submit_json = { apiVersion: 1, method: "close", backScreen: "default", inventoryList: {}, wakeupNeeded: false, activity: { A_PHYSICAL_INVENTORY_STAGE: 'Done', A_SE_TOTAL: "1", A_TOTAL: "1", aid: g_activityId, A_PI_ACTIVITY_MSG: "PI Initial Message : 0", A_ACTIVITY_LOG: activityLog } };
            activityLog = '';
            //Add part variables

            var addpartaction = {
                action: 'create', inv_aid: g_activityId, invtype: '',
                quantity: '', invpool: 'customer', entity: 'inventory',
                properties: {
                    I_ITEM_NUMBER: '', I_SUBINVENTORY: '', I_DEFECTIVE: '', I_INVENTORY_KEY: '', I_USED_QUANTITY: 1,
                    I_ITEM_COST: '', I_PRICE: '', I_ITEM_DESCRIPTION: '', I_SUBINVENTORY_NAME: '', I_RETURN_VENDOR: ''
                }
            };

            var listOfItemsAddedFromPartsCatalog = [];
            var isDefectiveSelected = false;

            var recountconst = 'Recount';
            //handle submit button variables
            var submitdetailtemplate = { category: '', issubmitenable: false };
            var percategory_submit_condition = []; //enable button by default
            var selectedValue;


            //method defenitions -s
            $.createElement = function (name, value) {
                var temp = document.createElementNS(name, name);
                if (value !== undefined) {
                    temp.innerHTML = value;
                }
                return temp;
            };
            $.updateActivityBinMgtFromLocalStorage= function(){
                let activityBinLocalStorage = "activityBinManagement-" + g_externalid;
                let temp = JSON.parse(localStorage.getItem(activityBinLocalStorage));
                activityBinManagement = $.createElement('UpdateBinLocations');   
                temp.forEach(a => {
                    var activityBinManagementElement = $.createElement('UpdateBinLocation');
                    activityBinManagementElement.append($.createElement('subinventory', a.subinventory));
                    activityBinManagementElement.append($.createElement('item', a.item));
                    activityBinManagementElement.append($.createElement('quantity', (a.qty == null || "" == a.qty ? 0 : temp.qty)));
                    activityBinManagementElement.append($.createElement('binmgt', a.binmgt));
                    activityBinManagementElement.append($.createElement('action', a.action));
                    try {
                        var tempActivityBinMgt = activityBinManagement.getElementsByTagName("UpdateBinLocations")[0];
                        tempActivityBinMgt.appendChild(activityBinManagementElement);
                    } catch (err) {
                        activityBinManagement.append(activityBinManagementElement);
                    }
                });
                console.log("activityBinManagment"+activityBinManagement);
            }

            let activityBinLocalStorage = "activityBinManagement-" + g_externalid;
             
            let data = localStorage.getItem(activityBinLocalStorage);
            if ( data == null || data.length==0){
                var activityBinManagement = (receivedData.activity.A_BIN_MGT != null && "" != receivedData.activity.A_BIN_MGT
                ? (parser.parseFromString(receivedData.activity.A_BIN_MGT, "text/xml")) : ""); 
            }
            else{
                $.updateActivityBinMgtFromLocalStorage();
            }



            $.updaterescourceBinMgtFromLocalStorage= function(){
                let resourceBinMgtUpdate = "resourceBinMgtUpdate-" + g_externalid;
                let temp = JSON.parse(localStorage.getItem(resourceBinMgtUpdate));  
                temp.forEach(a => {
                    $.extend(submit_json.inventoryList, { [a.invid]: { "I_BIN_MANAGEMENT": a.binManagementFlag } });
                });
                console.log("submit_json.inventoryList"+submit_json.inventoryList);
            }
            
            let resourceBinMgtUpdate = "resourceBinMgtUpdate-" + g_externalid;
             let resInv= localStorage.getItem(resourceBinMgtUpdate);
             if ( resInv == null || resInv.length==0){
                submit_json.inventoryList={};
              }
              else{
                $.updaterescourceBinMgtFromLocalStorage();
              }


            $.buildjsondata = function (receivedDataJson) {
                var inventorycollection = receivedDataJson.inventoryList;
                //add the A_SubInventory name as is
                var currentrecorditemname = g_subinventoryname;
                if (unique_inventory_names.indexOf(currentrecorditemname) < 0) {
                    unique_inventory_names.push(currentrecorditemname);
                    var submitdetail = JSON.parse(JSON.stringify(submitdetailtemplate));
                    submitdetail.category = currentrecorditemname;
                    percategory_submit_condition.push(submitdetail);
                }

                var currentrecorditemname = g_externalid + 'X'; // always external_id will be defective
                if (unique_inventory_names.indexOf(currentrecorditemname) < 0) {
                    unique_inventory_names.push(currentrecorditemname);
                    var submitdetail = JSON.parse(JSON.stringify(submitdetailtemplate));
                    submitdetail.category = currentrecorditemname;
                    percategory_submit_condition.push(submitdetail);
                }


                $.each(inventorycollection, function (key, invItem) {
                    var status = (activitytype == recountconst ? (invItem.I_RECOUNT == 'Y' || invItem.I_RECOUNT == 'T') : true);

                    if (g_activityId == invItem.inv_aid && invItem.invpool == "customer" && invItem.invtype == "PI" && status) {
                        if (invItem.I_SUBINVENTORY_NAME == null || invItem.I_SUBINVENTORY_NAME == '') {

                        }
                        else {
                            //identify unique I_SUBINVENTORY_NAME - 183404, 183404x
                            // Start added for CHG0075456 - Bin Locations for Field Service 	
                            var binNames = "";
                            if (invItem.I_PRIMARY_BIN_NAME != null) {
                                binNames += invItem.I_PRIMARY_BIN_NAME;
                            }
                            if (invItem.I_PRIMARY_BIN_QTY != null && "" != invItem.I_PRIMARY_BIN_QTY) {
                                binNames += '(' + invItem.I_PRIMARY_BIN_QTY + ')';
                            }
                            if ("" != binNames) {
                                binNames += ',';
                            }

                            if (invItem.I_SECONDARY_BIN_NAME != null) {
                                binNames += invItem.I_SECONDARY_BIN_NAME;
                            }
                            if (invItem.I_SECONDARY_BIN_QTY != null && "" != invItem.I_SECONDARY_BIN_QTY) {
                                binNames += '(' + invItem.I_SECONDARY_BIN_QTY + ')';
                            }
                            if ("" != binNames && !binNames.endsWith(",")) {
                                binNames += ',';
                            }

                            if (invItem.I_OUTOFBOX_BIN_NAME != null) {
                                binNames += invItem.I_OUTOFBOX_BIN_NAME;
                            }
                            if (invItem.I_OUTOFBOX_BIN_QTY != null && "" != invItem.I_OUTOFBOX_BIN_QTY) {
                                binNames += '(' + invItem.I_OUTOFBOX_BIN_QTY + ')';
                            }
                            if (binNames.endsWith(",")) {
                                binNames = binNames.substring(0, binNames.length - 1);
                            }
                            if ("" != binNames) {
                                binNames = '<div style="word-break:break-all;width:85%;">Bin mgt - ' + binNames + '</div>';
                            }

                            var currentrecorditemname = invItem.I_SUBINVENTORY_NAME;
                            var inventoryitem = {
                                subinventoryname: currentrecorditemname,
                                invid: invItem.invid, partnumber: invItem.I_ITEM_NUMBER,
                                description: invItem.I_ITEM_DESCRIPTION,
                                quantity: (activitytype == recountconst ? $.ParseIntegerSafely(invItem.I_EXPECT_QUANTITY) : $.ParseIntegerSafely(invItem.I_USED_QUANTITY)),
                                isaddedbypartcategory: false,
                                externalitem: null,
                                primaryBinName: invItem.I_PRIMARY_BIN_NAME,
                                binNames: binNames,
                                I_BIN_MANAGEMENT: invItem.I_BIN_MANAGEMENT
                            }; // End added for CHG0075456 - Bin Locations for Field Service
                            sub_inventoryname_collection.push(inventoryitem);
                        }
                    }
                });
                console.log("inventory object collection" + JSON.stringify(sub_inventoryname_collection));
            }
            $.ParseIntegerSafely = function (number, defaultvalue) {
                if (!defaultvalue)
                    defaultvalue = 0;

                return isNaN(parseInt(number, 10)) ? defaultvalue : parseInt(number, 10);
            }
            $.UpdateSelectedJsonData = function (inventorynumber, collection, value) {
                collection.forEach(function (indItem) {
                    if (indItem.invid == inventorynumber) {
                        indItem.quantity = value;
                        indItem.isupdated = true;
                        console.log("Update inventory :- indItem.invid : " + indItem.invid + " , indItem.partnumber : " + indItem.partnumber);
                    }

                });

            }
            // Start added for CHG0075456 - Bin Locations for Field Service
            $.UpdateBinMgtJsonData = function (inventorynumber, collection, value) {
                collection.forEach(function (indItem) {
                    if (indItem.invid == inventorynumber) {
                        indItem.I_BIN_MANAGEMENT = value;
                    }
                });
            } // End added for CHG0075456 - Bin Locations for Field Service

            $.BuildAddPartInventoryUI = function (elementcollection) {
                $.AppendGridElementsFromCollection(elementcollection);
            }
            $.AppendGridElementsFromCollection = function (elementcollection) {

                try {
                    $.each(elementcollection, function (key, indItem) {
                        var bindDynamicVar = this;

                        $("#cpf_dynamic_grid_elements").append(
                            '<div id="cpf_4-9" class="pi-grid-row">\
	                            <div class="pi-right-cell cpf_4-0">\
	                            <input id="cpf_add_item_'+ indItem.ITEM_NUMBER + '" type="button" class="cp_plugin_button button cp_plugin_button button submit" value="Add"> </div>\
	                            <div class="pi-left-cell cpf_4-1">\
	                            <div class="pi-part-number col2 cpf_4-1-0"><strong>' + indItem.ITEM_NUMBER + '</strong></div>\
	                            <div class="pi-description col2 cpf_4-1-1"><span>' + indItem.ITEM_DESCRIPTION + '</span></div>\
	                            </div>\
	                            </div>');

                        //wire up the add button click
                        $('#cpf_add_item_' + indItem.ITEM_NUMBER).on('click', function (e) {
                            //disable add button

                            $(this).attr('disabled', true);

                            var Item_Number = bindDynamicVar.ITEM_NUMBER;
                            var ITEM_DESCRIPTION = bindDynamicVar.ITEM_DESCRIPTION;
                            var partcatelogitem = {
                                itemnumber: bindDynamicVar.ITEM_NUMBER,
                                cost: bindDynamicVar.ITEM_COST,
                                price: bindDynamicVar.ITEM_PRICE,
                                description: bindDynamicVar.ITEM_DESCRIPTION,
                                vendor: bindDynamicVar.VENDOR
                            };

                            listOfItemsAddedFromPartsCatalog.push(partcatelogitem);
                        });
                    });
                }
                catch (err) {
                    activityLog = activityLog + ';Exception in AppendGridElementsFromCollection:' + err.message;
                    console.log(" Exception in AppendGridElementsFromCollection :" + err.message);
                }
            }

            $.generateCallId = function () {
                return btoa(String.fromCharCode.apply(null, window.crypto.getRandomValues(new Uint8Array(16))));
            },

                $.getPartsCatalog = function (searchKeywordOrig) {
                    //clear dynamic elements collection
                    listOfItemsAddedFromPartsCatalog = [];
                    $("#cpf_dynamic_grid_elements").empty();

                    //Parts Catalog Call started
                    console.log("Parts Catalog call started");
                    try {
                        //CHG0075659 - MPF Phase5 - Using call Procedure plugin API for Search Items (Offline Parts Catalog)
                        var uniquecallid = $.generateCallId();
                        var jsonSearchToSend = {
                            "apiVersion": 1,
                            "method": "callProcedure",
                            "callId": uniquecallid,
                            "procedure": "searchParts",
                            "params": {
                                "limit": 100,
                                "query": searchKeywordOrig,
                                "cacheOnly": false
                            }
                        }
                        console.log("Sending to browser tab" + jsonSearchToSend);
                        this._sendPostMessageData(jsonSearchToSend);
                    }
                    catch (err) {
                        var now = new Date(Date.now());
                        if (errorLogs == null) {
                            errorLogs = "";
                        }
                        errorLogs = errorLogs + "||" + now.toString() + "|Plugin :Enroute - Error Details:" + err.message;
                        console.log(errorLogs);

                        $.ErrorUpdate(activityId, errorLogs);
                    }


                    //CHG0075659 - MPF Phase5 -  Commenting  Search Items rest API call 
                    // var partsCatalogRestServiceURL = serverURL + "/PartsCatalog/rest/parts/search/items";
                    // console.log("REST -partsCatalogRestServiceURL "+partsCatalogRestServiceURL);
                    // var partsCatalogPayload = {"searchKeyword": searchKeywordOrig};

                    // console.log(" partsCatalogPayload "+JSON.stringify(partsCatalogPayload));

                    //    $.ajax({
                    //        dataType: "json",
                    //        url: partsCatalogRestServiceURL,
                    // 		data: JSON.stringify(partsCatalogPayload),
                    // 		processData: false,
                    // 		contentType: 'application/json; charset=utf-8',
                    // 		method: "POST",
                    // 		timeout:15000,
                    //        success: function(partsCatalogResponseData) {
                    //            console.log("Parts Catalog webservice response:" + JSON.stringify(partsCatalogResponseData));
                    //            $.processSearchResultsFnCallBck(partsCatalogResponseData);

                    //        }.bind(this),
                    //        error: function(errorData) {
                    //            console.log("Parts Catalog webservice error:" +  JSON.stringify(errorData));
                    //             var partsCatalogResponseData = {"element": [],"status":""};
                    // 		    //var partsCatalogResponseData = {"time before sending the request:":1518071999108,"time after getting the response:":1518072003047,"status":200,"element":[{"Item_Cost":"4.26","Item_Description":"[XREF TO AA140916] PIN PIN","Item_Disposition":"NA","Item_Number":"10R0300","Item_Price":"12.7","Item_Type":"NA","Linked_Count":"2","Top_Item":"AA140916","Vendor":"PARTS"},{"Item_Cost":"4.26","Item_Description":"[XREF TO AA140916] PIN PIN","Item_Disposition":"NA","Item_Number":"10R0300","Item_Price":"12.7","Item_Type":"NA","Linked_Count":"2","Top_Item":"AA140916","Vendor":"PARTS"},{"Item_Cost":"4.26","Item_Description":"[XREF TO AA140916] PIN PIN","Item_Disposition":"NA","Item_Number":"10R0300","Item_Price":"12.7","Item_Type":"NA","Linked_Count":"2","Top_Item":"AA140916","Vendor":"PARTS"},{"Item_Cost":"0","Item_Description":"[XREF TO HAZ250017] POWER SUPPLY","Item_Disposition":"NA","Item_Number":"CSP10R0315","Item_Price":"245","Item_Type":"NA","Linked_Count":"4","Top_Item":"HAZ250017","Vendor":"PARTS"}]};
                    //             $.processSearchResultsFnCallBck(partsCatalogResponseData);
                    //        }

                    //         });
                }.bind(this);

            $.PrepareUniqueParts = function (searchresultitems) {
                // debugger;
                var uniqueSearchKeyResults = [];
                var uniqueSearchValueResults = [];
                try {
                    searchresultitems.forEach(function (indItem) {
                        var itemIndex = uniqueSearchKeyResults.findIndex(function (indKey) {
                            //debugger;
                            return indItem.ITEM_NUMBER == indKey;
                        });
                        // debugger;
                        if (itemIndex == -1) {
                            uniqueSearchValueResults.push(indItem);
                            uniqueSearchKeyResults.push(indItem.ITEM_NUMBER);
                        }
                    });
                }
                catch (err) {
                    activityLog = activityLog + ';Exception in PrepareUniqueParts:' + err.message;
                    console.log(" Exception in PrepareUniqueParts :" + err.message);
                }
                return uniqueSearchValueResults;
            }
            $.processSearchResultsFnCallBck = function (responsedata) {
                try {
                    //hide loading
                    $("#cpf_progress").addClass("cp_hidden");
                    var fieldsarray = [];
                    $.each(responsedata.resultData.items, function (i, a) {

                        console.log(a.fields);
                        fieldsarray.push(a.fields);
                    });

                    console.log("Fieldsarray" + fieldsarray);

                    g_partscategory_collection = fieldsarray;

                    if (g_partscategory_collection.length == 0) {
                        alert("Part not found. You cannot add this part");
                        //invoke close click
                        $.HandleClosebuttonClick();
                        return;
                    }

                    if (g_partscategory_collection != null) {
                        g_partscategory_collection = $.PrepareUniqueParts(g_partscategory_collection);
                        if (g_partscategory_collection.length > PER_PAGE_COUNT) {
                            //enable load more
                            $("#cpf_loadmore").attr('disabled', false);
                        }
                        else {
                            //disable load more
                            $("#cpf_loadmore").attr('disabled', true);
                        }

                        //build ui dynamic elements
                        $.BuildAddPartInventoryUI(g_partscategory_collection.slice(0, PER_PAGE_COUNT));
                    }
                }
                catch (err) {
                    activityLog = activityLog + ';Exception in processSearchResultsFnCallBck:' + err.message;
                    console.log(" Exception in processSearchResultsFnCallBck :" + err.message);
                }

            }

            $.FetchInventoryListItems = function (itemnumberlike) {
                //fire ajax request
                var returnvalue = null; //ajax response object;
                var response = null;
                //show loading..
                $('#cpf_progress').removeClass("cp_hidden");
                //parse response to newinventoryitemcollection
                $.getPartsCatalog(itemnumberlike + '')

                // response = {
                //     "status": 200,
                //     "element": [
                //         {
                //             "Item_Cost": "198",
                //             "Item_Description": "OPERATION SUB-UNIT DIAC1 NA ASSY",
                //             "Item_Disposition": "NA",
                //             "Item_Number": "HD0391441",
                //             "Item_Price": "525.03",
                //             "Item_Type": "BOARD",
                //             "Linked_Count": "3",
                //             "Top_Item": "HD0391441",
                //             "Vendor": "PARTS"
                //         }
                //     ]
                // };
                // if(response.status == 200)
                // {
                //     returnvalue = response.element;
                // }
                // $.processSearchResultsFnCallBck(response);

                return returnvalue;
            }

            $.HandleStage = function (activityentity) {

                if (!activityentity.A_PHYSICAL_INVENTORY_STAGE) {
                    //blank
                }
                else if (activityentity.A_PHYSICAL_INVENTORY_STAGE == 'Recount') {
                    //fetch quantity from I_EXPECTED...

                }
                else if (activityentity.A_PHYSICAL_INVENTORY_STAGE == 'Done') {
                    $("#cpf_activity_done").removeClass("cp_hidden");
                    //Hide the main form.
                    $('#cpf_activity_inprogress').addClass("cp_hidden");

                }
            }


            $.closeMethod = function (submit_json) {
                console.log('closeMethod');
                // clear the local storage fields:
                localStorage.removeItem('V_ENROUTE_AID');
                localStorage.removeItem('V_ORACLE_STATUS');
                localStorage.removeItem('V_ODOMETER_END');
                localStorage.removeItem('V_APPT_NUMBER');
                localStorage.removeItem('V_RESOURCE_ID');
                localStorage.removeItem('V_ENROUTE_DATE');
                this._sendPostMessageData(submit_json);
            }.bind(this);


            // Changes for CHG0079011- Local Storage change
            //update the quantity of respective partNumber in Localstorage if exists or create new object and push to existing 
            //‘PI-activityID-selectedValue’ in localstorage
            $.updateLocalStorageResourceBinMgt= function (g_externalid,inventoryid,binMgtFlag){
                if (binMgtFlag != 'Y') {
                    binMgtFlag = 'N';
                }
                let resourceBinMgtUpdate = "resourceBinMgtUpdate-" + g_externalid;
                let data = localStorage.getItem(resourceBinMgtUpdate);
                if (data.length == 0 || data == "") {
                    let arr = [];
                    const object = {
                        invid:inventoryid,
                        binManagementFlag:binMgtFlag,
                    };
                    arr.push(object);
                    localStorage.setItem(resourceBinMgtUpdate, JSON.stringify(arr));

                }
                else{
                    let temp = JSON.parse(localStorage.getItem(resourceBinMgtUpdate));
                    let partsExists = false;
                    partsExists = temp.some(part => part.invid === inventoryid);
                    if (partsExists == true) {
                        temp.forEach(part => {
                            if (part.invid === inventoryid) {
                                part.binManagementFlag = binMgtFlag;
                            }
                        });
                    }
                    else {

                        const object = {
                            invid:inventoryid,
                            binManagementFlag:binMgtFlag,
                        };
                        temp.push(object);
                    }
                    localStorage.setItem(resourceBinMgtUpdate, JSON.stringify(temp));
                }
                

            }
            
            $.updateLocalStorageForActivityBinMgt = function (externalId, qty, ptNum, binMgtFlag, action,subinventory) {
                if (binMgtFlag != 'Y') {
                    binMgtFlag = 'N';
                }
                let activityBinLocalStorage = "activityBinManagement-" + g_externalid;
                let data = localStorage.getItem(activityBinLocalStorage);
                let quant= (qty == null || "" == qty ? 0 : qty);
                if (data.length == 0 || data == "") {
                    let arr = [];
                    const object = {
                        subinventory: subinventory,
                        binmgt: binMgtFlag,
                        item: ptNum,
                        quantity: quant,
                        action: action,
                    };
                    arr.push(object);
                    // localStorage.pi=[];
                    localStorage.setItem(activityBinLocalStorage, JSON.stringify(arr));
                    // localStorage.pi=JSON.stringify(arr);
                }
                else {
                    let temp = JSON.parse(localStorage.getItem(activityBinLocalStorage));
                    let partsExists = false;
                    partsExists = temp.some(part => part.item === ptNum);
                    if (partsExists == true) {
                        temp.forEach(part => {
                            if (part.item == ptNum) {
                                part.quantity = quant;
                                part.binmgt = binMgtFlag;
                            }
                        });
                    }
                    else {

                        const object = {
                            subinventory: subinventory,
                            binmgt: binMgtFlag,
                            item: ptNum,
                            quantity: quant,
                            action: action,
                        };
                        temp.push(object);
                    }
                    localStorage.setItem(activityBinLocalStorage, JSON.stringify(temp));
                    // localStorage.pi=JSON.stringify(temp);


                }
            }
            $.updateLocalStorageForQtyChange = function (inventoryid, qtyToUpdate, partNum, binMgtChk) {
                // var currentData = localStorage.getItem("PIList");
                //  currentData = currentData ? JSON.parse(currentData) : {};
                //  if(currentData != {})
                if (binMgtChk != 'Y') {
                    binMgtChk = 'N';
                }


                let name = "PI-" + activityId + "-" + selectedValue;
                let data = localStorage.getItem(name);
                if (data.length == 0 || data == "") {
                    let arr = [];
                    const object = {
                        invid: inventoryid,
                        activityId: activityId,
                        partNumber: partNum,
                        qty: qtyToUpdate,
                        binMgt: binMgtChk,
                    };
                    arr.push(object);
                    // localStorage.pi=[];
                    localStorage.setItem(name, JSON.stringify(arr));
                    // localStorage.pi=JSON.stringify(arr);
                }
                else {
                    let temp = JSON.parse(localStorage.getItem(name));
                    let partsExists = false;
                    partsExists = temp.some(part => part.partNumber === partNum);
                    if (partsExists == true) {
                        temp.forEach(part => {
                            if (part.partNumber == partNum) {
                                part.qty = qtyToUpdate;
                                part.binMgt = binMgtChk;
                            }
                        });
                    }
                    else {

                        const object = {
                            invid: inventoryid,
                            activityId: activityId,
                            partNumber: partNum,
                            qty: qtyToUpdate,
                            binMgt: binMgtChk,
                        };
                        temp.push(object);
                    }
                    localStorage.setItem(name, JSON.stringify(temp));
                    // localStorage.pi=JSON.stringify(temp);


                }

            }

            // Changes for CHG0079011- Local Storage change
            //call this proc to remove data from localstorage upon page submission
            $.removeLocalStorageOnSubmit = function (value) {
                //remove all attributes stored in localstorage after submission
                let name = "PI-" + activityId + "-" + value;
                localStorage.removeItem(name);

            }
            $.removeLocalStorageactivityMgt = function (value) {
                let name = "activityBinManagement-" + value;
                localStorage.removeItem(name);
            }
            $.removeLocalStorageResourceBinMgt = function (value) {
                let name = "resourceBinMgtUpdate-" + value;
                localStorage.removeItem(name);
            }



            $.srCreateAPICall = function (activityId, instanceName, resourceId, requestType, submit_json, todayDate) {
                var webServiceURL = "https://" + instanceName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/serviceRequests";
                var nowDate = new Date();
                var date = nowDate.toISOString().split('T')[0];
                var jsonPayload = {
                    instanceName: instanceName,
                    date: todayDate,
                    activityId: parseInt(activityId),
                    requestType: requestType,
                    requestEntity: "ACTIVITY",
                    submit_json: JSON.stringify(submit_json)

                }
                console.log('jsonPayload:' + JSON.stringify(jsonPayload));
                $.ajax({
                    url: webServiceURL,
                    method: 'POST',
                    dataType: 'json',
                    contentType: 'application/json; charset=utf-8',
                    data: JSON.stringify(jsonPayload),
                    async: false,
                    crossDomain: true,
                    headers: headers,
                    timeout: 15000,
                    success: function (response) {
                        console.log('API call for srCreateAPICall - success: ' + JSON.stringify(response));

                        // Added for PI Issue to display Property value -- A_PI_ACTIVITY_MSG
                        submit_json.activity.A_PI_ACTIVITY_MSG = submit_json.activity.A_PI_ACTIVITY_MSG + " || PI Request : " + JSON.stringify(jsonPayload) + " || PI Request Success : " + JSON.stringify(response);

                        $.closeMethod(submit_json);
                    }.bind(this),
                    error: function (response) {
                        console.log('API call for srCreateAPICall - failure: ' + JSON.stringify(response));



                        // Added for PI Issue to display Property value -- A_PI_ACTIVITY_MSG
                        submit_json.activity.A_PI_ACTIVITY_MSG = submit_json.activity.A_PI_ACTIVITY_MSG + " || PI Request : " + JSON.stringify(jsonPayload) + " || PI Request Exception : " + JSON.stringify(response);


                        //error logging mechanism

                        console.log("SRCreateEnrouteActivity - errr:" + JSON.stringify(response));
                        var now = new Date(Date.now());
                        var errorTime = now.getHours() + ":" + now.getMinutes() + ":" + now.getSeconds();
                        var errorDetails = response.responseJSON;

                        var eDetail = errorDetails.detail.replace(/(\r\n|\n|\r)/gm, " ");
                        var eStatus = errorDetails.status;
                        if (errorLogs == null) {
                            errorLogs = "";
                        }
                        errorLogs = errorLogs + "||" + now.toString() + "|Plugin :Physical Inventory " + "| URL:" + webServiceURL.toString() + "|Error Status:" + eStatus + "|Error Details:" + eDetail;
                        console.log(errorLogs);

                        $.ErrorUpdate(activityId, errorLogs);

                        $.closeMethod(submit_json);
                    }.bind(this)
                });

            },



                $.HandleCategorySubmitRecord = function (collection, category, value, sub_inventoryname_collection) {

                    var isdefective = category.endsWith('X');
                    var categorySubinventoryname = "";
                    var submitctrl_isenable = false;
                    var itemsEnteredQty_count = 0;
                    var itemsEmptyQty_count = 0;
                    // Start added for CHG0075456 - Bin Locations for Field Service
                    // if ("" != activityBinManagement) {
                    //     var activtyBinMgt = $.createElement('ParentUpdateBinLocations');
                    //     try {
                    //         activtyBinMgt.append(activityBinManagement);
                    //     } catch (err) {
                    //         activtyBinMgt.append(activityBinManagement.getElementsByTagName("UpdateBinLocations")[0]);
                    //     }
                    //     submit_json.activity.A_BIN_MGT = activtyBinMgt.innerHTML; //new XMLSerializer().serializeToString(activityBinManagement).replace(/xmlns="[^"]+"/, ''); // Modified for INC2343370
                    // } // End added for CHG0075456 - Bin Locations for Field Service
                    try {
                        collection.forEach(function (indItem) {
                            if (indItem.category == category) {
                                categorySubinventoryname = category.split(',');
                                categorySubinventoryname = categorySubinventoryname[0];
                                if (sub_inventoryname_collection) {
                                    indItem.issubmitenable = true;
                                    //submit set
                                    //add part list to the json....
                                    sub_inventoryname_collection.forEach(function (inventoryitem) {
                                        if (inventoryitem.subinventoryname == categorySubinventoryname) {

                                            if (inventoryitem.isaddedbypartcategory == false) {
                                                var invItem = { [inventoryitem.invid]: { I_USED_QUANTITY: inventoryitem.quantity, I_BIN_MANAGEMENT: inventoryitem.I_BIN_MANAGEMENT } }; // Modified for CHG0075456 - Bin Locations for Field Service
                                                ///submit_json.inventoryList.push(invItem);
                                                $.extend(submit_json.inventoryList, { [inventoryitem.invid]: { "I_BIN_MANAGEMENT": inventoryitem.I_BIN_MANAGEMENT, "I_USED_QUANTITY": $.ParseIntegerSafely(inventoryitem.quantity) + '' } }); // Modified for CHG0075456 - Bin Locations for Field Service
                                                //Navaz added to display the empty count.
                                                if (parseInt(inventoryitem.quantity) > 0) {
                                                    itemsEnteredQty_count = itemsEnteredQty_count + 1;
                                                } else {
                                                    itemsEmptyQty_count = itemsEmptyQty_count + 1;
                                                }
                                            }
                                            else {
                                                if (!submit_json.actions) {
                                                    submit_json.actions = [];
                                                }
                                                //update quantity from ui to action entity
                                                // var addpartaction = {action : 'create' ,inv_pid : g_pid ,inv_aid : g_activityId , invtype :'',
                                                // quantity : '', invpool: 'customer', entity: 'inventory' , properties : {
                                                //    I_ITEM_NUMBER : '',I_SUBINVENTORY : '', I_DEFECTIVE : '' , I_INVENTORY_KEY : '',I_USED_QUANTITY : 1
                                                // }   };

                                                inventoryitem.externalitem.properties.I_CREATED_FLAG = "true";
                                                inventoryitem.externalitem.quantity = inventoryitem.externalitem.properties.I_USED_QUANTITY = inventoryitem.quantity + '';
                                                submit_json.actions.push(inventoryitem.externalitem);
                                            }
                                        }
                                    });
                                }
                                else {
                                    submitctrl_isenable = indItem.issubmitenable;
                                }
                                return;
                            }
                        });

                        // Navaz: show the empty qty count Popup message:
                        if (itemsEmptyQty_count > 0) {

                            alert('You have non-verified ' + (isdefective ? "defective" : "usable") + ' inventory (' + itemsEmptyQty_count + ') items.\n All non-verified values will be set to "0".\n Click Ok to continue.');

                        }


                        var isshowmessgetosubmitdefective = true;
                        if (sub_inventoryname_collection) {
                            //iterate through collection for other category
                            collection.forEach(function (indItem) {
                                //check value of other category...
                                if (indItem.category != category && indItem.issubmitenable) {
                                    isshowmessgetosubmitdefective = false;
                                    //based on the true flag on both, send the post request
                                    $("#cpf_defective").attr("disabled", true);
                                    $("#cpf_usable").attr("disabled", true);

                                    return;
                                }
                            });

                            if (isshowmessgetosubmitdefective) {
                                if (isdefective) {
                                    $("#cpf_defective").attr("disabled", true);
                                }
                                else {
                                    $("#cpf_usable").attr("disabled", true);
                                }
                                alert("Please submit " + (isdefective ? "usable" : "defective") + " parts in order to continue.");
                            }
                            else {
                                console.log("Submit Json : " + JSON.stringify(submit_json));
                                submit_json.activity.A_PI_ACTIVITY_MSG = submit_json.activity.A_PI_ACTIVITY_MSG + " || Before PI Request Call for Activity Id : " + g_activityId;

                                //To add log message
                                if (activityLog != null && activityLog != '') {
                                    activityLog = pluginName + ' :- ' + activityLog;
                                    if (receivedData.activity.A_ACTIVITY_LOG != null) {
                                        activityLog = receivedData.activity.A_ACTIVITY_LOG + ';' + activityLog;
                                    }
                                }
                                else {
                                    if (receivedData.activity.A_ACTIVITY_LOG != null) {
                                        activityLog = receivedData.activity.A_ACTIVITY_LOG;
                                    }
                                    else {
                                        activityLog = null;
                                    }
                                }
                                submit_json.activity.A_ACTIVITY_LOG = activityLog;

                                // Start added for CHG0075456 - Bin Locations for Field Service
                                if ("" != activityBinManagement) {
                                    var activtyBinMgt = $.createElement('ParentUpdateBinLocations');
                                    try {
                                        activtyBinMgt.append(activityBinManagement);
                                    } catch (err) {
                                        activtyBinMgt.append(activityBinManagement.getElementsByTagName("UpdateBinLocations")[0]);
                                    }
                                    submit_json.activity.A_BIN_MGT = activtyBinMgt.innerHTML; //new XMLSerializer().serializeToString(activityBinManagement).replace(/xmlns="[^"]+"/, ''); // Modified for INC2343370
                                } // End added for CHG0075456 - Bin Locations for Field Service

                                $.srCreateAPICall(g_activityId, domainName, receivedData.resource.external_id, receivedData.securedData.physicalInventorySRType, submit_json, todayDate);
                                values.forEach(function (val) {
                                    $.removeLocalStorageOnSubmit(val);
                                    $.removeLocalStorageactivityMgt(g_externalid);
                                    $.removeLocalStorageResourceBinMgt(g_externalid);
                                });
                            }
                        }
                    }
                    catch (err) {
                        activityLog = activityLog + ';Exception in HandleCategorySubmitRecord:' + err.message;
                        console.log(" Exception in HandleCategorySubmitRecord :" + err.message);
                    }
                    return submitctrl_isenable;
                }.bind(this);
            //method defenitions -E
            $.HandleStage(receivedData.activity);
            $.buildjsondata(receivedDataJson);

            //add unique values to select drop down
            $.each(unique_inventory_names, function (key, value) {
                var testtodisplay = value;
                values.push(value);
                let name = "PI-" + activityId + "-" + testtodisplay;
                // set the localstorage item 
                if ($('#cpf_activity_inprogress').hasClass("cp_hidden") == false && localStorage.getItem(name) === null) {
                    localStorage.setItem(name, []);
                }
                if (testtodisplay.endsWith("X")) {
                    testtodisplay = testtodisplay + " (Defective)";
                }
                else {
                    testtodisplay = testtodisplay + " (Usable)";
                }
                $('#cpf_sub_inventory_inner')
                    .append($("<option></option>")
                        .attr("value", key)
                        .text(testtodisplay));
            });
            $.BuildUITable = function (sub_inventoryname_collection, itemnumberstring) {
                sub_inventoryname_collection.sort(function (item_list_1, item_list_2) {
                    var partnumber1 = item_list_1.partnumber.toLowerCase(), partnumber2 = item_list_2.partnumber.toLowerCase()
                    if (partnumber1 < partnumber2)
                        return -1
                    if (partnumber1 > partnumber2)
                        return 1
                    return 0
                });
                g_selectedcategorytotalcount = 0;
                //filter records
                var filtered_inventory_collection = sub_inventoryname_collection.filter(function (indItem) {
                    var curSelectedSubInv = (currentselectedinventory.indexOf(g_externalid) != -1 ? currentselectedinventory : g_subinventory);
                    if (indItem.subinventoryname == curSelectedSubInv) {
                        g_selectedcategorytotalcount = g_selectedcategorytotalcount + 1;
                        if (itemnumberstring) {
                            return (indItem.partnumber.indexOf(itemnumberstring) != -1);
                        }
                        return true;
                    }
                });
                //build dynamic controls
                $.dynamicBuildPhysicalInventoryUIElementsFunction(filtered_inventory_collection, g_selectedcategorytotalcount);
                $('#sortbypartnumber').prop('checked', true); // Added for CHG0075456 - Bin Locations for Field Service
            }
            // Start added for CHG0075456 - Bin Locations for Field Service
            $.BuildUITablePrimaryBinName = function (sub_inventoryname_collection, itemnumberstring) {
                sub_inventoryname_collection.sort(function (item_list_1, item_list_2) {
                    var primaryBinName1 = item_list_1.primaryBinName; //toLowerCase()
                    var primaryBinName2 = item_list_2.primaryBinName;
                    if (primaryBinName1 == null) return 1;// primaryBinName1.toLowerCase();
                    if (primaryBinName2 == null) return -1;//primaryBinName2.toLowerCase();
                    if (primaryBinName1 < primaryBinName2)
                        return -1
                    if (primaryBinName1 > primaryBinName2)
                        return 1
                    return 0
                });
                g_selectedcategorytotalcount = 0;
                //filter records
                var filtered_inventory_collection = sub_inventoryname_collection.filter(function (indItem) {
                    var curSelectedSubInv = (currentselectedinventory.indexOf(g_externalid) != -1 ? currentselectedinventory : g_subinventory);
                    if (indItem.subinventoryname == curSelectedSubInv) {
                        g_selectedcategorytotalcount = g_selectedcategorytotalcount + 1;
                        if (itemnumberstring) {
                            return (indItem.partnumber.indexOf(itemnumberstring) != -1);
                        }
                        return true;
                    }
                });
                //build dynamic controls
                $.dynamicBuildPhysicalInventoryUIElementsFunction(filtered_inventory_collection, g_selectedcategorytotalcount);
                $('#sortbyprimarybinname').prop('checked', true);
            } // End added for CHG0075456 - Bin Locations for Field Service

            $.ValidatePhysicalInventoryCollections = function (category, sub_inventoryname_collection) {

                var isvalid = false;

                var isdefective = category.endsWith('X');
                var recordswithemptyquantity = [];

                sub_inventoryname_collection.forEach(function (inventoryitem) {
                    if (inventoryitem.subinventoryname == category) {
                        if (isNaN(parseInt(inventoryitem.quantity))) {
                            recordswithemptyquantity.push(inventoryitem);
                        }
                    }
                });
                //prepare validation message in case of more than one empty quantity
                if (recordswithemptyquantity.length > 0) {
                    var showitemcount = 0;
                    var emptyquantity = "Document contains parts with empty  quantities:";
                    recordswithemptyquantity.forEach(function (inditem) {
                        if (showitemcount == 5) {
                            emptyquantity = emptyquantity + '/n' + 'and more...';
                            return;
                        }
                        emptyquantity = emptyquantity + '/n' + ' P/N:' + inditem.partnumber + ' Desc: ' + inditem.description;
                        showitemcount = showitemcount + 1;
                    });
                    emptyquantity = emptyquantity + '/n' + 'Click OK to confirm...';

                    isvalid = confirm(emptyquantity);
                }
                else {
                    isvalid = true;
                }
                return isvalid;
            }
            //based on the result json build the ui elements
            $.staticPhysicalInventoryUIElementsFunction = function (sub_inventoryname_collection) {
                //on inventory change
                $("#cpf_sub_inventory_inner").change(function () {
                    var selectedText = $(this).find("option:selected").text();
                    selectedValue = $(this).val();
                    //clear serach text box
                    $("#cpf_TechnicianGridSearch_inner").val('');

                    if (selectedText.trim() == '') {
                        currentselectedinventory = null;
                        $('#cpf_TechnicianGridRows').addClass("cp_hidden");
                        //clear grid controll
                        $("#cpf_TechnicianGrid").empty();
                        $("#cpf_defective").attr("disabled", true);
                        $("#cpf_usable").attr("disabled", true);
                        return;
                    }
                    else {
                        $('#cpf_TechnicianGridRows').removeClass("cp_hidden");
                    }
                    currentselectedinventory = unique_inventory_names[parseInt(selectedValue)];
                    selectedValue = currentselectedinventory;
                    isDefectiveSelected = currentselectedinventory.endsWith("X");

                    //handle submit button enable disable
                    var isenable = $.HandleCategorySubmitRecord(percategory_submit_condition, currentselectedinventory);
                    if (isDefectiveSelected) {
                        // $("#cpf_defective").attr("disabled", isenable);
                        //$("#cpf_usable").attr("disabled", !isenable);
                        $("#cpf_defective").attr("disabled", false);
                        $("#cpf_usable").attr("disabled", true);
                    }
                    else {
                        //$("#cpf_defective").attr("disabled", !isenable);
                        //$("#cpf_usable").attr("disabled", isenable);
                        $("#cpf_defective").attr("disabled", true);
                        $("#cpf_usable").attr("disabled", false);
                    }
                    //filter records
                    $.BuildUITable(sub_inventoryname_collection);
                });

                $("#cpf_defective").click(function (e) {
                    //validate defective collection
                    if ($.ValidatePhysicalInventoryCollections(selectedValue, sub_inventoryname_collection)) {
                        //prepare the json
                        $.HandleCategorySubmitRecord(percategory_submit_condition, selectedValue, true, sub_inventoryname_collection);
                        // $.removeLocalStorageOnSubmit();
                    }
                });
                $("#cpf_usable").click(function (e) {
                    //validate usable
                    if ($.ValidatePhysicalInventoryCollections(selectedValue, sub_inventoryname_collection)) {
                        //prepare the json
                        $.HandleCategorySubmitRecord(percategory_submit_condition, selectedValue, true, sub_inventoryname_collection);
                        // $.removeLocalStorageOnSubmit();
                    }
                });

                $("#cpf_TechnicianAddInventory").click(function (e) {
                    if (currentselectedinventory == null) {
                        alert("You must select sub-inventory before you can add parts");
                        return;
                    }
                    //if it is empty prompt user to type some character..
                    var itemnumberstartswith = document.getElementById("cpf_TechnicianGridSearch_inner").value;
                    if (!itemnumberstartswith) {
                        alert('Please enter "Part Number"');
                        return;
                    }
                    if (g_selectedcategorytotalcount == 0 && !confirm("Part number not found. Would you like to add new record?")) {
                        return;
                    }
                    //show add inventory controls
                    $("#cpf_addinventory").removeClass("cp_hidden");
                    //Hide the main form.
                    $('#cpf_mainscreen').addClass("cp_hidden");

                    $.FetchInventoryListItems(itemnumberstartswith);

                });

                $("#cpf_loadmore").click(function (e) {

                    //pagination
                    g_page_count = g_page_count + 1;
                    var pagedcollection = g_partscategory_collection.slice(g_page_count * PER_PAGE_COUNT, g_page_count * PER_PAGE_COUNT + PER_PAGE_COUNT)

                    $.AppendGridElementsFromCollection(pagedcollection);

                    if (g_partscategory_collection.length < g_page_count * PER_PAGE_COUNT + PER_PAGE_COUNT) {
                        //disable load more
                        $(this).attr('disabled', true);
                    }
                });
                $("#cpf_TechnicianGridSearch_inner").on("change paste keyup", function (e) {
                    //search in subinventory list
                    var itemnumbersearch = $(this).val();
                    //rebuild the ui
                    $.BuildUITable(sub_inventoryname_collection, itemnumbersearch);
                });
                $("#cpf_addInventoryCloseBtn").click(function (e) {
                    $.HandleClosebuttonClick();
                });
            }
            $.HandleClosebuttonClick = function () {
                //Hide the add inventory form.
                $('#cpf_addinventory').addClass("cp_hidden");
                //load the added elemts
                if (listOfItemsAddedFromPartsCatalog) {
                    listOfItemsAddedFromPartsCatalog.forEach(function (indpart) {
                        //if part already available in the inventory, increase the count
                        var curSelectedSubInv = (currentselectedinventory.indexOf(g_externalid) != -1 ? currentselectedinventory : g_subinventory); // Navaz Added 02March

                        var itemIndex = sub_inventoryname_collection.findIndex(function (indItem) {
                            return indItem.subinventoryname == curSelectedSubInv && indItem.partnumber == indpart.itemnumber; // Navaz Added 02March
                        });
                        if (itemIndex >= 0) {

                            //increase the quantity of the item
                            sub_inventoryname_collection[itemIndex].quantity = $.ParseIntegerSafely(sub_inventoryname_collection[itemIndex].quantity) + 1;
                        }
                        else {
                            // debugger;
                            var inventoryitem = {
                                subinventoryname: (currentselectedinventory.indexOf(g_externalid) != -1 ? currentselectedinventory : g_subinventory),//currentselectedinventory,
                                invid: indpart.itemnumber, partnumber: indpart.itemnumber,
                                description: indpart.description, quantity: 1, isaddedbypartcategory: true, externalitem: null
                            };

                            //add a create action to the json before submit
                            var addpartactionentity = JSON.parse(JSON.stringify(addpartaction)); //clone of add part json entity
                            addpartactionentity.invtype = "PI";//(currentselectedinventory.indexOf(g_externalid) != -1 ? "CAR_STOCK" : "SUBINVENTORY");  Navaz:Commented as per defect#1198
                            addpartactionentity.properties.I_ITEM_NUMBER = indpart.itemnumber;
                            //  addpartactionentity.properties.I_SUBINVENTORY = (currentselectedinventory.indexOf(g_externalid) != -1 ? "CAR_STOCK" : g_subinventory);
                            addpartactionentity.properties.I_SUBINVENTORY_NAME = (currentselectedinventory.indexOf(g_externalid) != -1 ? currentselectedinventory : g_subinventory);  //(currentselectedinventory.indexOf(g_externalid) != -1 ? currentselectedinventory : g_subinventoryname);  Navaz:Commented as per defect#1198
                            addpartactionentity.properties.I_DEFECTIVE = isDefectiveSelected ? 'Y' : 'N';
                            addpartactionentity.properties.I_INVENTORY_KEY = isDefectiveSelected ? 'X' + indpart.itemnumber : indpart.itemnumber; // indpart.itemnumber + '_' + g_externalid;  Navaz:Commented as per defect defect#1198
                            addpartactionentity.properties.I_USED_QUANTITY = inventoryitem.quantity + '';
                            addpartactionentity.properties.I_ITEM_COST = indpart.cost;
                            addpartactionentity.properties.I_PRICE = indpart.price;
                            addpartactionentity.properties.I_ITEM_DESCRIPTION = indpart.description;
                            addpartactionentity.properties.I_RETURN_VENDOR = indpart.vendor;

                            inventoryitem.externalitem = addpartactionentity;

                            sub_inventoryname_collection.push(inventoryitem);
                        }

                    });
                    //rebuild the ui table
                    $.BuildUITable(sub_inventoryname_collection);
                }
                //clear serach text box
                $("#cpf_TechnicianGridSearch_inner").val('');
                //shoe the main screen
                $("#cpf_mainscreen").removeClass("cp_hidden");
            }
            //based on the result json build the ui elements
            $.dynamicBuildPhysicalInventoryUIElementsFunction = function (filtered_inventory_collection, selectedcategorytotalcount) {
                // var inventoryitem = {subinventoryname : currentrecorditemname,
                //     invid: invItem.invid , partnumber : invItem.I_ITEM_NUMBER ,
                //     description : invItem.I_ITEM_DESCRIPTION , quantity : invItem.I_USED_QUANTITY, isupdated : false};

                // //as many number of rows create the collection
                var inventorycollection = filtered_inventory_collection;

                $("#cpf_TechnicianGrid").empty();
                //TODO:: KRishn -- show count basesd on filtered record count
                // Start added for CHG0075456 - Bin Locations for Field Service
                $("#cpf_TechnicianGrid").append(
                    '<tbody>\
                    <tr id="cpf_TechnicianGrid_header" class="test-grid-header">\
                       <td class="col2 cpf_0-0" style="">Parts list (' + inventorycollection.length + ' of ' + selectedcategorytotalcount + ' ) <br/>\
                       <div style="width: 15%;float: left;"><span style="font-weight: 400;">Sort by:</span></div>\
                       <div><input type="radio" name="soryByItems" id="sortbypartnumber" value="PART_NUMBER">\
                       <label for="sortbypartnumber" style="font-weight: 450;"> Part Number</label><br/>\
                       <input type="radio" name="soryByItems" id="sortbyprimarybinname" value="PRIMARY_BIN_NAME">\
                       <label for="sortbyprimarybinname" style="font-weight: 450;"> Primary bin Name</label></div>\
                       </td>\
                    </tr>');

                // Rebuild UI based on part number sort
                $('#sortbypartnumber').click(function () {
                    $.BuildUITable(sub_inventoryname_collection);
                });

                // Rebuild UI based on p number sort
                $('#sortbyprimarybinname').click(function () {
                    $.BuildUITablePrimaryBinName(sub_inventoryname_collection);
                }); // End added for CHG0075456 - Bin Locations for Field Service

                inventorycollection.forEach(function (inventoryitem) {
                    var uniqueinventorynumber = inventoryitem.invid;
                    var itemnumber = inventoryitem.partnumber;
                    var itemdescription = inventoryitem.description;
                    var itemQty = inventoryitem.quantity;
                    var binMgtChk = inventoryitem.I_BIN_MANAGEMENT;
                    if (itemQty == 0 || itemQty < 0 || isNaN(itemQty)) {
                        itemQty = "";
                    }
                    // Modified to add bin mgt flag for CHG0075456 - Bin Locations for Field Service
                    // Changes for CHG0079011- Local Storage change
                    let name = "PI-" + activityId + "-" + selectedValue;

                    let temp = localStorage.getItem(name);
                    if (temp != "" || temp.length > 0) {
                        let data = JSON.parse(localStorage.getItem(name));
                        let partsExists = false;
                        partsExists = data.some(part => part.partNumber === itemnumber);
                        if (partsExists == true) {
                            let searchObject = data.find((ar) => ar.partNumber == itemnumber);
                            itemQty = searchObject.qty;
                            binMgtChk = searchObject.binMgt;
                            $.UpdateSelectedJsonData(uniqueinventorynumber, inventorycollection, itemQty);
                            $.UpdateBinMgtJsonData(uniqueinventorynumber, inventorycollection, binMgtChk);
                        }
                        else {
                            itemQty = "";
                        }
                    }

                    $("#cpf_TechnicianGrid").append('<tr id="exception_grid_' + uniqueinventorynumber + ' class="test-grid-row">\
                    <td class="col2 cpf_0-0"><strong>' + itemnumber + '</strong>\
                       <span>'+ itemdescription + '</span>' + inventoryitem.binNames + '\
                       <div>Bin mgt flag: <input type="checkbox" name="inventory_lifecycle_bin_mgt_chk" id="bin_mgt_chk_'+ uniqueinventorynumber + '" ' + ('Y' == binMgtChk ? 'checked' : '') + '/></div>\
                    </td></tr>\
                    <tr id="exception_grid1_' + uniqueinventorynumber + ' class="test-grid-row"> \
                    <td class="col3 order-parts-spinner-column cpf_0-2">\
                       <div id="cpf_used_' + uniqueinventorynumber + '" class="cp_field order-parts-order-quantity">\
                          <div class="cp_field_row">\
                             <div class="cp_field_value cp_fullsize">\
                                <div class="cp_field_value_inner_wrapper">\
                                   <input id="cpf_used_button_decrease_' + uniqueinventorynumber + '" type="button" class="cpf-spinner-button-decrease button" value="-">\
                                   <input id="cpf_used_entered_qty_' + uniqueinventorynumber + '" type="text" class="cp_field_text_component cp_field_spinner_component form-item" value="' + itemQty + '">\
                                   <input id="cpf_used_button_increase_' + uniqueinventorynumber + '" type="button" class="cpf-spinner-button-increase button" value="+"><span id="cpf__unnamed_13_inner_read_only" class="cp_aux_hide"></span><span class="cp_measure_unit" id="">\
                                   </span><span class="cp_min_max" id="cpf__unnamed_13_min_max"></span>\
                                   <div class="cp_error_label" id="cpf__unnamed_13_error"></div>\
                                </div>\
                             </div>\
                          </div>\
                       </div>\
                    </td>\
                 </tr>');

                    $('#cpf_used_button_decrease_' + uniqueinventorynumber).on('click', function () {
                        //get the id
                        var currentcontrolId = this.id;
                        //split it with __
                        var classkey = currentcontrolId.split("_");
                        //take id and update respecive object
                        var inventoryid = classkey[classkey.length - 1];

                        var cpfEnteredQty = $(this).next();
                        var prevValue = cpfEnteredQty.val();

                        if (isNaN(prevValue) || prevValue.indexOf(' ') >= 0 || prevValue === "") {
                            cpfEnteredQty.val(0);
                        } else {
                            cpfEnteredQty.val(parseInt(prevValue));
                        }
                        prevValue = cpfEnteredQty.val();

                        var incCount = parseInt(prevValue);


                        if (incCount <= 0) {
                            incCount = 0;
                            cpfEnteredQty.val(0);
                        } else {
                            incCount -= 1;
                            cpfEnteredQty.val(incCount);
                        }
                        $.UpdateSelectedJsonData(inventoryid, inventorycollection, incCount);
                        // Changes for CHG0079011- Local Storage change
                        var binManagementFlag = $('#bin_mgt_chk_' + uniqueinventorynumber).is(':checked') ? "Y" : "N";
                        $.updateLocalStorageForQtyChange(uniqueinventorynumber, incCount, itemnumber, binManagementFlag);
                    });

                    $('#cpf_used_button_increase_' + uniqueinventorynumber).on('click', function () {

                        //get the id
                        var currentcontrolId = this.id;
                        //split it with __
                        var classkey = currentcontrolId.split("_");
                        //take id and update respecive object
                        var inventoryid = classkey[classkey.length - 1];

                        var cpfEnteredQty = $(this).prev();

                        var prevValue = cpfEnteredQty.val();

                        if (isNaN(prevValue) || prevValue.indexOf(' ') >= 0 || prevValue === "") {
                            cpfEnteredQty.val(0);
                        } else {
                            cpfEnteredQty.val(parseInt(prevValue));
                        }
                        prevValue = cpfEnteredQty.val();
                        var incCount = parseInt(prevValue);

                        if (incCount < 0) {
                            incCount = 0;
                            cpfEnteredQty.val(0);
                        }
                        else {
                            incCount += 1;
                            cpfEnteredQty.val(incCount);
                        }
                        $.UpdateSelectedJsonData(inventoryid, inventorycollection, incCount);
                        // Changes for CHG0079011- Local Storage change
                        var binManagementFlag = $('#bin_mgt_chk_' + uniqueinventorynumber).is(':checked') ? "Y" : "N";
                        $.updateLocalStorageForQtyChange(uniqueinventorynumber, incCount, itemnumber, binManagementFlag);
                    });

                    // Start added for CHG0075456 - Bin Locations for Field Service
                    $('#bin_mgt_chk_' + uniqueinventorynumber).on("change paste keyup", function () { //get the id

                        var binManagementFlag = $('#bin_mgt_chk_' + uniqueinventorynumber).is(':checked') ? "Y" : "N";
                        var incCount = $('#cpf_used_entered_qty_' + uniqueinventorynumber).val();
                        // $.UpdateSelectedJsonData(inventoryid, inventorycollection, incCount, binManagementFlag);
                        let activityBinLocalStorage = "activityBinManagement-" + g_externalid;
                        if(localStorage.getItem(activityBinLocalStorage)==null){
                            localStorage.setItem(activityBinLocalStorage,[]);
                        }

                        if (binManagementFlag != inventoryitem.I_BIN_MANAGEMENT) {
                            var itemExistinList = false; // Start added for INC2343370
                            if ("" != activityBinManagement) {
                                $(activityBinManagement).find('UpdateBinLocation').each(function (index) {
                                    if (itemnumber == $(this).find('item').text()) {
                                        itemExistinList = true;
                                        $(this).find('binmgt').text(binManagementFlag);
                                        $.updateLocalStorageForActivityBinMgt(g_externalid, itemQty, itemnumber, binManagementFlag, 'PI',inventoryitem.subinventoryname)
                                    }
                                });
                            } else {
                                activityBinManagement = $.createElement('UpdateBinLocations');
                            }
                            if (!itemExistinList) {
                                
                                var activityBinManagementElement = $.createElement('UpdateBinLocation');
                                activityBinManagementElement.append($.createElement('subinventory', inventoryitem.subinventoryname));
                                activityBinManagementElement.append($.createElement('item', itemnumber));
                                activityBinManagementElement.append($.createElement('quantity', (itemQty == null || "" == itemQty ? 0 : itemQty)));
                                activityBinManagementElement.append($.createElement('binmgt', binManagementFlag));
                                activityBinManagementElement.append($.createElement('action', 'PI'));
                                
                                console.log("itemQty"+itemQty);

                                try {
                                    var tempActivityBinMgt = activityBinManagement.getElementsByTagName("UpdateBinLocations")[0];
                                    tempActivityBinMgt.appendChild(activityBinManagementElement);
                                } catch (err) {
                                    activityBinManagement.append(activityBinManagementElement);
                                }
                                
                                $.updateLocalStorageForActivityBinMgt(g_externalid, itemQty, itemnumber, binManagementFlag, 'PI',inventoryitem.subinventoryname)

                            } // End added for INC2343370
                            // let activityBinLocalStorage = "activityBinManagement-" + g_externalid;
                            // console.log("activityBinMgt", activityBinManagement.outerHTML);
                            
                            // localStorage.setItem(activityBinLocalStorage,activityBinManagement.outerHTML);
                            
                        }
                        let resourceBinMgtUpdate = "resourceBinMgtUpdate-" + g_externalid;
                       
                        if(localStorage.getItem(resourceBinMgtUpdate)==null){
                            localStorage.setItem(resourceBinMgtUpdate,[]);
                        }

                        $.each(receivedData.inventoryList, function (keyP, itemP) {
                            //$(receivedData.inventoryList).each(function(keyP,itemP){
                            if (itemP.I_ITEM_NUMBER == itemnumber && (itemP.I_SUBINVENTORY == inventoryitem.subinventoryname
                                || inventoryitem.subinventoryname == receivedData.resource.external_id)
                                && itemP.invpool === 'provider') {
                                $.extend(submit_json.inventoryList, { [itemP.invid]: { "I_BIN_MANAGEMENT": binManagementFlag } });
                                $.updateLocalStorageResourceBinMgt(g_externalid,itemP.invid,binManagementFlag);
                            }
                        });

                        $.UpdateBinMgtJsonData(inventoryitem.invid, inventorycollection, binManagementFlag);
                        $.updateLocalStorageForQtyChange(uniqueinventorynumber, incCount, itemnumber, binManagementFlag);// Changes for CHG0079011- Local Storage change

                    }); // End added for CHG0075456 - Bin Locations for Field Service
                    $('#cpf_used_entered_qty_' + uniqueinventorynumber).on("change paste keyup", function () {

                        //get the id
                        var currentcontrolId = this.id;
                        //split it with __
                        var classkey = currentcontrolId.split("_");
                        //take id and update respecive object
                        var inventoryid = classkey[classkey.length - 1];

                        var enteredVal = $(this).val();

                        if (isNaN(enteredVal) || enteredVal.indexOf(' ') >= 0 || enteredVal === "") {
                            //alert('Only Numeric Values Are Allowed');
                            $(this).val(0);
                        } else {
                            $(this).val(parseInt(enteredVal));
                        }
                        var currentQty = parseInt($(this).val());
                        if (currentQty > 10000000) {
                            $(this).val(9999999);
                            currentQty = $(this).val();

                        }

                        $(this).val(currentQty);
                        $.UpdateSelectedJsonData(inventoryid, inventorycollection, currentQty);
                        // Changes for CHG0079011- Local Storage change
                        var binManagementFlag = $('#bin_mgt_chk_' + uniqueinventorynumber).is(':checked') ? "Y" : "N";
                        $.updateLocalStorageForQtyChange(uniqueinventorynumber, currentQty, itemnumber, binManagementFlag);
                    });
                });
                //close table body tag
                $("#cpf_TechnicianGrid").append('</tbody>');
            }

            

            $('#mainSectionCancelBtn').click(function () {

                this._sendPostMessageData({
                    "apiVersion": 1,
                    "method": "close",
                    "backScreen": "default",
                    "wakeupNeeded": false
                });

            }.bind(this));
            $.staticPhysicalInventoryUIElementsFunction(sub_inventoryname_collection);
        },





        /**
         * Business login on plugin wakeup (background open for sync)
         *
         * @param {Object} receivedData - JSON object that contain data from OFSC
         */
        pluginWakeup: function (receivedData) {
            this._log(window.location.host + ' WAKEUP', JSON.stringify(receivedData, null, 4));

            var wakeupData = {
                pluginWakeupCount: +localStorage.getItem('pluginWakeupCount'),
                pluginWakeupMaxCount: +localStorage.getItem('pluginWakeupMaxCount'),
                pluginWakeupDontRespondOn: +localStorage.getItem('pluginWakeupDontRespondOn')
            };

            wakeupData.pluginWakeupCount = wakeupData.pluginWakeupCount + 1;

            localStorage.setItem('pluginWakeupCount', wakeupData.pluginWakeupCount);
            localStorage.setItem('pluginWakeupMaxCount', wakeupData.pluginWakeupMaxCount);
            localStorage.setItem('pluginWakeupDontRespondOn', wakeupData.pluginWakeupDontRespondOn);

            this._log(window.location.host + ' SAVE WAKEUP DATA TO LOCAL STORAGE', JSON.stringify(wakeupData, null, 4));

            if (wakeupData.pluginWakeupDontRespondOn == wakeupData.pluginWakeupCount) {
                this._log(window.location.host + ' EMULATE NOT RESPONDING PLUGIN');

                return;
            }

            if (wakeupData.pluginWakeupCount < wakeupData.pluginWakeupMaxCount) {
                setTimeout(function () {
                    this._log(window.location.host + ' SLEEP. RETRY NEEDED');

                    this._sendPostMessageData({
                        apiVersion: 1,
                        method: 'sleep',
                        wakeupNeeded: true
                    });
                }.bind(this), 2000);
            } else {
                setTimeout(function () {
                    this._log(window.location.host + ' SLEEP. NO RETRY');

                    this._sendPostMessageData({
                        apiVersion: 1,
                        method: 'sleep',
                        wakeupNeeded: false
                    });
                }.bind(this), 12000);
            }
        },

        /**
         * Save configuration of wakeup (background open for sync) behavior for Plugin
         * to Local Storage
         *
         * @private
         */
        _saveWakeupData: function () {
            var wakeupData = {
                pluginWakeupCount: 0,
                pluginWakeupMaxCount: 0,
                pluginWakeupDontRespondOn: 0
            };

            if ($('#wakeup').is(':checked')) {
                wakeupData.pluginWakeupMaxCount = parseInt($('#repeat_count').val());

                if ($('#dont_respond').is(':checked')) {
                    wakeupData.pluginWakeupDontRespondOn = parseInt($('#dont_respond_on').val());
                }
            }

            localStorage.setItem('pluginWakeupCount', wakeupData.pluginWakeupCount);
            localStorage.setItem('pluginWakeupMaxCount', wakeupData.pluginWakeupMaxCount);
            localStorage.setItem('pluginWakeupDontRespondOn', wakeupData.pluginWakeupDontRespondOn);

            this._log(window.location.host + ' SAVE WAKEUP DATA TO LOCAL STORAGE', JSON.stringify(wakeupData, null, 4));
        },

        /**
         * Clear previous configuration of wakeup (background open for sync) behavior for Plugin
         * from the Local Storage
         *
         * @private
         */
        _clearWakeupData: function () {
            localStorage.removeItem('pluginWakeupCount');
            localStorage.removeItem('pluginWakeupMaxCount');
            localStorage.removeItem('pluginWakeupDontRespondOn');

            this._log(window.location.host + ' CLEAR WAKEUP DATA FROM LOCAL STORAGE');
        },

        addMandatoryParam: function (target, key, value) {
            key = key || '';
            value = value || '';

            var clonedElement = $('.example-property').clone().removeClass('example-property').addClass('item--mandatory');

            clonedElement.find('.key').removeClass('writable').removeAttr('contenteditable').text(key);
            clonedElement.find('.value').text(value);

            this.initChangeOfValue(clonedElement);
            this.initItemRemove(clonedElement);

            $(target).parent('.item').after(clonedElement);
        },

        initChangeOfWakeup: function (element) {

            function onWakeupChange(elem) {
                var isChecked = $(elem).is(':checked');

                if (isChecked) {
                    $(element).find('#repeat_count').prop('disabled', false);
                    $(element).find('#dont_respond').prop('disabled', false);

                    $(element).find('#wakeup_row').removeClass('wakeup-form-row--disabled');

                    onDontRespondChange($(element).find('#dont_respond'));
                } else {
                    $(element).find('#repeat_count').prop('disabled', true);
                    $(element).find('#dont_respond').prop('disabled', true);
                    $(element).find('#dont_respond_on').prop('disabled', true);

                    $(element).find('#wakeup_row').addClass('wakeup-form-row--disabled');
                    $(element).find('#dont_respond_row').addClass('wakeup-form-row--disabled');
                }
            }

            function onDontRespondChange(elem) {
                var isChecked = $(elem).is(':checked');

                if (isChecked) {
                    $(element).find('#dont_respond_on').prop('disabled', false);
                    $(element).find('#dont_respond_row').removeClass('wakeup-form-row--disabled');
                } else {
                    $(element).find('#dont_respond_on').prop('disabled', true);
                    $(element).find('#dont_respond_row').addClass('wakeup-form-row--disabled');
                }
            }

            $(element).find('#wakeup').change(function (e) {
                onWakeupChange(e.target);
            });

            $(element).find('#dont_respond').change(function (e) {
                onDontRespondChange(e.target);
            });

            onWakeupChange($(element).find('#wakeup'));
        },

        initChangeOfInventoryAction: function (element) {
            $(element).find('.select-inventory-action').on('change', function (e) {

                $(e.target).parents('.items').first().find('.item--mandatory').remove();

                switch ($(e.target).val()) {
                    case 'create':
                        this.addMandatoryParam(e.target, 'invpool');
                        this.addMandatoryParam(e.target, 'quantity');
                        this.addMandatoryParam(e.target, 'invtype');
                        this.addMandatoryParam(e.target, 'inv_aid');
                        this.addMandatoryParam(e.target, 'inv_pid');
                        break;

                    case 'delete':
                        this.addMandatoryParam(e.target, 'invid');
                        break;

                    case 'install':
                        this.addMandatoryParam(e.target, 'invid');
                        this.addMandatoryParam(e.target, 'inv_aid');
                        this.addMandatoryParam(e.target, 'quantity');
                        break;

                    case 'deinstall':
                        this.addMandatoryParam(e.target, 'invid');
                        this.addMandatoryParam(e.target, 'inv_pid');
                        this.addMandatoryParam(e.target, 'quantity');
                        break;

                    case 'undo_install':
                        this.addMandatoryParam(e.target, 'invid');
                        this.addMandatoryParam(e.target, 'quantity');
                        break;

                    case 'undo_deinstall':
                        this.addMandatoryParam(e.target, 'invid');
                        this.addMandatoryParam(e.target, 'quantity');
                        break;
                }

                this._updateResponseJSON();
            }.bind(this));
        },

        initChangeOfDataItems: function () {
            console.log(localStorage.getItem('dataItems'));
            //set checkboxes from local storage
            if (localStorage.getItem('dataItems')) {
                $('.data-items').attr('checked', true);
                $('.data-items-holder').show();

                var dataItems = JSON.parse(localStorage.getItem('dataItems'));
                console.log(dataItems);

                $('.data-items-holder input').each(function () {
                    if (dataItems.indexOf(this.value) != -1) {
                        $(this).attr('checked', true);
                    }
                });
            }

            //init handlers
            $('.data-items').on('change', function (e) {
                $('.data-items-holder').toggle();
            });
        },

        initChangeOfOpenOption: function (checkboxId, localStorageKey) {
            var optionCheckbox = $('#' + checkboxId);

            this.initLocalStorageOption(localStorageKey);

            if (localStorage.getItem(localStorageKey)) {
                optionCheckbox.attr('checked', true);
            }

            optionCheckbox.on('change', function (e) {
                if ($(this).is(':checked')) {
                    localStorage.setItem(localStorageKey, 'true');
                } else {
                    localStorage.setItem(localStorageKey, '');
                }
            });
        },

        initLocalStorageOption: function (localStorageKey) {
            if (localStorage.getItem(localStorageKey) === null) {
                localStorage.setItem(localStorageKey, 'true');
            }
        },

        initChangeOfValue: function (element) {

            $(element).find('.value__item.value__file').on('change', function (e) {
                var file = e.target.files[0];
                var container = $(e.target).closest('.item').find('.value__file_preview_container');
                var thumb = container.find('.value__file_preview');

                if (file && -1 !== $.inArray(file.type, ['image/png', 'image/jpeg', 'image/gif'])) {
                    thumb.attr('src', URL.createObjectURL(file));
                    container.show();
                } else {
                    container.hide();
                    thumb.attr('src', '');
                }
            }.bind(this));

            $(element).find('.key.writable').on('input change', function (e) {
                $(e.target).closest('.item').find('.value__item.value__file').attr('data-property-id', $(e.target).text());
            }.bind(this));

            $(element).find('.value__item.writable, .key.writable, #wakeup').on('input change', function (e) {
                $(e.target).parents('.item').addClass('edited');

                this._updateResponseJSON();
            }.bind(this));
        },

        initItemRemove: function (element) {
            $(element).find('.button--remove-item').on('click', function (e) {
                //remove item
                $(e.target).parents('.item').first().remove();

                //reindex actions
                if ($(e.target).parents('.item').first().find('.action-key').length > 0) {
                    $('.item:not(.example-action) .action-key').each(function (index) {
                        $(this).text(index);
                    });
                }

                this._updateResponseJSON();
            }.bind(this));
        },

        initCollapsableKeys: function (element) {
            $(element).find('.key').each(function (index, item) {
                if ($(item).siblings('.value').has('.items').length !== 0) {
                    $(item).addClass('clickable');
                }
            });

            $(element).find('.key').on('click', function () {
                if ($(this).siblings('.value').has('.items').length !== 0) {
                    $(this).siblings('.value').toggle();
                    $(this).toggleClass('collapsed');
                }
            });

            $(element).find('.item-expander').on('click', function (e) {
                var key = $(e.target).parents('.value').first().siblings('.key').first();

                if (key.hasClass('clickable')) {
                    key.trigger('click');
                }
            });
        },

        initAddButtons: function (element) {
            $(element).find('.button--add-property, .button--add-file-property').click(function (e) {
                var clonedElement;
                var isFileProperty = $(e.target).hasClass('button--add-file-property');

                if (isFileProperty) {
                    var entityId = 'action-' + $(e.target).parents('.item').children('.action-key').text();

                    clonedElement = $('.example-file-property').clone().removeClass('example-file-property');
                    clonedElement.find('.value__item.value__file').attr('data-entity-id', entityId);
                } else {
                    clonedElement = $('.example-property').clone().removeClass('example-property');
                }

                this.initChangeOfValue(clonedElement);
                this.initItemRemove(clonedElement);

                $(e.target).parent('.item').before(clonedElement);

                $(e.target).parents('.item').addClass('edited');

                this._updateResponseJSON();
            }.bind(this));

            $(element).find('.button--add-action').click(function (e) {
                var clonedElement = $('.example-action').clone().removeClass('example-action');
                var actionsCount = +$(e.target).parents('.item:not(.item--excluded)').find('.action-key').length;

                clonedElement.find('.action-key').text(actionsCount);

                this.initAddButtons(clonedElement);
                this.initCollapsableKeys(clonedElement);
                this.initChangeOfValue(clonedElement);
                this.initChangeOfInventoryAction(clonedElement);
                this.initItemRemove(clonedElement);

                $(e.target).parent('.item').before(clonedElement);

                $(e.target).parents('.item').addClass('edited');

                this._updateResponseJSON();
            }.bind(this));
        },

        /**
         * Render JSON object to DOM
         *
         * @param {Object} data - JSON object
         *
         * @returns {jQuery}
         */
        renderForm: function (data) {
            return this.renderCollection('data', data, true);
        },

        /**
         * Render JSON object to follow HTML:
         *
         * <div class="item">
         *     <div class="key">{key}</div>
         *     <div class="value">{value}</div>
         * </div>
         * <div class="item">
         *     <div class="key">{key}</div>
         *     <div class="value">
         *         <div class="items">
         *              <div class="item">
         *                  <div class="key">{key}</div>
         *                  <div class="value">{value}</div>
         *              </div>
         *              <div class="item">
         *                  <div class="key">{key}</div>
         *                  <div class="value">{value}</div>
         *              </div>
         *              ...
         *         </div>
         *     </div>
         * </div>
         * ...
         *
         * @param {String} key - Collection name
         * @param {Object} items - Child items of collection
         * @param {Boolean} [isWritable] - Will render as writable?
         * @param {number} [level] - Level of recursion
         * @param {string} [parentKey] - parent Key
         *
         * @returns {jQuery}
         */
        renderCollection: function (key, items, isWritable, level, parentKey) {
            var render_item = $('<div>').addClass('item');
            var render_key = $('<div>').addClass('key').text(key);
            var render_value = $('<div>').addClass('value value__collection');
            var render_items = $('<div>').addClass('items');

            isWritable = isWritable || false;
            level = level || 1;
            parentKey = parentKey || '';

            var newParentKey = key;
            var entityId = '';

            if ('activity' === key || 'activityList' == parentKey) {
                entityId = items.aid;
            } else if ('inventory' === key || 'inventoryList' == parentKey) {
                entityId = items.invid;
            }

            if (items) {
                $.each(items, function (key, value) {
                    if (value && typeof value === 'object') {
                        render_items.append(this.renderCollection(key, value, isWritable, level + 1, newParentKey));
                    } else {
                        render_items.append(this.renderItem(key, value, isWritable, level + 1, newParentKey, entityId).get(0));
                    }
                }.bind(this));
            }

            render_item.append('<div class="item-expander"></div>');
            render_item.append(render_key);

            render_value.append(render_items);
            render_item.append($('<br>'));
            render_item.append(render_value);

            return render_item;
        },

        /**
         * Render key and value to follow HTML:
         *
         * <div class="item">
         *     <div class="key">{key}</div>
         *     <div class="value">{value}</div>
         * </div>
         *
         * @param {String} key - Key
         * @param {String} value - Value
         * @param {Boolean} [isWritable] - Will render as writable?
         * @param {number} [level] - Level of recursion
         * @param {string} [parentKey] - parent Key
         *
         * @returns {jQuery}
         */
        renderItem: function (key, value, isWritable, level, parentKey, entityId) {
            var render_item = $('<div>').addClass('item');
            var render_value;
            var render_key;

            isWritable = isWritable || false;
            level = level || 1;
            parentKey = parentKey || '';

            render_key = $('<div>').addClass('key').text(key);
            render_item.append('<div class="item-expander"></div>')
                .append(render_key)
                .append('<span class="delimiter">: </span>');

            if (value === null) {
                value = '';
            }

            if (
                typeof this.renderReadOnlyFieldsByParent[parentKey] !== 'undefined' &&
                typeof this.renderReadOnlyFieldsByParent[parentKey][key] !== 'undefined' &&
                this.renderReadOnlyFieldsByParent[parentKey][key] === true
            ) {
                isWritable = false;
            }

            switch (key) {
                case "csign":
                    if (isWritable) {
                        render_value = $('<button>').addClass('button button--item-value button--generate-sign').text('Generate');
                    }
                    break;
                default:

                    var pluginInitData = false;

                    if (this._isJson(localStorage.getItem('pluginInitData'))) {
                        pluginInitData = JSON.parse(localStorage.getItem('pluginInitData'));
                    }

                    if (this.dictionary[key]) {
                        render_value = this.renderSelect(this.dictionary, key, value, isWritable).addClass('value value__item');
                    } else if (
                        pluginInitData &&
                        pluginInitData[key] &&
                        "enum" == pluginInitData[key].type &&
                        pluginInitData[key].enum
                    ) {
                        render_value = this.renderEnumSelect(pluginInitData[key].enum, key, value, isWritable).addClass('value value__item');
                    } else if (
                        pluginInitData &&
                        pluginInitData[key] &&
                        "file" == pluginInitData[key].type &&
                        "signature" !== pluginInitData[key].gui
                    ) {
                        render_value = this.renderFile(entityId, key);
                    } else {
                        render_value = $('<div>').addClass('value value__item').text(value);

                        if (isWritable) {
                            render_value.addClass('writable').attr('contenteditable', true);
                        }
                    }

                    break;
            }

            render_item.append(render_value);

            return render_item;
        },

        /**
         * Render enums with validate of outs values
         *
         * <select class="value [writable]" [disabled]>
         *     <option value="{value}" [selected]>{dictionary}</option>
         *     ...
         * </select>
         *
         * @param {Object} dictionary - Dictionary that will be used for Enum rendering
         * @param {String} key - Just field name
         * @param {String} value - Selected value
         * @param {Boolean} isWritable - Will render as writable?
         *
         * @returns {HTMLElement}
         */
        renderSelect: function (dictionary, key, value, isWritable) {
            var render_value;

            var outs = dictionary[key][value].outs;
            var allowedValues = [value].concat(outs);
            var disabled = '';

            render_value = $('<select>').css({ background: dictionary[key][value].color });

            if (!outs.length || !isWritable) {
                render_value.attr('disabled', true);
            } else {
                render_value.addClass('writable');
            }

            $.each(allowedValues, function (index, label) {
                render_value.append('<option' + (label === value ? ' selected' : '') + ' value="' + dictionary[key][label].label + '">' + dictionary[key][label].translation + '</option>');
            });

            return render_value;
        },

        renderFile: function (entityId, key) {
            var render_value = $('<div>')
                .addClass('writable value value__item value__file')
                .attr('data-entity-id', entityId)
                .attr('data-property-id', key);

            var input = $('<input type="file">').addClass('value__file_input');
            var preview =
                $('<div>').addClass('value__file_preview_container')
                    .append($('<img>').addClass('value__file_preview'));

            render_value.append(input);
            render_value.append(preview);

            return render_value;
        },

        /**
         * Render enums
         *
         * <select class="value [writable]" [disabled]>
         *     <option value="{value}" [selected]>{dictionary}</option>
         *     ...
         * </select>
         *
         * @param {Object} dictionary - Dictionary that will be used for Enum rendering
         * @param {String} key - Just field name
         * @param {String} value - Selected value
         * @param {Boolean} isWritable - Will render as writable?
         *
         * @returns {HTMLElement}
         */
        renderEnumSelect: function (dictionary, key, value, isWritable) {
            var render_value;

            var disabled = '';

            render_value = $('<select>');

            if (isWritable) {
                render_value.addClass('writable');
            } else {
                render_value.attr('disabled', true);
            }

            $.each(dictionary, function (index, label) {
                render_value.append('<option' + (index === value ? ' selected' : '') + ' value="' + index + '">' + label.text + '</option>');
            });

            return render_value;
        },

        /**
         * Generate output JSON
         *
         * @returns {Object}
         */
        generateJson: function () {
            var outputJson = {
                apiVersion: 1,
                method: 'close',
                backScreen: $('.back_method_select').val(),
                wakeupNeeded: $('#wakeup').is(':checked')
            };

            if (
                outputJson.backScreen === 'activity_by_id' ||
                outputJson.backScreen === 'end_activity' ||
                outputJson.backScreen === 'cancel_activity' ||
                outputJson.backScreen === 'notdone_activity' ||
                outputJson.backScreen === 'start_activity' ||
                outputJson.backScreen === 'suspend_activity' ||
                outputJson.backScreen === 'delay_activity'
            ) {
                $.extend(outputJson, {
                    backActivityId: $('.back_activity_id').val()
                });
            }

            //parse entity
            $.extend(outputJson, this.parseCollection($('.form')).data);

            //parse actions
            var actionsJson = this.parseCollection($('.actions-form'), true);

            if (actionsJson.actions.length > 0) {
                $.extend(outputJson, actionsJson);
            }

            delete outputJson.entity;
            delete outputJson.resource;

            return outputJson;
        },

        /**
         * Convert HTML elements to JSON
         *
         * @param {HTMLElement} rootElement - Root element that should be parsed recursively
         * @param {Boolean} [parseAllExceptExcluded] - Need to parse all elements except excluded
         *
         * @returns {Object}
         *
         * <div class="key">activity</div>
         * <div class="value value__collection">
         *     <div class="items"> <-------------------------------- rootElement !!!
         *         <div class="item edited">
         *             <div class="key">WO_COMMENTS</div>
         *             <div class="value">text_comments</div>
         *         </div>
         *         <div class="item">
         *             <div class="key">aid</div>
         *             <div class="value">4225274</div>
         *         </div>
         *         <div class="item">
         *             <div class="key">caddress</div>
         *             <div class="value">text_address</div>
         *         </div>
         *     </div>
         * </div>
         *
         * converts to:
         *
         * {
         *     "aid": "4225274",
         *     "WO_COMMENTS": "text_comments"
         * }
         *
         */
        parseCollection: function (rootElement, parseAllExceptExcluded) {
            parseAllExceptExcluded = parseAllExceptExcluded || false;

            var returnObject;

            if ($(rootElement).hasClass('items--without-key')) {
                returnObject = [];
            } else {
                returnObject = {};
            }



            $(rootElement).children('.item').each(function (itemIndex, item) {
                var parentKey;
                var valueKey;
                var value;
                var mandatoryField = false;

                var dataItemKey;

                parentKey = $(rootElement).parent().siblings('.key').get(0);
                valueKey = $(item).children('.key').get(0);
                dataItemKey = $(valueKey).text();

                //Logic of mandatory fields
                if ((parentKey !== undefined) && (
                    ('activity' === $(parentKey).text() && 'aid' === dataItemKey) || ('inventory' === $(parentKey).text() && 'invid' === dataItemKey)
                )) {
                    mandatoryField = true;
                }

                if (
                    $(item).hasClass('item') === true &&
                    (
                        $(item).hasClass('edited') === true || parseAllExceptExcluded || mandatoryField
                    ) &&
                    $(item).hasClass('item--excluded') === false
                ) {

                    value = $(item).children('.value').get(0);

                    if ($(value).children('.items').length > 0) {
                        var parsedChild = this.parseCollection($(value).children('.items').get(0), parseAllExceptExcluded);

                        if ($(rootElement).hasClass('items--without-key')) {
                            returnObject.push(parsedChild);
                        } else {
                            returnObject[dataItemKey] = parsedChild;
                        }
                    } else {
                        switch ($(value).prop("tagName")) {
                            case 'SELECT':
                                returnObject[dataItemKey] = $(value).val();
                                break;

                            case 'CANVAS':
                                returnObject[dataItemKey] = value.toDataURL();
                                break;

                            default:

                                if ($(value).hasClass('value__file')) {
                                    var fileInput = $(value).find('.value__file_input').get(0);
                                    var file = fileInput.files && fileInput.files[0];

                                    if (file) {
                                        returnObject[dataItemKey] = {
                                            fileName: file.name,
                                            fileContents: {}
                                        };
                                    }
                                } else {
                                    returnObject[dataItemKey] = $(value).text();
                                }

                                break;
                        }
                    }
                }
            }.bind(this));

            return returnObject;
        },

        _attachFiles: function (data) {
            if (!$.isPlainObject(data)) {
                return false;
            }

            $.each(data, function (dataKey, dataValue) {
                var entityId = '';

                if ('activity' === dataKey || 'inventory' === dataKey) {

                    if ('activity' === dataKey) {
                        entityId = dataValue.aid;
                    } else {
                        entityId = dataValue.invid;
                    }

                    if (!entityId) {
                        return true;
                    }

                    $.each(dataValue, function (propertyName, propertyValue) {
                        if ($.isPlainObject(propertyValue) && propertyValue.fileContents) {
                            var fileInput = $('.value__item.value__file[data-entity-id="' + entityId + '"][data-property-id="' + propertyName + '"]').find('.value__file_input').get(0);
                            var file = fileInput.files && fileInput.files[0];

                            if (file) {
                                propertyValue.fileContents = file;
                            }
                        }
                    });
                } else if ('activityList' === dataKey || 'inventoryList' === dataKey) {
                    $.each(dataValue, function (entityId, entity) {
                        $.each(entity, function (propertyName, propertyValue) {
                            if ($.isPlainObject(propertyValue) && propertyValue.fileContents) {
                                var fileInput = $('.value__item.value__file[data-entity-id="' + entityId + '"][data-property-id="' + propertyName + '"]').find('.value__file_input').get(0);
                                var file = fileInput.files && fileInput.files[0];

                                if (file) {
                                    propertyValue.fileContents = file;
                                }
                            }
                        });
                    });
                } else if ('actions' === dataKey) {
                    $.each(dataValue, function (actionId, action) {
                        if (!action.properties) {
                            return true;
                        }

                        $.each(action.properties, function (propertyName, propertyValue) {
                            if ($.isPlainObject(propertyValue) && propertyValue.fileContents) {
                                var fileInput = $('.value__item.value__file[data-entity-id="action-' + actionId + '"][data-property-id="' + propertyName + '"]').find('.value__file_input').get(0);
                                var file = fileInput.files && fileInput.files[0];

                                if (file) {
                                    propertyValue.fileContents = file;
                                }
                            }
                        });
                    });
                }
            });
        },

        /**
         * Update JSON
         *
         * @private
         */
        _updateResponseJSON: function () {
            var jsonToSend = this.generateJson();

            $('.json__response').text(JSON.stringify(jsonToSend, null, 4));
        },
        finishCallIdCallbacks: function (receivedJson) {
            let jsonObject = null;
            console.log("Call procedure:" + receivedJson);
            jsonObject = JSON.parse(receivedJson);
            console.log("Call Procedure JSONobject" + jsonObject);
            // console.log("linked_items"+ jsonObject.resultData.items[0].linkedItems);

            $.processSearchResultsFnCallBck(jsonObject);
        },

        /**
         * Initialization function
         */
        init: function () {
            if (navigator.serviceWorker) {
                this._log(window.location.host + ' Service Worker is supported');
                navigator.serviceWorker.register('physicalinventory-service-worker.js').then(function (registration) {
                    this._log(window.location.host + ' Service Worker is registered with scope: ' + registration.scope);
                    registration.addEventListener('updatefound', function () {
                        this._log(window.location.host + ' Service Worker update is found');
                        var newServiceWorker = registration.installing;
                        newServiceWorker.addEventListener('statechange', function () {
                            switch (newServiceWorker.state) {
                                case "installed":
                                    this._log(window.location.host + ' New Service Worker is installed');
                                    break;
                            }
                        }.bind(this));
                    }.bind(this));
                    navigator.serviceWorker.addEventListener('controllerchange', function () {
                        this.notifyAboutNewVersion();
                    }.bind(this));
                    this.startApplication();
                }.bind(this), function (err) {
                    this._log(window.location.host + ' Service Worker registration failed: ' + err);
                    this.startApplication();
                }.bind(this));
                return;
            } else {
                this._log(window.location.host + ' Service Worker is not supported');
            }
            this.startApplication();
        },
        startApplication: function () {
            this._log(window.location.host + ' PLUGIN HAS BEEN STARTED');
            // $('.back_method_select').on('change', function () {
            //     var selectValue = $('.back_method_select').val();
            //     if (
            //         selectValue == 'activity_by_id'||
            //         selectValue == 'end_activity' ||
            //         selectValue == 'cancel_activity' ||
            //         selectValue == 'notdone_activity' ||
            //         selectValue == 'start_activity' ||
            //         selectValue == 'suspend_activity'||
            //         selectValue == 'delay_activity'
            //     ) {
            //         $('.back_activity_id').show();
            //     } else {
            //         $('.back_activity_id').val('').hide();
            //     }
            // });

            // $('.json_local_storage_toggle').on('click', function () {
            //     $('.json__local-storage').toggle();
            // });

            // $('.json_request_toggle').on('click', function () {
            //     $('.column-item--request').toggle();
            // });

            // $('.json_response_toggle').on('click', function () {
            //     $('.column-item--response').toggle();
            // }.bind(this));


            window.addEventListener("message", this._getPostMessageData.bind(this), false);

            this.initLocalStorageOption('showHeader');
            this.initLocalStorageOption('backNavigationFlag');

            var jsonToSend = {
                apiVersion: 1,
                method: 'ready',
                sendInitData: true,
                showHeader: !!localStorage.getItem('showHeader'),
                enableBackButton: !!localStorage.getItem('backNavigationFlag')
            };

            //parse data items
            var dataItems = JSON.parse(localStorage.getItem('dataItems'));

            //var dataItems = ['resource', 'customerInventories'];

            if (dataItems) {
                $.extend(jsonToSend, { dataItems: dataItems });
            }

            this._sendPostMessageData(jsonToSend);
        },
        notifyAboutNewVersion: function () {
            this._log(window.location.host + ' New Service Worker is activated. Page refresh is needed');
            var footer = document.querySelector('.footer');
            var versionNotificationElement = document.createElement('div');
            versionNotificationElement.className = 'new-version-notification';
            versionNotificationElement.innerHTML = 'New version is detected. Please reopen the page';
            footer.appendChild(versionNotificationElement);
        }

    });
    window.OfscPlugin.getVersion = function () {
        return resourcesVersion;
    };

})(jQuery);