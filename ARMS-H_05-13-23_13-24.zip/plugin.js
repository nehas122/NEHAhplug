"use strict";

(function($) {
	window.OfscPlugin = function(debugMode) {
		this.debugMode = debugMode || false;
	};



	$.extend(window.OfscPlugin.prototype, {
		/**
		 * Dictionary of enums
		 */
		dictionary: {
			astatus: {
				pending: {
					label: 'pending',
					translation: 'Pending',
					outs: ['started', 'cancelled', 'suspended'],
					color: '#FFDE00'
				},
				started: {
					label: 'started',
					translation: 'Started',
					outs: ['complete', 'suspended', 'notdone', 'cancelled'],
					color: '#A2DE61'
				},
				complete: {
					label: 'complete',
					translation: 'Completed',
					outs: [],
					color: '#79B6EB'
				},
				suspended: {
					label: 'suspended',
					translation: 'Suspended',
					outs: [],
					color: '#9FF'
				},
				notdone: {
					label: 'notdone',
					translation: 'Not done',
					outs: [],
					color: '#60CECE'
				},
				cancelled: {
					label: 'cancelled',
					translation: 'Cancelled',
					outs: [],
					color: '#80FF80'
				}
			},
			invpool: {
				customer: {
					label: 'customer',
					translation: 'Customer',
					outs: ['deinstall'],
					color: '#04D330'
				},
				install: {
					label: 'install',
					translation: 'Installed',
					outs: ['provider'],
					color: '#00A6F0'
				},
				deinstall: {
					label: 'deinstall',
					translation: 'Deinstalled',
					outs: ['customer'],
					color: '#00F8E8'
				},
				provider: {
					label: 'provider',
					translation: 'Resource',
					outs: ['install'],
					color: '#FFE43B'
				}
			}
		},

		mandatoryActionProperties: {},

		/**
		 * Which field shouldn't be editable
		 *
		 * format:
		 *
		 * parent: {
		 *     key: true|false
		 * }
		 *
		 */
		renderReadOnlyFieldsByParent: {
			data: {
				apiVersion: true,
				method: true,
				entity: true
			},
			resource: {
				pid: true,
				pname: true,
				gender: true
			}
		},

		/**
		 * Check for string is valid JSON
		 *
		 * @param {*} str - String that should be validated
		 *
		 * @returns {boolean}
		 *
		 * @private
		 */
		_isJson: function(str) {
			try {
				JSON.parse(str);
			} catch (e) {
				return false;
			}
			return true;
		},

		/**
		 * Return origin of URL (protocol + domain)
		 *
		 * @param {String} url
		 *
		 * @returns {String}
		 *
		 * @private
		 */
		_getOrigin: function(url) {
			if (url != '') {
				if (url.indexOf("://") > -1) {
					return 'https://' + url.split('/')[2];
				} else {
					return 'https://' + url.split('/')[0];
				}
			}

			return '';
		},

		/**
		 * Return domain of URL
		 *
		 * @param {String} url
		 *
		 * @returns {String}
		 *
		 * @private
		 */
		_getDomain: function(url) {
			if (url != '') {
				if (url.indexOf("://") > -1) {
					return url.split('/')[2];
				} else {
					return url.split('/')[0];
				}
			}

			return '';
		},

		/**
		 * Sends postMessage to document.referrer
		 *
		 * @param {Object} data - Data that will be sent
		 *
		 * @private
		 */
		_sendPostMessageData: function(data) {
			var originUrl = document.referrer || (document.location.ancestorOrigins && document.location.ancestorOrigins[0]) || '';

			if (originUrl) {
				this._log(window.location.host + ' -> ' + data.method + ' ' + this._getDomain(originUrl), JSON.stringify(data, null, 4));

				parent.postMessage(data, this._getOrigin(originUrl));
			} else {
				this._log(window.location.host + ' -> ' + data.method + ' ERROR. UNABLE TO GET REFERRER');
			}
		},

		/**
		 * Handles during receiving postMessage
		 *
		 * @param {MessageEvent} event - Javascript event
		 *
		 * @private
		 */
		_getPostMessageData: function(event) {

			if (typeof event.data === 'undefined') {
				this._log(window.location.host + ' <- NO DATA ' + this._getDomain(event.origin), null, null, true);

				return false;
			}

			if (!this._isJson(event.data)) {
				this._log(window.location.host + ' <- NOT JSON ' + this._getDomain(event.origin), null, null, true);

				return false;
			}

			var data = JSON.parse(event.data);

			if (!data.method) {
				this._log(window.location.host + ' <- NO METHOD ' + this._getDomain(event.origin), null, null, true);

				return false;
			}

			this._log(window.location.host + ' <- ' + data.method + ' ' + this._getDomain(event.origin), JSON.stringify(data, null, 4));

			switch (data.method) {
				case 'init':
					this.pluginInitEnd(data);
					break;

				case 'open':
					this.pluginOpen(data);
					break;

				case 'wakeup':
					this.pluginWakeup(data);
					break;

				case 'error':
					data.errors = data.errors || {
						error: 'Unknown error'
					};
					this._showError(data.errors);
					break;

				default:
					this._log(window.location.host + ' <- UNKNOWN METHOD: ' + data.method + ' ' + this._getDomain(event.origin), null, null, true);
					break;
			}
		},

		/**
		 * Show alert with error
		 *
		 * @param {Object} errorData - Object with errors
		 *
		 * @private
		 */
		_showError: function(errorData) {
			alert(JSON.stringify(errorData, null, 4));
		},

		/**
		 * Logs to console
		 *
		 * @param {String} title - Message that will be log
		 * @param {String} [data] - Formatted data that will be collapsed
		 * @param {String} [color] - Color in Hex format
		 * @param {Boolean} [warning] - Is it warning message?
		 *
		 * @private
		 */
		_log: function(title, data, color, warning) {
			if (!this.debugMode) {
				return;
			}
			if (!color) {
				color = '#0066FF';
			}
			if (!!data) {
				console.groupCollapsed('%c[Plugin API] ' + title, 'color: ' + color + '; ' + (!!warning ? 'font-weight: bold;' : 'font-weight: normal;'));
				console.log('[Plugin API] ' + data);
				console.groupEnd();
			} else {
				console.log('%c[Plugin API] ' + title, 'color: ' + color + '; ' + (!!warning ? 'font-weight: bold;' : ''));
			}
		},

		/**
		 * Business login on plugin init
		 */
		saveToLocalStorage: function(data) {
			this._log(window.location.host + ' INIT. SET DATA TO LOCAL STORAGE', JSON.stringify(data, null, 4));

			if (data.attributeDescription) {
				localStorage.setItem('pluginInitData', JSON.stringify(data.attributeDescription));
			}
		},

		/**
		 * Business login on plugin init end
		 *
		 * @param {Object} data - JSON object that contain data from OFSC
		 */
		pluginInitEnd: function(data) {
			this.saveToLocalStorage(data);

			var messageData = {
				apiVersion: 1,
				method: 'initEnd'
			};

			if (localStorage.getItem('pluginWakeupCount') < localStorage.getItem('pluginWakeupMaxCount')) {
				this._log(window.location.host + ' UNFINISHED WAKEUP DATA FOUND IN LOCAL STORAGE');

				messageData.wakeupNeeded = true;
			}

			this._sendPostMessageData(messageData);
		},

		/**
		 * Business login on plugin open
		 *
		 * @param {Object} receivedData - JSON object that contain data from OFSC
		 */
		pluginOpen: function(receivedData) {
			console.log(receivedData);

			var ultimateBind = this;
			// var armsUrl="https://www2.cws.ricoh.co.jp/ARMS/login.jsp"; /* old URL Deprecated*/
			var armsUrl = "https://arms.glba.ricoh.co.jp/ARMS/login.jsp";  /* New URL CHG0074503 */
			var armsEligible = false;			
			if (typeof receivedData.activity != "undefined") {
				var serialNumber = receivedData.activity.A_MFG_SERIAL;
				var encSerialNumber = "";

				if (serialNumber === null) {
					serialNumber = "";
				}

				if (serialNumber != "") {
					encSerialNumber = btoa(serialNumber);
					if (encSerialNumber.endsWith("=")) {
						encSerialNumber = encSerialNumber.substring(0, encSerialNumber.length - 1);
					}
				}
				armsUrl = armsUrl + "?sn={" + encSerialNumber + "}";
				console.log("Calling ARMS from inside activity:" + armsUrl);
			}
			else {
				console.log("Calling ARMS on Activity list");
			}
			$.generateCallId = function() {
				return btoa(String.fromCharCode.apply(null, window.crypto.getRandomValues(new Uint8Array(16))));
			},

			//added for ARMS link call
			$('.button__send-procedure').click(function(e) {
				var uniquecallid = $.generateCallId();
				var jsonToSend = {
					"apiVersion": 1,
					"callId": uniquecallid,
					"method": "callProcedure",
					"procedure": "openLink",
					"params": {
						"url": armsUrl
					}
				}
				console.log("Sending to browser tab" + jsonToSend);
				//this.showProcedureJson(element, 'request', jsonToSend);
				this._sendPostMessageData(jsonToSend);
			}.bind(this));

			var closeJson = {
					"apiVersion": 1,
					"method": "close",
					"backScreen": "default",
					"wakeupNeeded": false
				};
				
			if(typeof receivedData.activity != "undefined"){
				$.extend(closeJson,{"activity": {
								"aid": receivedData.activity.aid,
								"A_ATREMOTE_FLAG": "Y"
							} });
			}
			$('.button_dismiss').click(function() {
				this._sendPostMessageData(closeJson);
			}.bind(this));

			// ARMS changes
			if (typeof receivedData.openParams.ATREMOTE == "undefined") {
				$('.button__send-procedure').trigger('click');
				$('.button_dismiss').trigger('click');
			}
			
			$('.btn-dismiss').click(function() {
				/*if(armsEligible){
				}*/
				$('.button__send-procedure').trigger('click');
				$('.button_dismiss').trigger('click');		
			}.bind(this));
		},
		/**
		 * Business login on plugin wakeup (background open for sync)
		 *
		 * @param {Object} receivedData - JSON object that contain data from OFSC
		 */
		pluginWakeup: function(receivedData) {
			this._log(window.location.host + ' WAKEUP', JSON.stringify(receivedData, null, 4));

			var wakeupData = {
				pluginWakeupCount: +localStorage.getItem('pluginWakeupCount'),
				pluginWakeupMaxCount: +localStorage.getItem('pluginWakeupMaxCount'),
				pluginWakeupDontRespondOn: +localStorage.getItem('pluginWakeupDontRespondOn')
			};

			wakeupData.pluginWakeupCount = wakeupData.pluginWakeupCount + 1;

			localStorage.setItem('pluginWakeupCount', wakeupData.pluginWakeupCount);
			localStorage.setItem('pluginWakeupMaxCount', wakeupData.pluginWakeupMaxCount);
			localStorage.setItem('pluginWakeupDontRespondOn', wakeupData.pluginWakeupDontRespondOn);

			this._log(window.location.host + ' SAVE WAKEUP DATA TO LOCAL STORAGE', JSON.stringify(wakeupData, null, 4));

			if (wakeupData.pluginWakeupDontRespondOn == wakeupData.pluginWakeupCount) {
				this._log(window.location.host + ' EMULATE NOT RESPONDING PLUGIN');

				return;
			}

			if (wakeupData.pluginWakeupCount < wakeupData.pluginWakeupMaxCount) {
				setTimeout(function() {
					this._log(window.location.host + ' SLEEP. RETRY NEEDED');

					this._sendPostMessageData({
						apiVersion: 1,
						method: 'sleep',
						wakeupNeeded: true
					});
				}.bind(this), 2000);
			} else {
				setTimeout(function() {
					this._log(window.location.host + ' SLEEP. NO RETRY');

					this._sendPostMessageData({
						apiVersion: 1,
						method: 'sleep',
						wakeupNeeded: false
					});
				}.bind(this), 12000);
			}
		},

		/**
		 * Save configuration of wakeup (background open for sync) behavior for Plugin
		 * to Local Storage
		 *
		 * @private
		 */
		_saveWakeupData: function() {
			var wakeupData = {
				pluginWakeupCount: 0,
				pluginWakeupMaxCount: 0,
				pluginWakeupDontRespondOn: 0
			};

			if ($('#wakeup').is(':checked')) {
				wakeupData.pluginWakeupMaxCount = parseInt($('#repeat_count').val());

				if ($('#dont_respond').is(':checked')) {
					wakeupData.pluginWakeupDontRespondOn = parseInt($('#dont_respond_on').val());
				}
			}

			localStorage.setItem('pluginWakeupCount', wakeupData.pluginWakeupCount);
			localStorage.setItem('pluginWakeupMaxCount', wakeupData.pluginWakeupMaxCount);
			localStorage.setItem('pluginWakeupDontRespondOn', wakeupData.pluginWakeupDontRespondOn);

			this._log(window.location.host + ' SAVE WAKEUP DATA TO LOCAL STORAGE', JSON.stringify(wakeupData, null, 4));
		},

		/**
		 * Clear previous configuration of wakeup (background open for sync) behavior for Plugin
		 * from the Local Storage
		 *
		 * @private
		 */
		_clearWakeupData: function() {
			localStorage.removeItem('pluginWakeupCount');
			localStorage.removeItem('pluginWakeupMaxCount');
			localStorage.removeItem('pluginWakeupDontRespondOn');

			this._log(window.location.host + ' CLEAR WAKEUP DATA FROM LOCAL STORAGE');
		},

		initChangeOfWakeup: function(element) {

			function onWakeupChange(elem) {
				var isChecked = $(elem).is(':checked');

				if (isChecked) {
					$(element).find('#repeat_count').prop('disabled', false);
					$(element).find('#dont_respond').prop('disabled', false);

					$(element).find('#wakeup_row').removeClass('wakeup-form-row--disabled');

					onDontRespondChange($(element).find('#dont_respond'));
				} else {
					$(element).find('#repeat_count').prop('disabled', true);
					$(element).find('#dont_respond').prop('disabled', true);
					$(element).find('#dont_respond_on').prop('disabled', true);

					$(element).find('#wakeup_row').addClass('wakeup-form-row--disabled');
					$(element).find('#dont_respond_row').addClass('wakeup-form-row--disabled');
				}
			}

			function onDontRespondChange(elem) {
				var isChecked = $(elem).is(':checked');

				if (isChecked) {
					$(element).find('#dont_respond_on').prop('disabled', false);
					$(element).find('#dont_respond_row').removeClass('wakeup-form-row--disabled');
				} else {
					$(element).find('#dont_respond_on').prop('disabled', true);
					$(element).find('#dont_respond_row').addClass('wakeup-form-row--disabled');
				}
			}

			$(element).find('#wakeup').change(function(e) {
				onWakeupChange(e.target);
			});

			$(element).find('#dont_respond').change(function(e) {
				onDontRespondChange(e.target);
			});

			onWakeupChange($(element).find('#wakeup'));
		},

		initChangeOfDataItems: function() {
			//set checkboxes from local storage
			if (localStorage.getItem('dataItems')) {
				$('.data-items').attr('checked', true);
				$('.data-items-holder').show();

				var dataItems = JSON.parse(localStorage.getItem('dataItems'));

				$('.data-items-holder input').each(function() {
					if (dataItems.indexOf(this.value) != -1) {
						$(this).attr('checked', true);
					}
				});
			}

			//init handlers
			$('.data-items').on('change', function(e) {
				$('.data-items-holder').toggle();
			});
		},

		initLocalStorageOption: function(localStorageKey) {
			if (localStorage.getItem(localStorageKey) === null) {
				localStorage.setItem(localStorageKey, 'true');
			}
		},




		/**
		 * Initialization function
		 */
		init: function() {
			if (navigator.serviceWorker) {
				this._log(window.location.host + ' Service Worker is supported');
				navigator.serviceWorker.register('ARMS-service-worker.js').then(function(registration) {
					this._log(window.location.host + ' Service Worker is registered with scope: ' + registration.scope);
					registration.addEventListener('updatefound', function() {
						this._log(window.location.host + ' Service Worker update is found');
						var newServiceWorker = registration.installing;
						newServiceWorker.addEventListener('statechange', function() {
							switch (newServiceWorker.state) {
								case "installed":
									this._log(window.location.host + ' New Service Worker is installed');
									break;
							}
						}.bind(this));
					}.bind(this));
					navigator.serviceWorker.addEventListener('controllerchange', function() {
						this.notifyAboutNewVersion();
					}.bind(this));
					this.startApplication();
				}.bind(this), function(err) {
					this._log(window.location.host + ' Service Worker registration failed: ' + err);
					this.startApplication();
				}.bind(this));
				return;
			} else {
				this._log(window.location.host + ' Service Worker is not supported');
			}
			this.startApplication();
		},
		startApplication: function() {
			this._log(window.location.host + ' PLUGIN HAS BEEN STARTED');
			$('.back_method_select').on('change', function() {
				var selectValue = $('.back_method_select').val();
				if (
					selectValue == 'activity_by_id' ||
					selectValue == 'end_activity' ||
					selectValue == 'cancel_activity' ||
					selectValue == 'notdone_activity' ||
					selectValue == 'start_activity' ||
					selectValue == 'suspend_activity' ||
					selectValue == 'delay_activity'
				) {
					$('.back_activity_id').show();
				} else {
					$('.back_activity_id').val('').hide();
				}
			});

			$('.json_local_storage_toggle').on('click', function() {
				$('.json__local-storage').toggle();
			});

			$('.json_request_toggle').on('click', function() {
				$('.column-item--request').toggle();
			});

			$('.json_response_toggle').on('click', function() {
				$('.column-item--response').toggle();
			}.bind(this));


			window.addEventListener("message", this._getPostMessageData.bind(this), false);

			this.initLocalStorageOption('showHeader');
			this.initLocalStorageOption('backNavigationFlag');

			var jsonToSend = {
				apiVersion: 1,
				method: 'ready',
				sendInitData: true,
				showHeader: !!localStorage.getItem('showHeader'),
				enableBackButton: !!localStorage.getItem('backNavigationFlag')
			};


			//parse data items
			// var dataItems = JSON.parse(localStorage.getItem('dataItems'));
			var dataItems = ['resource', 'resourceInventories', 'customerInventories'];

			if (dataItems) {
				$.extend(jsonToSend, {
					dataItems: dataItems
				});
			}

			this._sendPostMessageData(jsonToSend);
		},
		notifyAboutNewVersion: function() {
			this._log(window.location.host + ' New Service Worker is activated. Page refresh is needed');
			var footer = document.querySelector('.footer');
			var versionNotificationElement = document.createElement('div');
			versionNotificationElement.className = 'new-version-notification';
			versionNotificationElement.innerHTML = 'New version is detected. Please reopen the page';
			footer.appendChild(versionNotificationElement);
		}
	});
	window.OfscPlugin.getVersion = function() {
		return resourcesVersion;
	};

})(jQuery);