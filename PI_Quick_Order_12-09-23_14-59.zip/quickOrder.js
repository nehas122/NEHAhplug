"use strict";
(function($) {
	 window.OfscPlugin = function(debugMode) {
	        this.debugMode = debugMode || false;
	    };
	    var clientId = '',clientSecret = '', company = '', authorizationB64 = '', serviceRequestURL = '', orderPartsSRType = '';

		// CHG0075659 - MPF Phase 5 - Declaring Global variables
		var partssearchcallID = "";
		var linkedcallID = "";
		var searchflag = 0;
		var searchArray = [];
		var linkedArrayFlag=0;
		var multipleFieldsArray = [];
		var linkedflag =0;
		var islinkedcall = 0;
		var linkedItemsLength=0;
		var parentPartNo=0;
		var currItemNumber=0;
		var linkedArray =[];
		var partsContinueSearchCallId=0;
		var searchedParts = ""; // CHG0078235 - Change Starts
	    //To add log values
		var pluginName = 'PI_QuickOrder';
	    
	    $.extend(window.OfscPlugin.prototype, {
	        /**
	         * Dictionary of enums
	         */
	        dictionary: {
	            astatus: {
	                pending: {
	                    label: 'pending',
	                    translation: 'Pending',
	                    outs: ['started', 'cancelled', 'suspended'],
	                    color: '#FFDE00'
	                },
	                started: {
	                    label: 'started',
	                    translation: 'Started',
	                    outs: ['complete', 'suspended', 'notdone', 'cancelled'],
	                    color: '#A2DE61'
	                },
	                complete: {
	                    label: 'complete',
	                    translation: 'Completed',
	                    outs: [],
	                    color: '#79B6EB'
	                },
	                suspended: {
	                    label: 'suspended',
	                    translation: 'Suspended',
	                    outs: [],
	                    color: '#9FF'
	                },
	                notdone: {
	                    label: 'notdone',
	                    translation: 'Not done',
	                    outs: [],
	                    color: '#60CECE'
	                },
	                cancelled: {
	                    label: 'cancelled',
	                    translation: 'Cancelled',
	                    outs: [],
	                    color: '#80FF80'
	                }
	            },
	            invpool: {
	                customer: {
	                    label: 'customer',
	                    translation: 'Customer',
	                    outs: ['deinstall'],
	                    color: '#04D330'
	                },
	                install: {
	                    label: 'install',
	                    translation: 'Installed',
	                    outs: ['provider'],
	                    color: '#00A6F0'
	                },
	                deinstall: {
	                    label: 'deinstall',
	                    translation: 'Deinstalled',
	                    outs: ['customer'],
	                    color: '#00F8E8'
	                },
	                provider: {
	                    label: 'provider',
	                    translation: 'Resource',
	                    outs: ['install'],
	                    color: '#FFE43B'
	                }
	            }
	        },
	        mandatoryActionProperties: {},
	        /**
	         * Which field shouldn't be editable
	         * 
	         * format:
	         * parent: { key: true|false }
	         */
	        renderReadOnlyFieldsByParent: {
	            data: {
	                apiVersion: true,
	                method: true,
	                entity: true
	            },
	            resource: {
	                pid: true,
	                pname: true,
	                gender: true
	            }
	        },
	        /**
	         * Check for string is valid JSON
	         * 
	         * @param {*} str - String that should be validated
	         * @returns {boolean}
	         * @private
	         */
	        _isJson: function(str) {
	            try {
	                JSON.parse(str);
	            } catch (e) {
	                return false;
	            }
	            return true;
	        },
	        /**
	         * Return origin of URL (protocol + domain)
	         * 
	         * @param {String} url
	         * @returns {String}
	         * @private
	         */
	        _getOrigin: function(url) {
	            if (url != '') {
	                if (url.indexOf("://") > -1) {
	                    return 'https://' + url.split('/')[2];
	                } else {
	                    return 'https://' + url.split('/')[0];
	                }
	            }
	            return '';
	        },
	        /**
	         * Return domain of URL
	         * 
	         * @param {String} url
	         * @returns {String}
	         * @private
	         */
	        _getDomain: function(url) {
	            if (url != '') {
	                if (url.indexOf("://") > -1) {
	                    return url.split('/')[2];
	                } else {
	                    return url.split('/')[0];
	                }
	            }
	            return '';
	        },

			// CHG0075659 - MPF Phase 5 - getdomainurl implement
			_getDomainURL: function () {

				return document.referrer.match(/\:\/\/([^\/]+)\.(?:etadirect.com|fs.ocs.oraclecloud.com)/)[1];
			},
	        /**
	         * Sends postMessage to document.referrer
	         * 
	         * @param {Object} data - Data that will be sent
	         * @private
	         */
	        _sendPostMessageData: function(data) {
	            var originUrl = document.referrer || (document.location.ancestorOrigins &&
	                document.location.ancestorOrigins[0]) || '';
	            var isString = 'string' === typeof data;
	            if (originUrl) {
	                this._log(window.location.host + ' -> ' + (isString ? '' : data.method) + ' ' + this._getDomain(originUrl),
	                    isString ? data : JSON.stringify(data, null, 4));
	                parent.postMessage(data, this._getOrigin(originUrl));
	            } else {
	                this._log(window.location.host + ' -> ' + (isString ? '' : data.method) + ' ERROR. UNABLE TO GET REFERRER');
	            }
	        },
	        /**
	         * Handles during receiving postMessage
	         * 
	         * @param {MessageEvent} event - Javascript event
	         * @private
	         */
	        _getPostMessageData: function(event) {
	            if (typeof event.data === 'undefined') {
	                this._log(window.location.host + ' <- NO DATA ' + this._getDomain(event.origin), null, null, true);
	                return false;
	            }
	            if (!this._isJson(event.data)) {
	                this._log(window.location.host + ' <- NOT JSON ' + this._getDomain(event.origin), null, null, true);
	                return false;
	            }
	            var data = JSON.parse(event.data);
	            if (!data.method) {
	                this._log(window.location.host + ' <- NO METHOD ' + this._getDomain(event.origin), null, null, true);
	                return false;
	            }
	            this._log(window.location.host + ' <- ' + data.method + ' ' + this._getDomain(event.origin),
	                JSON.stringify(data, null, 4));
	            switch (data.method) {
	                case 'init':
	                    this.pluginInitEnd(data);
	                    break;
	                case 'open':
	                    this.pluginOpen(data);
	                    break;
	                case 'wakeup':
	                    this.pluginWakeup(data);
	                    break;
	                case 'error':
	                    data.errors = data.errors || {
	                        error: 'Unknown error'
	                    };
	                    
	                    this._showError(data.errors);
	                    break;
	                // CHG0075659 - MPF Phase 5 - To use Call Procedure Plugin API
					case 'callProcedureResult':
						this.finishCallIdCallbacks(event.data);
					break;
	                default:
	                   
	                    this._log(window.location.host + ' <- UNKNOWN METHOD: ' + data.method + ' ' +
	                        this._getDomain(event.origin), null, null, true);
	                    break;
	            }
	        },
	        /**
	         * Show alert with error
	         * 
	         * @param {Object} errorData - Object with errors
	         * @private
	         */
	        _showError: function(errorData) {
	            alert(JSON.stringify(errorData, null, 4));
	        },
	        /**
	         * Logs to console
	         * 
	         * @param {String} title - Message that will be log
	         * @param {String} [data] - Formatted data that will be collapsed
	         * @param {String} [color] - Color in Hex format
	         * @param {Boolean} [warning] - Is it warning message?
	         * 
	         * @private
	         */
	        _log: function(title, data, color, warning) {
	            if (!this.debugMode) {
	                return;
	            }
	            if (!color) {
	                color = '#0066FF';
	            }
	            if (!!data) {
	                console.groupCollapsed('%c[Plugin API] ' + title, 'color: ' + color + '; ' + (!!warning ? 'font-weight: bold;' : 'font-weight: normal;'));
	                console.log('[Plugin API] ' + data);
	                console.groupEnd();
	            } else {
	                console.log('%c[Plugin API] ' + title, 'color: ' + color + '; ' + (!!warning ? 'font-weight: bold;' : ''));
	            }
	        },
	        _getBlob: function(url) {
	            return new Promise(function(resolve, reject) {
	                var xhr = new XMLHttpRequest();
	                xhr.responseType = 'blob';
	                xhr.open('GET', url, true);
	                xhr.onreadystatechange = function() {
	                    if (xhr.readyState === xhr.DONE) {
	                        if (200 == xhr.status || 201 == xhr.status) {
	                            try {
	                                return resolve(xhr.response);
	                            } catch (e) {
	                                return reject(e);
	                            }
	                        }
	                        return reject(new Error(
	                            'Server returned an error. HTTP Status: ' + xhr.status
	                        ));
	                    }
	                };
	                xhr.send();
	            });
	        },
	        /**
	         * Business login on plugin init
	         */
	        saveToLocalStorage: function(data) {
	            this._log(window.location.host + ' INIT. SET DATA TO LOCAL STORAGE', JSON.stringify(data, null, 4));
	            var initData = {};
	            $.each(data, function(key, value) {
	                if (-1 !== $.inArray(key, ['apiVersion', 'method'])) {
	                    return true;
	                }
	                initData[key] = value;
	            });
	            localStorage.setItem('pluginInitData', JSON.stringify(initData));
	        },
	        /**
	         * Business login on plugin init end
	         * 
	         * @param {Object} data - JSON object that contain data from OFSC
	         */
	        pluginInitEnd: function(data) {
	            this.saveToLocalStorage(data);
	            var messageData = {
	                apiVersion: 1,
	                method: 'initEnd'
	            };
	            if (localStorage.getItem('pluginWakeupCount') < localStorage.getItem('pluginWakeupMaxCount')) {
	                this._log(window.location.host + ' UNFINISHED WAKEUP DATA FOUND IN LOCAL STORAGE');
	                messageData.wakeupNeeded = true;
	            }
	            this._sendPostMessageData(messageData);
	        },




	        /**
	         * Business login on plugin open
	         * 
	         * @param {Object} receivedData - JSON object that contain data from OFSC
	         */
	        pluginOpen: function(receivedData) {	
	            // Base 64 encryption for REST API calls
	            //authorizationB64 = btoa(receivedData.securedData.clientId+"@"+receivedData.securedData.company+":" + receivedData.securedData.clientSecret);	        	
	            //To add log entry
	            // $.logErrorMessages = function(errorCode,errorMessage){
		        // 	var logServiceURL = serverURL + "/PartsCatalog/rest/parts/logger";
		        // 	var payload = {
		        // 	             "pluginName": pluginName,
		        // 	             "resourceId":receivedData.resource.external_id,
		        // 	             "errorCode":errorCode,
		        // 	             "errorMessage":errorMessage,
		        // 	             "methodName": 'logErrorMessages'
		        // 	};
		    	//       $.ajax({
			    // 	      dataType: "json",
			    // 	      url: logServiceURL,
			    // 	      data: JSON.stringify(payload),
			    // 	      method: "POST",
			    // 	      processData: false,
			    // 	      contentType: 'application/json; charset=utf-8',
			    // 	      timeout: 15000,
			    // 	      success: function(response) {
			    // 	             console.log("Loger success response:" + JSON.stringify(response));
			    // 	      }.bind(this),
			    // 	      error: function(errorData) {
			    // 	             console.log("Loger error response:" + JSON.stringify(errorData));
			    // 	      }
		    	//       });
	            // };

				// Resource update URL
				
				var domainName = this._getDomainURL();
				
	        	var personalInventoryList = [];
	            var customerInventoryList = [];
	        	$('#cpf_SerachRequestField').html('');
	        	var ultimateBind = this;
				var resourceID = receivedData.resource.external_id;		//	CHG0082958 
				var area = receivedData.resource.R_AREA;				//	CHG0082958
				var managerResourceId = receivedData.resource.R_MGR_RESOURCE_NUMBER;		//	CHG0082958
	        	var resourceUpdateUrl = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/resources/" + receivedData.resource.external_id;
	    		
	    		var searchFieldCount = 25;			//CHG0082958
	    		var inventoryList = receivedData.inventoryList;
	    		var resourceId = receivedData.resource.external_id;
	    		var name = receivedData.resource.pname;
	    		var orderedItemsArray = [];
	    		var shipLocationCode = ''; // to load ship_to location on change
	    		var searchKeywordOrig = "";

				// Building Authorization headers
				var headers = {
					'Authorization':
						'Basic ' + btoa(receivedData.securedData.clientId + "@" + domainName + ":" + receivedData.securedData.clientSecret)
				};

				
		/**
		* CHG0075659 - MPF Phase 5-Ajax call to update the properties
		*/
		$.ajaxCall= function(url, payload, method, headers,isResUpdateCall) {
			// CHG0085446 Starts
			var asyncValue = true;
			if(isResUpdateCall) {
				asyncValue = false;
			}
			// CHG0085446 Ends
			$.ajax({
				dataType: "json",
				url: url,
				data: JSON.stringify(payload),
				method: method,
				async: asyncValue,
				crossDomain: true,
				headers: headers,
				processData: false,
				contentType: 'application/json; charset=utf-8',
				timeout: 15000,
				success: function(response) {
					console.log("Update Resource properties - Success messagae: " + JSON.stringify(response));
					if(isResUpdateCall){
						$.createServiceRequest();
					}
				}.bind(this),
				error: function(errorData) {
					console.log("Update Resource properties - Error messagae:" + JSON.stringify(errorData));
				}
			});
		};
			// Placing createServiceRequest & closeQuickOrder methods here - taken from $('#placeOrderButton').click function - CHG0085446
				$.createServiceRequest = function() {
					// Change Starts CHG0084717. RESOURCES_VERSION = '211.00'
					var quickOrderServiceRequestPayload = { "R_PLUGIN_ERROR": "Quick Order Service Request Method Invoked." };
					$.ajaxCall(resourceUpdateUrl, quickOrderServiceRequestPayload, "PATCH", headers, false);
					// Change Ends CHG0084717.
					
					// CHG0085446 Starts
		            var nowDate = new Date();
					var timeZoneName = receivedData.resource.time_zone;
		            var TimeZoneMapping = {
		                "19": "Alaska",
		                "6": "Arizona",
		                "4": "Central",
		                "2": "Eastern",
		                "15": "GMT",
		                "17": "Hawaii (Adak)",
		                "18": "Hawaii (Honolulu)",
		                "5": "Mountain",
		                "7": "Pacific"
		            };
		            var timeZone = TimeZoneMapping[timeZoneName];
		            console.log("timeZone param " + timeZone);
		            // CHG0085446 Ends
		            
					$.ajax({
						url: "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/serviceRequests",
						dataType: 'json',
						contentType: 'application/json; charset=utf-8',
						method: 'POST',
						async: false,
						crossDomain: true,
						headers: headers,
						timeout: 15000,
						data: JSON.stringify({
							"date": nowDate.toISOString().split('T')[0],
							"requestType": receivedData.securedData.orderPartsSRType,
							"timeZone": timeZone,
							"resourceId": resourceId,
							"name": name
						}),
						success: function(resourceData) {
							console.log("Order Parts success data-" + JSON.stringify(resourceData));
							// Change Starts CHG0083766.
							var quickOrderRequestPayload = { "R_PLUGIN_ERROR": "Quick Order Service Request. Request ID: " + resourceData.requestId + ", Request Type: " + resourceData.requestType };
							$.ajaxCall(resourceUpdateUrl, quickOrderRequestPayload, "PATCH", headers, false);
							// Change Ends CHG0083766.
							$.closeQuickOrder();
						}.bind(this),
						error: function(response) {
							var resourceErrorPayload = { "R_PLUGIN_ERROR": "Error calling workschedule api : " + response };
							$.ajaxCall(resourceUpdateUrl, resourceErrorPayload, "PATCH", headers, false);
							console.log("Order Parts error data-" + JSON.stringify(response));
							$.closeQuickOrder();
						}
					});
				};
			
				$.closeQuickOrder = function() {
					this._sendPostMessageData({
						"apiVersion": 1,
						"method": "close",
						"wakeupNeeded": false,
						"backScreen": "activity_list"
					});
				}.bind(this);
				// Placing createServiceRequest & closeQuickOrder methods here - taken from $('#placeOrderButton').click function - CHG0085446
		

	    		for (var i = 1; i <= searchFieldCount; i++) {
	    			var container = $('<div />').attr("id", "searchFieldRow" + i);
	    			container.addClass('cp_field_row');

	    			if (i != 1) {
	    				container.addClass('cp_hidden');
	    			}

	    			var searchField = $('<div/>').addClass('cp_field_value');
	    			searchField.append($('<input/>').attr({
	    				"id" : "searchKeyword" + i,
	    				"type" : "search",
	    				"placeholder" : "Search by keyword"
	    			}).addClass("cp_field_text_component form-item text-uppercase"));
	    			container.append(searchField);

	    			if (i != searchFieldCount) {
	    				var plusField = $('<div/>').addClass('cp_field_plus');
	    				plusField
	    						.append($('<input/>')
	    								.attr({
	    									"id" : "plusBun",
	    									"type" : "button",
	    									"value" : "+",
	    									"data-next" : i + 1
	    								})
	    								.addClass(
	    										"cp_plugin_button button add-inventory-search-button cl-fld-plus"));
	    				container.append(plusField);
	    			}
	    			$('#cpf_SerachRequestField').append(container);
	    		}

	    		$('.cl-fld-plus').click(function() {
	    			var next = $(this).attr("data-next");
	    			$('#searchFieldRow' + next).removeClass('cp_hidden');
	    		});
	    		
	    		// $.getLinkedPartsRestService = function(parentItemNumber) {
	    		// 	var linkedRestServiceURL = serverURL + "/PartsCatalog/rest/parts/search/linkedParts";
				// 	var linkedPartsPayload = {"searchKeyword": parentItemNumber};
				// 	 $.ajax({
				// 	    dataType: "json",
				// 	    url: linkedRestServiceURL,
				// 	    data: JSON.stringify(linkedPartsPayload),
				// 		processData: false,
				// 		contentType: 'application/json; charset=utf-8',
				// 		method: "POST",
				// 		timeout:15000,
				// 	    success: function(data) {
				// 	        console.log("Linked Items webservice response:" + JSON.stringify(data));
				// 	        $('#cpf_LinkedItems_'+parentItemNumber).empty();
				// 	        $.processSearchResultsFnCallBck(data,true,parentItemNumber);
				// 	    }.bind(this),
				// 	    error: function(errorData) {
				// 	        console.log("Linked Items webservice error:" +  JSON.stringify(errorData));
				// 	    }
				// 	});
	    		//};
	    		
	    		$.buildManualParts = function(resultantInvArray){
	    			try{
		    			var partsContainer = '', partsBody = $('<div />').addClass('cp_section_body').attr({'id':'cpf__unnamed_6_body'});;
		    			var displayManualAdditionSection = false;
		    			
		    			
					// CHG0078235 - Change Starts
		    			//	var searchKeyArray = searchKeywordOrig.split(",");
		    			var searchKeyArray = searchedParts.split(",");
					// CHG0078235 - Change Ends
				
		    			$.each(searchKeyArray, function(key,searchKeyValue){
		    				if(!resultantInvArray[searchKeyValue]){
		    					displayManualAdditionSection = true;
		    					partsContainer = $('<div />').attr({'id':'cpf_'+searchKeyValue.replace(/[/]/g,"")}).addClass('cp_wrapper');
		    					partsContainer.append($('<div />').attr({'id':'activity-inventory-left-cell-'+searchKeyValue.replace(/[/]/g,"")}).addClass('activity-inventory-left-cell'));
		    					partsContainer.children().append($('<div />').addClass('activity-inventory-part-number').append(searchKeyValue));
		    					var inventoryQtyData = $('<div />').addClass('activity-inventory-quantity-data');
		    					inventoryQtyData.append($('<div />').addClass('activity-inventory-qunatity activity-inventory-qunatity-car-stock'));
		    					inventoryQtyData.children().append($('<div />').addClass('activity-inventory-quantity-label').append('In Stock:'));
		    					inventoryQtyData.children().append($('<div />').addClass('activity-inventory-quantity-value').append('0'));
		    					
		    					var reqQtyDiv = $('<div />').addClass('activity-inventory-qunatity activity-inventory-qunatity-required-quantity');
		    					reqQtyDiv.append($('<div />').addClass('activity-inventory-quantity-label').append('Required Quantity:'));
		    					reqQtyDiv.append($('<div />').addClass('activity-inventory-quantity-value').attr({'id':'neededQtyDisplay'})
		    							.append($('<input />').addClass('max-width-70 cp_field_text_component cp_field_spinner_component form-item required-item-quantity')
		    									.attr({'id':'cpf_entered_qty','type':'number','data-item-num':searchKeyValue,'value':'0','maxlength':'3'})));
		    					inventoryQtyData.append(reqQtyDiv);
		    					partsContainer.children().append(inventoryQtyData);
		    					partsBody.append(partsContainer);
		    				}
		    			});
		    			if(displayManualAdditionSection){
		    				var manualAddition = $('<div />').addClass('cp_section manual-part-addition').attr({'id':'manual-part-addition'});
		    				manualAddition.append($('<div />').addClass('cp_section_header').attr({'id':'cpf__unnamed_6_header'}));
		    				manualAddition.children().append('Manual addition');
		    				manualAddition.children().append($('<div />').addClass('cp_text_block invitation-text').append('Part(s) Not found, please validate part number and proceed with debrief/order if valid.'));
		    				manualAddition.append(partsBody);
		    				$('#manualPartsAdditionSection').append(manualAddition);	    				
		    			}
		    			
		    			$('#manual-part-addition .required-item-quantity').on('change keyup paste',function(){
	                    	var enteredQty = parseInt($(this).val());
	                    	// resetting to 0 if user entered value is more than 999
	                      	if(enteredQty > 999){
	                      		$(this).val(0);
	                      		return false
	                      	}
	                      	// resetting to 0 for negative values
	                      	if(enteredQty < 0  || isNaN(enteredQty)) {
	    						$(this).val(0);
	    						return false;
	   						}
	                      	// To remove leading zeros
	                      	$(this).val(enteredQty);
	                    	var requiredItemNumber = $(this).attr("data-item-num");
	                    	var isItemPushed = false;
		                  	if(enteredQty > 0){
		                  		for(var l = 0; l < orderedItemsArray.length;l++){
		                  			if(orderedItemsArray[l].I_ITEM_NUMBER === requiredItemNumber) {
		                  				orderedItemsArray[l].Ordered = enteredQty;
						        		isItemPushed = true;
										break;
									}
		                  		}
		                  		if(!isItemPushed){
		                  			var orderedItems = {};
		                  			orderedItems['I_ITEM_NUMBER'] = requiredItemNumber;
	                  				orderedItems['I_ITEM_DESCRIPTION'] = '';
	                  				orderedItems['I_PRICE'] = '';
	                  				orderedItems['I_ITEM_COST'] = '';
	                  				orderedItems['Quantity'] = 0;
	                  				orderedItems['Ordered'] = enteredQty;
	                  				orderedItems['OnTheWay'] = 0;
	                  				orderedItemsArray.push(orderedItems)
		                  		}
		                  		console.log(orderedItemsArray);
		                  	}else{
		                  		for(var l = 0; l < orderedItemsArray.length;l++){
		                  			if(orderedItemsArray[l].I_ITEM_NUMBER === requiredItemNumber) {
		                  				orderedItemsArray.splice(l,1);
										break;
									}
		                  		}
		                  	}
		                  	if(orderedItemsArray.length > 0){
		                  		$('#reviewOrder').attr('disabled',false);
		                  	}else{
		                  		$('#reviewOrder').attr('disabled',true);
		                  	}
	                    });
	    			}
	    			catch(err){		

								
					 	console.log(" Exception in buildManualParts :"+err.message);
	    			}
	    		}
	    		
	    		$.buildPartsDiv = function(resultantInvArray, isLinkedParts, parentPartNumber){
	    			try{
		    			var partsContainer = '';
		    			$.each(resultantInvArray, function(resInvKey, resInvItem) {
		    				partsContainer = $('<div />').addClass('activity-inventory-grid-row').attr({'id':'cpf_'+resInvKey.replace(/[/]/g,"")});
		    				partsContainer.append($('<div />').addClass('activity-inventory-left-cell').attr({'id':'activity-inventory-left-cell-'+resInvKey.replace(/[/]/g,"")}));
		    				partsContainer.children().append($('<div />').addClass('activity-inventory-part-number').append(resInvItem.I_ITEM_NUMBER));
		    				partsContainer.children().append($('<div />').addClass('activity-inventory-description').append(resInvItem.I_ITEM_DESCRIPTION));
		    				partsContainer.children().append($('<div />').addClass('activity-inventory-price').append('(Price: $' + resInvItem.I_PRICE + ')'));
		    				if(resInvItem.I_ITEM_DISPOSITION.toLowerCase() == "returnable" || resInvItem.I_ITEM_DISPOSITION.toLowerCase() == "repairable"){
		    					partsContainer.children().append($('<div />').addClass('activity-inventory-item-is-returnable').append('(This part is returnable)'));
		    				}
		    				var maxMinDiv = $('<div />').addClass('activity-inventory-price');
		    				maxMinDiv.append('Max: ').append($('<b />').append(resInvItem.I_MAX)).append('  Min: ').append($('<b />').append(resInvItem.I_MIN));
		    				partsContainer.children().append(maxMinDiv);
		    				partsContainer.children().append($('<div />').addClass('activity-inventory-price').append($('<b />').append(' '+resInvItem.I_SUB_INV_NAMES)));
		    				var inventoryDataDiv = $('<div />').addClass('activity-inventory-quantity-data');
		    				inventoryDataDiv.append($('<div />').addClass('activity-inventory-qunatity activity-inventory-qunatity-car-stock'));
		    				inventoryDataDiv.children().append($('<div />').addClass('activity-inventory-quantity-label').append('In Stock:'));
		    				inventoryDataDiv.children().append($('<div />').addClass('activity-inventory-quantity-value').append(resInvItem.Quantity));
		    				
		    				var onTheWayDiv = $('<div />').addClass('activity-inventory-qunatity activity-inventory-qunatity-on-the-way');
		            		onTheWayDiv.append($('<div />').addClass('activity-inventory-quantity-label').append('On the Way:'));
		            		onTheWayDiv.append($('<div />').addClass('activity-inventory-quantity-value').append(resInvItem.OnTheWay));
		            		inventoryDataDiv.append(onTheWayDiv);
		    				
		    				if(resInvItem.Linked_Count > 0){
		    					var compatibelDiv = $('<div />').addClass('activity-inventory-qunatity activity-inventory-qunatity-compatible');
		    					compatibelDiv.append($('<span />').addClass('cp_plugin_link activity-inventory-dashed-link compatibleLink')
		    							.attr({'id':'compatibleLink','data-item-number':resInvKey}).append('Compatible: '+resInvItem.Linked_Count));
		    					inventoryDataDiv.append(compatibelDiv);
		    				}
		    				
		    				var requiredQtyDiv = $('<div />').addClass('activity-inventory-qunatity activity-inventory-qunatity-required-quantity');
		    				requiredQtyDiv.append($('<div />').addClass('activity-inventory-quantity-label').append('Required Quantity:'));
		    				requiredQtyDiv.append($('<div />').addClass('activity-inventory-quantity-value').attr({'id':'neededQtyDisplay'})
		    						.append($('<input />').addClass('max-width-70 cp_field_text_component cp_field_spinner_component form-item required-item-quantity')
		    								.attr({'id':'cpf_entered_needed_qty','type':'number','maxlength':'3','value':'0','data-item-number':resInvKey,'data-on-the-way':resInvItem.OnTheWay})));
		    				inventoryDataDiv.append(requiredQtyDiv);
		    				partsContainer.children().append(inventoryDataDiv);
		    				if(isLinkedParts){
		    					$('#cpf_LinkedItems_'+parentPartNumber.replace(/[/]/g,"")).append(partsContainer).removeClass('cp_hidden');
		    				}else{
		    					partsContainer.append($('<div />').addClass('cpf_grid_wrapper activity-inventory-inner-grid cp_hidden')
		    							.attr({'id':'cpf_LinkedItems_'+resInvKey.replace(/[/]/g,"")}));
		    					$('.activity-inventory-body').append(partsContainer);
		    				}
		    				
		    				//compatible link clicked:
							$('#activity-inventory-left-cell-' + resInvKey.replace(/[/]/g,"")).on('click', '#compatibleLink', function() {
								currItemNumber = resInvItem.I_ITEM_NUMBER;

								$.getLinkedPartsRestService(currItemNumber, false);
	                        });
							
							$('#activity-inventory-left-cell-' + resInvKey.replace(/[/]/g,"")).find('.required-item-quantity').on('change keyup paste',function(event){
								event.stopImmediatePropagation();
			                  	var enteredQty = parseInt($(this).val());
			                  	var onTheWay = parseInt($(this).attr('data-on-the-way'));
			                  	// resetting to 0 if user entered value is more than 999
			                  	if(enteredQty > 999){
			                  		$(this).val(0);
			                  		return false;
			                  	}
			                  	// To display soft message
			                  	if(enteredQty >100){
									alert("Value is greater than 100. Please notice.")
								}
			                  	
			                  	// resetting to 0 for negative values
			                  	if(enteredQty < 0  || isNaN(enteredQty)) {
									$(this).val(0);
									return false;
								}else{
									// To remove leading zeros
									$(this).val(enteredQty);
								}
			                    var isItemPushed = false;
			                  	if(enteredQty > 0){
			                  		$('#reviewOrder').attr('disabled',false);
			                  		for(var l = 0; l < orderedItemsArray.length;l++){
			                  			if(orderedItemsArray[l].I_ITEM_NUMBER === resInvItem.I_ITEM_NUMBER) {
			                  				orderedItemsArray.splice(l,1);
			                  				var orderedItems = {};
			                  				orderedItems['I_ITEM_NUMBER'] = resInvItem.I_ITEM_NUMBER;
			                  				orderedItems['I_ITEM_DESCRIPTION'] = resInvItem.I_ITEM_DESCRIPTION;
			                  				orderedItems['I_PRICE'] = resInvItem.I_PRICE;
			                  				orderedItems['I_ITEM_COST'] = resInvItem.I_ITEM_COST;
			                  				orderedItems['Quantity'] = resInvItem.Quantity;
			                  				orderedItems['Ordered'] = enteredQty;
			                  				orderedItems['OnTheWay'] = onTheWay;
			                  				orderedItemsArray.push(orderedItems)
							        		isItemPushed = true;
											break;
										}
			                  		}
			                  		if(!isItemPushed){
			                  			var orderedItems = {};
		                  				orderedItems['I_ITEM_NUMBER'] = resInvItem.I_ITEM_NUMBER;
		                  				orderedItems['I_ITEM_DESCRIPTION'] = resInvItem.I_ITEM_DESCRIPTION;
		                  				orderedItems['I_PRICE'] = resInvItem.I_PRICE;
		                  				orderedItems['I_ITEM_COST'] = resInvItem.I_ITEM_COST;
		                  				orderedItems['Quantity'] = resInvItem.Quantity;
		                  				orderedItems['Ordered'] = enteredQty;
		                  				orderedItems['OnTheWay'] = onTheWay;
		                  				orderedItemsArray.push(orderedItems)
			                  		}
			                  		console.log(orderedItemsArray);
			                  	}else{
			                  		for(var l = 0; l < orderedItemsArray.length;l++){
			                  			if(orderedItemsArray[l].I_ITEM_NUMBER === resInvItem.I_ITEM_NUMBER) { // Issue fix for remove items
			                  				orderedItemsArray.splice(l,1);
											break;
										}
			                  		}
			                  	}
			                  	if(orderedItemsArray.length > 0){
			                  		$('#reviewOrder').attr('disabled',false);
			                  	}else{
			                  		$('#reviewOrder').attr('disabled',true);
			                  	}
							});
							
		    			});
		    			if(!isLinkedParts){
		    				$.buildManualParts(resultantInvArray);
		    			}
		    		}
	    			catch(err){					
								
					 	console.log(" Exception in buildPartsDiv :"+err.message);
	    			}
	    			
	    		}
	    		
	    		$.processSearchResultsFnCallBck = function(data,isLinkedParts,parentPartNumber){
	    			try{
		    			var resultantInvList;
		    			var resultantInvArray = {};
		    			if(isLinkedParts){
							linkedflag=0;
		    				resultantInvList = data;
		    				$.each(resultantInvList, function(invkey, invItem) {
								console.log("****invitem:"+invItem);
		    					resultantInvArray[invItem.ITEM_NUMBER] = {
		    							I_ITEM_NUMBER : invItem.ITEM_NUMBER,
		    							I_ITEM_DESCRIPTION : invItem.ITEM_DESCRIPTION,
		    							I_PRICE : invItem.ITEM_PRICE,
		    							I_ITEM_COST : invItem.ITEM_COST,
		    							I_ITEM_DISPOSITION : 'NA',
		    							I_MIN : 0,
		    							I_MAX : 0,
		    							Quantity : 0,
		    							OnTheWay: 0,
		    							Linked_Count : 0,
		    							I_SUB_INV_NAMES : ""
		    					}
		    				})
		    			}else{
							searchflag = 0;
		    				resultantInvList = data;
		    				$.each(resultantInvList, function(invkey, invItem) {
		    					//var Quantity = parseInt(invItem.quantity);
		    					//if(isNaN(Quantity)){
		    					var Quantity = 0;
		    					//}
		    					resultantInvArray[invItem.ITEM_NUMBER] = {
		    							I_ITEM_NUMBER : invItem.ITEM_NUMBER,
		    							I_ITEM_DESCRIPTION : invItem.ITEM_DESCRIPTION,
		    							I_PRICE : invItem.ITEM_PRICE,
		    							I_ITEM_COST : invItem.ITEM_COST,
		    							I_ITEM_DISPOSITION : invItem.ITEM_DISPOSITION,
		    							I_MIN : 0,
		    							I_MAX : 0,
		    							OnTheWay: 0,
		    							Quantity : Quantity,
		    							Linked_Count : invItem.LINKED_COUNT,
		    							I_SUB_INV_NAMES : ""
		    					}
		    				});
		    			}
		    			
		    			var itemExistCount = 0;
		    			$.each(resultantInvArray, function(resInvkey, resInvItem) {
		    				itemExistCount = 0;
		    				$.each(inventoryList,function(invkey,invItem){
		    					var subInvName = "";
		                        if(invItem.I_SUBINVENTORY == resourceId){
		                        	subInvName = "CAR_STOCK";
		                        }else{
		                        	subInvName = invItem.I_SUBINVENTORY
		                        }
		    					if(resInvkey == invItem.I_ITEM_NUMBER){
		    						if(itemExistCount == 0){
		    							resultantInvArray[resInvkey].I_MIN = invItem.I_MIN;
		    							resultantInvArray[resInvkey].I_MAX = invItem.I_MAX;
		    						}
		    						var resInvItemQty = parseInt(resInvItem.Quantity);
	    							if(isNaN(resInvItemQty)){
	    								resInvItemQty = 0;
	    							}
	    							var invItemQty = parseInt(invItem.quantity);
	    							if(isNaN(invItemQty)){
	    								invItemQty = 0;
	    							}
									if ((invItem.invpool == "provider") && (invItem.invtype == "SUBINVENTORY" || invItem.invtype == "CAR_STOCK")) {
		    							resultantInvArray[resInvkey].Quantity = resInvItemQty + invItemQty;
									    if(invItemQty > 0){
									     	if("" == resultantInvArray[resInvkey].I_SUB_INV_NAMES){
									     		resultantInvArray[resInvkey].I_SUB_INV_NAMES = subInvName+"("+invItemQty+")";
									     	}else{
									     		resultantInvArray[resInvkey].I_SUB_INV_NAMES = resultantInvArray[resInvkey].I_SUB_INV_NAMES+", "+subInvName+"("+invItemQty+")";
									     	}
									    }
									}
		    						if (invItem.invpool == "customer" && (invItem.invtype == "OPEN" || invItem.invtype == "EXPECTED")) {
		    							resultantInvArray[resInvkey].OnTheWay = resInvItemQty + invItemQty;
		    						}
		    						
		    						itemExistCount = itemExistCount + 1;
		    					}
		    				});
		    				if(itemExistCount = 0){
		    					resultantInvArray[resInvkey].I_MIN = "";
		    					resultantInvArray[resInvkey].I_MAX = "";
		    				}
		    			});
		    			if(!isLinkedParts){
		    				$('.activity-inventory-body').empty();
		    				$('.found_parts_count').html(Object.keys(resultantInvArray).length);
		    			}
		    			$.buildPartsDiv(resultantInvArray,isLinkedParts,parentPartNumber);
		    		}
	    			catch(err){					
							
					 	console.log(" Exception in processSearchResultsFnCallBck :"+err.message);
	    			}
	    		};
	    		
	    		// Search Button behavior
	            $('#searchButton').click(function() {
	            	orderedItemsArray = [];
	            	searchKeywordOrig = "";
	            	for(var i = 1; i <= searchFieldCount; i++) {
	                	if($.trim($('#searchKeyword'+i).val())){
	                		if(searchKeywordOrig != null && searchKeywordOrig != ""){
	                			searchKeywordOrig = searchKeywordOrig +","+$.trim($('#searchKeyword'+i).val());
	                		}else{
	                			searchKeywordOrig = $.trim($('#searchKeyword'+i).val());
	                		}
	                	}
	                }
	            	if(searchKeywordOrig == "" || typeof searchKeywordOrig === undefined || searchKeywordOrig == null){
	    				alert("Please enter a search term.");
	    				return false;
	    			}else if(searchKeywordOrig.length < 3){
	    				alert("Please enter a search term more than 3 characters");
	    				return false;
	    			}
	            	searchedParts = searchKeywordOrig.toUpperCase();	// CHG0078235 - Change
	            	
	            	//start - CHG0075360
	                var searchKeyword = searchKeywordOrig.toLowerCase();
					
	                if(searchKeyword == 'd1272212') {
						alert('Reference: Best Practices Document-Toner Banding on the Back of Page' + '\n' +
							 'Note: Before replacing PCU, change SP2996-1 to “1” when the device is experiencing toner banding on the lead edge backside of the printed page.');
					}
					//end - CHG0075360

					//CHG0075659 - MPF Phase 5 - LOGIC TO GET MULTIPLE SEARCH ITEMS into an array
					searchArray = [];
					if (searchKeywordOrig.indexOf(',') != -1) {
						searchArray = searchKeywordOrig.split(',');
					}
	            	
	            	$('.activity-inventory-body,#partsCount,#manualPartsAdditionSection').empty();
	            	$('.activity-inventory-body').append('Loading...');
	            	$('#activityInventoryGrid').removeClass('cp_hidden');
	            	$('#reviewOrder').attr('disabled',true);
	            	searchKeywordOrig = searchKeywordOrig.toUpperCase();
	            	
	            	// var partsCatalogRestServiceURL = serverURL + "/PartsCatalog/rest/parts/search/items";
	    			// var partsCatalogPayload = {
	    			// 		"searchKeyword": searchKeywordOrig,
	    			// 		"subInvCode":null 
	    			// 		};
	    			// $.ajax({
	                //     dataType: "json",
	                //     url: partsCatalogRestServiceURL,
	                //     data: JSON.stringify(partsCatalogPayload),
	    			// 	processData: false,
	    			// 	contentType: 'application/json; charset=utf-8',
	    			// 	method: "POST",
	    			// 	timeout:20000,
	                //     success: function(data) {
	                //         console.log("Parts Catalog webservice response:" + JSON.stringify(data));
	                //         $.processSearchResultsFnCallBck(data,false,0);
	                //     }.bind(this),
	                //     error: function(errorData) {
	                //     	console.log("Parts Catalog webservice error:" +  JSON.stringify(errorData));
	                //     	$('.activity-inventory-body').append(errorData);
	                //     }
	                // });

					// CHG0075659 - MPF Phase 5 - Search Parts Plugin API logic

				$.generateCallId = function () {
					return btoa(String.fromCharCode.apply(null, window.crypto.getRandomValues(new Uint8Array(16))));
				},

				
				$.getPartsCatalogContinue = function (searchId) {
					try {
						
						//Parts Catalog Call started
						console.log("Parts Catalog Continue call started");
						var uniquecallid = $.generateCallId();
						partsContinueSearchCallId = uniquecallid;
						var jsonSearchContinueToSend = {
							"apiVersion": 1,
							"method": "callProcedure",
							"callId": uniquecallid,
							"procedure": "searchPartsContinue",
							"params": {
								"searchId": searchId
							}
						}
						console.log("Parts Catalog search call:" + jsonSearchContinueToSend);
						ultimateBind._sendPostMessageData(jsonSearchContinueToSend);

					}
					catch (err) {

						console.log("Error occurred" + err);
						var resourceErrorPayload = {"R_PLUGIN_ERROR": "Error calling iscontinue api : "+err.message};
						$.ajaxCall(resourceUpdateUrl, resourceErrorPayload, "PATCH", headers,false);
					}
					
				};
					//CHG0075659 - MPF Phase 5-getting PartsCatalog
					$.getPartsCatalog = function (searchValue) {
						
						try {
							if (searchValue != 1) {
								searchKeywordOrig = searchValue;
							}

							//Parts Catalog Call started
							console.log("Parts Catalog call started");
							var uniquecallid = $.generateCallId();
							partssearchcallID = uniquecallid;
							var jsonSearchToSend = {
								"apiVersion": 1,
								"method": "callProcedure",
								"callId": uniquecallid,
								"procedure": "searchParts",
								"params": {
									"limit": 100,
									"query": searchKeywordOrig,
									"cacheOnly": false
								}
							}
							console.log("Parts Catalog search call:" + jsonSearchToSend);
							ultimateBind._sendPostMessageData(jsonSearchToSend);

						}
						catch (err) {

							var resourceErrorPayload = {"R_PLUGIN_ERROR": "Error calling workschedule api : "+err.message};
							$.ajaxCall(resourceUpdateUrl, resourceErrorPayload, "PATCH", headers,false);
							
						}
						// CHG0075659 - MPF Phase 5 - commenting parts catalog api logic to implement plugin Call Procedure api
						// $.ajax({
						// 	dataType: "json",
						// 	url: partsCatalogRestServiceURL,
						// 	data: JSON.stringify(partsCatalogPayload),
						// 	processData: false,
						// 	contentType: 'application/json; charset=utf-8',
						// 	method: "POST",
						// 	timeout: 20000,
						// 	success: function (partsCatalogResponseData) {

						// 		console.log("Parts Catalog webservice response:" + JSON.stringify(partsCatalogResponseData));
						// 		$.processSearchResultsFnCallBck(partsCatalogResponseData);

						// 	}.bind(this),
						// 	error: function (errorData) {
						// 		console.log("Parts Catalog webservice error:" + JSON.stringify(errorData));
						// 		var partsCatalogResponseData = { "element": [], "status": "" };
						// 		$.processSearchResultsFnCallBck(partsCatalogResponseData);
						// 	}

						// });

					};

					//CHG0075659 - MPF Phase 5 - Getting linked Parts Array - on compatible click
				$.getLinkedPartsArray = function(linkedArrayData){
					
					console.log('Get Linked Parts Array Called '+linkedArrayData.fields);
					linkedItemsLength=linkedArrayData.linkedItems.length;
					linkedArray=[];
					$.each(linkedArrayData.linkedItems, function (i, a) {
						linkedArrayFlag+=1;
						console.log("Parts Catalog for Multiple Linked Parts: "+ a.label);
						linkedArray.push(a.label);
						$.getLinkedPartsRestService(a.label, true);
					});
					

				};

				// CHG0075659 - MPF Phase 5 - getting linkedParts catalog
				$.getLinkedPartsRestService = function (parentItemNumber, islinkedArrayCall) {

					linkedflag=1;
					if(!islinkedArrayCall){
						parentPartNo=parentItemNumber;
					}
					if(islinkedArrayCall){
						islinkedcall=1;
						linkedflag=0;
					}
					console.log("Linked Parts call started");
					try {
						//Parts Catalog Call started
						console.log("Parts Catalog call started");
						var uniquecallid = $.generateCallId();
						linkedcallID = uniquecallid;
						var jsonSearchToSend = {
							"apiVersion": 1,
							"method": "callProcedure",
							"callId": uniquecallid,
							"procedure": "searchParts",
							"params": {
								"limit": 100,
								"query": parentItemNumber,
								"cacheOnly": false
							}
						}
						$('#cpf_LinkedItems_'+parentItemNumber).empty();
						console.log("Sending to browser tab" + jsonSearchToSend);
						ultimateBind._sendPostMessageData(jsonSearchToSend);
					}

					catch (err) {

						var resourceErrorPayload = {"R_PLUGIN_ERROR": "Error calling workschedule api : "+err.message};
						$.ajaxCall(resourceUpdateUrl, resourceErrorPayload, "PATCH", headers,false);
					}
				};

				// CHG0075659 - MPF Phase 5 - Condition to call multiple search items 

			
				if (searchArray.length > 1) {
					$.each(searchArray, function (i, v) {
						searchflag += 1;
						
						console.log("Parts Catalog for Multiple parts: " + v);
						$.getPartsCatalog(v);
					});
				}
				else {
					// CHG0075659 - MPF Phase 5 - Condition to call single search item
					$.getPartsCatalog(1);
				}

					$('.searchOthers').removeClass('cp_hidden');		//CHG0082958
	            }.bind(this));


				//	CHG0082958 starts

				$("#searchOthers").click(function (event) {

					$.ajax({
						url: window.location.href,
						timeout: 2000,
						cache: false,
						type: 'GET',
						tryCount: 0,
						retryLimit: 3,
						success: function (successData) {
							console.log("online configuration - OtherInventories");
							var searchKeywordOrig = "";
							for (var i = 1; i <= searchFieldCount; i++) {
								if ($.trim($('#searchKeyword' + i).val())) {
									if (searchKeywordOrig != null && searchKeywordOrig != "") {
										searchKeywordOrig = searchKeywordOrig + "," + $.trim($('#searchKeyword' + i).val());
									} else {
										searchKeywordOrig = $.trim($('#searchKeyword' + i).val());
									}
								}
							}
	
							var urlParameters = "searchKeys=" + searchKeywordOrig + "&searchFieldCount=" + searchFieldCount + "&resourceId=" + resourceID + "&area=" + area + "&managerResourceId=" + managerResourceId;
							var encodeURLParameters = btoa(urlParameters);
							// CHG0075659 - MPF Phase 5 - Logic for Other Inventories navigation on button click
							var otherURL = "";
							if (domainName == "ricoh2.test") {
								otherURL = "https://jcsd.ricohonline.net";
							}
	
							if (domainName == "ricoh3.test") {
								otherURL = "https://jcsq.ricohonline.net";
							}
	
							if (domainName == "ricoh4.test") {
								otherURL = "https://jcst.ricohonline.net";
							}
	
							if (domainName == "ricoh") {
								otherURL = "https://jcsp.ricohonline.net";
							}
	
							var searchOthersURL = otherURL + "/OFSCSearchParts/RACOFSCSearchParts.jsp?" + encodeURLParameters;
							event.preventDefault();
							event.stopPropagation();
	
							window.open(searchOthersURL, '_system');
						},
						error: function (xhr, textStatus, errorThrown) {
							if (textStatus == 'timeout') {
								this.tryCount++;
								if (this.tryCount <= this.retryLimit) {
									//try again
									$.ajax(this);
									return false;
								}
								console.log("Offline configuration - OtherInventories");
								OtherInventoriesOffline();
							}
							if (xhr.status == 500) {
								console.log("Offline configuration - OtherInventories");
								OtherInventoriesOffline();
							}
							else {
								console.log("Offline configuration - OtherInventories");
								OtherInventoriesOffline();
							}
						}
					});
					function OtherInventoriesOffline() {
						alert("Parts Search in Others Inventory is not available while in an Offline condition. Check again when network connectivity is restored.");
					}
				}.bind(this));

				//	CHG0082958 ends
	
	            
	            $('#reviewOrder').click(function() {
	            	var orderedPartsDiv = '';
	            	var orderedItemCount = 0;
	            	$('#partsDiv').empty();
	            	var ordereItemCount = 0;
	            	$.each(orderedItemsArray,function(invkey,invItem){
	            		orderedPartsDiv = $('<div />').addClass('activity-inventory-grid-row');
	            		orderedPartsDiv.append($('<div />').addClass('activity-inventory-left-cell'));
	            		orderedPartsDiv.children().append($('<div />').addClass('activity-inventory-part-number').append(invItem.I_ITEM_NUMBER));
	            		orderedPartsDiv.children().append($('<div />').addClass('activity-inventory-description').append(invItem.I_ITEM_DESCRIPTION));
	            		if(!'' == invItem.I_PRICE){
	            			orderedPartsDiv.children().append($('<div />').addClass('activity-inventory-price').append('($').append(invItem.I_PRICE).append(')'));
	            		}
	            		
	            		var inventoryData = $('<div />').addClass('activity-inventory-quantity-data');
	            		inventoryData.append($('<div />').addClass('activity-inventory-qunatity activity-inventory-qunatity-car-stock'));
	            		inventoryData.children().append($('<div />').addClass('activity-inventory-quantity-label').append('In Stock:'));
	            		inventoryData.children().append($('<div />').addClass('activity-inventory-quantity-value').append(invItem.Quantity));
	            		
	            		var onTheWayDiv = $('<div />').addClass('activity-inventory-qunatity activity-inventory-qunatity-on-the-way');
	            		onTheWayDiv.append($('<div />').addClass('activity-inventory-quantity-label').append('On the Way:'));
	            		onTheWayDiv.append($('<div />').addClass('activity-inventory-quantity-value').append(invItem.OnTheWay));
	            		inventoryData.append(onTheWayDiv);
	            		
	            		var orderedItemDiv = $('<div />').addClass('activity-inventory-qunatity activity-inventory-qunatity-needed-qty');
	            		orderedItemDiv.append($('<div />').addClass('activity-inventory-quantity-label').append('Needed:'));
	            		orderedItemDiv.append($('<div />').addClass('activity-inventory-quantity-value').append(invItem.Ordered));
	            		inventoryData.append(orderedItemDiv);
	            		orderedPartsDiv.children().append(inventoryData);
	            		$('#partsDiv').append(orderedPartsDiv);
	            		ordereItemCount = ordereItemCount + parseInt(invItem.Ordered);
	            	});
	            	$('#partsCount').html(orderedItemsArray.length);
	            	$('#cpf_SectionOrderDetails_header').text('Order details ('+ordereItemCount+')');
	            	$('#searchContainer,#activityInventoryGrid,#manualPartsAdditionSection').addClass('cp_hidden');
	            	$('#resultsMainDiv,#placeOrderEditButton,#orderPartDetailsSection').removeClass('cp_hidden');
	            }.bind(this));
	            
	            $('#editOrderButton').click(function() {
	            	$('#resultsMainDiv,#placeOrderEditButton,#orderPartDetailsSection').addClass('cp_hidden');
	            	$('#searchContainer,#activityInventoryGrid,#manualPartsAdditionSection').removeClass('cp_hidden');
	            }.bind(this));
	            
	            $.processSubinventoryFnCallBck = function(invListResponseData) {
	            	try{
		        		if(invListResponseData.personalInventory != null || invListResponseData.personalInventory != ''){
		        			$.each(invListResponseData.personalInventory, function(key, personalInvData) {
		        				personalInventoryList.push(personalInvData.Inventory_Name);
		        			});
		        		}
		        		if(invListResponseData.customerInventory != null || invListResponseData.customerInventory != ''){
		        			$.each(invListResponseData.customerInventory, function(key, customerInvData) {
		        				customerInventoryList.push(customerInvData.Inventory_Name);
		        			});
		        		}	
	            	}
	    			catch(err){					
								
					 	console.log(" Exception in processSubinventoryFnCallBck :"+err.message);
	    			}
	        	}
	            
	            $.getResourceSubInventories = function(resourceNumber) {
	        		var serverURL = window.location.origin;
	        		console.log("WindLocatOrigin " + window.location.origin);
	        		var resInventoryServiceURL = serverURL + "/PartsCatalog/rest/parts/subinventory/resource";
	        		console.log("REST -getResourceSubInventories " + resInventoryServiceURL);
	        		var payload = {
	        				"resourceNumber": resourceNumber
	        		};
	        	    $.ajax({
	        			dataType: "json",
	        			url: resInventoryServiceURL,
	        			data: JSON.stringify(payload),
	        			method: "POST",
	        			processData: false,
	        			contentType: 'application/json; charset=utf-8',
	        			timeout: 15000,
	        			success: function(invListResponseData) {
	        				console.log("Subinventory List webservice success response:" + JSON.stringify(invListResponseData));
	        				$.processSubinventoryFnCallBck(invListResponseData);
	        			}.bind(this),
	        			error: function(errorData) {
	        				console.log("Subinventory List webservice error:" + JSON.stringify(errorData));
	        				var invListResponseData = {
	        					"status": 410,
	        					"message": "error",
	        					"data": {}
	        				};
	        			}
	        		});
	        	}
	            // to load the resource personal & shared sub-inventories
	           // $.getResourceSubInventories(receivedData.resource.external_id); -- THIS API CALL IS NOT GETTING USED - commented as part of CHG0075659 - MPF Phase 5
	            $('#cpf_OrderSubInventory').hide();
				$('#cpf_A_ORDER_ADDRESS_1_inner, #cpf_A_ORDER_ADDRESS_2_inner, #cpf_A_ORDER_CITY_inner, #cpf_A_ORDER_STATE_inner, #cpf_A_ORDER_POSTAL_CODE_inner').empty();
				// updating address data to order parts
				var subInventoryListNames,addressList,subInventoryList,addresses = null;
				/*$( "#cpf_OrderAddressType_inner" ).change(function() { CHG0064609 added for prod issue - Start
					if(receivedData.resource.R_SUBINVENTORY_NAME !== null && receivedData.resource.R_SUBINVENTORY_NAME !== undefined){
						subInventoryListNames = receivedData.resource.R_SUBINVENTORY_NAME;
						if(subInventoryListNames !== undefined){
							subInventoryList = subInventoryListNames.split(";");
						}
					}
					if(receivedData.resource.R_ADDRESS !== null && receivedData.resource.R_ADDRESS !== undefined){
						addressList = receivedData.resource.R_ADDRESS;
						addresses = addressList.split(",");
						var sdShipMethod = addresses[0].split('[SD]').pop().split('[AL1]').shift();
						if(sdShipMethod != 'Y'){
							$('#cpf_A_ORDER_SHIP_METHOD_inner').empty(); 
							$('#cpf_A_ORDER_SHIP_METHOD_inner').append("<option value=''></option>");
							$('#cpf_A_ORDER_SHIP_METHOD_inner').append('<option value="UPS 2ND DAY AM" >UPS 2ND DAY AM</option>');
							$('#cpf_A_ORDER_SHIP_METHOD_inner').append('<option value="UPS GROUND"  >UPS GROUND</option>');
							$('#cpf_A_ORDER_SHIP_METHOD_inner').append('<option value="UPS NEXT DAY REGULAR" >UPS NEXT DAY REGULAR</option>');
						}
					}
							
					$("#cpf_OrderSubInventory_inner").empty();
					$('#cpf_A_ORDER_ADDRESS_1_inner, #cpf_A_ORDER_ADDRESS_2_inner, #cpf_A_ORDER_CITY_inner, #cpf_A_ORDER_STATE_inner, #cpf_A_ORDER_POSTAL_CODE_inner').val('');
					var addressType = $("#cpf_OrderAddressType_inner").val();
					if(addressType == 'PERSONAL_SUBINVENTORY') {
						$("#cpf_OrderSubInventory").show();
						$("#cpf_OrderSubInventory_inner").append("<option value=''></option>");
						$("#cpf_OrderSubInventory_inner").append("<option value=\"CAR_STOCK\">Primary Sub-Inventory</option>");
						if(receivedData.resource.R_SUBINVENTORY_NAME !== null && receivedData.resource.R_SUBINVENTORY_NAME !== undefined){
							for (var i = 0; i < subInventoryList.length; i++){
								var inventoryVal = subInventoryList[i].split('[CODE]').pop().split('[TYPE]').shift();
								var tempArr = inventoryVal.split(',');
								var invPos = personalInventoryList.indexOf(tempArr[0]);
								if(invPos > -1){
									$("#cpf_OrderSubInventory_inner").append("<option value=\"" + tempArr[0] + "\">" + subInventoryList[i] + "</option>");
								}
							}
						}
					} else if(addressType == 'CUSTOMER_SUBINVENTORY') {
						$("#cpf_OrderSubInventory").show();
						$("#cpf_OrderSubInventory_inner").append("<option value=''></option>");
						if(receivedData.resource.R_SUBINVENTORY_NAME !== null && receivedData.resource.R_SUBINVENTORY_NAME !== undefined){
							for (var i = 0; i < subInventoryList.length; i++){
								var inventoryVal = subInventoryList[i].split('[CODE]').pop().split('[TYPE]').shift();
								var tempArr = inventoryVal.split(',');
								var invPos = customerInventoryList.indexOf(tempArr[0]);
								if(invPos > -1){
									$("#cpf_OrderSubInventory_inner").append("<option value=\"" + tempArr[0] + "\">" + subInventoryList[i] + "</option>");
								}
							}
						}
					}
				}.bind(this));*/
				
				
				$( "#cpf_OrderAddressType_inner" ).change(function() {
					try{
						if(receivedData.resource.R_SUBINVENTORY_NAME !== null && receivedData.resource.R_SUBINVENTORY_NAME !== undefined){
							subInventoryListNames = receivedData.resource.R_SUBINVENTORY_NAME;
	
							if(subInventoryListNames !== undefined){
			                subInventoryList = subInventoryListNames.split(";");
							}
						}
						if(receivedData.resource.R_ADDRESS !== null && receivedData.resource.R_ADDRESS !== undefined){
							addressList = receivedData.resource.R_ADDRESS;
							addresses = addressList.split(",");
								var sdShipMethod = addresses[0].split('[SD]').pop().split('[AL1]').shift(); 
								if(sdShipMethod != 'Y'){
									$('#cpf_A_ORDER_SHIP_METHOD_inner').empty(); 
										
									$('#cpf_A_ORDER_SHIP_METHOD_inner').append("<option value=''></option>");
									$('#cpf_A_ORDER_SHIP_METHOD_inner').append('<option value="UPS 2ND DAY AM" >UPS 2ND DAY AM</option>');
									$('#cpf_A_ORDER_SHIP_METHOD_inner').append('<option value="UPS GROUND"  >UPS GROUND</option>');
									$('#cpf_A_ORDER_SHIP_METHOD_inner').append('<option value="UPS NEXT DAY REGULAR" >UPS NEXT DAY REGULAR</option>');
								} 
						}
							  $("#cpf_OrderSubInventory_inner").empty();
							  $("#cpf_ShipToLocation_inner").empty();
							  $("#cpf_ShipToLocation_inner").val('');
							  $('#cpf_A_ORDER_ADDRESS_1_inner').val('');
							  $('#cpf_A_ORDER_ADDRESS_2_inner').val('');
							  $('#cpf_A_ORDER_CITY_inner').val('');
							  $('#cpf_A_ORDER_STATE_inner').val('');
							  $('#cpf_A_ORDER_POSTAL_CODE_inner').val('');
							  var addressType = $("#cpf_OrderAddressType_inner").val();
							  if(receivedData.resource.R_SUBINVENTORY_NAME !== null && receivedData.resource.R_SUBINVENTORY_NAME !== undefined){
								   if(addressType == 'MY_SUBINVENTORY'){
								  $("#cpf_OrderSubInventory" ).show();
								  $("#cpf_ShipToLocation" ).hide();
								  $("#cpf_OrderSubInventory_inner").append("<option value=''></option>");
								  for (var i = 0; i < subInventoryList.length; i++){
									var inventoryVal = subInventoryList[i].split('[CODE]').pop().split('[TYPE]').shift();
									var tempArr = inventoryVal.split(',');
									$("#cpf_OrderSubInventory_inner").append("<option value=\"" + tempArr[0] + "\">" + subInventoryList[i] + "</option>");
								  }
							  }
							  }
							  if(receivedData.resource.R_ADDRESS !== null && receivedData.resource.R_ADDRESS !== undefined){
								    if(addressType == 'MY_SHIPTO'){
								  $("#cpf_OrderSubInventory" ).hide();
			                      $("#cpf_ShipToLocation" ).show();
			                      $("#cpf_ShipToLocation_inner").append("<option value=''></option>");
								  for (var j = 0; j < addresses.length; j++){
									var str = addresses[j];
									var locationDA = str.split('[DA]').pop();
									if(!isNaN(locationDA)){
										var locationName = str.split('[AL1]').pop().split('[AL2]').shift();
										var locationCode = str.split('[CODE]').pop().split('[TYPE]').shift();
										$("#cpf_ShipToLocation_inner").append("<option value=\"" + locationCode+ "\">" + locationDA + ", " + locationName + "</option>");
									}
								  }
								}
							  }
						}
		    			catch(err){					
								
						 	console.log(" Exception in cpf_OrderAddressType_inner :"+err.message);
		    			}
					}.bind(this));

				
				
				
				
				//order subinventory dropdown behavior
				$( "#cpf_OrderSubInventory_inner" ).change(function() {
					var subInvVal =  $("#cpf_OrderSubInventory_inner").val();
					for(var i = 0; i < addresses.length; i++){
						var addressStr = addresses[i].indexOf(subInvVal);
						if(addressStr > 0 || addressStr == 0){
							var str = addresses[i];
							console.log('address contains:' + str);
							var address1 = str.split('[AL1]').pop().split('[AL2]').shift();
							var address2 = str.split('[AL2]').pop().split('[CITY]').shift();
							var city = str.split('[CITY]').pop().split('[ZIP]').shift();
							var state = str.split('[ST]').pop().split('[DA]').shift();
							var zip = str.split('[ZIP]').pop().split('[ST]').shift();

							$('#cpf_A_ORDER_ADDRESS_1_inner').val(address1);
							$('#cpf_A_ORDER_ADDRESS_2_inner').val(address2);
							$('#cpf_A_ORDER_CITY_inner').val(city);
							$('#cpf_A_ORDER_STATE_inner').val(state);
							$('#cpf_A_ORDER_POSTAL_CODE_inner').val(zip);

						}
					}
				}.bind(this));
				
				//ship to location dropdown behavior
				$( "#cpf_ShipToLocation_inner" ).change(function() {
					var shipLocationVal =  $("#cpf_ShipToLocation_inner").val();
					for(var i = 0; i < addresses.length; i++){
						var addressStr = addresses[i].indexOf(shipLocationVal);
						if(addressStr > 0 || addressStr == 0){
							var str = addresses[i];
							var address1 = str.split('[AL1]').pop().split('[AL2]').shift();
							var address2 = str.split('[AL2]').pop().split('[CITY]').shift();
							var city = str.split('[CITY]').pop().split('[ZIP]').shift();
							var state = str.split('[ST]').pop().split('[DA]').shift();
							var zip = str.split('[ZIP]').pop().split('[ST]').shift();

							$('#cpf_A_ORDER_ADDRESS_1_inner').val(address1);
							$('#cpf_A_ORDER_ADDRESS_2_inner').val(address2);
							$('#cpf_A_ORDER_CITY_inner').val(city);
							$('#cpf_A_ORDER_STATE_inner').val(state);
							$('#cpf_A_ORDER_POSTAL_CODE_inner').val(zip);

						}
					}
				}); // CHG0064609 added for prod issue - End
				
				var orderShipMethod = $('#cpf_A_ORDER_SHIP_METHOD_inner');
		        orderShipMethod.change(function () {
		            if(orderShipMethod.val() === 'SDA' || orderShipMethod.val() === 'SD'){
		                $('#cpf_A_ORDER_SHIP_OPTION').removeClass('cp_hidden');
		            }else {
		                $('#cpf_A_ORDER_SHIP_OPTION').addClass('cp_hidden');
		            }
		        }.bind(this));
		        
		        // OEM value check
				if(receivedData.resource.R_CAN_ORDER_OEM !== undefined ){
					$('#cpf_A_ORDER_OEM_CODE').removeClass('cp_hidden');
				}

				var orderTotal = 0;
				function checkOrderTotal(){
					orderTotal=0;
					$.each(orderedItemsArray,function(invkey,invItem){
						orderTotal += parseInt(invItem.Ordered) * parseInt(invItem.I_ITEM_COST);
					});
				}
				
				// $.urlParam = function(name) {
	            //     var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
	            //     return results[1] || 0;
	            // }
				
				
				
				
				$('#placeOrderButton').click(function(event){
					event.stopImmediatePropagation();
					var addressType = $('#cpf_OrderAddressType_inner').val();
					if(addressType === ''){
						alert('Please Choose Type Of Address');
						return false;
					}
					// CHG0064609 Start added for prod issue
					var orderSubInventory = "";
					if($('#cpf_ShipToLocation_inner').is(':visible')){
						orderSubInventory = $('#cpf_ShipToLocation_inner').val();
						if(orderSubInventory === ""){
							alert('Please Choose Ship To Location');
							return false;
						}
					}else if($('#cpf_OrderSubInventory_inner').is(':visible')){
						orderSubInventory = $('#cpf_OrderSubInventory_inner').val();
						if(orderSubInventory === ""){
							alert('Please Choose Sub-inventory');
							return false;
						}
					}
					// CHG0064609 End added for prod issue
					//var shipMethod = $('#cpf_A_ORDER_SHIP_METHOD_inner').text();
					var shipMethod = $('#cpf_A_ORDER_SHIP_METHOD_inner option:selected').text(); // CHG0067161 Prod Issue value coming as SD and SDA
					if(shipMethod === ''){
						alert('Please Choose Order Ship Method');
						return false;
					}
					var taskNumber = $('#cpf_A_TASK_NUMBER_inner').val();
					if(taskNumber === ''){
						alert('Please enter Task Number');
						return false;
					}
					
					
					$('#placeOrderButton').attr('disabled', true);
					var addressLine1 = $('#cpf_A_ORDER_ADDRESS_1_inner').val();
		            var addressLine2 = $('#cpf_A_ORDER_ADDRESS_2_inner').val();
		            var city = $('#cpf_A_ORDER_CITY_inner').val();
		            var state = $('#cpf_A_ORDER_STATE_inner').val();
		            var zipCode = $('#cpf_A_ORDER_POSTAL_CODE_inner').val();
		            var shipOption = $('#cpf_A_ORDER_SHIP_OPTION_inner').val();
					
					var oemVal = 'N';
		            if($('#cpf_A_ORDER_OEM_CODE_inner').is(':checked')){
		            	oemVal = 'Y';
		            }
		            
		            var R_ORDER_OVER_LIMIT = 0 ;
		            checkOrderTotal(); 
		            if(receivedData.resource.R_COST_LIMIT){
		            	var rcostLimit = parseInt(receivedData.resource.R_COST_LIMIT) ;
		            	R_ORDER_OVER_LIMIT = (orderTotal > rcostLimit)?1:0;
		            }
		            
		            /*if(orderSubInventory == 'CAR_STOCK'){ CHG0064609 added for prod issue
		            	orderSubInventory = shipLocationCode;
		            }*/
		            
		            var nowDate = new Date();
		            var orderPartsList = "";
					var orderMessage="";			// CHG0082958
		    	    var now = nowDate.toISOString();//.split('T')[0];
		            var partsOrderData = '<data><general><SOURCE_CODE>RO</SOURCE_CODE><activity_id></activity_id><external_id>'+resourceId+'</external_id><appt_number>'+taskNumber+'</appt_number></general><PartOrder>';
		            partsOrderData += '<date>'+now+'</date><A_SHIPPING_METHOD>'+shipMethod+'</A_SHIPPING_METHOD><A_PROCESS_TYPE>P</A_PROCESS_TYPE>';
		            partsOrderData += '<A_DESTINATION_CODE>'+orderSubInventory+'</A_DESTINATION_CODE><A_ORDER_POSTAL_CODE>'+zipCode+'</A_ORDER_POSTAL_CODE>';
		            partsOrderData += '<A_PICKUPCOURIER_FLAG>'+shipOption+'</A_PICKUPCOURIER_FLAG><A_ORDER_STATE>'+state+'</A_ORDER_STATE>';
		            partsOrderData += '<A_ORDER_CITY>'+city+'</A_ORDER_CITY><A_ORDER_ADDRESS_1>'+addressLine1+'</A_ORDER_ADDRESS_1>';
		            partsOrderData += '<A_ORDER_ADDRESS_2>'+addressLine2+'</A_ORDER_ADDRESS_2><A_PARTS_ORDER_CALLHEADERKEY>CQ</A_PARTS_ORDER_CALLHEADERKEY><cname></cname>';
		            partsOrderData += '<A_ORDER_OEM>'+oemVal+'</A_ORDER_OEM>';
		            partsOrderData += '<A_EQUIPMENT_NUMBER></A_EQUIPMENT_NUMBER><A_SUBINVENTORY_CODE>'+orderSubInventory+'</A_SUBINVENTORY_CODE>';
		            $.each(orderedItemsArray,function(invkey,invItem){
		            	partsOrderData += '<parts><A_ITEM_NO>'+invItem.I_ITEM_NUMBER+'</A_ITEM_NO><A_QUANTITY>'+invItem.Ordered+'</A_QUANTITY><OEM></OEM></parts>';
		            	orderPartsList += 'Part Number '+invItem.I_ITEM_NUMBER+', Quantity '+invItem.Ordered+', Part Cost '+ invItem.I_ITEM_COST+'  ';
						orderMessage +='Part Number: '+invItem.I_ITEM_NUMBER+',\nDescription: '+invItem.I_ITEM_DESCRIPTION+ ',\nQuantity: '+invItem.Ordered+',\nPrice: $'+ invItem.I_PRICE+'\n\n  '; 	//CHG0082958
					});
		            partsOrderData += '</PartOrder></data>';

					var rPayload={
						"R_QUICK_ORDER_DATA": partsOrderData,
						"R_QUICK_PARTS_LIST" : orderPartsList,
						"R_ORDER_OVER_LIMIT" : R_ORDER_OVER_LIMIT,
						"R_QUICK_ORDER_MSG_LIST": orderMessage				//CHG0082958
					};

					$.ajaxCall(resourceUpdateUrl, rPayload, "PATCH", headers, true);
					
					// Repositioned createServiceRequest and closeQuickOrder method which was placed here previously - CHG0085446
					
				}.bind(this));
				this.initAddButtons(document);
	        },
	        /**
	         * Business login on plugin wakeup (background open for sync)
	         * 
	         * @param {Object} receivedData - JSON object that contain data from OFSC
	         */
	        pluginWakeup: function(receivedData) {
	            this._log(window.location.host + ' WAKEUP', JSON.stringify(receivedData, null, 4));
	            var wakeupData = {
	                pluginWakeupCount: +localStorage.getItem('pluginWakeupCount'),
	                pluginWakeupMaxCount: +localStorage.getItem('pluginWakeupMaxCount'),
	                pluginWakeupDontRespondOn: +localStorage.getItem('pluginWakeupDontRespondOn'),
	                pluginWakeupChangeIcon: JSON.parse(localStorage.getItem('pluginWakeupChangeIcon'))
	            };
	            wakeupData.pluginWakeupCount = wakeupData.pluginWakeupCount + 1;
	            localStorage.setItem('pluginWakeupCount', wakeupData.pluginWakeupCount);
	            localStorage.setItem('pluginWakeupMaxCount', wakeupData.pluginWakeupMaxCount);
	            localStorage.setItem('pluginWakeupDontRespondOn', wakeupData.pluginWakeupDontRespondOn);
	            localStorage.setItem('pluginWakeupChangeIcon', wakeupData.pluginWakeupChangeIcon);
	            this._log(window.location.host + ' SAVE WAKEUP DATA TO LOCAL STORAGE', JSON.stringify(wakeupData, null,
	                4));
	            if (wakeupData.pluginWakeupDontRespondOn == wakeupData.pluginWakeupCount) {
	                this._log(window.location.host + ' EMULATE NOT RESPONDING PLUGIN');
	                return;
	            }
	            var iconUrl = './online.svg';
	            var iconPromise = wakeupData.pluginWakeupChangeIcon ? this._getBlob(iconUrl) : Promise.resolve(null);
	            iconPromise.then(function(iconFile) {
	                var iconDataParams = {};
	                if (iconFile) {
	                    iconDataParams.iconData = {
	                        text: '' + wakeupData.pluginWakeupCount,
	                        image: iconFile
	                    };
	                }
	                if (wakeupData.pluginWakeupCount < wakeupData.pluginWakeupMaxCount) {
	                    setTimeout(function() {
	                        this._log(window.location.host + ' SLEEP. RETRY NEEDED');
	                        this._sendPostMessageData($.extend({
	                            apiVersion: 1,
	                            method: 'sleep',
	                            wakeupNeeded: true
	                        }, iconDataParams));
	                    }.bind(this), 2000);
	                } else {
	                    setTimeout(function() {
	                        this._log(window.location.host + ' SLEEP. NO RETRY');
	                        this._sendPostMessageData($.extend({
	                            apiVersion: 1,
	                            method: 'sleep',
	                            wakeupNeeded: false
	                        }, iconDataParams));
	                    }.bind(this), 12000);
	                }
	            }.bind(this)).catch(function() {
	                this._log('Unable to load icon file "' + iconUrl + '"', null, null, true);
	            }.bind(this));
	        },
	        /**
	         * Save configuration of wakeup (background open for sync) behavior for
	         * Plugin to Local Storage
	         * 
	         * @private
	         */
	        _saveWakeupData: function() {
	            var wakeupData = {
	                pluginWakeupCount: 0,
	                pluginWakeupMaxCount: 0,
	                pluginWakeupDontRespondOn: 0,
	                pluginWakeupChangeIcon: false
	            };
	            if ($('#wakeup').is(':checked')) {
	                wakeupData.pluginWakeupMaxCount = parseInt($('#repeat_count').val());
	                if ($('#dont_respond').is(':checked')) {
	                    wakeupData.pluginWakeupDontRespondOn = parseInt($('#dont_respond_on').val());
	                }
	                if ($('#wakeup_change_icon').is(':checked')) {
	                    wakeupData.pluginWakeupChangeIcon = true;
	                }
	            }
	            localStorage.setItem('pluginWakeupCount', wakeupData.pluginWakeupCount);
	            localStorage.setItem('pluginWakeupMaxCount', wakeupData.pluginWakeupMaxCount);
	            localStorage.setItem('pluginWakeupDontRespondOn', wakeupData.pluginWakeupDontRespondOn);
	            localStorage.setItem('pluginWakeupChangeIcon', wakeupData.pluginWakeupChangeIcon);
	            this._log(window.location.host + ' SAVE WAKEUP DATA TO LOCAL STORAGE', JSON.stringify(wakeupData, null,
	                4));
	        },
	        /**
	         * Clear previous configuration of wakeup (background open for sync)
	         * behavior for Plugin from the Local Storage
	         * 
	         * @private
	         */
	        _clearWakeupData: function() {
	            localStorage.removeItem('pluginWakeupCount');
	            localStorage.removeItem('pluginWakeupMaxCount');
	            localStorage.removeItem('pluginWakeupDontRespondOn');
	            localStorage.removeItem('pluginWakeupChangeIcon');
	            this._log(window.location.host + ' CLEAR WAKEUP DATA FROM LOCAL STORAGE');
	        },
	        addMandatoryParam: function(target, key, value) {
	            key = key || '';
	            value = value || '';
	            var clonedElement = $('.example-property').clone().removeClass('example-property').addClass('item--mandatory');
	            clonedElement.find('.key').removeClass('writable').removeAttr('contenteditable').text(key);
	            clonedElement.find('.value').text(value);
	            this.initChangeOfValue(clonedElement);
	            this.initItemRemove(clonedElement);
	            $(target).parent('.item').after(clonedElement);
	        },
	        initChangeOfWakeup: function(element) {
	            function onWakeupChange(elem) {
	                var isChecked = $(elem).is(':checked');
	                if (isChecked) {
	                    $(element).find('#repeat_count').prop('disabled', false);
	                    $(element).find('#dont_respond').prop('disabled', false);
	                    $(element).find('#wakeup_change_icon').prop('disabled', false);
	                    $(element).find('#wakeup_row').removeClass('wakeup-form-row--disabled');
	                    onDontRespondChange($(element).find('#dont_respond'));
	                    onWakeupIconChange($(element).find('#wakeup_change_icon'));
	                } else {
	                    $(element).find('#repeat_count').prop('disabled', true);
	                    $(element).find('#dont_respond').prop('disabled', true);
	                    $(element).find('#dont_respond_on').prop('disabled', true);
	                    $(element).find('#wakeup_change_icon').prop('disabled', true);
	                    $(element).find('#wakeup_row').addClass('wakeup-form-row--disabled');
	                    $(element).find('#dont_respond_row').addClass('wakeup-form-row--disabled');
	                    $(element).find('#wakeup_change_icon_row').addClass('wakeup-form-row--disabled');
	                }
	            }

	            function onDontRespondChange(elem) {
	                var isChecked = $(elem).is(':checked');
	                if (isChecked) {
	                    $(element).find('#dont_respond_on').prop('disabled', false);
	                    $(element).find('#dont_respond_row').removeClass('wakeup-form-row--disabled');
	                } else {
	                    $(element).find('#dont_respond_on').prop('disabled', true);
	                    $(element).find('#dont_respond_row').addClass('wakeup-form-row--disabled');
	                }
	            }

	            function onWakeupIconChange(elem) {
	                var isChecked = $(elem).is(':checked');
	                if (isChecked) {
	                    $(element).find('#wakeup_change_icon_row').removeClass('wakeup-form-row--disabled');
	                } else {
	                    $(element).find('#wakeup_change_icon_row').addClass('wakeup-form-row--disabled');
	                }
	            }
	            $(element).find('#wakeup').change(function(e) {
	                onWakeupChange(e.target);
	            });
	            $(element).find('#dont_respond').change(function(e) {
	                onDontRespondChange(e.target);
	            });
	            $(element).find('#wakeup_change_icon').change(function(e) {
	                onWakeupIconChange(e.target);
	            });
	            onWakeupChange($(element).find('#wakeup'));
	        },
	        initChangeOfInventoryAction: function(element) {
	            $(element).find('.select-inventory-action').on('change', function(e) {
	                $(e.target).parents('.items').first().find('.item--mandatory').remove();
	                switch ($(e.target).val()) {
	                    case 'create':
	                        this.addMandatoryParam(e.target, 'invpool');
	                        this.addMandatoryParam(e.target, 'quantity');
	                        this.addMandatoryParam(e.target, 'invtype');
	                        this.addMandatoryParam(e.target, 'inv_aid');
	                        this.addMandatoryParam(e.target, 'inv_pid');
	                        break;
	                    case 'delete':
	                        this.addMandatoryParam(e.target, 'invid');
	                        break;
	                    case 'install':
	                        this.addMandatoryParam(e.target, 'invid');
	                        this.addMandatoryParam(e.target, 'inv_aid');
	                        this.addMandatoryParam(e.target, 'quantity');
	                        break;
	                    case 'deinstall':
	                        this.addMandatoryParam(e.target, 'invid');
	                        this.addMandatoryParam(e.target, 'inv_pid');
	                        this.addMandatoryParam(e.target, 'quantity');
	                        break;
	                    case 'undo_install':
	                        this.addMandatoryParam(e.target, 'invid');
	                        this.addMandatoryParam(e.target, 'quantity');
	                        break;
	                    case 'undo_deinstall':
	                        this.addMandatoryParam(e.target, 'invid');
	                        this.addMandatoryParam(e.target, 'quantity');
	                        break;
	                }
	                this._updateResponseJSON();
	            }.bind(this));
	        },
	        initChangeOfDataItems: function() {
	            // set checkboxes from local storage
	            if (localStorage.getItem('dataItems')) {
	                $('.data-items').attr('checked', true);
	                $('.data-items-holder').show();
	                var dataItems = JSON.parse(localStorage.getItem('dataItems'));
	                $('.data-items-holder input').each(function() {
	                    if (dataItems.indexOf(this.value) != -1) {
	                        $(this).attr('checked', true);
	                    }
	                });
	            }
	            // init handlers
	            $('.data-items').on('change', function(e) {
	                $('.data-items-holder').toggle();
	            });
	        },
	        initChangeOfOpenOption: function(checkboxId, localStorageKey) {
	            var optionCheckbox = $('#' + checkboxId);
	            this.initLocalStorageOption(localStorageKey);
	            if (localStorage.getItem(localStorageKey)) {
	                optionCheckbox.attr('checked', true);
	            }
	            optionCheckbox.on('change', function(e) {
	                if ($(this).is(':checked')) {
	                    localStorage.setItem(localStorageKey, 'true');
	                } else {
	                    localStorage.setItem(localStorageKey, '');
	                }
	            });
	        },
	        initLocalStorageOption: function(localStorageKey) {
	            if (localStorage.getItem(localStorageKey) === null) {
	                localStorage.setItem(localStorageKey, 'true');
	            }
	        },
	        initFileInputPreview: function(element, mimeTypes) {
	            $(element).find('.value__item.value__file').on('change', function(e) {
	                var inputElem = e.target;
	                var file = inputElem.files[0];
	                var container = $(inputElem).closest('.item').find('.value__file_preview_container');
	                var thumb = container.find('.value__file_preview');
	                var mimeTypes = ['image/png', 'image/jpeg', 'image/gif'];
	                if ($(inputElem).hasClass('image_file')) {
	                    mimeTypes = $(inputElem).attr('accept').split(',');
	                }
	                if (file && -1 !== $.inArray(file.type, mimeTypes)) {
	                    thumb.attr('src', URL.createObjectURL(file));
	                    container.show();
	                } else {
	                    container.hide();
	                    thumb.attr('src', '');
	                }
	            }.bind(this));
	        },
	        initChangeOfValue: function(element) {
	            this.initFileInputPreview(element);
	            $(element).find('.key.writable').on('input textinput change', function(e) {
	                $(e.target).closest('.item').find('.value__item.value__file').attr('data-property-id', $(e.target).text());
	            }.bind(this));
	            $(element).find('.value__item.writable, .key.writable, #wakeup').on('input textinput change', function(e) {
	                $(e.target).parents('.item').addClass('edited');
	                this._updateResponseJSON();
	            }.bind(this));
	        },
	        initItemRemove: function(element) {
	            $(element).find('.button--remove-item').on('click', function(e) {
	                // remove item
	                $(e.target).parents('.item').first().remove();
	                // reindex actions
	                if ($(e.target).parents('.item').first().find('.action-key').length > 0) {
	                    $('.item:not(.example-action) .action-key').each(function(index) {
	                        $(this).text(index);
	                    });
	                }
	                this._updateResponseJSON();
	            }.bind(this));
	        },
	        initCollapsableKeys: function(element) {
	            $(element).find('.key').each(function(index, item) {
	                if ($(item).siblings('.value').has('.items').length !== 0) {
	                    $(item).addClass('clickable');
	                }
	            });
	            $(element).find('.key').on('click', function() {
	                if ($(this).siblings('.value').has('.items').length !== 0) {
	                    $(this).siblings('.value').toggle();
	                    $(this).toggleClass('collapsed');
	                }
	            });
	            $(element).find('.item-expander').on('click', function(e) {
	                var key = $(e.target).parents('.value').first().siblings('.key').first();
	                if (key.hasClass('clickable')) {
	                    key.trigger('click');
	                }
	            });
	        },
	        initAddButtons: function(element) {
	            $(element).find('.button--add-property, .button--add-file-property').click(function(e) {
	                var clonedElement;
	                var isFileProperty = $(e.target).hasClass('button--add-file-property');
	                if (isFileProperty) {
	                    var entityId = 'action-' + $(e.target).parents('.item').children('.action-key').text();
	                    clonedElement = $('.example-file-property').clone().removeClass('example-file-property');
	                    clonedElement.find('.value__item.value__file').attr('data-entity-id', entityId);
	                } else {
	                    clonedElement = $('.example-property').clone().removeClass('example-property');
	                }
	                this.initChangeOfValue(clonedElement);
	                this.initItemRemove(clonedElement);
	                $(e.target).parent('.item').before(clonedElement);
	                $(e.target).parents('.item').addClass('edited');
	                this._updateResponseJSON();
	            }.bind(this));
	            $(element).find('.button--add-action').click(function(e) {
	                var clonedElement = $('.example-action').clone().removeClass('example-action');
	                var actionsCount = +$(e.target).parents('.item:not(.item--excluded)').find('.action-key').length;
	                clonedElement.find('.action-key').text(actionsCount);
	                this.initAddButtons(clonedElement);
	                this.initCollapsableKeys(clonedElement);
	                this.initChangeOfValue(clonedElement);
	                this.initChangeOfInventoryAction(clonedElement);
	                this.initItemRemove(clonedElement);
	                $(e.target).parent('.item').before(clonedElement);
	                $(e.target).parents('.item').addClass('edited');
	                this._updateResponseJSON();
	            }.bind(this));
	        },
	        initProcedureActions: function(element) {
	            $(element).find('.button__send-procedure').click(function(e) {
	                var jsonToSend = $(element).find('.json__procedure-new').text().replace(/%%uniqueId%%/g,
	                    this.generateCallId());
	                this.showProcedureJson(element, 'request', jsonToSend);
	                this._sendPostMessageData(jsonToSend);
	            }.bind(this));
	        },
	        processProcedureResult: function(element, receivedJson) {
	            this.showProcedureJson(element, 'response', receivedJson);
	        },
	        /**
	         * @param {Element} element - DOM element whose children will be affected
	         * 
	         * @param {String} jsonType - 'request' or 'response'
	         * @param {String} json
	         */
	        showProcedureJson: function(element, jsonType, json) {
	            if ('request' !== jsonType && 'response' !== jsonType) {
	                console.error('Unknown jsonType', jsonType);
	            }
	            var jsonList = $(element).find('.procedures-json-list');
	            var eventTime = this.getCurrentTime();
	            var callId = '';
	            try {
	                var jsonObject = JSON.parse(json);
	                callId = jsonObject.callId || '';
	                json = JSON.stringify(jsonObject, null, 4);
	            } catch (e) {}
	            var procedureContainer = $(element).find('.section__procedure[data-call-id="' + callId + '"]');
	            var isContainerExisted = !!(callId && procedureContainer.length);
	            if (!isContainerExisted) {
	                procedureContainer = $('.section__procedure-example').clone().removeClass('section__procedure-example');
	            }
	            var containerDataSet = procedureContainer.get(0).dataset;
	            containerDataSet.callId = callId;
	            containerDataSet[jsonType + 'Time'] = eventTime;
	            procedureContainer.find('.json__procedure-' + jsonType).text(json).removeClass('json__procedure-hidden');
	            procedureContainer.find('.procedure-' + jsonType + '-time').text(eventTime);
	            if (!isContainerExisted) {
	                var procedureNumber = ++jsonList.get(0).dataset.procedureCount;
	                containerDataSet.procedureNumber = '' + procedureNumber;
	                procedureContainer.find('.procedure-number').text('#' + procedureNumber).click(function() {
	                    procedureContainer.find('.json__procedure').toggleClass('json__procedure-full');
	                });
	                jsonList.prepend(procedureContainer);
	            }
	            json = null;
	            jsonObject = null;
	        },
	        getCurrentTime: function() {
	            var d = new Date();
	            return '' + ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2) + '.' + ('00' +
	                d.getMilliseconds()).slice(-3);
	        },
	        generateCallId: function() {
	            return btoa(String.fromCharCode.apply(null, window.crypto.getRandomValues(new Uint8Array(16))));
	        },
	        /**
	         * Render JSON object to DOM
	         * 
	         * @param {Object} data - JSON object
	         * @returns {jQuery}
	         */
	        renderForm: function(data) {
	            return this.renderCollection('data', data, true);
	        },
	        /**
	         * Render JSON object to follow HTML:
	         * 
	         * <div class="item"> <div class="key">{key}</div>
	         * <div class="value">{value}</div> </div> <div
	         * class="item"> <div class="key">{key}</div> <div
	         * class="value"> <div class="items"> <div
	         * class="item"> <div class="key">{key}</div> <div
	         * class="value">{value}</div> </div> <div
	         * class="item"> <div class="key">{key}</div> <div
	         * class="value">{value}</div> </div> ... </div>
	         * </div> </div> ...
	         * 
	         * @param {String} key - Collection name
	         * @param {Object} items - Child items of collection
	         * @param {Boolean} [isWritable] - Will render as writable?
	         * @param {number} [level] - Level of recursion
	         * @param {string} [parentKey] - parent Key
	         * 
	         * @returns {jQuery}
	         */
	        renderCollection: function(key, items, isWritable, level, parentKey) {
	            var render_item = $('<div>').addClass('item');
	            var render_key = $('<div>').addClass('key').text(key);
	            var render_value = $('<div>').addClass('value value__collection');
	            var render_items = $('<div>').addClass('items');
	            isWritable = isWritable || false;
	            level = level || 1;
	            parentKey = parentKey || '';
	            var newParentKey = key;
	            var entityId = '';
	            if ('activity' === key || 'activityList' == parentKey) {
	                entityId = items.aid;
	            } else if ('inventory' === key || 'inventoryList' == parentKey) {
	                entityId = items.invid;
	            }
	            if (items) {
	                $.each(items, function(key, value) {
	                    if (value && typeof value === 'object') {
	                        render_items.append(this.renderCollection(key, value, isWritable, level + 1, newParentKey));
	                    } else {
	                        render_items.append(this.renderItem(key, value, isWritable, level + 1, newParentKey, entityId).get(0));
	                    }
	                }.bind(this));
	            }
	            render_item.append('<div class="item-expander"></div>');
	            render_item.append(render_key);
	            render_value.append(render_items);
	            render_item.append($('<br>'));
	            render_item.append(render_value);
	            return render_item;
	        },
	        /**
	         * Render key and value to follow HTML:
	         * 
	         * <div class="item"> <div class="key">{key}</div>
	         * <div class="value">{value}</div> </div>
	         * 
	         * @param {String} key - Key
	         * @param {String} value - Value
	         * @param {Boolean} [isWritable] - Will render as writable?
	         * @param {Number} [level] - Level of recursion
	         * @param {String} [parentKey] - parent Key
	         * @param {String} [entityId] - id of OFSC entity to associate the file input with
	         * 
	         * @returns {jQuery}
	         */
	        renderItem: function(key, value, isWritable, level, parentKey, entityId) {
	            var render_item = $('<div>').addClass('item');
	            var render_value;
	            var render_key;
	            isWritable = isWritable || false;
	            level = level || 1;
	            parentKey = parentKey || '';
	            render_key = $('<div>').addClass('key').text(key);
	            render_item.append('<div class="item-expander"></div>')
	                .append(render_key)
	                .append('<span class="delimiter">: </span>');
	            if (value === null) {
	                value = '';
	            }
	            if (
	                typeof this.renderReadOnlyFieldsByParent[parentKey] !== 'undefined' &&
	                typeof this.renderReadOnlyFieldsByParent[parentKey][key] !== 'undefined' &&

	                this.renderReadOnlyFieldsByParent[parentKey][key] === true
	            ) {
	                isWritable = false;
	            }
	            switch (key) {
	                case "csign":
	                    if (isWritable) {
	                        render_value = $('<button>').addClass('button button--item-value button--generate-sign').text('Generate');
	                    }
	                    break;
	                default:
	                    var pluginInitData = false;
	                    var attributeDescription = {};
	                    if (this._isJson(localStorage.getItem('pluginInitData'))) {
	                        pluginInitData = JSON.parse(localStorage.getItem('pluginInitData'));
	                        attributeDescription = pluginInitData.attributeDescription || {};
	                    }
	                    if (this.dictionary[key]) {
	                        render_value = this.renderSelect(this.dictionary, key, value, isWritable).addClass('value value__item');
	                    } else if (
	                        attributeDescription[key] &&
	                        "enum" == attributeDescription[key].type &&
	                        attributeDescription[key].enum
	                    ) {
	                        render_value = this.renderEnumSelect(attributeDescription[key].enum, key, value,
	                            isWritable).addClass('value value__item');
	                    } else if (
	                        attributeDescription[key] &&
	                        "file" == attributeDescription[key].type &&
	                        "signature" !== attributeDescription[key].gui
	                    ) {
	                        render_value = this.renderFile(entityId, key);
	                    } else {
	                        render_value = $('<div>').addClass('value value__item').text(value);
	                        if (isWritable) {
	                            render_value.addClass('writable').attr('contenteditable', true);
	                        }
	                    }
	                    break;
	            }
	            render_item.append(render_value);
	            return render_item;
	        },
	        /**
	         * Render enums with validate of outs values
	         * 
	         * <select class="value [writable]" [disabled]>
	         * <option value="{value}" [selected]>{dictionary}</option>
	         * ... </select>
	         * 
	         * @param {Object} dictionary - Dictionary that will be used for Enum rendering
	         * @param {String} key - Just field name
	         * @param {String} value - Selected value
	         * @param {Boolean} isWritable - Will render as writable?
	         * 
	         * @returns {HTMLElement}
	         */
	        renderSelect: function(dictionary, key, value, isWritable) {
	            var render_value;
	            var outs = dictionary[key][value].outs;
	            var allowedValues = [value].concat(outs);
	            var disabled = '';
	            render_value = $('<select>').css({
	                background: dictionary[key][value].color
	            });
	            if (!outs.length || !isWritable) {
	                render_value.attr('disabled', true);
	            } else {
	                render_value.addClass('writable');
	            }
	            $.each(allowedValues, function(index, label) {
	                render_value.append('<option' + (label === value ? ' selected' : '') + ' value="' + dictionary[key]
	                    [label].label + '">' + dictionary[key][label].translation + '</option>');
	            });
	            return render_value;
	        },
	        renderFile: function(entityId, key) {
	            var render_value = $('<div>')
	                .addClass('writable value value__item value__file')
	                .attr('data-entity-id', entityId)
	                .attr('data-property-id', key);
	            var input = $('<input type="file">').addClass('value__file_input');
	            var preview =
	                $('<div>').addClass('value__file_preview_container')
	                .append($('<img>').addClass('value__file_preview'));
	            render_value.append(input);
	            render_value.append(preview);
	            return render_value;
	        },
	        /**
	         * Render enums
	         * 
	         * <select class="value [writable]" [disabled]> <option value="{value}"
	         * [selected]>{dictionary}</option> ... </select>
	         * 
	         * @param {Object} dictionary - Dictionary that will be used for Enum rendering
	         * @param {String} key - Just field name
	         * @param {String} value - Selected value
	         * @param {Boolean} isWritable - Will render as writable?
	         * 
	         * @returns {HTMLElement}
	         */
	        renderEnumSelect: function(dictionary, key, value, isWritable) {
	            var render_value;
	            var disabled = '';
	            render_value = $('<select>');
	            if (isWritable) {
	                render_value.addClass('writable');
	            } else {
	                render_value.attr('disabled', true);
	            }
	            $.each(dictionary, function(index, label) {
	                var option = $('<option' + (index === value ? ' selected' : '') + ' value="' + index + '"></option>').text(label.text);
	                render_value.append(option);
	            });
	            return render_value;
	        },
	        /**
	         * Generate output JSON
	         * 
	         * @returns {Object}
	         */
	        generateJson: function() {
	            var outputJson = {
	                apiVersion: 1,
	                method: 'close',
	                backScreen: $('.back_method_select').val(),
	                wakeupNeeded: $('#wakeup').is(':checked')
	            };
	            if (
	                outputJson.backScreen === 'activity_by_id' ||
	                outputJson.backScreen === 'end_activity' ||
	                outputJson.backScreen === 'cancel_activity' ||
	                outputJson.backScreen === 'notdone_activity' ||
	                outputJson.backScreen === 'start_activity' ||
	                outputJson.backScreen === 'suspend_activity' ||
	                outputJson.backScreen === 'delay_activity'
	            ) {
	                $.extend(outputJson, {
	                    backActivityId: $('.back_activity_id').val()
	                });
	            }
	            if (outputJson.backScreen === 'inventory_by_id') {
	                $.extend(outputJson, {
	                    backInventoryId: $('.back_inventory_id').val()
	                });
	            }
	            var backActivityId = $('.back_activity_id').val();
	            if (outputJson.backScreen === 'inventory_list' && backActivityId) {
	                $.extend(outputJson, {
	                    backActivityId: backActivityId,
	                });
	            }
	            if (
	                outputJson.backScreen === 'install_inventory' ||
	                outputJson.backScreen === 'deinstall_inventory'
	            ) {
	                $.extend(outputJson, {
	                    backActivityId: $('.back_activity_id').val(),
	                    backInventoryId: $('.back_inventory_id').val()
	                });
	            }
	            if (outputJson.backScreen === 'plugin_by_label') {
	                $.extend(outputJson, {
	                    backPluginLabel: $('.back_plugin_label').val(),
	                });
	                if ($('.back_plugin_link_id').val()) {
	                    $.extend(outputJson, {
	                        backPluginLinkId: $('.back_plugin_link_id').val()
	                    });
	                }
	                if ($('.back_plugin_params').val()) {
	                    $.extend(outputJson, {
	                        backPluginOpenParams: JSON.parse($('.back_plugin_params').val())
	                    });
	                }
	            }
	            // icon data
	            $.extend(outputJson, this.parseIconData($('.icon-options-holder')));
	            // parse entity
	            $.extend(outputJson, this.parseCollection($('.form')).data);
	            // parse actions
	            var actionsJson = this.parseCollection($('.actions-form'), true);
	            if (actionsJson.actions.length > 0) {
	                $.extend(outputJson, actionsJson);
	            }
	            delete outputJson.entity;
	            delete outputJson.resource;
	            return outputJson;
	        },
	        /**
	         * Convert HTML elements to JSON
	         * 
	         * @param {HTMLElement} rootElement - Root element that should be parsed recursively
	         * @param {Boolean} [parseAllExceptExcluded] - Need to parse all elements except excluded
	         * 
	         * @returns {Object}
	         * 
	         * <div class="key">activity</div> <div class="value value__collection">
	         * <div class="items"> <-------------------------------- rootElement !!!
	         * <div class="item edited"> <div class="key">WO_COMMENTS</div> <div
	         * class="value">text_comments</div> </div> <div class="item"> <div
	         * class="key">aid</div> <div class="value">4225274</div> </div> <div
	         * class="item"> <div class="key">caddress</div> <div
	         * class="value">text_address</div> </div> </div> </div>
	         * 
	         * converts to: { "aid": "4225274", "WO_COMMENTS": "text_comments" }
	         */
	        parseCollection: function(rootElement, parseAllExceptExcluded) {
	            parseAllExceptExcluded = parseAllExceptExcluded || false;
	            var returnObject;
	            if ($(rootElement).hasClass('items--without-key')) {
	                returnObject = [];
	            } else {
	                returnObject = {};
	            }
	            $(rootElement).children('.item').each(function(itemIndex, item) {
	                var parentKey;
	                var valueKey;
	                var value;
	                var mandatoryField = false;
	                var dataItemKey;
	                parentKey = $(rootElement).parent().siblings('.key').get(0);
	                valueKey = $(item).children('.key').get(0);
	                dataItemKey = $(valueKey).text();
	                // Logic of mandatory fields
	                if ((parentKey !== undefined) && (
	                        ('activity' === $(parentKey).text() && 'aid' === dataItemKey) || ('inventory' === $(parentKey).text() &&
	                            'invid' === dataItemKey)
	                    )) {
	                    mandatoryField = true;
	                }
	                if (
	                    ($(item).hasClass('edited') || parseAllExceptExcluded || mandatoryField) &&
	                    !$(item).hasClass('item--excluded')
	                ) {
	                    value = $(item).children('.value').get(0);
	                    if ($(value).children('.items').length > 0) {
	                        var parsedChild = this.parseCollection($(value).children('.items').get(0), parseAllExceptExcluded);
	                        if ($(rootElement).hasClass('items--without-key')) {
	                            returnObject.push(parsedChild);
	                        } else {
	                            returnObject[dataItemKey] = parsedChild;
	                        }
	                    } else {
	                        switch ($(value).prop("tagName")) {
	                            case 'SELECT':
	                                returnObject[dataItemKey] = $(value).val();
	                                break;
	                            case 'CANVAS':
	                                returnObject[dataItemKey] = value.toDataURL();
	                                break;
	                            default:
	                                if ($(value).hasClass('value__file')) {
	                                    var fileInput = $(value).find('.value__file_input').get(0);
	                                    var file = fileInput.files && fileInput.files[0];
	                                    if (file) {
	                                        returnObject[dataItemKey] = {
	                                            fileName: file.name,
	                                            fileContents: {}
	                                        };
	                                    }
	                                } else {
	                                    returnObject[dataItemKey] = $(value).text();
	                                }
	                                break;
	                        }
	                    }
	                }
	            }.bind(this));
	            return returnObject;
	        },
	        parseIconData: function(rootElement) {
	            var colorItem = rootElement.find('#iconColor');
	            var textItem = rootElement.find('#iconText');
	            var blobItem = rootElement.find('#iconImage');
	            var linkIdItem = rootElement.find('#iconLinkId');
	            var iconData = {};
	            var hasData = false;
	            if (colorItem.hasClass('edited')) {
	                hasData = true;
	                iconData.color = colorItem.find('.value__item').val();
	            }
	            if (textItem.hasClass('edited')) {
	                hasData = true;
	                iconData.text = textItem.find('.value__item').text();
	            }
	            if (blobItem.hasClass('edited')) {
	                hasData = true;
	                iconData.image = {};
	            }
	            if (!hasData) {
	                return {};
	            }
	            var linkId = linkIdItem.find('.value__item').text();
	            if (linkId.length) {
	                var linksIconData = {};
	                linksIconData[linkId] = iconData;
	                return {
	                    linksIconData: linksIconData
	                };
	            }
	            return {
	                iconData: iconData
	            }
	        },
	        _attachFiles: function(data) {
	            if (!$.isPlainObject(data)) {
	                return false;
	            }
	            $.each(data, function(dataKey, dataValue) {
	                var entityId = '';
	                if ('activity' === dataKey || 'inventory' === dataKey) {
	                    if ('activity' === dataKey) {
	                        entityId = dataValue.aid;
	                    } else {
	                        entityId = dataValue.invid;
	                    }
	                    if (!entityId) {
	                        return true;
	                    }
	                    $.each(dataValue, function(propertyName, propertyValue) {
	                        if ($.isPlainObject(propertyValue) && propertyValue.fileContents) {
	                            var fileInput = $('.value__item.value__file[data-entity-id="' + entityId + '"][data-property-id="' +
	                                propertyName + '"]').find('.value__file_input').get(0);
	                            var file = fileInput.files && fileInput.files[0];
	                            if (file) {
	                                propertyValue.fileContents = file;
	                            }
	                        }
	                    });
	                } else if ('activityList' === dataKey || 'inventoryList' === dataKey) {
	                    $.each(dataValue, function(entityId, entity) {
	                        $.each(entity, function(propertyName, propertyValue) {
	                            if ($.isPlainObject(propertyValue) && propertyValue.fileContents) {
	                                var fileInput = $('.value__item.value__file[data-entity-id="' + entityId + '"][data-property-id="' +
	                                    propertyName + '"]').find('.value__file_input').get(0);
	                                var file = fileInput.files && fileInput.files[0];
	                                if (file) {
	                                    propertyValue.fileContents = file;
	                                }
	                            }
	                        });
	                    });
	                } else if ('actions' === dataKey) {
	                    $.each(dataValue, function(actionId, action) {
	                        if (!action.properties) {
	                            return true;
	                        }
	                        $.each(action.properties, function(propertyName, propertyValue) {
	                            if ($.isPlainObject(propertyValue) && propertyValue.fileContents) {
	                                var fileInput = $('.value__item.value__file[data-entity-id="action-' + actionId + '"][data-property-id="' +
	                                    propertyName + '"]').find('.value__file_input').get(0);
	                                var file = fileInput.files && fileInput.files[0];
	                                if (file) {
	                                    propertyValue.fileContents = file;
	                                }
	                            }
	                        });
	                    });
	                } else if ('iconData' === dataKey) {
	                    if ($.isPlainObject(dataValue.image)) {
	                        var fileInput = $('.icon-options-holder #iconImage .value__file_input').get(0);
	                        var file = fileInput.files && fileInput.files[0];
	                        if (file) {
	                            dataValue.image = file;
	                        }
	                    }
	                } else if ('linksIconData' === dataKey) {
	                    if (!$.isPlainObject(dataValue)) {
	                        return;
	                    }
	                    Object.keys(dataValue).forEach(function(linkId) {
	                        var iconData = dataValue[linkId];
	                        if ($.isPlainObject(iconData.image)) {
	                            var fileInput = $('.icon-options-holder #iconImage .value__file_input').get(0);
	                            var file = fileInput.files && fileInput.files[0];
	                            if (file) {
	                                iconData.image = file;
	                            }
	                        }
	                    });
	                }
	            });
	        },
	        /**
	         * Update JSON
	         * 
	         * @private
	         */
	        _updateResponseJSON: function() {
	            var jsonToSend = this.generateJson();
	            $('.json__response').text(JSON.stringify(jsonToSend, null, 4));
	        },


			// CHG0075659 - MPF Phase 5 - Function to handle Call Procedure api result
		finishCallIdCallbacks: function (receivedJson) {
			
			let jsonObject = null;
			console.log("Call procedure:" + receivedJson);
			jsonObject = JSON.parse(receivedJson);
			console.log("Call Procedure JSONobject" + JSON.stringify(jsonObject));
			var jsonObjectItemLength= jsonObject.resultData.items.length;

			if(jsonObjectItemLength!=0){

			if(linkedflag==0 && islinkedcall!=1){
				$.each(jsonObject.resultData.items, function (i, a) {

					console.log("Field Details", a.fields);
					multipleFieldsArray.push(a.fields);
					a.fields.LINKED_COUNT = a.linkedItems.length;
				});
			}
		}
		if(jsonObject.resultData.isContinueAvailable == true && linkedflag==0 && islinkedcall==0 ){
			$.getPartsCatalogContinue(jsonObject.resultData.searchId);
		}

			if( islinkedcall==1){

					console.log("****Linked parts array created.");

					$.each(jsonObject.resultData.items, function(i,v){
						
						var itemDetails = jsonObject.resultData.items[i].fields;
						console.log("Field Details", itemDetails);
						multipleFieldsArray.push(itemDetails);

					});
					
						
					
					//itemDetails.LINKED_COUNT = itemDetails.linkedItems.length;
			}

			if(linkedflag==1){
				console.log("*****Getlinkedpartsarray called ");
				var linkedItemIndex =0;
				$.each(jsonObject.resultData.items,function(i,v){
					if(v.fields.ITEM_NUMBER == currItemNumber){
						linkedItemIndex = i;
					}
					
				});
				$.getLinkedPartsArray(jsonObject.resultData.items[linkedItemIndex]);

			} 

			if (searchflag == searchArray.length && linkedflag!=1 && jsonObject.resultData.isContinueAvailable == false) {
				if (jsonObject.callId == partsContinueSearchCallId) {
					console.log("*********PROCESS SEARCH RESULT CALLED");
					$.processSearchResultsFnCallBck(multipleFieldsArray,false,0);
					multipleFieldsArray = [];
				}
				// CHG0078235 - Change Starts
				if (jsonObject.callId == partssearchcallID) {
					console.log("*********PROCESS SEARCH RESULT CALLED FOR ZERO PARTS FOUND");
					$.processSearchResultsFnCallBck(multipleFieldsArray,false,0);
					multipleFieldsArray = [];
				}
				// CHG0078235 - Change Ends
			}

			if(linkedArrayFlag==linkedItemsLength){
			if (jsonObject.callId == linkedcallID) {
				console.log("*********PROCESS LINKED SEARCH RESULT CALLED");
				var newLinkArray = multipleFieldsArray;
				$.each(newLinkArray, function(i,v){
					if (v !== undefined){
						if (v.ITEM_NUMBER == currItemNumber){
							multipleFieldsArray.splice(i,1);
						}
				}
				});
				
				var filteredMultipleArray =[];
				$.each(multipleFieldsArray,function(i,v){
					if(linkedArray.indexOf(v.ITEM_NUMBER)!=-1){
						filteredMultipleArray.push(v);
					}
				});

				$.processSearchResultsFnCallBck(filteredMultipleArray,true,parentPartNo);
				islinkedcall=0;
				linkedArrayFlag=0;
				multipleFieldsArray=[];
				filteredMultipleArray=[];
			}
		}
		
		},

	        /**
	         * Initialization function
	         */
		init: function() {
			if (navigator.serviceWorker) {
				this._log(window.location.host + ' Service Worker is supported');
				navigator.serviceWorker.register('quickOrder-service-worker.js').then(function(registration) {
					this._log(window.location.host + ' Service Worker is registered with scope: ' + registration.scope);
					registration.addEventListener('updatefound', function() {
						this._log(window.location.host + ' Service Worker update is found');
						var newServiceWorker = registration.installing;
						newServiceWorker.addEventListener('statechange', function() {
							switch (newServiceWorker.state) {
								case "installed":
									this._log(window.location.host + ' New Service Worker is installed');
									break;
							}
						}.bind(this));
					}.bind(this));
					navigator.serviceWorker.addEventListener('controllerchange', function() {
						this.notifyAboutNewVersion();
					}.bind(this));
					this.startApplication();
				}.bind(this), function(err) {
					this._log(window.location.host + ' Service Worker registration failed: ' + err);
					this.startApplication();
				}.bind(this));
				return;
			} else {
				this._log(window.location.host + ' Service Worker is not supported');
			}
			this.startApplication();
		},
		startApplication: function() {
	            this._log(window.location.host + ' PLUGIN HAS BEEN STARTED');
	           
	            window.addEventListener("message", this._getPostMessageData.bind(this), false);
	            this.initLocalStorageOption('showHeader');
	            this.initLocalStorageOption('backNavigationFlag');
	            var jsonToSend = {
	                apiVersion: 1,
	                method: 'ready',
	                sendInitData: true,
	                showHeader: !!localStorage.getItem('showHeader'),
	                enableBackButton: !!localStorage.getItem('backNavigationFlag')
	            };
	            // parse data items
	            var dataItems = JSON.parse(localStorage.getItem('dataItems'));
	            if (dataItems) {
	                $.extend(jsonToSend, {
	                    dataItems: dataItems
	                });
	            }
	            this._sendPostMessageData(jsonToSend);
		},
		notifyAboutNewVersion: function() {
			this._log(window.location.host + ' New Service Worker is activated. Page refresh is needed');
			var footer = document.querySelector('.footer');
			var versionNotificationElement = document.createElement('div');
			versionNotificationElement.className = 'new-version-notification';
			versionNotificationElement.innerHTML = 'New version is detected. Please reopen the page';
			footer.appendChild(versionNotificationElement);
		}		
    });
	window.OfscPlugin.getVersion = function() {
		return resourcesVersion;
	};
})(jQuery);