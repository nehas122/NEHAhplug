"use strict";
(function ($) {
	window.OfscPlugin = function (debugMode) {
		this.debugMode = debugMode || false;
	};

	var g_activityId, g_firstInRoute, g_wakeupNeeded;
	$.extend(window.OfscPlugin.prototype, {
		/**
		 * Dictionary of enums
		 */
		dictionary: {
			astatus: {
				pending: {
					label: 'pending',
					translation: 'Pending',
					outs: ['started', 'cancelled', 'suspended'],
					color: '#FFDE00'
				},
				started: {
					label: 'started',
					translation: 'Started',
					outs: ['complete', 'suspended', 'notdone', 'cancelled'],
					color: '#A2DE61'
				},
				complete: {
					label: 'complete',
					translation: 'Completed',
					outs: [],
					color: '#79B6EB'
				},
				suspended: {
					label: 'suspended',
					translation: 'Suspended',
					outs: [],
					color: '#9FF'
				},
				notdone: {
					label: 'notdone',
					translation: 'Not done',
					outs: [],
					color: '#60CECE'
				},
				cancelled: {
					label: 'cancelled',
					translation: 'Cancelled',
					outs: [],
					color: '#80FF80'
				}
			},
			invpool: {
				customer: {
					label: 'customer',
					translation: 'Customer',
					outs: ['deinstall'],
					color: '#04D330'
				},
				install: {
					label: 'install',
					translation: 'Installed',
					outs: ['provider'],
					color: '#00A6F0'
				},
				deinstall: {
					label: 'deinstall',
					translation: 'Deinstalled',
					outs: ['customer'],
					color: '#00F8E8'
				},
				provider: {
					label: 'provider',
					translation: 'Resource',
					outs: ['install'],
					color: '#FFE43B'
				}
			}
		},
		actions: {
			activity: [
				{
					value: '',
					translation: 'Select Action...'
				},
				{
					value: 'create',
					translation: 'Create Activity'
				}
			],
			inventory: [
				{
					value: '',
					translation: 'Select Action...'
				},
				{
					value: 'create',
					translation: 'Create Inventory'
				},
				{
					value: 'delete',
					translation: 'Delete Inventory'
				},
				{
					value: 'install',
					translation: 'Install Inventory'
				},
				{
					value: 'deinstall',
					translation: 'Deinstall Inventory'
				},
				{
					value: 'undo_install',
					translation: 'Undo Install Inventory'
				},
				{
					value: 'undo_deinstall',
					translation: 'Undo Deinstall Inventory'
				}
			]
		},

		/**
		 * Check for string is valid JSON
		 *
		 * @param {*} str - String that should be validated
		 *
		 * @returns {boolean}
		 *
		 * @private
		 */
		_isJson: function (str) {
			try {
				JSON.parse(str);
			} catch (e) {
				return false;
			}
			return true;
		},
		/**
		 * Return origin of URL (protocol + domain)
		 *
		 * @param {String} url
		 *
		 * @returns {String}
		 *
		 * @private
		 */
		_getOrigin: function (url) {
			if (url != '') {
				if (url.indexOf("://") > -1) {
					return 'https://' + url.split('/')[2];
				} else {
					return 'https://' + url.split('/')[0];
				}
			}
			return '';
		},
		/**
		 * Return domain of URL
		 *
		 * @param {String} url
		 *
		 * @returns {String}
		 *
		 * @private
		 */
		_getDomain: function (url) {
			if (url != '') {
				if (url.indexOf("://") > -1) {
					return url.split('/')[2];
				} else {
					return url.split('/')[0];
				}
			}
			return '';
		},
		/**
		* get domain / company name
		*/
		_getDomainURL: function () {
			//return document.referrer.match(/\:\/\/([^\/]+)\.etadirect\.com\//)[1];
			//Reg Ex modified to handle both etadirect.com and fs.ocs.oraclecloud.com URLs
			return document.referrer.match(/\:\/\/([^\/]+)\.(?:etadirect.com|fs.ocs.oraclecloud.com)/)[1];
		},
		/**
		 * Sends postMessage to document.referrer
		 *
		 * @param {Object} data - Data that will be sent
		 *
		 * @private
		 */
		_sendPostMessageData: function (data) {
			var originUrl = document.referrer || (document.location.ancestorOrigins && document.location.ancestorOrigins[0]) || '';
			var isString = 'string' === typeof data;
			if (originUrl) {
				this._log(window.location.host + ' -> ' + (isString ? '' : data.method) + ' ' + this._getDomain(originUrl), isString ? data : JSON.stringify(data, null, 4));
				parent.postMessage(data, this._getOrigin(originUrl));
			} else {
				this._log(window.location.host + ' -> ' + (isString ? '' : data.method) + ' ERROR. UNABLE TO GET REFERRER');
			}
		},
		/**
		 * Handles during receiving postMessage
		 *
		 * @param {MessageEvent} event - Javascript event
		 *
		 * @private
		 */
		_getPostMessageData: function (event) {
			if (typeof event.data === 'undefined') {
				this._log(window.location.host + ' <- NO DATA ' + this._getDomain(event.origin), null, null, true);
				return false;
			}
			if (!this._isJson(event.data)) {
				this._log(window.location.host + ' <- NOT JSON ' + this._getDomain(event.origin), null, null, true);
				return false;
			}
			var data = JSON.parse(event.data);
			if (!data.method) {
				this._log(window.location.host + ' <- NO METHOD ' + this._getDomain(event.origin), null, null, true);
				return false;
			}
			this._log(window.location.host + ' <- ' + data.method + ' ' + this._getDomain(event.origin), JSON.stringify(data, null, 4));
			switch (data.method) {
				case 'init':
					this.pluginInitEnd(data);
					break;
				case 'open':
					this.pluginOpen(data);
					break;
				case 'wakeup':
					this.pluginWakeup(data);
					break;
				case 'error':
					data.errors = data.errors || { error: 'Unknown error' };
					this._showError(data.errors);
					break;
				default:
					this._log(window.location.host + ' <- UNKNOWN METHOD: ' + data.method + ' ' + this._getDomain(event.origin), null, null, true);
					break;
			}
		},
		/**
		 * Show alert with error
		 *
		 * @param {Object} errorData - Object with errors
		 *
		 * @private
		 */
		_showError: function (errorData) {
			alert(JSON.stringify(errorData, null, 4));
		},
		/**
		 * Logs to console
		 *
		 * @param {String} title - Message that will be log
		 * @param {String} [data] - Formatted data that will be collapsed
		 * @param {String} [color] - Color in Hex format
		 * @param {Boolean} [warning] - Is it warning message?
		 *
		 * @private
		 */
		_log: function (title, data, color, warning) {
			if (!this.debugMode) {
				return;
			}
			if (!color) {
				color = '#0066FF';
			}
			if (!!data) {
				console.groupCollapsed('%c[Plugin API] ' + title, 'color: ' + color + '; ' + (!!warning ? 'font-weight: bold;' : 'font-weight: normal;'));
				console.log('[Plugin API] ' + data);
				console.groupEnd();
			} else {
				console.log('%c[Plugin API] ' + title, 'color: ' + color + '; ' + (!!warning ? 'font-weight: bold;' : ''));
			}
		},

		/**
		 * Business login on plugin init
		 */
		saveToLocalStorage: function (data) {
			this._log(window.location.host + ' INIT. SET DATA TO LOCAL STORAGE', JSON.stringify(data, null, 4));
			var initData = {};
			$.each(data, function (key, value) {
				if (-1 !== $.inArray(key, ['apiVersion', 'method'])) {
					return true;
				}
				initData[key] = value;
			});
			localStorage.setItem('pluginInitData', JSON.stringify(initData));
		},
		/**
		 * Business login on plugin init end
		 *
		 * @param {Object} data - JSON object that contain data from OFSC
		 */
		pluginInitEnd: function (data) {
			this.saveToLocalStorage(data);
			var messageData = {
				apiVersion: 1,
				method: 'initEnd'
			};
			if (localStorage.getItem('pluginWakeupCount') < localStorage.getItem('pluginWakeupMaxCount')) {
				this._log(window.location.host + ' UNFINISHED WAKEUP DATA FOUND IN LOCAL STORAGE');
				messageData.wakeupNeeded = true;
			}
			this._sendPostMessageData(messageData);
		},
		/**
		 * Clear previous configuration of wakeup (background open for sync) behavior for Plugin
		 * from the Local Storage
		 *
		 * @private
		 */
		_clearWakeupData: function () {
			localStorage.removeItem('pluginWakeupCount');
			localStorage.removeItem('pluginWakeupMaxCount');
			localStorage.removeItem('pluginWakeupDontRespondOn');
			localStorage.removeItem('pluginWakeupChangeIcon');
			localStorage.removeItem('PunchinMainRESTCallQue');

			this._log(window.location.host + ' CLEAR WAKEUP DATA FROM LOCAL STORAGE');
		},
		/**
		* Ajax call to update the properties
		*/
		ajaxCall: function (url, payload, method, headers) {
			$.ajax({
				dataType: "json",
				url: url,
				data: JSON.stringify(payload),
				method: method,
				//async: false,
				crossDomain: true,
				headers: headers,
				processData: false,
				contentType: 'application/json; charset=utf-8',
				timeout: 15000,
				success: function (response) {
					console.log("Update Resource properties - Success messagae: " + JSON.stringify(response));
				}.bind(this),
				error: function (errorData) {
					console.log("Update Resource properties - Error messagae:" + JSON.stringify(errorData));
				}
			});
		},
		/**
		 * Business login on plugin open
		 *
		 * @param {Object} receivedData - JSON object that contain data from OFSC
		 */
		pluginOpen: function (receivedData) {
			this._clearWakeupData();
			if (localStorage.getItem('pluginInitData')) {
				this._log(window.location.host + ' OPEN. GET DATA FROM LOCAL STORAGE', JSON.stringify(JSON.parse(localStorage.getItem('pluginInitData')), null, 4));
			}
			
			//Begin CHG0078450
			var rPunchinTime = receivedData.resource.R_PUNCH_IN_TIME;
			var activityId = receivedData.activity.aid;
			//var email = receivedData.resource.email; No more needed
			var resource_paycode = receivedData.resource.P_PAYCODE;
			var domainName = this._getDomainURL();
			var resourceTimeZone = receivedData.resource.time_zone;

			var resourceUpdateUrl = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/resources/" + receivedData.resource.external_id;

			var TimeZoneMapping = {
				"19": "Alaska",
				"6": "Arizona",
				"4": "Central",
				"2": "Eastern",
				"15": "GMT",
				"17": "Hawaii (Adak)",
				"18": "Hawaii (Honolulu)",
				"5": "Mountain",
				"7": "Pacific"
			};

			var timeZone = TimeZoneMapping[resourceTimeZone];


			// Set the timezone to retreive the Date & time for Activate route & punch in 
			if ("Alaska" == timeZone || "Arizona" == timeZone || "Central" == timeZone
				|| "Eastern" == timeZone || "Mountain" == timeZone || "Pacific" == timeZone) {
				resourceTimeZone = "US/" + timeZone;
			} else if ("Hawaii (Adak)" == timeZone) {
				resourceTimeZone = "America/Adak";
			} else if ("Hawaii (Honolulu)" == timeZone) {
				resourceTimeZone = "Pacific/Honolulu";
			}

			// if the resource time zone is null, then assign to EST.
			if (resourceTimeZone == null || "" == resourceTimeZone || typeof (resourceTimeZone) == undefined) {
				resourceTimeZone = "EST";
			}
			//End CHG0078450
			
			// Current Date & Time of resource time zone
			var todayDate;
			try {
				todayDate = new Date(new Date().toLocaleString('en-US', { timeZone: resourceTimeZone }));
			} catch (err) {
				todayDate = new Date();
			}
			var day = ("0" + todayDate.getDate()).slice(-2);
			var month = ("0" + (todayDate.getMonth() + 1)).slice(-2);
			var hours = ("0" + todayDate.getHours()).slice(-2);
			var minutes = ("0" + todayDate.getMinutes()).slice(-2);
			var seconds = ("0" + todayDate.getSeconds()).slice(-2);

			var date_YYYY_MM_DD = todayDate.getFullYear().toString() + "-" + month + "-" + day;
			var date_yyyy_MM_dd_HH_mm_ss = date_YYYY_MM_DD + " " + hours + ":" + minutes + ":" + seconds;
			var date_yyyy_MM_dd_T_HH_mm = date_YYYY_MM_DD + "T" + hours + ":" + minutes;
			var date = todayDate.toISOString().split('T')[0];

			var rid = receivedData.resource.external_id;
			var dataItemsToProcess = [];
			var dataItems = ['resource'];
			var totalResults = 0;
			var offSet = 0;
			console.log("Data Items: ", dataItems);
			var resourceInventories = false;
			var InventoryData = {};
			var aDate = date_YYYY_MM_DD.concat("-"+rid);
			

			console.log("RI Local storage : ", localStorage.ri);
			console.log("RI Data Presents ? : ", !localStorage.ri);
			if (localStorage.storageDataItems) {
				dataItemsToProcess = localStorage.storageDataItems.split(',');
			}
			

			if ((typeof localStorage.aDate === 'undefined' || aDate != localStorage.aDate) || (dataItemsToProcess.indexOf('resourceInventories') === -1)) {
				localStorage.storageDataItems = [];
				dataItemsToProcess = [];
				localStorage.ri = [];
				localStorage.di = [];
				localStorage.ii = [];
				localStorage.ci = [];
				localStorage.aDate = aDate;
				dataItems.push('customerInventories');
				dataItems.push('deinstalledInventories');
				dataItems.push('installedInventories');
				storeResourceInvToLocal();
			} 
			else 
			{
				if (dataItemsToProcess.indexOf('resourceInventories') === -1) {
					dataItems.push('resourceInventories');
				}

				if (dataItemsToProcess.indexOf('customerInventories') === -1) {
					dataItems.push('customerInventories');
				}

				if (dataItemsToProcess.indexOf('deinstalledInventories') === -1) {
					dataItems.push('deinstalledInventories');
				}

				if (dataItemsToProcess.indexOf('installedInventories') === -1) {
					dataItems.push('installedInventories');
				}
				console.log("Data Items : ", dataItems);
			}
			
			//Function to initialise resource inventory data updation
			function storeResourceInvToLocal() {
				callApi(rid);
			}
			function callApi(resourceId) {
				$.ajax({
					url: window.location.href,
					timeout: 2000,
					cache: false,
					type: 'GET',
					tryCount: 0,
					retryLimit: 3,
					success: function (response) {
						console.log(' online configuration');
						ResourceInventory();
					}.bind(this),
					error: function (xhr, textStatus, errorThrown) {
						if (textStatus == 'timeout') {
							this.tryCount++;
							if (this.tryCount <= this.retryLimit) {
								//try again
								$.ajax(this);
								return false;
							}
							console.log(' Offline configuration');
							$.showNoDataFound();

						}
						if (xhr.status == 500) {
							console.log(' Offline configuration');
							$.showNoDataFound();
						}
						else {
							console.log(' Offline configuration');
							$.showNoDataFound();
						}
					}.bind(this)
				});

				function ResourceInventory() {
					var rInventoryURL = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/resources/" + rid + "/inventories";

					$.ajax({
						url: rInventoryURL,
						method: 'GET',
						dataType: 'json',
						processData: false,
						contentType: 'application/json; charset=utf-8',
						headers: headers,
						async: false,
						crossDomain: true,
						timeout: 15000,
						success: function (successData) {
							console.log("ResourceInventory Success Data", successData);
							resourceInventories = true;
							if (dataItemsToProcess.indexOf('resourceInventories') === -1) {
								dataItemsToProcess.push('resourceInventories');
							}
							console.log(dataItemsToProcess);
							localStorage.storageDataItems = dataItemsToProcess;
							totalResults = successData.totalResults;
							ResourceInventoryBySize();
						},
						error: function (errorData) {
							console.log("ResourceInventory Error: ", errorData);

						}
					});
				}
				function ResourceInventoryBySize() {

					while (totalResults > offSet) {

						var rInventoryURL = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/resources/" + rid + "/inventories?offset=" + offSet + "&limit=100";
						$.ajax({
							url: rInventoryURL,
							method: 'GET',
							dataType: 'json',
							processData: false,
							contentType: 'application/json; charset=utf-8',
							headers: headers,
							async: false,
							crossDomain: true,
							timeout: 15000,
							success: function (successData) {
								console.log(successData);
								
								if (offSet == 0) {
									InventoryData.ri = successData.items;

								}
								if (offSet > 0) {
									$.each(successData.items, function (i, a) {
										InventoryData.ri.push(a);
									});


								}
								
							},
							error: function (errorData) {
								console.log(errorData);
								dataItems.push('resourceInventories');
								resourceInventories = true;
								InventoryData.ri = [];
								
							}
						});
						offSet = offSet + 100;
					}
					callReadyMethod();

				}
				$.showNoDataFound = function () {
					$('#context-body').append("<tr class=\"cl-row\">\n" +
						"    <td class=\"cl-fld\">\n" +
						"        <div class=\"cl-fld-outer\">\n" +
						"            No data found.\n" +
						"        </div>\n" +
						"    </td>\n" +
						"</tr>");
				};
				function callReadyMethod() {
					console.log('in Ready Method');
					if (resourceInventories) {
						//storing data to localStorage
						localStorage.ri = JSON.stringify(InventoryData.ri);
						//passing consolidated data-items
						console.log(dataItems);
						localStorage.storageDataItems = dataItemsToProcess;
						// if (dataItems) {
						// 	$.extend(jsonToSend, {dataItems: dataItems});
						// }
						// thisVar._sendPostMessageData(jsonToSend);
					}
				}


			}
			
			//Begin CHG0078450
			/**
			var rPunchinTime = receivedData.resource.R_PUNCH_IN_TIME;
			var activityId = receivedData.activity.aid;
			//var email = receivedData.resource.email; No more needed
			var resource_paycode = receivedData.resource.P_PAYCODE;
			var domainName = this._getDomainURL();
			var resourceTimeZone = receivedData.resource.time_zone;

			var resourceUpdateUrl = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/resources/" + receivedData.resource.external_id;

			var TimeZoneMapping = {
				"19": "Alaska",
				"6": "Arizona",
				"4": "Central",
				"2": "Eastern",
				"15": "GMT",
				"17": "Hawaii (Adak)",
				"18": "Hawaii (Honolulu)",
				"5": "Mountain",
				"7": "Pacific"
			};

			var timeZone = TimeZoneMapping[resourceTimeZone];


			// Set the timezone to retreive the Date & time for Activate route & punch in 
			if ("Alaska" == timeZone || "Arizona" == timeZone || "Central" == timeZone
				|| "Eastern" == timeZone || "Mountain" == timeZone || "Pacific" == timeZone) {
				resourceTimeZone = "US/" + timeZone;
			} else if ("Hawaii (Adak)" == timeZone) {
				resourceTimeZone = "America/Adak";
			} else if ("Hawaii (Honolulu)" == timeZone) {
				resourceTimeZone = "Pacific/Honolulu";
			}

			// if the resource time zone is null, then assign to EST.
			if (resourceTimeZone == null || "" == resourceTimeZone || typeof (resourceTimeZone) == undefined) {
				resourceTimeZone = "EST";
			}
			**/
			// End CHG0078450
			
			// Building Authorization headers
			var headers = {
				'Authorization':
					'Basic ' + btoa(receivedData.securedData.clientId + "@" + domainName + ":" + receivedData.securedData.clientSecret)
			};

			// set the radio button to the default value
			if (typeof (resource_paycode) != undefined && resource_paycode != null && "" != resource_paycode) {
				$("input[name='p_paycode'][value='" + resource_paycode + "']").prop('checked', true);
			}

			// On click event from Punch in page
			$('.submitpunch').click(function () {
				try {
					//disabling it to prevent multiple clicks
					$('#punch-in-submit-btn').attr('disabled', true);
					
					//Change Starts - CHG0078233
					// Check if user is authorized , if not alert user and return
					var punchInResource = receivedData.resource.email; 
					punchInResource = punchInResource.toLowerCase();
					var punchInUser = receivedData.user.ulogin;
					punchInUser = punchInUser.toLowerCase();
					if (punchInResource != punchInUser) {
						alert("Not allowed to Punch In for other Technicians");
						$('#punch-in-submit-btn').attr('disabled', false);
						return false;
					}
					//Change ends - CHG0078233
					
					
					// Check if the punch type is selected, if not alert user and return
					var paycode = $("input[type='radio'][name='p_paycode']:checked").val();
					if (typeof (paycode) == undefined || paycode == "" || paycode == null) {
						alert("Please select the shift.");
						$('#punch-in-submit-btn').attr('disabled', false);
						return false;
					}

					// to load cursor wait & enable please wait loading
					$('body').css({ "cursor": "wait" });
					this.popupEnable("Please wait ...", false, true, "regularMessage");

					var firstInRoute = 0;
					var punchinDate = "";
					if (rPunchinTime) {
						rPunchinTime = rPunchinTime.replace("|", "");
						punchinDate = rPunchinTime.substr(0, 10);
					}

					

					// Current Date & Time of UTC timeZone
					var UTCdate = new Date(new Date().toLocaleString('en-US', { timeZone: "UTC" }));
					var UTCday = ("0" + UTCdate.getDate()).slice(-2);
					var UTCmonth = ("0" + (UTCdate.getMonth() + 1)).slice(-2);
					var UTChours = ("0" + UTCdate.getHours()).slice(-2);
					var UTCminutes = ("0" + UTCdate.getMinutes()).slice(-2);

					var UTCDate_yyyy_MM_dd_T_HH_mm = UTCdate.getFullYear().toString() + "-" + UTCmonth + "-" + UTCday + "T" + UTChours + ":" + UTCminutes;

					// resource Request payload
					var resourceRequest = {
						"resourceId": receivedData.resource.external_id,
						"status": "active",
						"language": "en",
						"name": receivedData.resource.pname,
						"P_PAYCODE": paycode,
						"R_WORKING_STATUS": "working"
					};
					if (typeof (rPunchinTime) != undefined || "" != rPunchinTime || rPunchinTime != null) {
						if (punchinDate != date_YYYY_MM_DD) {
							$.extend(resourceRequest, {
								"R_TOTAL_TIME_DIFF": "",
								"R_TOTAL_MILEAGE_DIFF": "",
								"R_TOTAL_EXPENSES_DIFF": "",
								"R_EXPENSES": "",
								"R_EOD_ACTIVITY_ID": "",
								"R_PUNCH_IN_TIME": ""
							});
							firstInRoute = 1;
						}
					} else {
						$.extend(resourceRequest, {
							"R_TOTAL_TIME_DIFF": "",
							"R_TOTAL_MILEAGE_DIFF": "",
							"R_TOTAL_EXPENSES_DIFF": "",
							"R_EXPENSES": "",
							"R_EOD_ACTIVITY_ID": "",
							"R_PUNCH_IN_TIME": ""
						});
						firstInRoute = 1;
					}

					//var serviceRequestURL = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/serviceRequests";
					var serviceReqeustParams = {
						"resourceId": receivedData.resource.external_id,
						"SR_ACTION_TIME_EST": date_yyyy_MM_dd_T_HH_mm,
						"SR_ACTION_TIME_UTC": UTCDate_yyyy_MM_dd_T_HH_mm,
						"date": date,
						"requestType": receivedData.securedData.requestType,
						"SR_ACTION_TIME_EST_DISPLAY": date_yyyy_MM_dd_T_HH_mm.replace("T", " ")
					};

					var payload = {
						resourceUpdateUrl: resourceUpdateUrl,
						resourceRequestParams: resourceRequest,
						activateRouteUrl: "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/resources/" + receivedData.resource.external_id + "/routes/" + date_YYYY_MM_DD + "/custom-actions/activate",
						activateRouteParams: { "time": date_yyyy_MM_dd_HH_mm_ss },
						serviceRequestURL: "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/serviceRequests",
						serviceReqeustParams: serviceReqeustParams,
						headers: headers,
						activityId: receivedData.activity.aid,
						firstInRoute: firstInRoute,
						resourceId: receivedData.resource.external_id
					}

					var current = this;
					//Validate internet connectivity and punchin
					$.ajax({
						url: '//' + window.location.host + '/robots.txt' + '?rand=' + Math.random(),
						timeout: 2000,
						type: 'GET',
						tryCount: 0,
						retryLimit: 3,
						success: function (json) {
							console.log('online configuration');
							current.submitPunch(payload, false, false);
						},
						error: function (xhr, textStatus, errorThrown) {
							//CHG0070440 Start
							current.popupEnable("Currently you are in Offline Mode and your Punch In Time: " + payload.serviceReqeustParams.SR_ACTION_TIME_EST.replace("T", " "), true, true, "successMessage");
							g_activityId = payload.activityId;
							g_firstInRoute = payload.firstInRoute;
							g_wakeupNeeded = true;
							//CHG0070440 Start
							if (textStatus == 'timeout') {
								this.tryCount++;
								if (this.tryCount <= this.retryLimit) {
									//try again
									$.ajax(this);
									return false;
								}
								console.log('offline configuration');
								localStorage.setItem("PunchinMainRESTCallQue", JSON.stringify(payload));
								$('body').css({ "cursor": "default" });
								//current.closeMethod(activityId,firstInRoute,true); //CHG0070440
							}
							if (xhr.status == 500) {
								console.log('offline configuration');
								localStorage.setItem("PunchinMainRESTCallQue", JSON.stringify(payload));
								$('body').css({ "cursor": "default" });
								//current.closeMethod(activityId,firstInRoute,true); //CHG0070440
							} else {
								console.log('offline configuration');
								localStorage.setItem("PunchinMainRESTCallQue", JSON.stringify(payload));
								$('body').css({ "cursor": "default" });
								//current.closeMethod(activityId,firstInRoute,true); //CHG0070440
							}
						}
					});
					/* Commenting the below section to improve online offline check 
						if(!navigator.onLine){
							console.log('offline configuration');
							localStorage.setItem("PunchinMainRESTCallQue", JSON.stringify(payload));
							$('body').css({"cursor": "default"});
							this.closeMethod(activityId,firstInRoute,true);
						} else {
							this.submitPunch(payload, false, false);
						}
					*/
				}
				catch (err) {
					var resourceErrorPayload = { "R_PLUGIN_ERROR": "error while calling the Submit Punch" + err.message };
					this.ajaxCall(payload.resourceUpdateUrl, resourceErrorPayload, "PATCH", payload.headers);
				}
			}.bind(this));

			$('#messagePanel #notification-clear').click(function () {
				$('#messagePanel').hide();
				this.closeMethod(g_activityId, g_firstInRoute, g_wakeupNeeded);
			}.bind(this));
		},
		activateRoute: function (payload, wakeupNeeded, wakupMethod, ajaxErrorMessage) {
			try {
				$.ajax({
					dataType: "json",
					url: payload.activateRouteUrl,
					data: JSON.stringify(payload.activateRouteParams),
					method: "POST",
					//async: false,
					crossDomain: true,
					headers: payload.headers,
					processData: false,
					contentType: 'application/json; charset=utf-8',
					timeout: 15000,
					success: function (response) {
						console.log("Activate Route - Success messagae: " + JSON.stringify(response));
						this.createServiceRequest(payload, wakeupNeeded, wakupMethod, ajaxErrorMessage);
					}.bind(this),
					error: function (errorData) {
						console.error("Activate Route - Error messagae: " + JSON.stringify(errorData));
						var responseJSON = errorData.responseJSON;
						if ('409' != responseJSON.status && 'Route was activated for current user' != responseJSON.detail) {

							ajaxErrorMessage += "API: " + payload.activateRouteUrl + "<br />Request: " + JSON.stringify(payload.activateRouteParams) + "<br />Response: " + JSON.stringify(errorData);
							this.completeAction(false, ajaxErrorMessage, wakupMethod, wakeupNeeded, payload);
						} else {
							this.createServiceRequest(payload, wakeupNeeded, wakupMethod, ajaxErrorMessage);
						}
					}.bind(this)
				});
			} catch (err) {
				var resourceErrorPayload = { "R_PLUGIN_ERROR": "error while Activating Route: " + err.message };
				this.ajaxCall(payload.resourceUpdateUrl, resourceErrorPayload, "PATCH", payload.headers);
			}
		},
		createServiceRequest: function (payload, wakeupNeeded, wakupMethod, ajaxErrorMessage) {
			try {
				$.ajax({
					dataType: "json",
					url: payload.serviceRequestURL,
					data: JSON.stringify(payload.serviceReqeustParams),
					method: "POST",
					//async: false,
					crossDomain: true,
					headers: payload.headers,
					processData: false,
					contentType: 'application/json; charset=utf-8',
					timeout: 15000,
					success: function (response) {
						console.log("Punch in resource Service Request - Success messagae: " + JSON.stringify(response));
						this.completeAction(true, ajaxErrorMessage, wakupMethod, wakeupNeeded, payload);
					}.bind(this),
					error: function (errorData) {
						console.log("Punch in resource Service Request - Error messagae: " + JSON.stringify(errorData));
						ajaxErrorMessage += "API: " + payload.serviceRequestURL + "<br />Request: " + JSON.stringify(payload.serviceReqeustParams) + "<br />Response: " + JSON.stringify(errorData);
						this.completeAction(false, ajaxErrorMessage, wakupMethod, wakeupNeeded, payload);
					}.bind(this)
				});
			} catch (err) {
				var resourceErrorPayload = { "R_PLUGIN_ERROR": "error while creating Service Request: " + err.message };
				this.ajaxCall(payload.resourceUpdateUrl, resourceErrorPayload, "PATCH", payload.headers);
			}
		},
		/**
		* Submit punchin action on offline & online mode
		*/
		submitPunch: function (payload, wakeupNeeded, wakupMethod) {
			try {
				var ajaxErrorMessage = "";
				// Ajax call to update Resource properties
				$.ajax({
					dataType: "json",
					url: payload.resourceUpdateUrl,
					data: JSON.stringify(payload.resourceRequestParams),
					method: "PATCH",
					//async: false,
					crossDomain: true,
					headers: payload.headers,
					processData: false,
					contentType: 'application/json; charset=utf-8',
					timeout: 15000,
					success: function (response) {
						console.log("Update Resource properties - Success messagae: " + JSON.stringify(response));
						this.activateRoute(payload, wakeupNeeded, wakupMethod, ajaxErrorMessage);
					}.bind(this),
					error: function (errorData) {

						ajaxErrorMessage += "API: " + payload.resourceUpdateUrl + "<br />Request: " + JSON.stringify(payload.resourceRequestParams) + "<br />Response: " + JSON.stringify(errorData);
						console.log("Update Resource properties - Error messagae:" + JSON.stringify(errorData));
						this.completeAction(false, ajaxErrorMessage, wakupMethod, wakeupNeeded, payload);
					}.bind(this)
				});
			} catch (err) {
				var resourceErrorPayload = { "R_PLUGIN_ERROR": "error while calling the Submit Punch: " + err.message };
				this.ajaxCall(payload.resourceUpdateUrl, resourceErrorPayload, "PATCH", payload.headers);
			}
		},
		completeAction: function (callNextAjax, ajaxErrorMessage, wakupMethod, wakeupNeeded, payload) {
			// Send post message data to OFSC
			if (callNextAjax && "" == ajaxErrorMessage && !wakupMethod) {
				if (!wakupMethod) {
					this.popupEnable("Punch In Succeeded At: " + payload.serviceReqeustParams.SR_ACTION_TIME_EST.replace("T", " "), true, true, "successMessage");  //CHG0070440
					g_activityId = payload.activityId;
					g_firstInRoute = payload.firstInRoute;
					g_wakeupNeeded = wakeupNeeded;
				}
			} else {
				if (!wakupMethod) {
					var errorMessage = JSON.parse(ajaxErrorMessage.split("Response:").pop()).status;
					errorMessage = "<br>Error status: " + errorMessage;
					this.popupEnable("Punch in Failed. Please try again immediately. If the issue still exists,please take a screenshot and report the error below to ITSC at 1-800-641-2425 option 3." + errorMessage, true, true, "errorMessage");
				}
				var resourceErrorPayload = { "R_PLUGIN_ERROR": ajaxErrorMessage };
				this.ajaxCall(payload.resourceUpdateUrl, resourceErrorPayload, "PATCH", payload.headers);
				g_activityId = payload.activityId;
				g_firstInRoute = payload.firstInRoute;
				g_wakeupNeeded = wakeupNeeded;
			}
			$('body').css({ "cursor": "default" });
			if (wakupMethod) {
				this._sendPostMessageData({
					apiVersion: 1,
					method: 'sleep',
					wakeupNeeded: false
				});
			}
		},
		/**
		 * Popup method
		 */
		popupEnable: function (message, enableButton, displayPopup, styleClass) {
			if (message != null && "" != message && typeof (message) != undefined) {
				$('#messagePanel ul').html($('<li/>').addClass(styleClass).append(message));
				if (enableButton) {
					$('#messagePanel #notification-clear').show();
				} else {
					$('#messagePanel #notification-clear').hide();
				}
				if (displayPopup) {
					$('#messagePanel').show();
				} else {
					$('#messagePanel').hide();
				}
			}
		},
		/**
		 * Close method 
		 */
		closeMethod: function (activityId, firstInRoute, wakeNeeded) {
			$('#punch-in-submit-btn').attr('disabled', true);
			console.log('closeMethod called for activityId:' + activityId + 'firstInRoute -' + firstInRoute);
			if (activityId != null && "" != activityId && typeof (activityId) != undefined) {
				this._sendPostMessageData({
					apiVersion: 1,
					method: 'close',
					wakeupNeeded: wakeNeeded,
					backScreen: 'default',
					"activity": {
						"aid": activityId,
						"A_FIRST_IN_ROUTE": firstInRoute,
						"A_PUNCH_IN_DONE": 1  // added for punch in icon change done for CHG0071392
					}
				});
			} else {
				this._sendPostMessageData({
					apiVersion: 1,
					method: 'close',
					wakeupNeeded: wakeNeeded,
					backScreen: 'default'
				});
			}
		},
		/**
		 * Business login on plugin wakeup (background open for sync)
		 *
		 * @param {Object} receivedData - JSON object that contain data from OFSC
		 */
		pluginWakeup: function (receivedData) {
			this._log(window.location.host + ' WAKEUP', JSON.stringify(receivedData, null, 4));
			var wakeupData = {
				pluginWakeupCount: +localStorage.getItem('pluginWakeupCount'),
				pluginWakeupMaxCount: +localStorage.getItem('pluginWakeupMaxCount'),
				pluginWakeupDontRespondOn: +localStorage.getItem('pluginWakeupDontRespondOn')
			};

			wakeupData.pluginWakeupCount = wakeupData.pluginWakeupCount + 1;

			localStorage.setItem('pluginWakeupCount', wakeupData.pluginWakeupCount);
			localStorage.setItem('pluginWakeupMaxCount', wakeupData.pluginWakeupMaxCount);
			localStorage.setItem('pluginWakeupDontRespondOn', wakeupData.pluginWakeupDontRespondOn);

			this._log(window.location.host + ' SAVE WAKEUP DATA TO LOCAL STORAGE', JSON.stringify(wakeupData, null, 4));

			if (localStorage.getItem('PunchinMainRESTCallQue') !== '' && localStorage.getItem('PunchinMainRESTCallQue') !== null && localStorage.getItem('PunchinMainRESTCallQue') !== undefined) {
				var punchInPayload = JSON.parse(localStorage.getItem('PunchinMainRESTCallQue'));
				console.log(punchInPayload);
				this.submitPunch(punchInPayload, true, true);
			}

			if (wakeupData.pluginWakeupDontRespondOn == wakeupData.pluginWakeupCount) {
				this._log(window.location.host + ' EMULATE NOT RESPONDING PLUGIN');
				return;
			}

			if (wakeupData.pluginWakeupCount < wakeupData.pluginWakeupMaxCount) {
				setTimeout(function () {
					this._log(window.location.host + ' SLEEP. RETRY NEEDED');
					this._sendPostMessageData({
						apiVersion: 1,
						method: 'sleep',
						wakeupNeeded: true
					});
				}.bind(this), 2000);
			} else {
				setTimeout(function () {
					this._log(window.location.host + ' SLEEP. NO RETRY');
					this._sendPostMessageData({
						apiVersion: 1,
						method: 'sleep',
						wakeupNeeded: false
					});
				}.bind(this), 12000);
			}
		},
		/**
		 * Initialization function
		 */
		init: function () {
			if (navigator.serviceWorker) {
				this._log(window.location.host + ' Service Worker is supported');
				navigator.serviceWorker.register('punchin-service-worker.js').then(function (registration) {
					this._log(window.location.host + ' Service Worker is registered with scope: ' + registration.scope);
					registration.addEventListener('updatefound', function () {
						this._log(window.location.host + ' Service Worker update is found');
						var newServiceWorker = registration.installing;
						newServiceWorker.addEventListener('statechange', function () {
							switch (newServiceWorker.state) {
								case "installed":
									this._log(window.location.host + ' New Service Worker is installed');
									break;
							}
						}.bind(this));
					}.bind(this));
					navigator.serviceWorker.addEventListener('controllerchange', function () {
						this.notifyAboutNewVersion();
					}.bind(this));
					this.startApplication();
				}.bind(this), function (err) {
					this._log(window.location.host + ' Service Worker registration failed: ' + err);
					this.startApplication();
				}.bind(this));
				return;
			} else {
				this._log(window.location.host + ' Service Worker is not supported');
			}
			this.startApplication();
		},
		startApplication: function () {
			this._log(window.location.host + ' PLUGIN HAS BEEN STARTED');

			window.addEventListener("message", this._getPostMessageData.bind(this), false);
			var jsonToSend = {
				apiVersion: 1,
				method: 'ready',
				sendInitData: true
			};
			//parse data items
			var dataItems = JSON.parse(localStorage.getItem('dataItems'));
			if (dataItems) {
				$.extend(jsonToSend, { dataItems: dataItems });
			}
			this._sendPostMessageData(jsonToSend);
		},
		notifyAboutNewVersion: function () {
			this._log(window.location.host + ' New Service Worker is activated. Page refresh is needed');
			var footer = document.querySelector('.footer');
			var versionNotificationElement = document.createElement('div');
			versionNotificationElement.className = 'new-version-notification';
			versionNotificationElement.innerHTML = 'New version is detected. Please reopen the page';
			footer.appendChild(versionNotificationElement);
		}
	});
	window.OfscPlugin.getVersion = function () {
		return resourcesVersion;
	};
})(jQuery);