    "use strict";

    (function ($) {
        window.OfscPlugin = function (debugMode) {
            this.debugMode = debugMode || false;
        };

        $.extend(window.OfscPlugin.prototype, {
            /**
             * Dictionary of enums
             */
            dictionary: {
                astatus: {
                    pending: {
                        label: 'pending',
                        translation: 'Pending',
                        outs: ['started', 'cancelled', 'suspended'],
                        color: '#FFDE00'
                    },
                    started: {
                        label: 'started',
                        translation: 'Started',
                        outs: ['complete', 'suspended', 'notdone', 'cancelled'],
                        color: '#A2DE61'
                    },
                    complete: {
                        label: 'complete',
                        translation: 'Completed',
                        outs: [],
                        color: '#79B6EB'
                    },
                    suspended: {
                        label: 'suspended',
                        translation: 'Suspended',
                        outs: [],
                        color: '#9FF'
                    },
                    notdone: {
                        label: 'notdone',
                        translation: 'Not done',
                        outs: [],
                        color: '#60CECE'
                    },
                    cancelled: {
                        label: 'cancelled',
                        translation: 'Cancelled',
                        outs: [],
                        color: '#80FF80'
                    }
                },
                invpool: {
                    customer: {
                        label: 'customer',
                        translation: 'Customer',
                        outs: ['deinstall'],
                        color: '#04D330'
                    },
                    install: {
                        label: 'install',
                        translation: 'Installed',
                        outs: ['provider'],
                        color: '#00A6F0'
                    },
                    deinstall: {
                        label: 'deinstall',
                        translation: 'Deinstalled',
                        outs: ['customer'],
                        color: '#00F8E8'
                    },
                    provider: {
                        label: 'provider',
                        translation: 'Resource',
                        outs: ['install'],
                        color: '#FFE43B'
                    }
                }
            },

            mandatoryActionProperties: {},

            /**
             * Which field shouldn't be editable
             *
             * format:
             *
             * parent: {
             *     key: true|false
             * }
             *
             */
            renderReadOnlyFieldsByParent: {
                data: {
                    apiVersion: true,
                    method: true,
                    entity: true
                },
                resource: {
                    pid: true,
                    pname: true,
                    gender: true
                }
            },

            /**
             * Check for string is valid JSON
             *
             * @param {*} str - String that should be validated
             *
             * @returns {boolean}
             *
             * @private
             */
            _isJson: function (str) {
                try {
                    JSON.parse(str);
                }
                catch (e) {
                    return false;
                }
                return true;
            },

            /**
             * Return origin of URL (protocol + domain)
             *
             * @param {String} url
             *
             * @returns {String}
             *
             * @private
             */
            _getOrigin: function (url) {
                if (url != '') {
                    if (url.indexOf("://") > -1) {
                        return 'https://' + url.split('/')[2];
                    } else {
                        return 'https://' + url.split('/')[0];
                    }
                }

                return '';
            },

            /**
             * Return domain of URL
             *
             * @param {String} url
             *
             * @returns {String}
             *
             * @private
             */
            _getDomain: function (url) {
                if (url != '') {
                    if (url.indexOf("://") > -1) {
                        return url.split('/')[2];
                    } else {
                        return url.split('/')[0];
                    }
                }

                return '';
            },

            /**
             * Sends postMessage to document.referrer
             *
             * @param {Object} data - Data th
             at will be sent
             *
             * @private
             */
            _sendPostMessageData: function (data) {
                var originUrl = document.referrer || (document.location.ancestorOrigins && document.location.ancestorOrigins[0]) || '';

                if (originUrl) {
                    this._log(window.location.host + ' -> ' + data.method + ' ' + this._getDomain(originUrl), JSON.stringify(data, null, 4));

                    parent.postMessage(JSON.stringify(data), this._getOrigin(originUrl));
                } else {
                    this._log(window.location.host + ' -> ' + data.method + ' ERROR. UNABLE TO GET REFERRER');
                }
            },

            /**
             * Handles during receiving postMessage
             *
             * @param {MessageEvent} event - Javascript event
             *
             * @private
             */
            _getPostMessageData: function (event) {

                if (typeof event.data === 'undefined') {
                    this._log(window.location.host + ' <- NO DATA ' + this._getDomain(event.origin), null, null, true);

                    return false;
                }

                if (!this._isJson(event.data)) {
                    this._log(window.location.host + ' <- NOT JSON ' + this._getDomain(event.origin), null, null, true);

                    return false;
                }

                var data = JSON.parse(event.data);

                if (!data.method) {
                    this._log(window.location.host + ' <- NO METHOD ' + this._getDomain(event.origin), null, null, true);

                    return false;
                }

                this._log(window.location.host + ' <- ' + data.method + ' ' + this._getDomain(event.origin), JSON.stringify(data, null, 4));

                switch (data.method) {
                    case 'init':
                        this.pluginInitEnd(data);
                        break;

                    case 'open':
                        this.pluginOpen(data);
                        break;

                    case 'wakeup':
                        this.pluginWakeup(data);
                        break;

                    case 'error':
                        data.errors = data.errors || {error: 'Unknown error'};
                        this._showError(data.errors);
                        break;

                    default:
                        this._log(window.location.host + ' <- UNKNOWN METHOD: ' + data.method + ' ' + this._getDomain(event.origin), null, null, true);
                        break;
                }
            },

            /**
             * Show alert with error
             *
             * @param {Object} errorData - Object with errors
             *
             * @private
             */
            _showError: function (errorData) {
                alert(JSON.stringify(errorData, null, 4));
            },

            /**
             * Logs to console
             *
             * @param {String} title - Message that will be log
             * @param {String} [data] - Formatted data that will be collapsed
             * @param {String} [color] - Color in Hex format
             * @param {Boolean} [warning] - Is it warning message?
             *
             * @private
             */
            _log: function (title, data, color, warning) {
                if (!this.debugMode) {
                    return;
                }
                if (!color) {
                    color = '#0066FF';
                }
                if (!!data) {
                    console.groupCollapsed('%c[Plugin API] ' + title, 'color: ' + color + '; ' + (!!warning ? 'font-weight: bold;' : 'font-weight: normal;'));
                    console.log('[Plugin API] ' + data);
                    console.groupEnd();
                } else {
                    console.log('%c[Plugin API] ' + title, 'color: ' + color + '; ' + (!!warning ? 'font-weight: bold;' : ''));
                }
            },

            /**
             * Business login on plugin init
             */
            saveToLocalStorage: function (data) {
                this._log(window.location.host + ' INIT. SET DATA TO LOCAL STORAGE', JSON.stringify(data, null, 4));

                if (data.attributeDescription) {
                    localStorage.setItem('pluginInitData', JSON.stringify(data.attributeDescription));
                }
            },

            /**
             * Business login on plugin init end
             *
             * @param {Object} data - JSON object that contain data from OFSC
             */
            pluginInitEnd: function (data) {
                this.saveToLocalStorage(data);

                var messageData = {
                    apiVersion: 1,
                    method: 'initEnd'
                };

                if (localStorage.getItem('pluginWakeupCount') < localStorage.getItem('pluginWakeupMaxCount')) {
                    this._log(window.location.host + ' UNFINISHED WAKEUP DATA FOUND IN LOCAL STORAGE');

                    messageData.wakeupNeeded = true;
                }

                this._sendPostMessageData(messageData);
            },

            /**
             * Business login on plugin open
             *
             * @param {Object} receivedData - JSON object that contain data from OFSC
             */
            pluginOpen: function (receivedData) {
				console.log(receivedData);
				
				/*Reimbursable Expenses*/
				var reimbursableExpensesArr = [];
				var activitiesArr = [];
				var chargeableActivityArr = [];
				var serviceadvantagechargeableactivitiesArr = []; //CHG0065328
				var cbmActivitiesArr = []; //CHG0067765 Condition Based Maintenance
				var resultantData = [];

				var reimbursableExpensesOptions = [];
				var reimbursableExpensesOptionsDetails = [];
				var activityOptions = [];
				var activityOptionsDetails = [];
				var chargeableActivityOptions = [];
				var chargeableActivityOptionsDetails = [];
				var serviceadvantagechargeableactivitiesOptions = []; //CHG0065328
				var serviceadvantagechargeableactivitiesOptionsDetails = []; //CHG0065328
				var cbmActivityOptions = [];  //CHG0067765 Condition Based Maintenance
				var cbmActivityOptionsDetails = [];  //CHG0067765 Condition Based Maintenance

				
				$('#cpf__expenses_or_activities_submit_btn').click(function () {
					var nullCheckAmount = true;
					var nullCheckQuantity = true;
				  
					$.each(resultantData, function(key, val){
						console.log(key, val);
						if(val.type === "reimbursable_expenses_type" || val.type === "chargeable_activities_type"){ 
							if(parseFloat(val.amount).toFixed(2) <= 0.00){
								nullCheckAmount =  false;
							}
						}
						if(val.type === "activities_type" || val.type === "chargeable_activities_type" || val.type === "service_advantage_chargeable_activities_type" || val.type === "cbm_activities_type"){  //CHG0067765 Condition Based Maintenance
							if(parseFloat(val.quantity).toFixed(2) <= 0.00){
								nullCheckQuantity =  false;
							}
						}
						
					});
					if(!nullCheckAmount){
						alert('Amount should not be Zero(0)');
						return false;
					}
					
					if(!nullCheckQuantity){
						alert('Qunatity should not be Zero(0)');
						return false;
					}
					

					$.createElement = function(name, value){
						var temp = document.createElementNS(name,name);
						if(value !== undefined){
							temp.innerHTML = value;
						}
						return temp;

					};

					var $expensesOutboundXml = $('<XMLDocument />');
					resultantData.forEach(function (data) {
						var $expensesOutbound = $.createElement('DebriefExpenseLine');
						$expensesOutbound.append($.createElement('A_EXPENSE_TYPE',data.value));
						$expensesOutbound.append($.createElement('A_AMOUNT',data.quantity));
						$expensesOutbound.append($.createElement('A_OVERRIDE_PRICE',data.amount));
						$expensesOutbound.append($.createElement('A_PRICE_OVERRIDE_REASON_CODE',data.overridedPriceReason));
						$expensesOutboundXml.append($expensesOutbound);
					});

					var $expensesPluginXml = $('<XMLDocument />');
					resultantData.forEach(function (data) {
						var $expensesPlugin = $.createElement('DebriefExpenseLine');
						$expensesPlugin.append($.createElement('A_EXPENSE_SECTION',data.type));
						$expensesPlugin.append($.createElement('A_EXPENSE_LABEL',data.name));
						$expensesPlugin.append($.createElement('A_EXPENSE_TYPE',data.value));
						$expensesPlugin.append($.createElement('A_QUANTITY',data.quantity));
						$expensesPlugin.append($.createElement('A_AMOUNT',data.amount));
						$expensesPlugin.append($.createElement('A_OVERRIDE_PRICE',data.overridedPrice));
						$expensesPlugin.append($.createElement('A_PRICE_OVERRIDE_REASON_CODE',data.overridedPriceReason));
						$expensesPluginXml.append($expensesPlugin);
					});

					var $seExpensesPluginXml = $('<XMLDocument />');
					resultantData.forEach(function (data) {
						var $seExpensesPlugin = $.createElement('DebriefExpenseLine');
						$seExpensesPlugin.append($.createElement('A_EXPENSE_SECTION',data.type));
						$seExpensesPlugin.append($.createElement('A_EXPENSE_LABEL',data.name));
						$seExpensesPlugin.append($.createElement('A_EXPENSE_TYPE',data.value));
						$seExpensesPlugin.append($.createElement('A_QUANTITY',data.quantity));
						$seExpensesPlugin.append($.createElement('A_AMOUNT',data.amount));
						$seExpensesPlugin.append($.createElement('A_OVERRIDE_PRICE',data.overridedPrice));
						$seExpensesPlugin.append($.createElement('A_PRICE_OVERRIDE_REASON_CODE',data.overridedPriceReason));
						$seExpensesPluginXml.append($seExpensesPlugin);
					});

					var tempString = JSON.stringify($expensesOutboundXml.html());

					var tempStructure =  tempString.replace(/&/g, "&amp;").replace(/>/g, "&gt;").replace(/</g, "&lt;").replace(/"/g, "");

					var pi_activity_expenses = {
						"apiVersion": 1,
						"method": "close",
						"backScreen": "default",
						"wakeupNeeded": false,
						"activity": {
							"aid": receivedData.activity.aid,
							"A_EXPENSES_OUTBOUND": tempStructure,
							"A_EXPENSES_PLUGIN": $expensesPluginXml.html(),
							"A_SE_EXPENSES_PLUGIN": $seExpensesPluginXml.html()
							//"A_SA_EXPENSES_PLUGIN": $saExpensesPluginXml.html(),	//CHG0065328
						}
					};
					this._sendPostMessageData(pi_activity_expenses);

				}.bind(this));

				$('#cpf_NewActivitiesQuantity_inner').keyup(function(evt){
					var enteredVal = $(this).val();
					if(isNaN(enteredVal) || enteredVal.indexOf(' ') >=0 || enteredVal === "") { 
					$(this).val(0.00); 
					}else{ 
					$(this).val(parseInt(enteredVal)); 
					} 
				});

				// $('#cpf_NewChargeableActivitiesQuantity_inner').keypress(function(evt){
					// evt = (evt) ? evt : window.event;
					// var charCode = (evt.which) ? evt.which : evt.keyCode;
					// if (charCode > 31 && (charCode < 48 || charCode > 57)) {
						// return false;
					// }
					// return true;
				// });
				
				$('#cpf_NewChargeableActivitiesQuantity_inner').keyup(function(evt){
					var enteredVal = $(this).val();
					if(isNaN(enteredVal) || enteredVal.indexOf(' ') >=0 || enteredVal === "") { 
					$(this).val(0.00); 
					}else{ 
					$(this).val(parseInt(enteredVal)); 
					} 
					if(parseFloat($(this).val())> 9999){
						$(this).val($(this).val().slice(0, -1));
					};
					
				});
				
				$('#cpf_NewServiceAdvantageChargeableActivitiesQuantity_inner').keyup(function(evt){
					var enteredVal = $(this).val();
					if(isNaN(enteredVal) || enteredVal.indexOf(' ') >=0 || enteredVal === "") { 
					$(this).val(0.00); 
					}else{ 
					$(this).val(parseInt(enteredVal)); 
					} 
					if(parseFloat($(this).val())> 9999){
						$(this).val($(this).val().slice(0, -1));
					};
					
				});

				$('#cpf__expenses_or_activities_cancel_btn').click(function () {
					this._sendPostMessageData({
						"apiVersion": 1,
						"method": "close",
						"backScreen": "default",
						"wakeupNeeded": false

					});
				}.bind(this));

				$('#cpf_ReimbursableExpensesType_inner option').each(function (val) {
					if($(this).text() !== ''){
						var temp = {
							value: $(this).val(),
							name: $(this).text()
						};
						reimbursableExpensesOptions.push($(this).val());
						reimbursableExpensesOptionsDetails.push(temp);
					}
				});
				$('#cpf_ActivitiesType_inner option').each(function (val) {
					if($(this).text() !== ''){
						var temp = {
							value: $(this).val(),
							name: $(this).text()
						};
						activityOptions.push($(this).val());
						activityOptionsDetails.push(temp);
					}
				});
				$('#cpf_ChargeableActivitiesType_inner option').each(function (val) {
					if($(this).text() !== ''){
						var temp = {
							value: $(this).val(),
							name: $(this).text()
						};
						chargeableActivityOptions.push($(this).val());
						chargeableActivityOptionsDetails.push(temp);
					}

				});
				
				//CHG0065328
				$('#cpf_ServiceAdvantageChargeableActivitiesType_inner option').each(function (val) {
					if($(this).text() !== ''){
						var temp = {
							value: $(this).val(),
							name: $(this).text()
						};
						serviceadvantagechargeableactivitiesOptions.push($(this).val());
						serviceadvantagechargeableactivitiesOptionsDetails.push(temp);
					}
				});
				//CHG0067765 Condition Based Maintenance
				$('#cpf_CBMActivitiesType_inner option').each(function (val) {
					if($(this).text() !== ''){
						var temp = {
							value: $(this).val(),
							name: $(this).text()
						};
						cbmActivityOptions.push($(this).val());
						cbmActivityOptionsDetails.push(temp);
					}
				});

				var xmlData = receivedData.activity.A_EXPENSES_PLUGIN;
				var xmlDocAction = $(xmlData).find('A_EXPENSE_SECTION');
				var xmlDocLabel = $(xmlData).find('A_EXPENSE_LABEL');
				var xmlDoc = $(xmlData).find('A_EXPENSE_TYPE');
				var xmlDocQty = $(xmlData).find('A_QUANTITY');
				var xmlDocAmt = $(xmlData).find('A_AMOUNT');
				var xmlDocOvrPrice = $(xmlData).find('A_OVERRIDE_PRICE');
				var xmlDocOvrPriceReason = $(xmlData).find('A_PRICE_OVERRIDE_REASON_CODE');

				var previousOptions = [];
				$.each(xmlDocAction, function (key, value) {
					previousOptions.push($(value).text());
				});
				$.each(xmlDocLabel, function (key, value) {
					previousOptions.push($(value).text());
				});
				$.each(xmlDoc, function (key, value) {
					previousOptions.push($(value).text());
				});
				$.each(xmlDocQty, function (key, value) {
					previousOptions.push($(value).text());
				});
				$.each(xmlDocAmt, function (key, value) {
					previousOptions.push($(value).text());
				});
				$.each(xmlDocOvrPrice, function (key, value) {
					previousOptions.push($(value).text());
				});
				$.each(xmlDocOvrPriceReason, function (key, value) {
					previousOptions.push($(value).text());
				});

				var tempArr = [];
				var previousTagsLength = xmlDoc.length;
				for(var i=0;i<previousTagsLength;i++){ // length should match properly
					var tempObj = {};
					tempObj.type = previousOptions[i];
					tempObj.name = previousOptions[i+previousTagsLength];
					tempObj.value = previousOptions[i+(previousTagsLength*2)];
					tempObj.quantity= previousOptions[i+(previousTagsLength*3)];
					tempObj.amount = previousOptions[i+(previousTagsLength*4)];
					tempObj.overridedPrice  = previousOptions[i+(previousTagsLength*5)];
					tempObj.overridedPriceReason  = previousOptions[i+(previousTagsLength*6)];
					tempArr.push(tempObj);
				}
				$.each(tempArr, function (key, selected) {
					if(selected.type === 'reimbursable_expenses_type' ){
						reimbursableExpensesArr.push(selected.value);
						resultantData.push(selected);
						selectedContentForReimbursableExpenses(selected.name, selected.value,selected);
					}else if(selected.type === 'activities_type'){
						activitiesArr.push(selected.value);
						resultantData.push(selected);
						selectedContentForActivity(selected.name, selected.value,selected);
					}else if(selected.type === 'chargeable_activities_type'){
						chargeableActivityArr.push(selected.value);
						resultantData.push(selected);
						selectedContentForChargeableActivity(selected.name, selected.value,selected);
					}else if(selected.type === 'service_advantage_chargeable_activities_type' ){                  //CHG0065328
						serviceadvantagechargeableactivitiesArr.push(selected.value);
						resultantData.push(selected);
						selectedContentForServiceAdvantageChargeableActivities(selected.name, selected.value,selected);
					}else if(selected.type === 'cbm_activities_type' ){			//CHG0067765 Condition Based Maintenance
						cbmActivitiesArr.push(selected.value);
						resultantData.push(selected);
						selectedContentForCBMActivities(selected.name, selected.value,selected);
					}
				});

				$("#cpf_addReimbursableExpenses").click(function () {
					var optionList = $('select#cpf_ReimbursableExpensesType_inner option').length-1;
					if(reimbursableExpensesArr.length < optionList){
						$("#cpf_addReimbursableExpenses").hide();
						$('#cpf_ReimbursableExpenses_footer').removeClass('cp_hidden');;
					}else {
						alert('You Added All The Items');
					}
				});
				
				 $('#cpf_NewReimbursableExpensesAmount_inner').keyup(function (event) {
					 var enteredVal = $(this).val();
					if(isNaN(enteredVal) || enteredVal.indexOf(' ') >=0 || enteredVal === "") { 
					alert('Only Numerical values are allowed');	// Added for INC1759284
					$(this).val(0.00); 
					}
					if(parseFloat($(this).val())> 999999.99){
						$(this).val($(this).val().slice(0, -1));
					};
				});

				$('#re_imbursable_save_btn').click(function () {
					var selectedItem = $('#cpf_ReimbursableExpensesType_inner').val();
					var selectedItemName = $('#cpf_ReimbursableExpensesType_inner option:selected').text();
					var expenseAmountInput = $('#cpf_NewReimbursableExpensesAmount_inner');
					var expenseAmount = expenseAmountInput.val();
					if(selectedItem !== undefined && selectedItem !== null && selectedItem !== '' && expenseAmount !== undefined && expenseAmount !== null && expenseAmount !== ''){
						//if(reimbursableExpensesArr.indexOf(selectedItem) === -1){		Commented for INC1576963 - Multiple Expense line addition issue
							if($.isNumeric(expenseAmount) && parseFloat(expenseAmount).toFixed(2)>0.00){
								var selectedObj = {
									value:selectedItem,
									name:selectedItemName,
									quantity:1,
									amount: parseFloat(expenseAmount).toFixed(2),
									overridedPrice:'',
									type:'reimbursable_expenses_type',
									overridedPriceReason:''
								};
								reimbursableExpensesArr.push(selectedItem);
								resultantData.push(selectedObj);
								selectedContentForReimbursableExpenses(selectedItemName,selectedItem,selectedObj);
								$('#cpf_addReimbursableExpenses').show();
								$('#cpf_ReimbursableExpenses_footer').addClass('cp_hidden');
								expenseAmountInput.val(null);
							}else {
								if(expenseAmount === "0"){
									alert('Amount Should Be Greater Than Zero(0)');
								}else {
									alert('Only Positive Numeric Values Are Allowed');
								}
							}
			// Begin Modification for INC1576963 - Multiple Expense line addition issue				
						/*}else {
							alert('This Expenses Type Is Already Added');
						}*/
			// End Modification for INC1576963 - Multiple Expense line addition issue			
					}else {
						alert('Please Fill Out All The Fields');
					}
				});

				function selectedContentForReimbursableExpenses(name,value,selectedObj) {
					$("#cpf_ReimbursableExpenses_header_filled_details").append(" <div id=\"cpf_3-0\" class=\"order-parts-grid-row reimbursable-expenses-content\">\n" +
						"                        <div class=\"order-parts-left-cell cpf_3-0\">\n" +
						"                            <div class=\"exp-title cpf_3-0-0\">"+name+"</div>\n" +
						"                            <div class=\"exp-value cpf_3-0-1\">"+value+"</div>\n" +
						"                            <div selectedData='"+JSON.stringify(selectedObj)+"'  class=\"exp-remove-button-column cpf_3-0-2\">" +
						"                               <a href=\"javascript:;\" id=\"cpf__unnamed_4\" class='cp_plugin_link plugin-remove-link'>Remove</a> " +
						"                           </div>\n" +
						"                        </div>\n" +
						"                        <div class=\"order-parts-right-cell cpf_3-1\">\n" +
						"                            <div class=\"order-parts-spinner-column cpf_3-1-0\">\n" +
						"                                <div id=\"cpf__unnamed_5\" class=\"cp_field \">\n" +
						"                                    <div class=\"cp_field_row\">\n" +
						"                                        <div class=\"cp_field_label\"><span class=\"cp_field_label_text\">Amount:</span></div>\n" +
						"                                        <div class=\"cp_field_ismandatory\"></div>\n" +
						"                                        <div class=\"cp_field_value\">\n" +
						"                                            <div selectedData='"+JSON.stringify(selectedObj)+"' class=\"cp_field_value_inner_wrapper\">\n" +
						"                                                <span class=\"cp_prefix_measure_unit\" id=\"cpf__unnamed_5_prefix_measure_unit\"></span>" +
						"                                                <input  id='re_imbursable_amount' type=\"text\" maxlength='9' class=\"cp_field_text_component cp_field_number_component form-item read\" value=\""+selectedObj.amount+"\"><span class=\"cp_measure_unit\" id=\"cpf__unnamed_5_measure_unit\"> $</span><span class=\"cp_min_max\" id=\"cpf__unnamed_5_min_max\"></span>\n" +
						"                                                <div class=\"cp_error_label\" id=\"cpf__unnamed_5_error\"></div>\n" +
						"                                                <span id=\"cpf__unnamed_5_inner_read_only\" class=\"cp_aux_hide\"></span>\n" +
						"                                            </div>\n" +
						"                                        </div>\n" +
						"                                    </div>\n" +
						"                                </div>\n" +
						"                            </div>\n" +
						"                        </div>\n" +
						"                    </div>");
				}
				
				function selectedContentForActivity(name, value, selectedObj) {
					$("#cpf_activities_header_filled_details").append("<div id=\"cpf_4-0\" class=\"order-parts-grid-row activities-content\">\n" +
						"                        <div class=\"order-parts-left-cell cpf_4-0\">\n" +
						"                            <div class=\"exp-title cpf_4-0-0\">"+name+"</div>\n" +
						"                            <div class=\"exp-value cpf_4-0-1\">"+value+"</div>\n" +
						"                            <div selectedData='"+JSON.stringify(selectedObj)+"'   class=\"exp-remove-button-column cpf_4-0-2\">" +
						"                               <a href=\"javascript:;\" id=\"cpf__unnamed_7\" class=\"cp_plugin_link plugin-remove-link\">Remove</a> </div>\n" +
						"                        </div>\n" +
						"                        <div class=\"order-parts-right-cell cpf_4-1\">\n" +
						"                            <div class=\"order-parts-spinner-column cpf_4-1-0\">\n" +
						"                                <div id=\"cpf__unnamed_8\" class=\"cp_field \">\n" +
						"                                    <div class=\"cp_field_row\">\n" +
						"                                        <div class=\"cp_field_label\"><span class=\"cp_field_label_text\">Qty:</span></div>\n" +
						"                                        <div class=\"cp_field_ismandatory\"></div>\n" +
						"                                        <div class=\"cp_field_value\">\n" +
						"                                            <div changedData='"+JSON.stringify(selectedObj)+"'  class=\"cp_field_value_inner_wrapper\">\n" +
						"                                                <input  id=\"cpf__unnamed_8_button_decrease\" type=\"button\" class=\"cpf-spinner-button-decrease button remove\" value=\"-\"><input id=\"cpf__unnamed_8_inner\" type=\"text\" maxlength='4' class=\"cp_field_text_component cp_field_spinner_component form-item read\" value=\""+selectedObj.quantity+"\" value=\"\">" +
						"                                                   <input  id=\"cpf__unnamed_8_button_increase\" type=\"button\" class=\"cpf-spinner-button-increase button add\" value=\"+\"><span id=\"cpf__unnamed_8_inner_read_only\" class=\"cp_aux_hide\"></span><span class=\"cp_measure_unit\" id=\"\"> </span><span class=\"cp_min_max\" id=\"cpf__unnamed_8_min_max\"></span>\n" +
						"                                                <div class=\"cp_error_label\" id=\"cpf__unnamed_8_error\"></div>\n" +
						"                                            </div>\n" +
						"                                        </div>\n" +
						"                                    </div>\n" +
						"                                </div>\n" +
						"                            </div>\n" +
						"                        </div>\n" +
						"                    </div>");
				}
				
				//CHG0067765 Condition Based Maintenance
				function selectedContentForCBMActivities(name,value,selectedObj) {
					$("#cpf_CBMActivities_header_filled_details").append(" <div id=\"cpf_7-0\" class=\"order-parts-grid-row cbm-activities-content\">\n" +
						"                        <div class=\"order-parts-left-cell cpf_7-0\">\n" +
						"                            <div class=\"exp-title cpf_7-0-0\">"+name+"</div>\n" +
						"                            <div class=\"exp-value cpf_7-0-1\">"+value+"</div>\n" +
						"                            <div selectedData='"+JSON.stringify(selectedObj)+"'  class=\"exp-remove-button-column cpf_7-0-2\">" +
						"                               <a href=\"javascript:;\" id=\"cpf__unnamed_21\" class='cp_plugin_link plugin-remove-link'>Remove</a> " +
						"                           </div>\n" +
						"                        </div>\n" +
						"                        <div class=\"order-parts-right-cell cpf_7-1\">\n" +
						"                            <div class=\"order-parts-spinner-column cpf_7-1-0\">\n" +
						"                                <div id=\"cpf__unnamed_22\" class=\"cp_field \">\n" +
						"                                    <div class=\"cp_field_row\">\n" +
						"                                        <div class=\"cp_field_label\"><span class=\"cp_field_label_text\">Duration:</span></div>\n" +
						"                                        <div class=\"cp_field_ismandatory\"></div>\n" +
						"                                        <div class=\"cp_field_value\">\n" +
						"                                            <div selectedData='"+JSON.stringify(selectedObj)+"' class=\"cp_field_value_inner_wrapper\">\n" +
						"                                                <input  id=\"cpf__unnamed_22_inner\" type=\"text\" maxlength='3' class=\"cp_field_text_component cp_field_number_component form-item read\" value=\""+selectedObj.quantity+"\"><span class=\"cp_suffix_measure_unit\" id=\"cpf__unnamed_22_suffix_measure_unit\"></span><span class=\"cp_measure_unit\" id=\"cpf__unnamed_22_measure_unit\"> Mins</span><span class=\"cp_min_max\" id=\"cpf__unnamed_22_min_max\"></span>\n" +
						"                                                <div class=\"cp_error_label\" id=\"cpf__unnamed_22_error\"></div>\n" +
						"                                                <span id=\"cpf__unnamed_22_inner_read_only\" class=\"cp_aux_hide\"></span>\n" +
						"                                            </div>\n" +
						"                                        </div>\n" +
						"                                    </div>\n" +
						"                                </div>\n" +
						"                            </div>\n" +
						"                        </div>\n" +
						"                    </div>");
				}
				
				function selectedContentForChargeableActivity(name, value, selectedObj) {
					$("#cpf_chargeable_activities_header_filled_details").append("<div id=\"cpf_5-0\" class=\"order-parts-grid-row chargeable-activities-content\">\n" +
						"                        <div class=\"order-parts-left-cell cpf_5-0\">\n" +
						"                            <div class=\"exp-title cpf_5-0-0\">"+name+"</div>\n" +
						"                            <div class=\"exp-value cpf_5-0-1\">"+value+"</div>\n" +
						"                            <div selectedData='"+JSON.stringify(selectedObj)+"' class=\"exp-remove-button-column cpf_5-0-2\">" +
						"                                   <a href=\"javascript:;\" id=\"cpf__unnamed_11\" class=\"cp_plugin_link plugin-remove-link\">Remove</a> </div>\n" +
						"                        </div>\n" +
						"                        <div class=\"order-parts-right-cell cpf_5-1\">\n" +
						"                            <div class=\"order-parts-spinner-column cpf_5-1-0\">\n" +
						"                                <div id=\"cpf__unnamed_12\" class=\"cp_field \">\n" +
						"                                    <div class=\"cp_field_row\">\n" +
						"                                        <div class=\"cp_field_label\"><span class=\"cp_field_label_text\">Amount:</span></div>\n" +
						"                                        <div class=\"cp_field_ismandatory\"></div>\n" +
						"                                        <div class=\"cp_field_value\">\n" +
						"                                            <div selectedData='"+JSON.stringify(selectedObj)+"' class=\"cp_field_value_inner_wrapper\">\n" +
						"                                                <span class=\"cp_prefix_measure_unit\" id=\"cpf__unnamed_12_prefix_measure_unit\">" +
						"                                                   </span><input id='chargeable_activity_amount' type=\"text\" maxlength='9'  class=\"cp_field_text_component cp_field_number_component form-item read\" value='"+selectedObj.amount+"'><span class=\"cp_measure_unit\" id=\"cpf__unnamed_12_measure_unit\"> $</span><span class=\"cp_min_max\" id=\"cpf__unnamed_12_min_max\"></span>\n" +
						"                                                <div class=\"cp_error_label\" id=\"cpf__unnamed_12_error\"></div>\n" +
						"                                                <span id=\"cpf__unnamed_12_inner_read_only\" class=\"cp_aux_hide\"></span>\n" +
						"                                            </div>\n" +
						"                                        </div>\n" +
						"                                    </div>\n" +
						"                                </div>\n" +
						"                            </div>\n" +
						"                            <div class=\"order-parts-spinner-column cpf_5-1-1\">\n" +
						"                                <div id=\"cpf__unnamed_13\" class=\"cp_field \">\n" +
						"                                    <div class=\"cp_field_row\">\n" +
						"                                        <div class=\"cp_field_label\"><span class=\"cp_field_label_text\">Qty:</span></div>\n" +
						"                                        <div class=\"cp_field_ismandatory\"></div>\n" +
						"                                        <div class=\"cp_field_value\">\n" +
						"                                            <div changedData='"+JSON.stringify(selectedObj)+"'  class=\"cp_field_value_inner_wrapper\">\n" +
						"                                                <input  id=\"cpf__unnamed_13_button_decrease\" type=\"button\" class=\"cpf-spinner-button-decrease button remove\" value=\"-\"><input id=\"cpf__unnamed_13_inner\" maxlength='4' type=\"text\" class=\"cp_field_text_component cp_field_spinner_component form-item read\" value='"+selectedObj.quantity+"'>" +
						"                                                   <input  id=\"cpf__unnamed_13_button_increase\" type=\"button\" class=\"cpf-spinner-button-increase button add\" value=\"+\"><span id=\"cpf__unnamed_13_inner_read_only\" class=\"cp_aux_hide\"></span><span class=\"cp_measure_unit\" id=\"\"> </span><span class=\"cp_min_max\" id=\"cpf__unnamed_13_min_max\"></span>\n" +
						"                                                <div class=\"cp_error_label\" id=\"cpf__unnamed_13_error\"></div>\n" +
						"                                            </div>\n" +
						"                                        </div>\n" +
						"                                    </div>\n" +
						"                                </div>\n" +
						"                            </div>\n" +
						"                        </div>\n" +
						"                    </div>");
				}
				
				//CHG0065328
				function selectedContentForServiceAdvantageChargeableActivities(name,value,selectedObj) {
					$("#cpf_service_advantage_chargeable_activities_header_filled_details").append("<div id=\"cpf_6-0\" class=\"order-parts-grid-row service-advantage-chargeable-activities-content\">\n" +
							"                        <div class=\"order-parts-left-cell cpf_6-0\">\n" +
							"                            <div class=\"exp-title cpf_6-0-0\">"+name+"</div>\n" +
							"                            <div class=\"exp-value cpf_6-0-1\">"+value+"</div>\n" +
							"                            <div selectedData='"+JSON.stringify(selectedObj)+"' class=\"exp-remove-button-column cpf_6-0-2\">" +
							"                                   <a href=\"javascript:;\" id=\"cpf__unnamed_16\" class=\"cp_plugin_link plugin-remove-link\">Remove</a> </div>\n" +
							"                        </div>\n" +
							"                        <div class=\"order-parts-right-cell cpf_6-1\">\n" +
							"                            <div class=\"order-parts-spinner-column cpf_6-1-0\">\n" +
							"                                <div id=\"cpf__unnamed_17\" class=\"cp_field \">\n" +
							"                                    <div class=\"cp_field_row\">\n" +
							"                                        <div class=\"cp_field_label\"><span class=\"cp_field_label_text\">Amount:</span></div>\n" +
							"                                        <div class=\"cp_field_ismandatory\"></div>\n" +
							"                                        <div class=\"cp_field_value\">\n" +
							"                                            <div selectedData='"+JSON.stringify(selectedObj)+"' class=\"cp_field_value_inner_wrapper\">\n" +
							"                                                <span class=\"cp_prefix_measure_unit\" id=\"cpf__unnamed_17_prefix_measure_unit\">" +
							"                                                   </span><input id='service_advantage_chargeable_activities_amount' type=\"text\" maxlength='9'  class=\"cp_field_text_component cp_field_number_component form-item read\" value='"+selectedObj.amount+"'><span class=\"cp_measure_unit\" id=\"cpf__unnamed_17_measure_unit\"> $</span><span class=\"cp_min_max\" id=\"cpf__unnamed_17_min_max\"></span>\n" +
							"                                                <div class=\"cp_error_label\" id=\"cpf__unnamed_17_error\"></div>\n" +
							"                                                <span id=\"cpf__unnamed_17_inner_read_only\" class=\"cp_aux_hide\"></span>\n" +
							"                                            </div>\n" +
							"                                        </div>\n" +
							"                                    </div>\n" +
							"                                </div>\n" +
							"                            </div>\n" +
							"                            <div class=\"order-parts-spinner-column cpf_6-1-1\">\n" +
							"                                <div id=\"cpf__unnamed_18\" class=\"cp_field \">\n" +
							"                                    <div class=\"cp_field_row\">\n" +
							"                                        <div class=\"cp_field_label\"><span class=\"cp_field_label_text\">Qty:</span></div>\n" +
							"                                        <div class=\"cp_field_ismandatory\"></div>\n" +
							"                                        <div class=\"cp_field_value\">\n" +
							"                                            <div changedData='"+JSON.stringify(selectedObj)+"'  class=\"cp_field_value_inner_wrapper\">\n" +
							"                                                <input  id=\"cpf__unnamed_18_button_decrease\" type=\"button\" class=\"cpf-spinner-button-decrease button remove\" value=\"-\"><input id=\"cpf__unnamed_18_inner\" maxlength='4' type=\"text\" class=\"cp_field_text_component cp_field_spinner_component form-item read\" value='"+selectedObj.quantity+"'>" +
							"                                                   <input  id=\"cpf__unnamed_18_button_increase\" type=\"button\" class=\"cpf-spinner-button-increase button add\" value=\"+\"><span id=\"cpf__unnamed_18_inner_read_only\" class=\"cp_aux_hide\"></span><span class=\"cp_measure_unit\" id=\"\"> </span><span class=\"cp_min_max\" id=\"cpf__unnamed_18_min_max\"></span>\n" +
							"                                                <div class=\"cp_error_label\" id=\"cpf__unnamed_18_error\"></div>\n" +
							"                                            </div>\n" +
							"                                        </div>\n" +
							"                                    </div>\n" +
							"                                </div>\n" +
							"                            </div>\n" +
							"                        </div>\n" +
							"                    </div>");
				}
				
				
				$(document).on("keyup", "input.cp_field_text_component.cp_field_number_component.form-item.read" ,
				function(){
					var enteredVal = $(this).val();
					if(isNaN(enteredVal) || enteredVal.indexOf(' ') >=0 || enteredVal === "") { 
					$(this).val(0.00); 
					}
							

					if(parseFloat($(this).val())> 999999.99){
						$(this).val($(this).val().slice(0, -1));
					};
					var chargeableActivityAmount = this;
					var serviceadvantagechargeableactivitiesAmount = this;
					var changableObj = JSON.parse($(this).parent('div').attr('selectedData'));
					var qtyInput = $(this).prev();
					if($.isNumeric($(this).val())){
						var prevValue = parseFloat($(this).val()).toFixed(2);
						//if(prevValue>0.00){
							resultantData.forEach(function (data) {
								if(data.value === changableObj.value){
									data.amount = prevValue
								}
							});

						//}
					}else {
						return false;
					}
				});

				/*Activities*/
				$("#cpf_addActivities").click(function () {
					var optionList = $('select#cpf_ActivitiesType_inner option').length-1;
					if(activitiesArr.length < optionList){
						$("#cpf_addActivities").hide();
						$('#cpf_Activities_footer').removeClass('cp_hidden');
					}else {
						alert('You Added All The Items');
					}
				});
				
				$('#cpf_NewActivitiesQuantity_button_increase').click(function () {
					var qtyInput = $('#cpf_NewActivitiesQuantity_inner');
					var prevValue = parseInt(qtyInput.val());
					if(prevValue < 999){    //modification done for CHG0059320
						if(isNaN(prevValue)){
							return false;
						}else {
							prevValue +=1;
							qtyInput.val(prevValue);
						}
					}

				});

				$('#cpf_NewActivitiesQuantity_button_decrease').click(function () {
					var qtyInput = $('#cpf_NewActivitiesQuantity_inner');
					var prevValue = parseInt(qtyInput.val());
					if(isNaN(prevValue)){
						return false;
					}else if(prevValue <=1){
						return false;
					}else {
						prevValue -= 1;
						qtyInput.val(prevValue);
					}

				});
				
				$('#activities_save_btn').click(function () {
					var selectedItem = $('#cpf_ActivitiesType_inner').val();
					var selectedItemName = $('#cpf_ActivitiesType_inner option:selected').text();
					var activityQtyInput = $('#cpf_NewActivitiesQuantity_inner');
					var activityQty = activityQtyInput.val();
					if(selectedItem !== undefined && selectedItem !== undefined && selectedItem !== '' && activityQty !== undefined && activityQty !== undefined && activityQty !== ''){
						//if(activitiesArr.indexOf(selectedItem) === -1){	Commented for INC1576963 - Multiple Expense line addition issue
							if($.isNumeric(activityQty) && parseInt(activityQty)>0){
								var selectedObj = {
									value:selectedItem,
									name:selectedItemName,
									quantity:activityQty,
									amount:0.00,
									overridedPrice:'',
									type:'activities_type',
									overridedPriceReason:''
								};
								activitiesArr.push(selectedItem);
								resultantData.push(selectedObj);
								selectedContentForActivity(selectedItemName,selectedItem,selectedObj);
								$("#cpf_addActivities").show();
								$('#cpf_Activities_footer').addClass('cp_hidden');
								activityQtyInput.val(1);
							}else {
								alert('Quntity Should Be Greater Than Zero(0)');
							}
			// Begin Modification for INC1576963 - Multiple Expense line addition issue
						/*}else {
							alert('This Expenses Type Is Already Added');
						}*/
			// End Modification for INC1576963 - Multiple Expense line addition issue			
					}else {
						alert('Please Fill Out All The Fields');
					}
				});


				$('#cpf_NewChargeableActivitiesQuantity_button_increase').click(function () {
					var qtyInput = $('#cpf_NewChargeableActivitiesQuantity_inner');
					var prevValue = parseInt(qtyInput.val());
					if(prevValue < 999){    //modification done for CHG0059320
						if(isNaN(prevValue)){
							return false;
						}else {
							prevValue += 1;
							qtyInput.val(prevValue);
						}
					}
				});


				// $('#cpf_NewChargeableActivitiesAmount_inner').keypress(function (event) {
					// if ((event.which != 46 || $(this).val().indexOf('.') != -1) && (event.which < 48 || event.which > 57)) {
						// event.preventDefault();
					// }
				// });
				$('#cpf_NewChargeableActivitiesAmount_inner').keyup(function(){
					var enteredVal = $(this).val();
					if(isNaN(enteredVal) || enteredVal.indexOf(' ') >=0 || enteredVal === "") {
					alert('Only Numerical values are allowed');	// Added for INC1759284						
					$(this).val(0.00); 
					}
							
					if(parseFloat($(this).val())> 999999.99){
						$(this).val($(this).val().slice(0, -1));
					};
				});
		
		

				// $('#cpf_NewReimbursableExpensesAmount_inner').keypress(function (event) {
					// if ((event.which != 46 || $(this).val().indexOf('.') != -1) && (event.which < 48 || event.which > 57)) {
						// event.preventDefault();
					// }
				// });


				// $(document).on("keypress", "input.cp_field_text_component.cp_field_number_component.form-item.read" , function() {
					// if ((event.which !== 46 || $(this).val().indexOf('.') !== -1) && (event.which < 48 || event.which > 57)) {
						// event.preventDefault();
					// }
				// });
		
		
				$("#txtnumber").on('keyup keydown', function () {
					if (isnan(($(this).val()))) {
						$(this).val($(this).val()
							.substring(0, ($(this).val().length - 1)));
					}
					if ($(this).val().length > 10 && $(this).val().indexof('.') === -1) {
						$(this).val($(this).val().substring(0, 10));
					}
					if ($(this).val().indexof('.') !== -1 && $(this).val().length > 9) {
						$(this).val($(this).val().substring(0, 9));
					}
					if (($(this).val().indexof('.') !== -1)) {
						var decimal = $(this).val().split('.');
						if (decimal[1].length > 2) {
							$(this).val($(this).val()
								.substring(0, ($(this).val().length - 1)));
						}
					}
				});




				$('#cpf_NewChargeableActivitiesQuantity_button_decrease').click(function () {
					var qtyInput = $('#cpf_NewChargeableActivitiesQuantity_inner');
					var prevValue = parseInt(qtyInput.val());
					if(isNaN(prevValue)){
						return false;
					}else if(prevValue <=1){
						return false;
					}else {
						prevValue -=1;
						qtyInput.val(prevValue);
					}
				});

				/*Chargeable Activities*/
				$('#cpf_addChargeableActivities').click(function () {
					var optionList = $('select#cpf_ChargeableActivitiesType_inner option').length-1;
					if(activitiesArr.length < optionList){
						$("#cpf_addChargeableActivities").hide();
						$('#cpf_ChargeableActivities_footer').removeClass('cp_hidden');;
					}else {
						alert('You Added All The Items');
					}
				});

				$('#chargeable_activity_save_btn').click(function () {
					var selectedItem = $('#cpf_ChargeableActivitiesType_inner').val();
					var selectedItemName = $('#cpf_ChargeableActivitiesType_inner option:selected').text();
					var activityAmountInput = $('#cpf_NewChargeableActivitiesAmount_inner');
					var activityQtyInput = $('#cpf_NewChargeableActivitiesQuantity_inner');
					var activityQty = activityQtyInput.val();
					if(activityQty === "0"){
						alert('Quntity Should Be Greater Than Zero(0)');
						return false;
					}
					var activityAmount = activityAmountInput.val();
					if(selectedItem !== undefined && selectedItem !== undefined && selectedItem !== '' &&
						activityQty !== undefined && activityQty !== undefined && activityQty !== '' &&
						activityAmount !== undefined && activityAmount !== undefined && activityAmount !== '' ){
						// if(chargeableActivityArr.indexOf(selectedItem) === -1){		Commented for INC1576963 - Multiple Expense line addition issue
							if($.isNumeric(activityQty) && $.isNumeric(activityAmount) && parseFloat(activityAmount).toFixed(2)>0.00){
								var selectedObj = {
									value:selectedItem,
									name:selectedItemName,
									quantity:activityQty,
									amount: parseFloat(activityAmount).toFixed(2),
									overridedPrice:'',
									type:'chargeable_activities_type',
									overridedPriceReason:''
								};
								chargeableActivityArr.push(selectedItem);
								resultantData.push(selectedObj);
								selectedContentForChargeableActivity(selectedItemName,selectedItem,selectedObj);
								$('#cpf_addChargeableActivities').show();
								$('#cpf_ChargeableActivities_footer').addClass('cp_hidden');
								activityQtyInput.val('1');
								activityAmountInput.val(null);
							}else {
								if(activityAmount === "0"){
									alert('Amount Should Be Greater Than Zero(0)');
								}else {
									alert('Only Positive Numeric Values Are Allowed');
								}

							}
			// Begin Modification for INC1576963 - Multiple Expense line addition issue
						/*}else {
							alert('This Expenses Type Is Already Added');
						}*/
			// End Modification for INC1576963 - Multiple Expense line addition issue						
					}else {
						alert('Please Fill Out All The Fields');
					}
				});

		//Modification for adding Service Advantage Chargeable Expense Codes Change Request Number CHG0065328
				/*ServiceAdvantageChargeableActivities*/
		 
				$('#cpf_NewServiceAdvantageChargeableActivitiesQuantity_button_increase').click(function () {
					var qtyInput = $('#cpf_NewServiceAdvantageChargeableActivitiesQuantity_inner');
					var prevValue = parseInt(qtyInput.val());
					if(prevValue < 999){    
						if(isNaN(prevValue)){
							return false;
						}else {
							prevValue += 1;
							qtyInput.val(prevValue);
						}
					}
				});

				$('#cpf_NewServiceAdvantageChargeableActivitiesAmount_inner').keyup(function(){
					var enteredVal = $(this).val();
					if(isNaN(enteredVal) || enteredVal.indexOf(' ') >=0 || enteredVal === "") {
					alert('Only Numerical values are allowed');						
					$(this).val(0.00); 
					}
							
					if(parseFloat($(this).val())> 999999.99){
						$(this).val($(this).val().slice(0, -1));
					};
				});
		
				$("#txtnumber").on('keyup keydown', function () {
					if (isnan(($(this).val()))) {
						$(this).val($(this).val()
							.substring(0, ($(this).val().length - 1)));
					}
					if ($(this).val().length > 10 && $(this).val().indexof('.') === -1) {
						$(this).val($(this).val().substring(0, 10));
					}
					if ($(this).val().indexof('.') !== -1 && $(this).val().length > 9) {
						$(this).val($(this).val().substring(0, 9));
					}
					if (($(this).val().indexof('.') !== -1)) {
						var decimal = $(this).val().split('.');
						if (decimal[1].length > 2) {
							$(this).val($(this).val()
								.substring(0, ($(this).val().length - 1)));
						}
					}
				});


				$('#cpf_NewServiceAdvantageChargeableActivitiesQuantity_button_decrease').click(function () {
					var qtyInput = $('#cpf_NewServiceAdvantageChargeableActivitiesQuantity_inner');
					var prevValue = parseInt(qtyInput.val());
					if(isNaN(prevValue)){
						return false;
					}else if(prevValue <=1){
						return false;
					}else {
						prevValue -=1;
						qtyInput.val(prevValue);
					}
				});

				/*ServiceAdvantageChargeableActivities*/
				$('#cpf_addServiceAdvantageChargeableActivities').click(function () {
					var optionList = $('select#cpf_ServiceAdvantageChargeableActivitiesType_inner option').length-1;
					if(serviceadvantagechargeableactivitiesArr.length < optionList){
						$("#cpf_addServiceAdvantageChargeableActivities").hide();
						$('#cpf_ServiceAdvantageChargeableActivities_footer').removeClass('cp_hidden');;
					}else {
						alert('You Added All The Items');
					}
				});

				    
				$('#service_advantage_chargeable_activities_save_btn').click(function () {
					var selectedItem = $('#cpf_ServiceAdvantageChargeableActivitiesType_inner').val();
					var selectedItemName = $('#cpf_ServiceAdvantageChargeableActivitiesType_inner option:selected').text();
					var activityAmountInput = $('#cpf_NewServiceAdvantageChargeableActivitiesAmount_inner');
					var activityQtyInput = $('#cpf_NewServiceAdvantageChargeableActivitiesQuantity_inner');
					var activityQty = activityQtyInput.val();
					if(activityQty === "0"){
						alert('Quntity Should Be Greater Than Zero(0)');
						return false;
					}
					var activityAmount = activityAmountInput.val();
					if(selectedItem !== undefined && selectedItem !== undefined && selectedItem !== '' &&
						activityQty !== undefined && activityQty !== undefined && activityQty !== '' &&
						activityAmount !== undefined && activityAmount !== undefined && activityAmount !== '' ){
						
							if($.isNumeric(activityQty) && $.isNumeric(activityAmount) && parseFloat(activityAmount).toFixed(2)>=0.00){
								var selectedObj = {
									value:selectedItem,
									name:selectedItemName,
									quantity:activityQty,
									amount: parseFloat(activityAmount).toFixed(2),
									overridedPrice:'',
									type:'service_advantage_chargeable_activities_type',
									overridedPriceReason:''
								};
								serviceadvantagechargeableactivitiesArr.push(selectedItem);
								resultantData.push(selectedObj);
								selectedContentForServiceAdvantageChargeableActivities(selectedItemName,selectedItem,selectedObj);
								$('#cpf_addServiceAdvantageChargeableActivities').show();
								$('#cpf_ServiceAdvantageChargeableActivities_footer').addClass('cp_hidden');
								activityQtyInput.val('1');
								activityAmountInput.val(null);
							}else {
									alert('Only Positive Numeric Values Are Allowed');
							}	
					}else {
						alert('Please Fill Out All The Fields');
					}
				});

				//Modification for adding Condition Based Maintenance Expense Activity Codes Change Request Number CHG0067765
				/*Condition Based Maintenance Activities*/
				
				$("#cpf_addCBMActivities").click(function () {
					var optionList = $('select#cpf_CBMActivitiesType_inner option').length-1;
					if(cbmActivitiesArr.length < optionList){
						$("#cpf_addCBMActivities").hide();
						$('#cpf_CBMActivities_footer').removeClass('cp_hidden');;
					}else {
						alert('You Added All The Items');
					}
				});
				

				//CHG0067765 Condition Based Maintenance
				$('#cpf_NewCBMActivitiesQuantity_inner').keyup(function(evt){
					var enteredVal = $(this).val();
					if(isNaN(enteredVal) || enteredVal.indexOf(' ') >=0 || enteredVal === "") { 
					$(this).val(0.00); 
					}else{ 
					$(this).val(parseInt(enteredVal)); 
					} 
					if(parseInt($(this).val()) > 999){
						$(this).val($(this).val().slice(0, -1));
					};
					
				});
				
				
				$('#cbmactivities_save_btn').click(function () {
					var selectedItem = $('#cpf_CBMActivitiesType_inner').val();
					var selectedItemName = $('#cpf_CBMActivitiesType_inner option:selected').text();
					var activityQtyInput = $('#cpf_NewCBMActivitiesQuantity_inner');
					var activityQty = activityQtyInput.val();
					if(selectedItem !== undefined && selectedItem !== undefined && selectedItem !== '' && activityQty !== undefined && activityQty !== undefined && activityQty !== ''){
						
							if($.isNumeric(activityQty) && parseInt(activityQty)>0 && parseInt(activityQty)<=540){
								var selectedObj = {
									value:selectedItem,
									name:selectedItemName,
									quantity:parseInt(activityQty),
									//duration : parseInt(activityDuration),
									amount:0.00,
									overridedPrice:'',
									type:'cbm_activities_type',
									overridedPriceReason:''
								};
								cbmActivitiesArr.push(selectedItem);
								resultantData.push(selectedObj);
								selectedContentForCBMActivities(selectedItemName,selectedItem,selectedObj);
								$('#cpf_addCBMActivities').show();
								$('#cpf_CBMActivities_footer').addClass('cp_hidden');
								//activityQtyInput.val(1);
								activityQtyInput.val(null);
							}else {
								if(activityQty === "0"){
									alert('Time Duration Should Be Greater Than Zero(0)');
								}else {
									alert('Time Duration must be less then 540 Minutes');
								}
							}		
						}else {
							alert('Please Fill Out All The Fields');
					}
				});
				
				
				/*Removing a tag from a List*/
				
				$(document).on("click", "a.cp_plugin_link.plugin-remove-link" , function() {
					var removableObj = JSON.parse($(this).parent('div').attr('selectedData'));
					if(removableObj.type === 'reimbursable_expenses_type'){
						for(var i = 0; i < resultantData.length; i++) {
							if (resultantData[i].value === removableObj.value) {
								resultantData.splice(i,1);
								var reimbursableExpensesArrLength = reimbursableExpensesArr.length;
								for(var j=0;j<reimbursableExpensesArrLength;j++){
									if(reimbursableExpensesArr[j] === removableObj.value){
										reimbursableExpensesArr.splice(j,1);
									}
								}

							}
						}
					}else if (removableObj.type === 'activities_type'){
						for(var i = 0; i < resultantData.length; i++) {
							if (resultantData[i].value === removableObj.value) {
								resultantData.splice(i,1);
								var activitiesArrLength = activitiesArr.length;
								for(var j=0;j<activitiesArrLength;j++){
									if(activitiesArr[j] === removableObj.value){
										activitiesArr.splice(j,1);
									}
								}

							}
						}
					}else if (removableObj.type === 'chargeable_activities_type'){
						for(var i = 0; i < resultantData.length; i++) {
							if (resultantData[i].value === removableObj.value) {
								resultantData.splice(i,1);
								var chargeableActivityArrLength = chargeableActivityArr.length;
								for(var j=0;j<chargeableActivityArrLength;j++){
									if(chargeableActivityArr[j] === removableObj.value){
										chargeableActivityArr.splice(j,1);
									}
								}
							}
						}
					}else if (removableObj.type === 'service_advantage_chargeable_activities_type'){
						for(var i = 0; i < resultantData.length; i++) {
							if (resultantData[i].value === removableObj.value) {
								resultantData.splice(i,1);
								var serviceadvantagechargeableactivitiesArrLength = serviceadvantagechargeableactivitiesArr.length;
								for(var j=0;j<serviceadvantagechargeableactivitiesArrLength;j++){
									if(serviceadvantagechargeableactivitiesArr[j] === removableObj.value){
										serviceadvantagechargeableactivitiesArr.splice(j,1);
									}
								}
							}
						}
					}else if(removableObj.type === 'cbm_activities_type'){ //CHG0067765 Condition Based Maintenance
						for(var i = 0; i < resultantData.length; i++) {
							if (resultantData[i].value === removableObj.value) {
								resultantData.splice(i,1);
								var cbmActivitiesArrLength = cbmActivitiesArr.length;
								for(var j=0;j<cbmActivitiesArrLength;j++){
									if(cbmActivitiesArr[j] === removableObj.value){
										cbmActivitiesArr.splice(j,1);
									}
								}

							}
						}
					}
					$(this).parent('div').parent().parent().remove();
				});

				$(document).on("click", "input.cpf-spinner-button-increase.button.add" , function() {
					var changableObj = JSON.parse($(this).parent('div').attr('changedData'));
					var qtyInput = $(this).prev();
					var prevValue = parseInt(qtyInput.val());
					if(prevValue < 999){                          //modification done for CHG0059320
						if(isNaN(prevValue)){
							return false;
						}else {
							prevValue +=1;
							changableObj.quantity = prevValue;
							qtyInput.val(prevValue);
						}
						resultantData.forEach(function (data) {
							if(data.value === changableObj.value){
								data.quantity = changableObj.quantity
							}
						})
					}
				});
		
	

				$(document).on("keyup", "input.cp_field_text_component.cp_field_spinner_component.form-item.read" , function() {
					var enteredVal = $(this).val();
					if(isNaN(enteredVal) || enteredVal.indexOf(' ') >=0 || enteredVal === "") { 
					$(this).val(0.00); 
					}else{ 
					$(this).val(parseInt(enteredVal)); 
					} 
					
					var selectedQuantityItem = this;
					var changableObj = JSON.parse($(this).parent('div').attr('changedData'));
					var qtyInput = $(this).val();
					var prevValue = parseInt(qtyInput);
					if(isNaN(prevValue)){
						return false;
					}else if(prevValue <=0){
						resultantData.forEach(function (data) {
							if(data.value === changableObj.value){
								$(selectedQuantityItem).val(data.quantity);
							}
						})
					}else {
						resultantData.forEach(function (data) {
							if(data.value === changableObj.value){
								data.quantity = prevValue
							}
						})
					}

				});

				// $(document).on("keypress", "input.cp_field_text_component.cp_field_spinner_component.form-item.read" , function(evt) {
					// evt = (evt) ? evt : window.event;
					// var charCode = (evt.which) ? evt.which : evt.keyCode;
					// if (charCode > 31 && (charCode < 48 || charCode > 57)) {
						// return false;
					// }
					// return true;
				// });

				$(document).on("click", "input.cpf-spinner-button-decrease.button.remove" , function() {
					var changableObj = JSON.parse($(this).parent('div').attr('changedData'));
					var qtyInput = $(this).next();
					var prevValue = parseInt(qtyInput.val());
					if(isNaN(prevValue)){
						return false;
					}else if(prevValue <=1){
						return false;
					}else {
						prevValue -=1;
						changableObj.quantity = prevValue;
						qtyInput.val(prevValue);
					}
					resultantData.forEach(function (data) {
						if(data.value === changableObj.value){
							data.quantity = changableObj.quantity
						}
					})
				});


				this._clearWakeupData();
				this.initChangeOfWakeup(document);
				this.initChangeOfDataItems();
				if (localStorage.getItem('pluginInitData')) {
					this._log(window.location.host + ' OPEN. GET DATA FROM LOCAL STORAGE', JSON.stringify(JSON.parse(localStorage.getItem('pluginInitData')), null, 4));

					$('.json__local-storage').text(JSON.stringify(JSON.parse(localStorage.getItem('pluginInitData')), null, 4));
				}
             },



            /**
             * Business login on plugin wakeup (background open for sync)
             *
             * @param {Object} receivedData - JSON object that contain data from OFSC
             */
            pluginWakeup: function (receivedData) {
                this._log(window.location.host + ' WAKEUP', JSON.stringify(receivedData, null, 4));

                var wakeupData = {
                    pluginWakeupCount: +localStorage.getItem('pluginWakeupCount'),
                    pluginWakeupMaxCount: +localStorage.getItem('pluginWakeupMaxCount'),
                    pluginWakeupDontRespondOn: +localStorage.getItem('pluginWakeupDontRespondOn')
                };

                wakeupData.pluginWakeupCount = wakeupData.pluginWakeupCount + 1;

                localStorage.setItem('pluginWakeupCount', wakeupData.pluginWakeupCount);
                localStorage.setItem('pluginWakeupMaxCount', wakeupData.pluginWakeupMaxCount);
                localStorage.setItem('pluginWakeupDontRespondOn', wakeupData.pluginWakeupDontRespondOn);

                this._log(window.location.host + ' SAVE WAKEUP DATA TO LOCAL STORAGE', JSON.stringify(wakeupData, null, 4));

                if (wakeupData.pluginWakeupDontRespondOn == wakeupData.pluginWakeupCount) {
                    this._log(window.location.host + ' EMULATE NOT RESPONDING PLUGIN');

                    return;
                }

                if (wakeupData.pluginWakeupCount < wakeupData.pluginWakeupMaxCount) {
                    setTimeout(function () {
                        this._log(window.location.host + ' SLEEP. RETRY NEEDED');

                        this._sendPostMessageData({
                            apiVersion: 1,
                            method: 'sleep',
                            wakeupNeeded: true
                        });
                    }.bind(this), 2000);
                } else {
                    setTimeout(function () {
                        this._log(window.location.host + ' SLEEP. NO RETRY');

                        this._sendPostMessageData({
                            apiVersion: 1,
                            method: 'sleep',
                            wakeupNeeded: false
                        });
                    }.bind(this), 12000);
                }
            },

            /**
             * Save configuration of wakeup (background open for sync) behavior for Plugin
             * to Local Storage
             *
             * @private
             */
            _saveWakeupData: function () {
                var wakeupData = {
                    pluginWakeupCount: 0,
                    pluginWakeupMaxCount: 0,
                    pluginWakeupDontRespondOn: 0
                };

                if ($('#wakeup').is(':checked')) {
                    wakeupData.pluginWakeupMaxCount = parseInt($('#repeat_count').val());

                    if ($('#dont_respond').is(':checked')) {
                        wakeupData.pluginWakeupDontRespondOn = parseInt($('#dont_respond_on').val());
                    }
                }

                localStorage.setItem('pluginWakeupCount', wakeupData.pluginWakeupCount);
                localStorage.setItem('pluginWakeupMaxCount', wakeupData.pluginWakeupMaxCount);
                localStorage.setItem('pluginWakeupDontRespondOn', wakeupData.pluginWakeupDontRespondOn);

                this._log(window.location.host + ' SAVE WAKEUP DATA TO LOCAL STORAGE', JSON.stringify(wakeupData, null, 4));
            },

            /**
             * Clear previous configuration of wakeup (background open for sync) behavior for Plugin
             * from the Local Storage
             *
             * @private
             */
            _clearWakeupData: function () {
                localStorage.removeItem('pluginWakeupCount');
                localStorage.removeItem('pluginWakeupMaxCount');
                localStorage.removeItem('pluginWakeupDontRespondOn');

                this._log(window.location.host + ' CLEAR WAKEUP DATA FROM LOCAL STORAGE');
            },


            initChangeOfWakeup: function (element) {

                function onWakeupChange(elem) {
                    var isChecked = $(elem).is(':checked');

                    if (isChecked) {
                        $(element).find('#repeat_count').prop('disabled', false);
                        $(element).find('#dont_respond').prop('disabled', false);

                        $(element).find('#wakeup_row').removeClass('wakeup-form-row--disabled');

                        onDontRespondChange($(element).find('#dont_respond'));
                    } else {
                        $(element).find('#repeat_count').prop('disabled', true);
                        $(element).find('#dont_respond').prop('disabled', true);
                        $(element).find('#dont_respond_on').prop('disabled', true);

                        $(element).find('#wakeup_row').addClass('wakeup-form-row--disabled');
                        $(element).find('#dont_respond_row').addClass('wakeup-form-row--disabled');
                    }
                }

                function onDontRespondChange(elem) {
                    var isChecked = $(elem).is(':checked');

                    if (isChecked) {
                        $(element).find('#dont_respond_on').prop('disabled', false);
                        $(element).find('#dont_respond_row').removeClass('wakeup-form-row--disabled');
                    } else {
                        $(element).find('#dont_respond_on').prop('disabled', true);
                        $(element).find('#dont_respond_row').addClass('wakeup-form-row--disabled');
                    }
                }

                $(element).find('#wakeup').change(function (e) {
                    onWakeupChange(e.target);
                });

                $(element).find('#dont_respond').change(function (e) {
                    onDontRespondChange(e.target);
                });

                onWakeupChange($(element).find('#wakeup'));
            },

            initChangeOfDataItems: function () {
                //set checkboxes from local storage
                if (localStorage.getItem('dataItems')) {
                    $('.data-items').attr('checked', true);
                    $('.data-items-holder').show();

                    var dataItems = JSON.parse(localStorage.getItem('dataItems'));

                    $('.data-items-holder input').each(function () {
                        if (dataItems.indexOf(this.value) != -1) {
                            $(this).attr('checked', true);
                        }
                    });
                }

                //init handlers
                $('.data-items').on('change', function (e) {
                    $('.data-items-holder').toggle();
                });
            },

            initLocalStorageOption: function(localStorageKey) {
                if (localStorage.getItem(localStorageKey) === null) {
                    localStorage.setItem(localStorageKey, 'true');
                }
            },

            /**
             * Initialization function
             */
            init: function () {
				if (navigator.serviceWorker) {
              this._log(window.location.host + ' Service Worker is supported');
              navigator.serviceWorker.register('Expenses-service-worker.js').then(function(registration) {
                this._log(window.location.host + ' Service Worker is registered with scope: ' + registration.scope);
                registration.addEventListener('updatefound', function() {
                  this._log(window.location.host + ' Service Worker update is found');
                  var newServiceWorker = registration.installing;
                  newServiceWorker.addEventListener('statechange', function() {
                    switch (newServiceWorker.state) {
                      case "installed":
                        this._log(window.location.host + ' New Service Worker is installed');
						break;
                    }
                   }.bind(this));
				}.bind(this));
                navigator.serviceWorker.addEventListener('controllerchange', function() {
					this.notifyAboutNewVersion();
				}.bind(this));
					this.startApplication();
				}.bind(this), function(err) {
					this._log(window.location.host + ' Service Worker registration failed: ' + err);
					this.startApplication();
				    }.bind(this));
                return;
            } else {
                this._log(window.location.host + ' Service Worker is not supported');
			        }
			this.startApplication();
			},
			startApplication: function() {
				
                this._log(window.location.host + ' PLUGIN HAS BEEN STARTED');

                $('.back_method_select').on('change', function () {
                    if ($('.back_method_select').val() == 'activity_by_id') {
                        $('.back_activity_id').show();
                    } else {
                        $('.back_activity_id').val('').hide();
                    }
                });

                $('.json_local_storage_toggle').on('click', function () {
                    $('.json__local-storage').toggle();
                });

                $('.json_request_toggle').on('click', function () {
                    $('.column-item--request').toggle();
                });

                $('.json_response_toggle').on('click', function () {
                    $('.column-item--response').toggle();
                }.bind(this));


                window.addEventListener("message", this._getPostMessageData.bind(this), false);

                this.initLocalStorageOption('showHeader');
                this.initLocalStorageOption('backNavigationFlag');
                
                var jsonToSend = {
                    apiVersion: 1,
                    method: 'ready',
                    sendInitData: true
                };

                //parse data items
				var dataItems = JSON.parse(localStorage.getItem('dataItems_expAct'));
                //var dataItems = ['resource'];
                console.log(dataItems);

                if (dataItems) {
                    $.extend(jsonToSend, {dataItems: dataItems});
                }

                this._sendPostMessageData(jsonToSend);
            },
			
			notifyAboutNewVersion: function() {
			    this._log(window.location.host + ' New Service Worker is activated. Page refresh is needed');
			    var footer = document.querySelector('.footer');
			    var versionNotificationElement = document.createElement('div');
			    versionNotificationElement.className = 'new-version-notification';
			    versionNotificationElement.innerHTML = 'New version is detected. Please reopen the page';
			    footer.appendChild(versionNotificationElement);	
		
        }
        });
		
		window.OfscPlugin.getVersion = function() {
			return resourcesVersion;
	};

    })(jQuery);