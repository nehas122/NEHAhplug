"use strict";

(function($) {
	window.OfscPlugin = function(debugMode) {
		this.debugMode = debugMode || false;
	};

	var aLinkedServiceItem1 = "";
	var g_activityId, g_wakeupNeeded, g_domainName;

	$.extend(window.OfscPlugin.prototype, {
		/**
		 * Dictionary of enums
		 */
		dictionary: {
			astatus: {
				pending: {
					label: 'pending',
					translation: 'Pending',
					outs: ['started', 'cancelled', 'suspended'],
					color: '#FFDE00'
				},
				started: {
					label: 'started',
					translation: 'Started',
					outs: ['complete', 'suspended', 'notdone', 'cancelled'],
					color: '#A2DE61'
				},
				complete: {
					label: 'complete',
					translation: 'Completed',
					outs: [],
					color: '#79B6EB'
				},
				suspended: {
					label: 'suspended',
					translation: 'Suspended',
					outs: [],
					color: '#9FF'
				},
				notdone: {
					label: 'notdone',
					translation: 'Not done',
					outs: [],
					color: '#60CECE'
				},
				cancelled: {
					label: 'cancelled',
					translation: 'Cancelled',
					outs: [],
					color: '#80FF80'
				}
			},
			invpool: {
				customer: {
					label: 'customer',
					translation: 'Customer',
					outs: ['deinstall'],
					color: '#04D330'
				},
				install: {
					label: 'install',
					translation: 'Installed',
					outs: ['provider'],
					color: '#00A6F0'
				},
				deinstall: {
					label: 'deinstall',
					translation: 'Deinstalled',
					outs: ['customer'],
					color: '#00F8E8'
				},
				provider: {
					label: 'provider',
					translation: 'Resource',
					outs: ['install'],
					color: '#FFE43B'
				}
			}
		},

		mandatoryActionProperties: {},

		/**
		 * Which field shouldn't be editable
		 *
		 * format:
		 *
		 * parent: {
		 *     key: true|false
		 * }
		 *
		 */
		renderReadOnlyFieldsByParent: {
			data: {
				apiVersion: true,
				method: true,
				entity: true
			},
			resource: {
				pid: true,
				pname: true,
				gender: true
			}
		},

		/**
		 * Check for string is valid JSON
		 *
		 * @param {*} str - String that should be validated
		 *
		 * @returns {boolean}
		 *
		 * @private
		 */
		_isJson: function(str) {
			try {
				JSON.parse(str);
			} catch (e) {
				return false;
			}
			return true;
		},

		/**
		 * Return origin of URL (protocol + domain)
		 *
		 * @param {String} url
		 *
		 * @returns {String}
		 *
		 * @private
		 */
		_getOrigin: function(url) {
			if (url != '') {
				if (url.indexOf("://") > -1) {
					return 'https://' + url.split('/')[2];
				} else {
					return 'https://' + url.split('/')[0];
				}
			}

			return '';
		},

		/**
		 * Return domain of URL
		 *
		 * @param {String} url
		 *
		 * @returns {String}
		 *
		 * @private
		 */
		_getDomain: function(url) {
			if (url != '') {
				if (url.indexOf("://") > -1) {
					return url.split('/')[2];
				} else {
					return url.split('/')[0];
				}
			}

			return '';
		},

		//added for MPF Phase 4 - CHG0069304
		_getDomainURL: function() {
			//return document.referrer.match(/\:\/\/([^\/]+)\.etadirect\.com\//)[1];
			//Reg Ex modified to handle both etadirect.com and fs.ocs.oraclecloud.com URLs
			return document.referrer.match(/\:\/\/([^\/]+)\.(?:etadirect.com|fs.ocs.oraclecloud.com)/)[1];
		},
		//

		/**
		 * Sends postMessage to document.referrer
		 *
		 * @param {Object} data - Data that will be sent
		 *
		 * @private
		 */
		_sendPostMessageData: function(data) {
			//	alert("_sendPostMessageData");
			//	alert("data:" + JSON.stringify(data));
			var originUrl = document.referrer || (document.location.ancestorOrigins && document.location.ancestorOrigins[0]) || '';

			if (originUrl) {
				this._log(window.location.host + ' -> ' + data.method + ' ' + this._getDomain(originUrl), JSON.stringify(data, null, 4));

				parent.postMessage(data, this._getOrigin(originUrl));
			} else {
				this._log(window.location.host + ' -> ' + data.method + ' ERROR. UNABLE TO GET REFERRER');
			}
		},

		/**
		 * Handles during receiving postMessage
		 *
		 * @param {MessageEvent} event - Javascript event
		 *
		 * @private
		 */
		_getPostMessageData: function(event) {

			if (typeof event.data === 'undefined') {
				this._log(window.location.host + ' <- NO DATA ' + this._getDomain(event.origin), null, null, true);

				return false;
			}

			if (!this._isJson(event.data)) {
				this._log(window.location.host + ' <- NOT JSON ' + this._getDomain(event.origin), null, null, true);

				return false;
			}

			var data = JSON.parse(event.data);

			if (!data.method) {
				this._log(window.location.host + ' <- NO METHOD ' + this._getDomain(event.origin), null, null, true);

				return false;
			}

			this._log(window.location.host + ' <- ' + data.method + ' ' + this._getDomain(event.origin), JSON.stringify(data, null, 4));

			switch (data.method) {
				case 'init':
					this.pluginInitEnd(data);
					break;

				case 'open':
					this.pluginOpen(data);
					break;

				case 'wakeup':
					this.pluginWakeup(data);
					break;

				case 'error':
					data.errors = data.errors || {
						error: 'Unknown error'
					};
					this._showError(data.errors);
					break;

				default:
					this._log(window.location.host + ' <- UNKNOWN METHOD: ' + data.method + ' ' + this._getDomain(event.origin), null, null, true);
					break;
			}
		},

		/**
		 * Show alert with error
		 *
		 * @param {Object} errorData - Object with errors
		 *
		 * @private
		 */
		_showError: function(errorData) {
			alert(JSON.stringify(errorData, null, 4));
		},
		// Start changes for CHG0069377-Service_Advantage_Billing
		/**
		 * Check Null value
		 *
		 * @param {value} - Actual value
		 *
		 * return value
		 */
		_checkNull: function(value) {
			if (value == null || 'undefined' == value)
				return "";
			else
				return value;
		},
		/**
		 * Check single digit
		 *
		 * @param {value} - Actual value
		 *
		 * return value
		 */
		_checkSingleDigit: function(value) {
			if (value >= 0 && value < 10)
				return '0' + value;
			else
				return value;
		},

		/**
		 * Logs to console
		 *
		 * @param {String} title - Message that will be log
		 * @param {String} [data] - Formatted data that will be collapsed
		 * @param {String} [color] - Color in Hex format
		 * @param {Boolean} [warning] - Is it warning message?
		 *
		 * @private
		 */
		_log: function(title, data, color, warning) {
			if (!this.debugMode) {
				return;
			}
			if (!color) {
				color = '#0066FF';
			}
			if (!!data) {
				console.groupCollapsed('%c[Plugin API] ' + title, 'color: ' + color + '; ' + (!!warning ? 'font-weight: bold;' : 'font-weight: normal;'));
				console.log('[Plugin API] ' + data);
				console.groupEnd();
			} else {
				console.log('%c[Plugin API] ' + title, 'color: ' + color + '; ' + (!!warning ? 'font-weight: bold;' : ''));
			}
		},

		/**
		 * Business login on plugin init
		 */
		saveToLocalStorage: function(data) {
			this._log(window.location.host + ' INIT. SET DATA TO LOCAL STORAGE', JSON.stringify(data, null, 4));

			if (data.attributeDescription) {
				localStorage.setItem('pluginInitData', JSON.stringify(data.attributeDescription));
			}
		},

		/**
		 * Business login on plugin init end
		 *
		 * @param {Object} data - JSON object that contain data from OFSC
		 */
		pluginInitEnd: function(data) {
			this.saveToLocalStorage(data);

			var messageData = {
				apiVersion: 1,
				method: 'initEnd'
			};

			if (localStorage.getItem('pluginWakeupCount') < localStorage.getItem('pluginWakeupMaxCount')) {
				this._log(window.location.host + ' UNFINISHED WAKEUP DATA FOUND IN LOCAL STORAGE');

				messageData.wakeupNeeded = true;
			}

			this._sendPostMessageData(messageData);
		},

		/**
		 * Business login on plugin open
		 *
		 * @param {Object} receivedData - JSON object that contain data from OFSC
		 */
		pluginOpen: function(receivedData) {

			// clearing the Wakeup data

			this._clearWakeupData();
			if (localStorage.getItem('pluginInitData')) {
				this._log(window.location.host + ' OPEN. GET DATA FROM LOCAL STORAGE', JSON.stringify(JSON.parse(localStorage.getItem('pluginInitData')), null, 4));
				$('.json__local-storage').text(JSON.stringify(JSON.parse(localStorage.getItem('pluginInitData')), null, 4));
			}
			this.initChangeOfWakeup(document);
			this.initChangeOfDataItems();
			var $parentThis = this;




			//on page load getting detail

			var domainName = this._getDomainURL();
			g_domainName = domainName;
			var activityId = receivedData.activity.aid;

			// to show hide dropdown start  --------

			var ddc = 0;
			if (receivedData.activity.A_HD_SURRENDER_STATUS == "Yes" || receivedData.activity.A_HD_SURRENDER_STATUS == "NoHardDrive") {
				$('#upperSubmitDiv').hide();
				$('#hdSurrenderStatusDiv').hide();
			} else if (receivedData.activity.A_HD_SURRENDER_STATUS == "No" && receivedData.activity.A_HD_SUR_IC_FLOW_FLAG == 1) {
				$('#upperSubmitDiv').show();
				$('#hdSurrenderStatusDiv').show();
				ddc = 1;
				$("#cpf_billingReasonDDSectionParts option[value=No]").remove();
				$("#cpf_billingReasonDDSectionParts option[value=NoHardDrive]").remove();
			} else if ((receivedData.activity.A_HD_SURRENDER_STATUS == "Yes" || receivedData.activity.A_HD_SURRENDER_STATUS == "NoHardDrive")
				&& receivedData.activity.A_HD_SUR_IC_FLOW_FLAG == 2) {
				$('#upperSubmitDiv').hide();
				$('#hdSurrenderStatusDiv').hide();
			} else if (receivedData.activity.A_HD_SURRENDER_STATUS == "No" && receivedData.activity.A_HD_SUR_IC_FLOW_FLAG == null) {
				$('#upperSubmitDiv').hide();
				$('#hdSurrenderStatusDiv').hide();
			} else {
				$('#upperSubmitDiv').show();
				$('#hdSurrenderStatusDiv').show();
			}

			// to show hide dropdown end  --------

			// to call function start  --------

			$('#hdStatusFlagSubmitBtn').click(function(event) {
				var value = $('#cpf_billingReasonDDSectionParts').val();

				if (!value) {
					alert('Please select HD Surrender Status.');
					return false;
				}

				if (value != null && (value == 'Yes' || value == 'NoHardDrive') && receivedData.activity.A_HD_SUR_IC_FLOW_FLAG == null) {
					$('#completionPluginWrapper1').show();
					$('#upperSubmitDiv').hide();
					$('#customerNameField').html(receivedData.activity.cname);
				} else if (value != null && (value == 'Yes' || value == 'NoHardDrive') && receivedData.activity.A_HD_SUR_IC_FLOW_FLAG != null && receivedData.activity.A_HD_SURRENDER_STATUS != null) {
					$('#completionPluginWrapper1').hide();
					incompleteFlow();
				} else {
					$('#completionPluginWrapper1').hide();
					incompleteFlow();
				}
			}.bind(this));

			// to call function end --------

			var ultimateBind = this;
			var errorLogs = receivedData.activity.A_PLUGIN_ERROR_LOG;
			//	var activityId = receivedData.activity.aid;
			/*			
						var headers = {
							'Authorization':
								'Basic ' + btoa(receivedData.securedData.client_id + "@" + domainName + ":" + receivedData.securedData.client_secret)
						};
			*/
			var headers = {
				'accept': 'application/json',
				'Authorization':
					'Basic ' + window.btoa(receivedData.securedData.clientId + "@" + domainName + ":" + receivedData.securedData.clientSecret)
			};
			$.ErrorUpdate = function(activityId, sErrorLogs) {

				this._sendPostMessageData({
					"apiVersion": 1,
					"method": "update",
					"activity": {
						"A_PLUGIN_ERROR_LOG": sErrorLogs,
						"aid": activityId
					}

				});
			}.bind(this);



			var envVar = window.location.hostname;
			var temp1 = envVar.split('.');
			var env = temp1[0];
			var nowDate = new Date();
			var now = nowDate.toISOString();
			var dateArr = now.split('T');
			var currentDate = dateArr[0];
			var pluginName = "PI-HD-Surrender";
			var ofscDate = '';

			var company = receivedData.securedData.company;
			var clientId = receivedData.securedData.client_id;
			var clientSecret = receivedData.securedData.client_secret;
			// Base 64 encryption for REST API calls
			var authorizationB64 = btoa(clientId + "@" + company + ":" + clientSecret);

			var shiftLabel = null;
			var activityLog = null;
			var todaysDate = new Date();

			$.convertDate = function(date) {
				var yyyy = date.getFullYear().toString();
				var mm = (date.getMonth() + 1).toString();
				var dd = date.getDate().toString();

				var mmChars = mm.split('');
				var ddChars = dd.split('');

				return yyyy + '-' + (mmChars[1] ? mm : "0" + mmChars[0]) + '-' + (ddChars[1] ? dd : "0" + ddChars[0]);
			};

			var todaysDate = $.convertDate(todaysDate);

			this.QtyDDSection = $("#QtyDDSection").html();
			this.billingReasonDDSection = $("#billingReasonDDSection").html();
			this.billingAmountUndoSection = $("#billingAmountUndoSection").html();
			var activityId = receivedData.activity.aid;
			var activityStatus = receivedData.activity.A_STATUS;
			var inventoryList = receivedData.inventoryList;

			// Current Date Time Section:
			var TodayDate = new Date();
			var year = TodayDate.getYear().toString().substr(-2);
			var day = TodayDate.getDate(); //it returns the date
			day = ("0" + day).slice(-2);
			var month = TodayDate.getMonth() + 1;
			month = ("0" + month).slice(-2);
			var hours = TodayDate.getHours();
			hours = ("0" + hours).slice(-2);
			var minutes = TodayDate.getMinutes();
			minutes = ("0" + minutes).slice(-2);
			var date_MM_DD = month + "-" + day;
			var date_MM_DD_YY = month + "/" + day + "/" + year;
			var date_YYYY_MM_DD = TodayDate.getFullYear().toString() + "-" + month + "-" + day;
			//	var currDateTimeFormat = TodayDate.getFullYear().toString() + "-" + month + "-" + day + " " + hours + ":" + minutes;
			var currDateTimeFormat = TodayDate.getFullYear().toString() + "-" + month + "-" + day + "T" + hours + ":" + minutes + ":" + "00";
			var currdateTime = date_MM_DD_YY + " " + hours + ":" + minutes;
			var showExtraLaborRow = false;

			/* var startTimeMinit = (parseInt(minutes) + 1);
			var scanInTimeeMinit = (parseInt(minutes) + 2);
			var scanOutTimeMinit = (parseInt(minutes) + 3)

			var startTimeMinitStr = startTimeMinit < 10 ? ("0" + startTimeMinit) : startTimeMinit;
			var scanInTimeeMinitStr = scanInTimeeMinit < 10 ? ("0" + scanInTimeeMinit) : scanInTimeeMinit;
			var scanOutTimeMinitStr = scanOutTimeMinit < 10 ? ("0" + scanOutTimeMinit) : scanOutTimeMinit;

			var startTime = TodayDate.getFullYear().toString() + "-" + month + "-" + day + "T" + hours + ":" + startTimeMinitStr + ":" + "00";
			var scanInTime = TodayDate.getFullYear().toString() + "-" + month + "-" + day + "T" + hours + ":" + scanInTimeeMinitStr + ":" + "00";
			var scanOutTime = TodayDate.getFullYear().toString() + "-" + month + "-" + day + "T" + hours + ":" + scanOutTimeMinitStr + ":" + "00"; */

			// for start time CHG0085961
 
			var startDateTime = new Date();
			var startDateTimeMillisecondssince1970 = startDateTime.getTime();
			var startDateTimeNewMillisec = startDateTimeMillisecondssince1970 + (1000 * 60);
 
			var startDateTimeNewDate = new Date(startDateTimeNewMillisec);
			var startTime = startDateTimeNewDate.getFullYear().toString() + "-" + ("0" + (startDateTimeNewDate.getMonth() + 1)).slice(-2) + "-" + ("0" + startDateTimeNewDate.getDate()).slice(-2) + "T" + ("0" + startDateTimeNewDate.getHours()).slice(-2) + ":" + ("0" + startDateTimeNewDate.getMinutes()).slice(-2) + ":" + "00";
			//
 
			// for scain in time CHG0085961
 
			var scanInDateTime = new Date();
			var scanInDateTimeMillisecondssince1970 = scanInDateTime.getTime();
			var scanInDateTimeNewMillisec = scanInDateTimeMillisecondssince1970 + (1000 * 60 * 2);
 
			var scanInDateTimeNewDate = new Date(scanInDateTimeNewMillisec);
			var scanInTime = scanInDateTimeNewDate.getFullYear().toString() + "-" + ("0" + (scanInDateTimeNewDate.getMonth() + 1)).slice(-2) + "-" + ("0" + scanInDateTimeNewDate.getDate()).slice(-2) + "T" + ("0" + scanInDateTimeNewDate.getHours()).slice(-2) + ":" + ("0" + scanInDateTimeNewDate.getMinutes()).slice(-2) + ":" + "00";
			//
 
			// for scan out time CHG0085961
 
			var scanOutDateTime = new Date();
			var scanOutDateTimeMillisecondssince1970 = scanOutDateTime.getTime();
			var scanOutDateTimeNewMillisec = scanOutDateTimeMillisecondssince1970 + (1000 * 60 * 3);
 
			var scanOutDateTimeNewDate = new Date(scanOutDateTimeNewMillisec);
			var scanOutTime = scanOutDateTimeNewDate.getFullYear().toString() + "-" + ("0" + (scanOutDateTimeNewDate.getMonth() + 1)).slice(-2) + "-" + ("0" + scanOutDateTimeNewDate.getDate()).slice(-2) + "T" + ("0" + scanOutDateTimeNewDate.getHours()).slice(-2) + ":" + ("0" + scanOutDateTimeNewDate.getMinutes()).slice(-2) + ":" + "00";
			//

			var activityId = receivedData.activity.aid;
			var resourceNumber = receivedData.resource.R_EMPLOYEE_NUMBER;
			var rid = receivedData.resource.external_id;

			var aHDSurrenderRequired = receivedData.activity.A_HD_SURRENDER_REQUIRED;
			var aRMANumber = receivedData.activity.A_RMA_SERIAL_NUMBER;
			$('#rmaNumber').text(aRMANumber);
			// Signature Section.
			var sigdiv = $("#signature");
			sigdiv.signature();
			var onloadedEmptySignatureBlock = sigdiv.signature('toDataURL');
			$('#signature').signature({
				change: function(event, ui) {
					////	alert('Signature changed');
				}
			});
			$('#clear_btn').click(function() {
				$('#signature').signature('clear');
			});

			$('.cancelBtn').click(function() {
				this._sendPostMessageData({
					"apiVersion": 1,
					"method": "close",
					"backScreen": "default",
					"wakeupNeeded": false

				});
			}.bind(this));

			//allow only numeric values(excludes .) in input field
			$("input:text.cp_field_number_n").on('keyup', function(e) {
				$(this).val($(this).val().replace(/[^0-9]/g, ''));
			});

			//	var activityCreationUrl = "https://" + domainName + ".etadirect.com/rest/ofscCore/v1/activities";
			$('#hdSurrenderFormSubmitBtn').click(function(event) {
				$("#hdSurrenderFormSubmitBtn").attr("disabled", true);

				var hdSurrenderStatusDD = $('#cpf_billingReasonDDSectionParts').val();

				if (hdSurrenderStatusDD != null && hdSurrenderStatusDD == "Yes") {
					// alert("Yes.");
					var hdSurrenderStatusDDPayload = hdSurrenderStatusDD;
					var resolutionCode = "HDS";
					var expenceOutbound = "<DebriefExpenseLine><A_EXPENSE_TYPE>HD-SURRENDER</A_EXPENSE_TYPE><A_AMOUNT>0</A_AMOUNT><A_OVERRIDE_PRICE>0</A_OVERRIDE_PRICE><A_PRICE_OVERRIDE_REASON_CODE></A_PRICE_OVERRIDE_REASON_CODE></DebriefExpenseLine>";
					var billingComment = "Signing this form is acknowledgement the hard drive from the listed serial number has been removed and surrendered and is in the customer custody.";
				} else if (hdSurrenderStatusDD != null && hdSurrenderStatusDD == "NoHardDrive") {
					// alert("NoHardDrive");
					var hdSurrenderStatusDDPayload = hdSurrenderStatusDD;
					var resolutionCode = "NHD";
					var expenceOutbound = "";
					var billingComment = "Device did not have a hard drive installed";
				} else {
					alert("Invalid Status Selection.");
					var hdSurrenderStatusDDPayload = hdSurrenderStatusDD;
					var resolutionCode = "NA";
					var expenceOutbound = "NA";
					var billingComment = "NA";
					return false;
				}

				var blackAndWhite = $('#blackAndWhiteMeter').val();
				var color = $('#colorMeter').val();
				var total = $('#totalMeter').val();
				var primmaryEmails = $('#primmaryEmails').val();
				var ccEmails = $('#ccEmails').val();
				var hdSigneeName = $('#signeeName').val();

				$('#signeeName').ForceAlphabetsOnly();

				// checking valid email format entered by user in service ticket screen 
				var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,6})?$/;

				if (primmaryEmails != null && primmaryEmails != '') {
					if (!(emailReg.test(primmaryEmails))) {
						$("#hdSurrenderFormSubmitBtn").removeAttr("disabled");
						alert('Please enter Contact Email in valid format.');
						return false;
					}
				}
				if (hdSigneeName == null || hdSigneeName == '') {
					$("#hdSurrenderFormSubmitBtn").removeAttr("disabled");
					alert("Some fields were not filled correctly: \n \n Surrender To Name - is not filled.");
					return false;
				}

				var signatureImageData = sigdiv.signature('toDataURL');

				if (onloadedEmptySignatureBlock == signatureImageData) {
					$("#hdSurrenderFormSubmitBtn").removeAttr("disabled");
					alert("Some fields were not filled correctly: \n \n Contact Signature - is not filled.");
					return false;
				}

				var actionsArr = [];
				var actEndTime = TodayDate.getFullYear().toString() + "-" + month + "-" + day + " " + hours + ":" + (minutes + 5);
				var activityPayload = {
					"activityType": "Inst",
					"date": todaysDate,
					"resourceId": rid,
					"resourceNumber": resourceNumber,
					"language": "en",
					"languageISO": "en-US",
					"A_RMA_SERIAL_NUMBER": aRMANumber,
					"Customer_Name": receivedData.activity.cname,
					"A_COUNTER_BLACK_WHITE_HDSURRENDER": blackAndWhite,
					"A_COUNTER_COLOR_HDSURRENDER": color,
					"A_COUNTER_TOTAL_HDSURRENDER": total,
					"A_SIGNATURE": signatureImageData,
					"A_CUSTOMER_CONTACT_EMAIL": primmaryEmails,
					"A_CC_EMAILS": ccEmails,
					"A_SYSTEM_SOURCE": "ORACLE",
					"A_COMPANY_NAME": receivedData.activity.A_COMPANY_NAME,
					"A_TASK_TYPE": "Hard Drive Surrender",
					"A_LINKED_SERVICE_ITEM": receivedData.activity.A_LINKED_SERVICE_ITEM,
					"A_HD_SURRENDER_REQUIRED": "Y",
					"A_NEW_EQUIPMENT_ID": receivedData.activity.A_NEW_EQUIPMENT_ID,
					"A_HD_SURRENDER_STATUS": hdSurrenderStatusDDPayload,  // making dynamic bcoz no hard drive flow
					"A_PROBLEM_CODE": "HN01", // need to ask
					"A_EQUIPMENT_NUMBER": receivedData.activity.A_EQUIPMENT_NUMBER, // remove
					"A_MODEL": receivedData.activity.A_MODEL, // remove
					"A_SERIAL": aRMANumber,
					"customerPhone": receivedData.activity.cphone,
					"A_SR_TYPE": "Deinstall",
					"A_SUMMARY": "HD Surrender call",
					"A_SIGNEE_NAME": receivedData.activity.cname,
					"A_SIGNEE_EMAIL": primmaryEmails,
					"A_CONTACT": receivedData.activity.A_CONTACT,
					"timeSlot": "8-17",
					"streetAddress": receivedData.activity.caddress,
					"city": receivedData.activity.ccity,
					"stateProvince": receivedData.activity.cstate,
					"postalCode": receivedData.activity.czip,
					"customerEmail": receivedData.activity.cemail,
					//	"A_START_TIME": currDateTimeFormat, // 
					//	"A_SCAN_OUT_TIME": currDateTimeFormat,//
					//	"A_SCAN_OUT_TIME": actEndTime,
					"A_ODOMETER_START": "0",
					"A_ODOMETER_END": "0",
					"A_RESOLUTION_CODE": resolutionCode,
					"A_EMAIL_SERVICE_TICKET": "Y",
					"A_BILLING_COMMENT": billingComment,
					"A_EXPENSES_OUTBOUND": expenceOutbound,
					"A_SIGNEE_NAME": hdSigneeName,
					// new labor fiels added
					"A_DISPATCH_TIME": currDateTimeFormat,
					"startTime": currDateTimeFormat,
					"endTime": currDateTimeFormat,
					"A_START_TIME": startTime, //
					"A_SCAN_IN_TIME": scanInTime,
					"A_START_TIME_OVERRIDE": startTime,
					"A_SCAN_OUT_TIME": scanOutTime, //
					"A_LABOR_TIME": "1.00",
					"A_MACHINE_STATUS_BEFORE": "DOWN",
					"A_MACHINE_STATUS_AFTER": "UP",
					"travelTime": 1,
					"A_EQUIPMENT_CONNECTED": "Y",
					"A_STATUS": "CM"
				};

				var activityCreationUrl = "https://" + domainName + ".etadirect.com/rest/ofscCore/v1/activities";
				var authorization = 'Basic ' + window.btoa(receivedData.securedData.clientId + "@" + g_domainName + ":" + receivedData.securedData.clientSecret);
				var payload = {
					activityPayload: activityPayload,
					signatureImageData: signatureImageData,
					resourceId: receivedData.resource.external_id,
					headers: headers,
					activityCreationUrl: activityCreationUrl,
					authorization: authorization,
					parantActivityId: activityId,
					domainName: domainName
				}

				// commenting this way of calling for activty creation fir offline and online mode
				//activityCreation(activityPayload, signatureImageData);
				// new way

				var current = this;
				//Validate internet connectivity and punchin

				$.ajax({
					url: '//' + window.location.host + '/robots.txt' + '?rand=' + Math.random(),
					timeout: 2000,
					type: 'GET',
					tryCount: 0,
					retryLimit: 3,
					success: function(json) {
						console.log('online configuration');
						current.activityCreation(payload, false, false);
					},
					error: function(xhr, textStatus, errorThrown) {
						current.popupEnable("Currently you are in Offline Mode. ", true, true, "successMessage");

						// changes on 16 06 2023 to update hd surrender status flag to yes before activity creation
						current._sendPostMessageData({
							"apiVersion": 1,
							"method": "update",
							"activity": {
								"aid": activityId,
								"A_HD_SURRENDER_STATUS": "Yes"
							}
						});
						//

						//	g_activityId = payload.activityId;
						g_wakeupNeeded = true;
						if (textStatus == 'timeout') {
							this.tryCount++;
							if (this.tryCount <= this.retryLimit) {
								$("#hdSurrenderFormSubmitBtn").removeAttr("disabled");
								//try again
								$.ajax(this);
								return false;
							}
							console.log('offline configuration');
							localStorage.setItem("HDMainRESTCallQue", JSON.stringify(payload));
							$('body').css({ "cursor": "default" });
							///	current.closeMethod(activityId, true);
						} else if (xhr.status == 500) {
							console.log('offline configuration');
							localStorage.setItem("HDMainRESTCallQue", JSON.stringify(payload));
							$('body').css({ "cursor": "default" });
							//	current.closeMethod(activityId, true);
						} else {
							console.log('offline configuration');
							localStorage.setItem("HDMainRESTCallQue", JSON.stringify(payload));
							$('body').css({ "cursor": "default" });
							//	current.closeMethod(activityId, true);
						}
					}
				});

			}.bind(this));

			$('#blackAndWhiteMeter').keyup(function(e) {
				var a = $('#blackAndWhiteMeter').val();
				if (a == null || a == '' || a == undefined) {
					a = 0;
				} else {
					a = parseInt(a);
				}
				var b = $('#colorMeter').val();
				if (b == null || b == '' || b == undefined) {
					b = 0;
				} else {
					b = parseInt(b);
				}
				var c = a + b;
				$('#totalMeter').val(c);

			})
			$('#colorMeter').keyup(function(e) {

				var a = $('#blackAndWhiteMeter').val();
				if (a == null || a == '' || a == undefined) {
					a = 0;
				} else {
					a = parseInt(a);
				}
				var b = $('#colorMeter').val();
				if (b == null || b == '' || b == undefined) {
					b = 0;
				} else {
					b = parseInt(b);
				}

				var c = a + b;
				$('#totalMeter').val(c);

			})

			jQuery.fn.ForceNumericOnly =
				function() {
					return this.each(function() {
						$(this).keydown(function(e) {
							var key = e.charCode || e.keyCode || 0;
							// allow backspace, tab, delete, enter, arrows, numbers and keypad numbers ONLY
							// home, end, period, and numpad decimal
							return (
								key == 8 ||
								key == 9 ||
								key == 13 ||
								key == 46 ||
								key == 110 ||
								key == 190 ||
								(key >= 48 && key <= 57));
						});
					});
				};

			jQuery.fn.ForceAlphabetsOnly =
				function() {
					return this.each(function() {
						$(this).keydown(function(e) {
							var key = e.charCode || e.keyCode || 0;
							return ((key >= 65 && key <= 90) || key == 8);
						});
					});
				};


			$('#messagePanel #notification-clear').click(function() {
				$('#messagePanel').hide();
				//	this.closeMethod(g_activityId, g_wakeupNeeded);
				this.closeMethod(activityId, g_wakeupNeeded);
			}.bind(this));

			function incompleteFlow() {
				var activityPayload = {
					"activityType": "Inst",
					"date": todaysDate,
					"resourceId": rid,
					"resourceNumber": resourceNumber,
					"language": "en",
					"languageISO": "en-US",
					"A_RMA_SERIAL_NUMBER": aRMANumber,
					"Customer_Name": receivedData.activity.cname,
					"A_SYSTEM_SOURCE": "ORACLE",
					"A_COMPANY_NAME": receivedData.activity.A_COMPANY_NAME,
					"A_TASK_TYPE": "Hard Drive Surrender",
					//"A_LINKED_SERVICE_ITEM": aLinkedServiceItem,
					"A_LINKED_SERVICE_ITEM": receivedData.activity.A_LINKED_SERVICE_ITEM,
					"A_HD_SURRENDER_REQUIRED": "Y",
					"A_HD_SURRENDER_STATUS": "No",
					"A_PROBLEM_CODE": "HN01",
					"A_MODEL": receivedData.activity.A_MODEL,
					"A_SERIAL": aRMANumber,
					"customerPhone": receivedData.activity.cphone,
					"A_SR_TYPE": "Deinstall",
					"A_SUMMARY": "HD Surrender call",
					"A_CONTACT": receivedData.activity.A_CONTACT,
					"timeSlot": "8-17",
					"streetAddress": receivedData.activity.caddress,
					"city": receivedData.activity.ccity,
					"stateProvince": receivedData.activity.cstate,
					"postalCode": receivedData.activity.czip,
					"customerEmail": receivedData.activity.cemail,
					"A_HD_SUR_IC_FLOW_FLAG": "1",
					"A_STATE": "EN",
					"A_BILLING_COMMENT": "Signing this form is acknowledgement the hard drive from the listed serial number has been removed and surrendered and is in the customer custody.",
					"A_EXPENSES_OUTBOUND": "<DebriefExpenseLine><A_EXPENSE_TYPE>HD-SURRENDER</A_EXPENSE_TYPE><A_AMOUNT>0</A_AMOUNT><A_OVERRIDE_PRICE>0</A_OVERRIDE_PRICE><A_PRICE_OVERRIDE_REASON_CODE></A_PRICE_OVERRIDE_REASON_CODE></DebriefExpenseLine>"
				};

				var activityCreationUrl = "https://" + domainName + ".etadirect.com/rest/ofscCore/v1/activities";

				headers = {
					'accept': 'application/json',
					'Authorization':
						'Basic ' + window.btoa(receivedData.securedData.clientId + "@" + domainName + ":" + receivedData.securedData.clientSecret)
				};
				var payloadInc = {
					activityPayload: activityPayload,
					resourceId: receivedData.resource.external_id,
					headers: headers,
					activityCreationUrl: activityCreationUrl,
					parantActivityId: activityId
				}

				console.log("Activity Payload: " + JSON.stringify(activityPayload));
				if (receivedData.activity.A_HD_SUR_IC_FLOW_FLAG == null) {
					ultimateBind._sendPostMessageData({
						"apiVersion": 1,
						"method": "update",
						"activity": {
							"aid": receivedData.activity.aid,
							"A_HD_SURRENDER_STATUS": "No"
						}
					});

					//Validate internet connectivity and punchin
					$.ajax({
						url: '//' + window.location.host + '/robots.txt' + '?rand=' + Math.random(),
						timeout: 2000,
						type: 'GET',
						tryCount: 0,
						retryLimit: 3,
						success: function(json) {
							console.log('online configuration');
							ultimateBind.activityCreationIncomplete(payloadInc, false, false);
						},
						error: function(xhr, textStatus, errorThrown) {
							ultimateBind.popupEnable("Currently you are in Offline Mode. ", true, true, "successMessage");
							//	g_activityId = payload.activityId;
							g_wakeupNeeded = true;
							if (textStatus == 'timeout') {
								this.tryCount++;
								if (this.tryCount <= this.retryLimit) {
									//try again
									$.ajax(this);
									return false;
								}
								console.log('offline configuration');
								localStorage.setItem("HDIncompleteMainRESTCallQue", JSON.stringify(payloadInc));
								$('body').css({ "cursor": "default" });
								//	ultimateBind.closeMethod(activityId, true);
							} else if (xhr.status == 500) {
								console.log('offline configuration');
								localStorage.setItem("HDIncompleteMainRESTCallQue", JSON.stringify(payloadInc));
								$('body').css({ "cursor": "default" });
								//	ultimateBind.closeMethod(activityId, true);
							} else {
								console.log('offline configuration');
								localStorage.setItem("HDIncompleteMainRESTCallQue", JSON.stringify(payloadInc));
								$('body').css({ "cursor": "default" });
								//	ultimateBind.closeMethod(activityId, true);
							}
						}
					});

				} else {
					//	alert("only closing the plugin");
					ultimateBind._sendPostMessageData({
						"apiVersion": 1,
						"method": "close",
						"backScreen": "default",
						"activity": {
							"aid": receivedData.activity.aid,
							"A_HD_SUR_IC_FLOW_FLAG": "2",
							"A_HD_SURRENDER_STATUS": "Yes"
						}
					});
				}
			}
		},
		activityCreation: function(payload, wakeupNeeded, wakupMethod) {
			console.log("JSON.stringify(payload.activityPayload)===>" + JSON.stringify(payload.activityPayload));
			var errorLogs = "";
			try {
				var ajaxErrorMessage = "";
				$.ajax({
					url: payload.activityCreationUrl,
					timeout: 20000,
					// cache: false,
					method: 'POST',
					dataType: 'json',
					contentType: 'application/json; charset=utf-8',
					data: JSON.stringify(payload.activityPayload),
					crossDomain: true,
					headers: payload.headers,
					processData: false,
					success: function(successData) {
						//	alert("Activity has been created!!");
						console.log("Activity created - Success messagae: " + JSON.stringify(successData));
						//updating sinatire the activity  send data to r12
						//new call for update signature
						this.updateActivitySignature(payload, wakeupNeeded, wakupMethod, ajaxErrorMessage, successData.activityId);
					}.bind(this),
					error: function(errorData) {
						$("#hdSurrenderFormSubmitBtn").removeAttr("disabled");
						alert("There is some issue!!");
						console.log("Create activity Update Resource properties - Error messagae:" + JSON.stringify(errorData));
						var responseJSON = errorData.responseJSON;

						ajaxErrorMessage += "API: " + payload.activityCreationUrl + "<br />Request: " + JSON.stringify(payload) + "<br />Response: " + JSON.stringify(errorData);
						$.ErrorUpdate(payload.parantActivityId, ajaxErrorMessage);
						this.completeAction(false, ajaxErrorMessage, wakupMethod, wakeupNeeded, payload, null);

					}.bind(this)
				});


			} catch (err) {
				var now = new Date(Date.now());

				if (errorLogs == null) {
					errorLogs = "";
				}
				errorLogs = errorLogs + "||" + now.toString() + "|Plugin :HD Surrender activity creation : Exception " + err.message;
				console.log("Create activity Update Resource properties - Error messagae:" + JSON.stringify(err));
				console.log("Create activity - Error messagae log:" + JSON.stringify(err));
				$.ErrorUpdate(payload.parantActivityId, errorLogs);
			}
		},
		updateActivitySignature: function(payload, wakeupNeeded, wakupMethod, ajaxErrorMessage, actId) {
			var errorLogs = "";
			const binaryData = this.convertBase64ToBlob(payload.signatureImageData);
			try {
				var activityFileUpdateUrl = "https://" + payload.domainName + ".etadirect.com/rest/ofscCore/v1/activities/" + actId + "/A_SIGNATURE";
				$.ajax({
					"url": activityFileUpdateUrl,
					"method": "PUT",
					"timeout": 20000,
					processData: false,
					"headers": {
						"Accept": "application/octet-stream",
						"Content-Type": "image/png",
						'Authorization': payload.authorization
					},
					"data": binaryData,
					success: function(successData) {
						console.log("iimage update response==>" + successData);
						// updatating the status
						//	this.updateHDStatusActivity(payload, wakeupNeeded, wakupMethod, ajaxErrorMessage, actId);
						this.cancelActivity(payload, wakeupNeeded, wakupMethod, ajaxErrorMessage, actId);

					}.bind(this),
					error: function(errorData) {
						$("#hdSurrenderFormSubmitBtn").removeAttr("disabled");
						alert("There is some issue!!");
						console.log("Update signature activity Update Resource properties - Error messagae:" + JSON.stringify(errorData));
						var responseJSON = errorData.responseJSON;

						ajaxErrorMessage += "API: " + activityFileUpdateUrl + "<br />Request: " + JSON.stringify(payload) + "<br />Response: " + JSON.stringify(errorData);
						this.completeAction(false, ajaxErrorMessage, wakupMethod, wakeupNeeded, payload, actId);
						$.ErrorUpdate(actId, ajaxErrorMessage);
					}.bind(this)
				});
			} catch (err) {
				var now = new Date(Date.now());
				if (errorLogs == null) {
					errorLogs = "";
				}
				errorLogs = errorLogs + "||" + now.toString() + "|Plugin :HD Surrender activity signature update : Exception " + err.message;
				$.ErrorUpdate(actId, errorLogs);
			}

		},
		convertBase64ToBlob: function(base64Image) {
			// Split into two parts
			const parts = base64Image.split(';base64,');
			// Hold the content type
			const imageType = parts[0].split(':')[1];
			// Decode Base64 string
			const decodedData = window.atob(parts[1]);
			// Create UNIT8ARRAY of size same as row data length
			const uInt8Array = new Uint8Array(decodedData.length);
			// Insert all character code into uInt8Array
			for (let i = 0; i < decodedData.length; ++i) {
				uInt8Array[i] = decodedData.charCodeAt(i);
			}
			// Return BLOB image after conversion
			//	return new Blob([uInt8Array], { type: imageType });
			return uInt8Array;
		},
		cancelActivity: function(payload, wakeupNeeded, wakupMethod, ajaxErrorMessage, actId) {
			var errorLogs = "";
			try {
				var activityCancelUrl = "https://" + payload.domainName + ".etadirect.com/rest/ofscCore/v1/activities/" + actId + "/custom-actions/cancel";
				$.ajax({
					url: activityCancelUrl,
					timeout: 20000,
					cache: false,
					method: 'POST',
					dataType: 'json',
					contentType: 'application/json; charset=utf-8',
					headers: {
						'accept': 'application/json',
						'Authorization': payload.authorization
					},
					success: function(successData) {
						//	alert("Activity got canceled!!");
						alert("Service request for HD Surrender has been created!!");
						console.log("Activity got canceled - Success messagae: " + JSON.stringify(successData));
						//	localStorage.setItem("Punchin", JSON.stringify(response));
						this.completeAction(true, ajaxErrorMessage, wakupMethod, wakeupNeeded, payload, actId);
					}.bind(this),
					error: function(errorData) {
						$("#hdSurrenderFormSubmitBtn").removeAttr("disabled");
						alert("There is some issue!!");
						console.log("Cancel activity Update Resource properties - Error messagae:" + JSON.stringify(errorData));
						var responseJSON = errorData.responseJSON;

						ajaxErrorMessage += "API: " + activityCancelUrl + "<br />Request: " + JSON.stringify(payload) + "<br />Response: " + JSON.stringify(errorData);
						this.completeAction(false, ajaxErrorMessage, wakupMethod, wakeupNeeded, payload, actId);
						$.ErrorUpdate(actId, ajaxErrorMessage);

					}.bind(this)
				});
			} catch (err) {
				var now = new Date(Date.now());
				if (errorLogs == null) {
					errorLogs = "";
				}
				errorLogs = errorLogs + "||" + now.toString() + "|Plugin :HD Surrender activity signature update : Exception " + err.message;
				$.ErrorUpdate(actId, errorLogs);
			}
		},
		updateHDStatusActivity: function(payload, wakeupNeeded, wakupMethod, ajaxErrorMessage, actId) {
			var errorLogs = "";
			try {
				var activityHDStatusUpdateUrl = "https://" + payload.domainName + ".etadirect.com/rest/ofscCore/v1/activities/" + payload.parantActivityId;

				$.ajax({
					url: activityHDStatusUpdateUrl,
					timeout: 20000,
					cache: false,
					method: 'PATCH',
					dataType: 'json',
					contentType: 'application/json; charset=utf-8',
					headers: {
						'accept': 'application/json',
						'Authorization': payload.authorization
					},
					data: JSON.stringify({
						"A_HD_SURRENDER_STATUS": "Yes"
					}),
					success: function(successData) {
						// alert("HD Surrender status has been updated!!");
						console.log("Activity HD Surrender status has been updated! - Success messagae: " + JSON.stringify(successData));
						this.cancelActivity(payload, wakeupNeeded, wakupMethod, ajaxErrorMessage, actId);
					}.bind(this),
					error: function(errorData) {
						alert("There is some issue!!");
						console.log("Cancel activity Update Resource properties - Error messagae:" + JSON.stringify(errorData));
						var responseJSON = errorData.responseJSON;

						ajaxErrorMessage += "API: " + activityHDStatusUpdateUrl + "<br />Request: " + JSON.stringify(payload) + "<br />Response: " + JSON.stringify(errorData);
						this.completeAction(false, ajaxErrorMessage, wakupMethod, wakeupNeeded, payload, actId);
						$.ErrorUpdate(actId, ajaxErrorMessage);

					}.bind(this)
				});
			} catch (err) {
				var now = new Date(Date.now());
				if (errorLogs == null) {
					errorLogs = "";
				}
				errorLogs = errorLogs + "||" + now.toString() + "|Plugin :HD Surrender Status has been upated : Exception " + err.message;
				$.ErrorUpdate(actId, errorLogs);
			}
		},
		completeAction: function(callNextAjax, ajaxErrorMessage, wakupMethod, wakeupNeeded, payload, activityId) {
			$("#hdSurrenderFormSubmitBtn").removeAttr("disabled");
			// Send post message data to OFSC
			if (callNextAjax && "" == ajaxErrorMessage && !wakupMethod) {
				if (!wakupMethod) {
					///	this.popupEnable("Activity got canceled: ", true, true, "successMessage");
					g_activityId = activityId;
					g_wakeupNeeded = wakeupNeeded;
				}
			} else {
				if (!wakupMethod) {
					var errorMessage = JSON.parse(ajaxErrorMessage.split("Response:").pop()).status;
					errorMessage = "<br>Error status: " + errorMessage;
					//	this.popupEnable("Sone Issue." + errorMessage, true, true, "errorMessage");
				}
				var resourceErrorPayload = { "R_PLUGIN_ERROR": ajaxErrorMessage };
				//this.ajaxCall(payload.resourceUpdateUrl, resourceErrorPayload, "PATCH", payload.headers);
				g_activityId = activityId;
				g_wakeupNeeded = wakeupNeeded;
			}

			$('body').css({ "cursor": "default" });
			if (wakupMethod) {
				this._sendPostMessageData({
					"apiVersion": 1,
					"method": 'sleep',
					"wakeupNeeded": false
				});
			}

			// Send post message data to OFSC
			if (callNextAjax && "" == ajaxErrorMessage) {
				// newplace to cancel n update  in parent activity
				this._sendPostMessageData({
					"apiVersion": 1,
					"method": "close",
					"backScreen": "cancel_activity",
					"backActivityId": payload.parantActivityId,
					"activity": {
						"aid": payload.parantActivityId,
						"A_HD_SURRENDER_STATUS": "Yes"
					}
				})
				//
			}

		},
		completeActionIncomplete: function(callNextAjax, ajaxErrorMessage, wakupMethod, wakeupNeeded, payload, activityId) {
			// Send post message data to OFSC
			if (callNextAjax && "" == ajaxErrorMessage && !wakupMethod) {
				if (!wakupMethod) {
					//	this.popupEnable("Activity got closed: ", true, true, "successMessage");
					g_activityId = activityId;
					g_wakeupNeeded = wakeupNeeded;
				}
			} else {
				if (!wakupMethod) {
					var errorMessage = JSON.parse(ajaxErrorMessage.split("Response:").pop()).status;
					errorMessage = "<br>Error status: " + errorMessage;
					//	this.popupEnable("Sone Issue." + errorMessage, true, true, "errorMessage");
				}
				var resourceErrorPayload = { "R_PLUGIN_ERROR": ajaxErrorMessage };
				//this.ajaxCall(payload.resourceUpdateUrl, resourceErrorPayload, "PATCH", payload.headers);
				g_activityId = activityId;
				g_wakeupNeeded = wakeupNeeded;
			}
			$('body').css({ "cursor": "default" });
			if (wakupMethod) {
				this._sendPostMessageData({
					apiVersion: 1,
					method: 'sleep',
					wakeupNeeded: false
				});
			}

			// Send post message data to OFSC
			if (callNextAjax && "" == ajaxErrorMessage) {
				// newplace to close n update  in parent activity
				this._sendPostMessageData({
					"apiVersion": 1,
					"method": "close",
					"backScreen": "default"
				});
				//
			}

		},
		activityCreationIncomplete: function(payload, wakeupNeeded, wakupMethod) {
			var errorLogs = "";
			try {
				var ajaxErrorMessage = "";

				$.ajax({
					url: payload.activityCreationUrl,
					timeout: 20000,
					cache: false,
					method: 'POST',
					dataType: 'json',
					contentType: 'application/json; charset=utf-8',
					data: JSON.stringify(payload.activityPayload),
					headers: payload.headers,
					success: function(successData) {
						alert("Service request has been created for today, kindly view it in the pending list");
						console.log("Activity created for Incomplete flow - Success messagae: " + JSON.stringify(successData));
						this.completeActionIncomplete(true, ajaxErrorMessage, wakupMethod, wakeupNeeded, payload, successData.activityId);
					}.bind(this),
					error: function(errorData) {
						alert("There is some issue!!");
						console.log("Create activity Incomplete Update Resource properties - Error messagae:" + JSON.stringify(errorData));
						var responseJSON = errorData.responseJSON;

						ajaxErrorMessage += "API: " + payload.activityCreationUrl + "<br />Request: " + JSON.stringify(payload) + "<br />Response: " + JSON.stringify(errorData);
						$.ErrorUpdate(payload.parantActivityId, ajaxErrorMessage);
						this.completeActionIncomplete(false, ajaxErrorMessage, wakupMethod, wakeupNeeded, payload, null);
					}.bind(this)
				});
			} catch (err) {
				var now = new Date(Date.now());

				if (errorLogs == null) {
					errorLogs = "";
				}
				errorLogs = errorLogs + "||" + now.toString() + "|Plugin :HD Surrender activity creation : Exception " + err.message;
				console.log("Create activity Incomplete Update Resource properties - Error messagae:" + JSON.stringify(err));
				$.ErrorUpdate(payload.parantActivityId, errorLogs);
			}
		},
		/**
		 * Popup method
		 */
		popupEnable: function(message, enableButton, displayPopup, styleClass) {
			///	alert("in popupEnable");
			if (message != null && "" != message && typeof (message) != undefined) {
				//	alert("in popupEnable in side mesg");
				$('#messagePanel ul').html($('<li/>').addClass(styleClass).append(message));
				if (enableButton) {
					//		alert("in popupEnable in side mesg in side enableButton if");
					$('#messagePanel #notification-clear').show();
				} else {
					//		alert("in popupEnable in side mesg in side enableButton else");
					$('#messagePanel #notification-clear').hide();
				}
				if (displayPopup) {
					//		alert("in popupEnable in side mesg in side displayPopup if");
					$('#messagePanel').show();
				} else {
					//		alert("in popupEnable in side mesg in side displayPopup else");
					$('#messagePanel').hide();
				}
			}
		},
		/**
		* Ajax call to update the properties
		*/
		ajaxCall: function(url, payload, method, headers) {
			$.ajax({
				dataType: "json",
				url: url,
				data: JSON.stringify(payload),
				method: method,
				//async: false,
				crossDomain: true,
				headers: headers,
				processData: false,
				contentType: 'application/json; charset=utf-8',
				timeout: 15000,
				success: function(response) {
					console.log("Update Resource properties - Success messagae: " + JSON.stringify(response));
				}.bind(this),
				error: function(errorData) {
					console.log("Update Resource properties - Error messagae:" + JSON.stringify(errorData));
				}
			});
		},
		/**
		 * Close method 
		 */
		closeMethod: function(activityId, wakeNeeded) {
			if (activityId != null && "" != activityId && typeof (activityId) != undefined) {
				this._sendPostMessageData({
					apiVersion: 1,
					method: 'close',
					wakeupNeeded: wakeNeeded,
					backScreen: 'default',
					"activity": {
						"aid": activityId,
					}
				});
			} else {
				this._sendPostMessageData({
					apiVersion: 1,
					method: 'close',
					wakeupNeeded: wakeNeeded,
					backScreen: 'default'
				});
			}
		},
		/**
 * Update method 
 */
		updateMethod: function(activityId) {
			this._sendPostMessageData({
				"apiVersion": 1,
				"method": "update",
				"activity": {
					"aid": activityId,
					"A_HD_SURRENDER_STATUS": "Yes"
				}
			});
		},

		/**
		 * Business login on plugin wakeup (background open for sync)
		 *
		 * @param {Object} receivedData - JSON object that contain data from OFSC
		 */
		pluginWakeup: function(receivedData) {
			this._log(window.location.host + ' WAKEUP', JSON.stringify(receivedData, null, 4));

			var wakeupData = {
				pluginWakeupCount: +localStorage.getItem('pluginWakeupCount'),
				pluginWakeupMaxCount: +localStorage.getItem('pluginWakeupMaxCount'),
				pluginWakeupDontRespondOn: +localStorage.getItem('pluginWakeupDontRespondOn')
			};

			wakeupData.pluginWakeupCount = wakeupData.pluginWakeupCount + 1;

			localStorage.setItem('pluginWakeupCount', wakeupData.pluginWakeupCount);
			localStorage.setItem('pluginWakeupMaxCount', wakeupData.pluginWakeupMaxCount);
			localStorage.setItem('pluginWakeupDontRespondOn', wakeupData.pluginWakeupDontRespondOn);

			this._log(window.location.host + ' SAVE WAKEUP DATA TO LOCAL STORAGE', JSON.stringify(wakeupData, null, 4));


			if (localStorage.getItem('HDMainRESTCallQue') !== '' && localStorage.getItem('HDMainRESTCallQue') !== null && localStorage.getItem('HDMainRESTCallQue') !== undefined) {
				var hdCompletePayload = JSON.parse(localStorage.getItem('HDMainRESTCallQue'));
				this.activityCreation(hdCompletePayload, true, true);
			}
			if (localStorage.getItem('HDIncompleteMainRESTCallQue') !== '' && localStorage.getItem('HDIncompleteMainRESTCallQue') !== null && localStorage.getItem('HDIncompleteMainRESTCallQue') !== undefined) {
				var hdInCompletePayload = JSON.parse(localStorage.getItem('HDIncompleteMainRESTCallQue'));
				this.activityCreationIncomplete(hdInCompletePayload, true, true);
			}

			if (wakeupData.pluginWakeupDontRespondOn == wakeupData.pluginWakeupCount) {
				this._log(window.location.host + ' EMULATE NOT RESPONDING PLUGIN');

				return;
			}


			///	alert("JSON.parse(localStorage.getItem('HDMainRESTCallQue'))==>" + JSON.parse(localStorage.getItem('HDMainRESTCallQue')));
			///	alert("JSON.parse(localStorage.getItem('HDIncompleteMainRESTCallQue'))==>" + JSON.parse(localStorage.getItem('HDIncompleteMainRESTCallQue')));

			if (wakeupData.pluginWakeupCount < wakeupData.pluginWakeupMaxCount) {
				setTimeout(function() {
					this._log(window.location.host + ' SLEEP. RETRY NEEDED');

					this._sendPostMessageData({
						apiVersion: 1,
						method: 'sleep',
						wakeupNeeded: true
					});
				}.bind(this), 2000);
			} else {
				setTimeout(function() {
					this._log(window.location.host + ' SLEEP. NO RETRY');

					this._sendPostMessageData({
						apiVersion: 1,
						method: 'sleep',
						wakeupNeeded: false
					});
				}.bind(this), 12000);
			}
		},

		/**
		 * Save configuration of wakeup (background open for sync) behavior for Plugin
		 * to Local Storage
		 *
		 * @private
		 */
		_saveWakeupData: function() {
			var wakeupData = {
				pluginWakeupCount: 0,
				pluginWakeupMaxCount: 0,
				pluginWakeupDontRespondOn: 0
			};

			if ($('#wakeup').is(':checked')) {
				wakeupData.pluginWakeupMaxCount = parseInt($('#repeat_count').val());

				if ($('#dont_respond').is(':checked')) {
					wakeupData.pluginWakeupDontRespondOn = parseInt($('#dont_respond_on').val());
				}
			}

			localStorage.setItem('pluginWakeupCount', wakeupData.pluginWakeupCount);
			localStorage.setItem('pluginWakeupMaxCount', wakeupData.pluginWakeupMaxCount);
			localStorage.setItem('pluginWakeupDontRespondOn', wakeupData.pluginWakeupDontRespondOn);

			this._log(window.location.host + ' SAVE WAKEUP DATA TO LOCAL STORAGE', JSON.stringify(wakeupData, null, 4));
		},

		/**
		 * Clear previous configuration of wakeup (background open for sync) behavior for Plugin
		 * from the Local Storage
		 *
		 * @private
		 */
		_clearWakeupData: function() {
			localStorage.removeItem('pluginWakeupCount');
			localStorage.removeItem('pluginWakeupMaxCount');
			localStorage.removeItem('pluginWakeupDontRespondOn');
			localStorage.removeItem('HDMainRESTCallQue');
			localStorage.removeItem('HDIncompleteMainRESTCallQue');

			this._log(window.location.host + ' CLEAR WAKEUP DATA FROM LOCAL STORAGE');
		},

		initChangeOfWakeup: function(element) {

			function onWakeupChange(elem) {
				var isChecked = $(elem).is(':checked');

				if (isChecked) {
					$(element).find('#repeat_count').prop('disabled', false);
					$(element).find('#dont_respond').prop('disabled', false);

					$(element).find('#wakeup_row').removeClass('wakeup-form-row--disabled');

					onDontRespondChange($(element).find('#dont_respond'));
				} else {
					$(element).find('#repeat_count').prop('disabled', true);
					$(element).find('#dont_respond').prop('disabled', true);
					$(element).find('#dont_respond_on').prop('disabled', true);

					$(element).find('#wakeup_row').addClass('wakeup-form-row--disabled');
					$(element).find('#dont_respond_row').addClass('wakeup-form-row--disabled');
				}
			}

			function onDontRespondChange(elem) {
				var isChecked = $(elem).is(':checked');

				if (isChecked) {
					$(element).find('#dont_respond_on').prop('disabled', false);
					$(element).find('#dont_respond_row').removeClass('wakeup-form-row--disabled');
				} else {
					$(element).find('#dont_respond_on').prop('disabled', true);
					$(element).find('#dont_respond_row').addClass('wakeup-form-row--disabled');
				}
			}

			$(element).find('#wakeup').change(function(e) {
				onWakeupChange(e.target);
			});

			$(element).find('#dont_respond').change(function(e) {
				onDontRespondChange(e.target);
			});

			onWakeupChange($(element).find('#wakeup'));
		},

		initChangeOfDataItems: function() {
			//set checkboxes from local storage
			if (localStorage.getItem('dataItems')) {
				$('.data-items').attr('checked', true);
				$('.data-items-holder').show();

				var dataItems = JSON.parse(localStorage.getItem('dataItems'));


				$('.data-items-holder input').each(function() {
					if (dataItems.indexOf(this.value) != -1) {
						$(this).attr('checked', true);
					}
				});
			}

			//init handlers
			$('.data-items').on('change', function(e) {
				$('.data-items-holder').toggle();
			});
		},

		initLocalStorageOption: function(localStorageKey) {
			if (localStorage.getItem(localStorageKey) === null) {
				localStorage.setItem(localStorageKey, 'true');
			}
		},


		//	 * Initialization function

		init: function() {
			if (navigator.serviceWorker) {
				this._log(window.location.host + ' Service Worker is supported');
				navigator.serviceWorker.register('hdSurrender-service-worker.js').then(function(registration) {
					this._log(window.location.host + ' Service Worker is registered with scope: ' + registration.scope);
					registration.addEventListener('updatefound', function() {
						this._log(window.location.host + ' Service Worker update is found');
						var newServiceWorker = registration.installing;
						newServiceWorker.addEventListener('statechange', function() {
							switch (newServiceWorker.state) {
								case "installed":
									this._log(window.location.host + ' New Service Worker is installed');
									break;
							}
						}.bind(this));
					}.bind(this));
					navigator.serviceWorker.addEventListener('controllerchange', function() {
						this.notifyAboutNewVersion();
					}.bind(this));
					this.startApplication();
				}.bind(this), function(err) {
					this._log(window.location.host + ' Service Worker registration failed: ' + err);
					this.startApplication();
				}.bind(this));
				return;
			} else {
				this._log(window.location.host + ' Service Worker is not supported');
			}
			this.startApplication();
		},
		startApplication: function() {
			this._log(window.location.host + ' PLUGIN HAS BEEN STARTED');
			//	alert("startApplication HD Surrender");
			window.addEventListener("message", this._getPostMessageData.bind(this), false);

			this.initLocalStorageOption('showHeader');
			this.initLocalStorageOption('backNavigationFlag');

			var jsonToSend = {
				apiVersion: 1,
				method: 'ready',
				sendInitData: true,
				showHeader: !!localStorage.getItem('showHeader'),
				enableBackButton: !!localStorage.getItem('backNavigationFlag')
			};

			//parse data items
			//var dataItems = JSON.parse(localStorage.getItem('dataItems'));
			var dataItems = ['resource', 'installedInventories', 'deinstalledInventories'];

			if (dataItems) {
				$.extend(jsonToSend, {
					dataItems: dataItems
				});
			}

			//	alert("Hd Srrender is Ready");

			this._sendPostMessageData(jsonToSend);
		},
		notifyAboutNewVersion: function() {
			this._log(window.location.host + ' New Service Worker is activated. Page refresh is needed');
			var footer = document.querySelector('.footer');
			var versionNotificationElement = document.createElement('div');
			versionNotificationElement.className = 'new-version-notification';
			versionNotificationElement.innerHTML = 'New version is detected. Please reopen the page';
			footer.appendChild(versionNotificationElement);
		}
	});
	window.OfscPlugin.getVersion = function() {
		return resourcesVersion;
	};

})(jQuery);