"use strict";
(function($) {
	window.OfscPlugin = function(debugMode) {
		this.debugMode = debugMode || false;
	};

	$.extend(window.OfscPlugin.prototype, {
        /**
         * Dictionary of enums
         */
		dictionary: {
			astatus: {
				pending: {
					label: 'pending',
					translation: 'Pending',
					outs: ['started', 'cancelled', 'suspended'],
					color: '#FFDE00'
				},
				started: {
					label: 'started',
					translation: 'Started',
					outs: ['complete', 'suspended', 'notdone', 'cancelled'],
					color: '#A2DE61'
				},
				complete: {
					label: 'complete',
					translation: 'Completed',
					outs: [],
					color: '#79B6EB'
				},
				suspended: {
					label: 'suspended',
					translation: 'Suspended',
					outs: [],
					color: '#9FF'
				},
				notdone: {
					label: 'notdone',
					translation: 'Not done',
					outs: [],
					color: '#60CECE'
				},
				cancelled: {
					label: 'cancelled',
					translation: 'Cancelled',
					outs: [],
					color: '#80FF80'
				}
			},
			invpool: {
				customer: {
					label: 'customer',
					translation: 'Customer',
					outs: ['deinstall'],
					color: '#04D330'
				},
				install: {
					label: 'install',
					translation: 'Installed',
					outs: ['provider'],
					color: '#00A6F0'
				},
				deinstall: {
					label: 'deinstall',
					translation: 'Deinstalled',
					outs: ['customer'],
					color: '#00F8E8'
				},
				provider: {
					label: 'provider',
					translation: 'Resource',
					outs: ['install'],
					color: '#FFE43B'
				}
			}
		},
		actions: {
			activity: [
				{
					value: '',
					translation: 'Select Action...'
				},
				{
					value: 'create',
					translation: 'Create Activity'
				}
			],
			inventory: [
				{
					value: '',
					translation: 'Select Action...'
				},
				{
					value: 'create',
					translation: 'Create Inventory'
				},
				{
					value: 'delete',
					translation: 'Delete Inventory'
				},
				{
					value: 'install',
					translation: 'Install Inventory'
				},
				{
					value: 'deinstall',
					translation: 'Deinstall Inventory'
				},
				{
					value: 'undo_install',
					translation: 'Undo Install Inventory'
				},
				{
					value: 'undo_deinstall',
					translation: 'Undo Deinstall Inventory'
				}
			]
		},

        /**
         * Check for string is valid JSON
         *
         * @param {*} str - String that should be validated
         *
         * @returns {boolean}
         *
         * @private
         */
		_isJson: function(str) {
			try {
				JSON.parse(str);
			} catch (e) {
				return false;
			}
			return true;
		},
        /**
         * Return origin of URL (protocol + domain)
         *
         * @param {String} url
         *
         * @returns {String}
         *
         * @private
         */
		_getOrigin: function(url) {
			if (url != '') {
				if (url.indexOf("://") > -1) {
					return 'https://' + url.split('/')[2];
				} else {
					return 'https://' + url.split('/')[0];
				}
			}
			return '';
		},
        /**
         * Return domain of URL
         *
         * @param {String} url
         *
         * @returns {String}
         *
         * @private
         */
		_getDomain: function(url) {
			if (url != '') {
				if (url.indexOf("://") > -1) {
					return url.split('/')[2];
				} else {
					return url.split('/')[0];
				}
			}
			return '';
		},
		/**
		* get domain / company name
		*/
		_getDomainURL: function() {
			//return document.referrer.match(/\:\/\/([^\/]+)\.etadirect\.com\//)[1];
			//Reg Ex modified to handle both etadirect.com and fs.ocs.oraclecloud.com URLs
			return document.referrer.match(/\:\/\/([^\/]+)\.(?:etadirect.com|fs.ocs.oraclecloud.com)/)[1];
		},
        /**
         * Sends postMessage to document.referrer
         *
         * @param {Object} data - Data that will be sent
         *
         * @private
         */
		_sendPostMessageData: function(data) {
			var originUrl = document.referrer || (document.location.ancestorOrigins && document.location.ancestorOrigins[0]) || '';
			var isString = 'string' === typeof data;
			if (originUrl) {
				this._log(window.location.host + ' -> ' + (isString ? '' : data.method) + ' ' + this._getDomain(originUrl), isString ? data : JSON.stringify(data, null, 4));
				parent.postMessage(data, this._getOrigin(originUrl));
			} else {
				this._log(window.location.host + ' -> ' + (isString ? '' : data.method) + ' ERROR. UNABLE TO GET REFERRER');
			}
		},
        /**
         * Handles during receiving postMessage
         *
         * @param {MessageEvent} event - Javascript event
         *
         * @private
         */
		_getPostMessageData: function(event) {
			if (typeof event.data === 'undefined') {
				this._log(window.location.host + ' <- NO DATA ' + this._getDomain(event.origin), null, null, true);
				return false;
			}
			if (!this._isJson(event.data)) {
				this._log(window.location.host + ' <- NOT JSON ' + this._getDomain(event.origin), null, null, true);
				return false;
			}
			var data = JSON.parse(event.data);
			if (!data.method) {
				this._log(window.location.host + ' <- NO METHOD ' + this._getDomain(event.origin), null, null, true);
				return false;
			}
			this._log(window.location.host + ' <- ' + data.method + ' ' + this._getDomain(event.origin), JSON.stringify(data, null, 4));
			switch (data.method) {
				case 'init':
					this.pluginInitEnd(data);
					break;
				case 'open':
					this.pluginOpen(data);
					break;
				case 'wakeup':
					this.pluginWakeup(data);
					break;
				case 'error':
					data.errors = data.errors || { error: 'Unknown error' };
					this._showError(data.errors);
					break;
				default:
					this._log(window.location.host + ' <- UNKNOWN METHOD: ' + data.method + ' ' + this._getDomain(event.origin), null, null, true);
					break;
			}
		},
        /**
         * Show alert with error
         *
         * @param {Object} errorData - Object with errors
         *
         * @private
         */
		_showError: function(errorData) {
			alert(JSON.stringify(errorData, null, 4));
		},
        /**
         * Logs to console
         *
         * @param {String} title - Message that will be log
         * @param {String} [data] - Formatted data that will be collapsed
         * @param {String} [color] - Color in Hex format
         * @param {Boolean} [warning] - Is it warning message?
         *
         * @private
         */
		_log: function(title, data, color, warning) {
			if (!this.debugMode) {
				return;
			}
			if (!color) {
				color = '#0066FF';
			}
			if (!!data) {
				console.groupCollapsed('%c[Plugin API] ' + title, 'color: ' + color + '; ' + (!!warning ? 'font-weight: bold;' : 'font-weight: normal;'));
				console.log('[Plugin API] ' + data);
				console.groupEnd();
			} else {
				console.log('%c[Plugin API] ' + title, 'color: ' + color + '; ' + (!!warning ? 'font-weight: bold;' : ''));
			}
		},

        /**
         * Business login on plugin init
         */
		saveToLocalStorage: function(data) {
			this._log(window.location.host + ' INIT. SET DATA TO LOCAL STORAGE', JSON.stringify(data, null, 4));
			var initData = {};
			$.each(data, function(key, value) {
				if (-1 !== $.inArray(key, ['apiVersion', 'method'])) {
					return true;
				}
				initData[key] = value;
			});
			localStorage.setItem('pluginInitData', JSON.stringify(initData));
		},
        /**
         * Business login on plugin init end
         *
         * @param {Object} data - JSON object that contain data from OFSC
         */
		pluginInitEnd: function(data) {
			this.saveToLocalStorage(data);
			var messageData = {
				apiVersion: 1,
				method: 'initEnd'
			};
			if (localStorage.getItem('pluginWakeupCount') < localStorage.getItem('pluginWakeupMaxCount')) {
				this._log(window.location.host + ' UNFINISHED WAKEUP DATA FOUND IN LOCAL STORAGE');
				messageData.wakeupNeeded = true;
			}
			this._sendPostMessageData(messageData);
		},
		/**
         * Clear previous configuration of wakeup (background open for sync) behavior for Plugin
         * from the Local Storage
         *
         * @private
         */
		_clearWakeupData: function() {
			localStorage.removeItem('pluginWakeupCount');
			localStorage.removeItem('pluginWakeupMaxCount');
			localStorage.removeItem('pluginWakeupDontRespondOn');
			localStorage.removeItem('pluginWakeupChangeIcon');

			this._log(window.location.host + ' CLEAR WAKEUP DATA FROM LOCAL STORAGE');
		},
		/**
		* Ajax call to update the properties
		*/
		ajaxCall: function(url, payload, method, headers) {
			$.ajax({
				dataType: "json",
				url: url,
				data: JSON.stringify(payload),
				method: method,
				//async: false,
				crossDomain: true,
				headers: headers,
				processData: false,
				contentType: 'application/json; charset=utf-8',
				timeout: 15000,
				success: function(response) {
					console.log("Update Resource properties - Success messagae: " + JSON.stringify(response));
				}.bind(this),
				error: function(errorData) {
					console.log("Update Resource properties - Error messagae:" + JSON.stringify(errorData));
				}
			});
		},
        /**
         * Business login on plugin open
         *
         * @param {Object} receivedData - JSON object that contain data from OFSC
         */
		pluginOpen: function(receivedData) {
			this._clearWakeupData();
			if (localStorage.getItem('pluginInitData')) {
				this._log(window.location.host + ' OPEN. GET DATA FROM LOCAL STORAGE', JSON.stringify(JSON.parse(localStorage.getItem('pluginInitData')), null, 4));
			}
			
			var $parentThis = this;
			
			var blnIsTechOnline = false;

			var domainName = this._getDomainURL();
			var resourceTimeZone = receivedData.resource.time_zone;
			
			var TimeZoneMapping = {
                "19": "Alaska",
                "6": "Arizona",
                "4": "Central",
                "2": "Eastern",
                "15": "GMT",
                "17": "Hawaii (Adak)",
                "18": "Hawaii (Honolulu)",
                "5": "Mountain",
                "7": "Pacific"
            };
			
            var timeZone = TimeZoneMapping[resourceTimeZone];
			
			// Set the timezone to retreive the Date & time for Activate route & punch in 
			if ("Alaska" == timeZone || "Arizona" == timeZone || "Central" == timeZone
			 	|| "Eastern" == timeZone || "Mountain" == timeZone || "Pacific" == timeZone) {
				resourceTimeZone = "US/" + timeZone;
			} else if ("Hawaii (Adak)" == timeZone) {
				resourceTimeZone = "America/Adak";
			} else if ("Hawaii (Honolulu)" == timeZone) {
				resourceTimeZone = "Pacific/Honolulu";
			}

			// if the resource time zone is null, then assign to EST.
			if (resourceTimeZone == null || "" == resourceTimeZone || typeof (resourceTimeZone) == undefined) {
				resourceTimeZone = "EST";
			}

			// Building Authorization headers
			var headers = {
				'accept':'application/json',
				'Authorization':
					'Basic ' + btoa(receivedData.securedData.clientId + "@" + domainName + ":" + receivedData.securedData.clientSecret)
			};

			var globalNotesDetails = {};

			//----- added for CHG# -- FY23 ----
			checkIfTechIsOnline();
			
			var activityId = receivedData.activity.aid;
			
			if(blnIsTechOnline == false){
				var offlineDataAttr = "NOTES_ACT_OFFLINE_FILE";
				
				if( localStorage.getItem(offlineDataAttr) !== null && 
					localStorage.getItem(offlineDataAttr) !== undefined && 
					localStorage.getItem(offlineDataAttr) !== '')
				{
					var offlineData = JSON.parse(localStorage.getItem(offlineDataAttr));
					globalNotesDetails = JSON.parse(offlineData);
				}
			}else{
			//---------------------------------
				// Added exception while fetching the global notes for  activity 
				
				try {
					var globalNotesURL = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/activities/" + receivedData.activity.aid + "/A_GLOBAL_NOTES_FILE";
					console.log(globalNotesURL);
					// Ajax call to get the global notes url
					$.ajax({
						url: globalNotesURL,
						method: "GET",
						async: false,
						headers: headers,
						success: function (response) {
							if(response.aAWSGlobalNotes){
								globalNotesDetails = JSON.parse(response.aAWSGlobalNotes);
							}
						}.bind(this),
						error: function (errorData) {
							console.log("While retreiving NOTES data - Error messagae:" + JSON.stringify(errorData));
							globalNotesDetails = {};
						}
					});
				} catch (err) {
					var notesErrorPayload = {
						"NOTES_PLUGIN_ERROR": "Error creating NOTES: " + err.message
					};
				}
			}
			// Display global notes based on file/ property availality
			if(!jQuery.isEmptyObject(globalNotesDetails)){
				$.each(globalNotesDetails, function(key, value){
					if('MENU' == receivedData.openParams.NOTES.toUpperCase() || receivedData.openParams.NOTES.toUpperCase() == key.toUpperCase() || "ALL" == key.toUpperCase()){
						var divRow = $('<div />').addClass('cl-row block');
						var divTitle = $('<div />').addClass('cl-fld-title inline-block');
						divTitle.append($('<span />').addClass('title-text').html(key));
						divRow.append(divTitle);
						var divValue = $('<div />').addClass('cl-fld-value inline-block');
						$.each(value, function(k,v){
							// update links to remove the link and add the clickable links
							var value = $('<div />').html($parentThis.updateLinks(v));
							divValue.append(value);
						});
						divRow.append(divValue);
						$('.notes-content').append(divRow);
					}
				});
				if('MENU' == receivedData.openParams.NOTES.toUpperCase()){
					var prviousTechNotes = "";
					if(receivedData.activity.A_GN_TECHCOMMENTS != null){
						prviousTechNotes = receivedData.activity.A_GN_TECHCOMMENTS
					}
					var techFeedbackButton = $('<input />').attr({'type':'button','value':'Global Notes Feedback','data-class':'tech-feedback'}).addClass('dismiss button feedback');
					$parentThis.createRow('', techFeedbackButton);
					var techFeedback = $('<div />');
					var techFeedbackTextarea= $('<div/>').append($('<textarea />').addClass('form-item').attr({'name':'techComments', 'id':'techComments'}).text(prviousTechNotes));
					var techFeedbackSubmit = $('<div/>').append($('<input />').addClass('submit button submit_feedback').attr({'type':'button', 'value' :'Submit Feedback'}));
					techFeedback.append(techFeedbackTextarea);
					techFeedback.append(techFeedbackSubmit);
					$parentThis.createRow('Tech Comments', techFeedback, 'tech-feedback');
				}
			} else if (receivedData.activity.A_GLOBAL_NOTES !=  null) { 
				$parentThis.createRow('Global Notes', receivedData.activity.A_GLOBAL_NOTES);
			} else {
				$parentThis.createRow('', 'No Global notes available');
			}
			
			// Display the other notes only when tech access from Menu 
			if(receivedData.openParams.NOTES.toUpperCase() == 'MENU'){
				if(receivedData.activity.A_SUMMARY != null){
					$parentThis.createRow('Problem Summary', receivedData.activity.A_SUMMARY);
				}
				if(receivedData.activity.A_PROBLEM_DETAILS != null){
					$parentThis.createRow('Problem Details', receivedData.activity.A_PROBLEM_DETAILS);
				}
				if(receivedData.activity.DISPATCHER_COMMENTS != null){
					$parentThis.createRow('Dispatch Notes', receivedData.activity.DISPATCHER_COMMENTS);
				}
				if(receivedData.activity.A_SR_INSTRUCTIONS != null){
					$parentThis.createRow('SR Instructions', receivedData.activity.A_SR_INSTRUCTIONS);
				}
			}
			
			var activityJSONData = {
                    aid: receivedData.activity.aid
			}
			
			if('DEBRIEF' == receivedData.openParams.NOTES.toUpperCase()){
				$('#dismiss').val('Verified');
				$.extend(activityJSONData, {
					"A_GN_DEBRIEF_VERIFIED": 1
				});
			}
			
			$('#dismiss').click(function(){
				$parentThis._sendPostMessageData({
	                apiVersion: 1,
	                method: 'close',
	                wakeupNeeded: false,
	                backScreen: 'default',
	                "activity": activityJSONData
	            }); 
			});
			
			$('.feedback').click(function(){
				var customClass = $(this).attr('data-class');
				$('.'+customClass).show();
			});
			
			// format date yyyy-mm-dd
			function formatDate(formatDate) {
			    var d = new Date(formatDate),
			        month = ("00" + (d.getMonth() + 1)).slice(-2),
			        day = ("00" + d.getDate()).slice(-2),
			        year = d.getFullYear();
			    return [year, month, day].join('-');
			}
			
			
			$('.submit_feedback').click(function(){	
				var techComments = $('#techComments').val();
				if('' == techComments || techComments == null){
					alert('Plese Enter tech comments');
					return false;
				}
				var dateResourceTimeZone;
				try{
					dateResourceTimeZone = new Date(new Date().toLocaleString('en-US', { timeZone: resourceTimeZone }));	
				}catch(err){
					dateResourceTimeZone = new Date();
				}
				var dateResourceTimeZoneDate = formatDate(dateResourceTimeZone);
				 
				var serviceRequestURL= "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/serviceRequests";
				var serviceReqeustParams= {
						date: dateResourceTimeZoneDate,
						activityId: parseInt(receivedData.activity.aid),
						requestType: receivedData.securedData.requestType
				};
				
				var closeParams = {
						apiVersion: 1,
		                method: 'close',
		                wakeupNeeded: false,
		                backScreen: 'default',
		                activity: {
		                	aid: receivedData.activity.aid,
		                	A_GN_TECHCOMMENTS:techComments
		                }
				}
				
				var payload = {
						"serviceRequestURL": serviceRequestURL,
						"serviceReqeustParams": serviceReqeustParams,
						"headers": headers,
						"closeParams": closeParams
				}
				
				//----- added for CHG# -- FY23 ----
				checkIfTechIsOnline();
				
				var offlineSrCreateAttr = "NOTES_ACT_SR_CREATE";
				
				if(blnIsTechOnline == false){
					localStorage.setItem(offlineSrCreateAttr, JSON.stringify(payload));
					
					closeParams.wakeupNeeded = true;
					
					$parentThis._sendPostMessageData(closeParams);
				//---------------------------------
				}else{
					$parentThis.createServiceRequest(payload);
				}
				
			});
			
			//-----------------------------------------------------------
			//Added for offline capability
			function checkIfTechIsOnline() {
				var domainLink = window.location.href;				
				$.ajax({
					url : domainLink,
					timeout : 2000,	
					cache: false,				
					type : 'GET', 
					async: false,
					tryCount : 0,
					retryLimit : 3,
					success: function(response)	{
						console.log(' online');
						blnIsTechOnline = true;
						return true;
					}.bind(this),
					error : function(xhr, textStatus, errorThrown )	{
						if (textStatus == 'timeout') {
							this.tryCount++;
							if (this.tryCount <= this.retryLimit) {
								//try again
								$.ajax(this);
								console.log(' offline');
								blnIsTechOnline = false;
								return false;
							}            
						}
						if(xhr.status == 500){
							console.log(' offline');
							blnIsTechOnline = false;
							return false;
						}else {
							console.log(' offline');
							blnIsTechOnline = false;
							return false;
						}
					}
				});
			}
			//-----------------------------------------------------------
		},
		createRow: function(key, value, customclass){
			var divRow = $('<div />').addClass('cl-row block '+customclass);
			if('' == key){
				var divValue = $('<div />').html(value);
				divRow.append(divValue);
			} else {
				var divTitle = $('<div />').addClass('cl-fld-title inline-block');
				divTitle.append($('<span />').addClass('title-text').html(key));
				divRow.append(divTitle);
				var divValue = $('<div />').addClass('cl-fld-value inline-block');
				divValue.append($('<div />').html(value));
				divRow.append(divValue);
			}
			$('.notes-content').append(divRow);
		},
		updateLinks(text){
			text = this.updateLinkAction(text,"https://");
			text = this.updateLinkAction(text,"http://");
			text = this.updateLinkAction(text,"www.");
			return text;
		},
		updateLinkAction: function(text, actionLinkCheck){
			var count = 0;
			while(text.indexOf(actionLinkCheck, count) > 0 ){
				var startIndex = text.indexOf(actionLinkCheck,count);
				var endUrlIndex = text.indexOf(" ",startIndex);
				if(endUrlIndex <= -1){
					endUrlIndex = text.length;
				}
				var url = text.substring(startIndex, endUrlIndex);
				
			// Change Starts CHG0079537
				var anchorLink = '<a target="_blank" rel="noopener noreferrer" onclick="linkAction(\''+url+'\')" href="' + url + '">' + url + '</a>';
			//	var anchorLink = '<a onclick="linkAction(\''+url+'\')" href="#">Click Here</a>';
			// Change Ends CHG0079537
				
				text = text.replace(url, anchorLink);
				count = startIndex+anchorLink.length;
			}
			return text;
		},
		linkAction: function(url){
			var callIdValue=btoa(String.fromCharCode.apply(null, window.crypto.getRandomValues(new Uint8Array(16))));
			this._sendPostMessageData({
                "apiVersion": 1,
				"method": "callProcedure",
				"procedure": "openLink",
				"callId": callIdValue,
				"params": {
					"url": url
				}
			});
		},
		createServiceRequest: function(payload){
			try{
				$.ajax({
					dataType: "json",
					url: payload.serviceRequestURL,
					data: JSON.stringify(payload.serviceReqeustParams),
					method: "POST",
					//async: false,
					crossDomain: true,
					headers: payload.headers,
					processData: false,
					contentType: 'application/json; charset=utf-8',
					timeout: 15000,
					success: function(response) {
						console.log("Notes create Service Request - Success messagae: " + JSON.stringify(response));
						this._sendPostMessageData(payload.closeParams); 
					}.bind(this),
					error: function(errorData) {
						console.log("Notes create Service Request - Error messagae: " + JSON.stringify(errorData));
						this._sendPostMessageData(payload.closeParams); 
					}.bind(this)
				});
			} catch(err){
					var resourceErrorPayload = {"R_PLUGIN_ERROR":"error while creating Service Request: "+err.message};
			}
		},
		
		/**
		 * Business login on plugin wakeup (background open for sync)
		 *
		 * @param {Object} receivedData - JSON object that contain data from OFSC
		 */
		pluginWakeup: function(receivedData) {
			this._log(window.location.host + ' WAKEUP', JSON.stringify(receivedData, null, 4));
			var wakeupData = {
				pluginWakeupCount: +localStorage.getItem('pluginWakeupCount'),
				pluginWakeupMaxCount: +localStorage.getItem('pluginWakeupMaxCount'),
				pluginWakeupDontRespondOn: +localStorage.getItem('pluginWakeupDontRespondOn')
			};
			
			//--------------------------------------------------------------------------------------------
			//---- added for offline capable
			console.log("Wakeup receivedData = " + receivedData);
			var offlineDataAttr = "NOTES_ACT_SR_CREATE";
			
			if( localStorage.getItem(offlineDataAttr) !== null && 
				localStorage.getItem(offlineDataAttr) !== undefined && 
				localStorage.getItem(offlineDataAttr) !== '')
			{
				console.log("found the local storage attr in wakup");
				
				var offlineData = JSON.parse(localStorage.getItem(offlineDataAttr));
				this.createServiceRequest(offlineData);
				
				localStorage.setItem(offlineDataAttr, '');
			}
			//--------------------------------------------------------------------------------------------
			
			wakeupData.pluginWakeupCount = wakeupData.pluginWakeupCount + 1;
		
			localStorage.setItem('pluginWakeupCount', wakeupData.pluginWakeupCount);
			localStorage.setItem('pluginWakeupMaxCount', wakeupData.pluginWakeupMaxCount);
			localStorage.setItem('pluginWakeupDontRespondOn', wakeupData.pluginWakeupDontRespondOn);
		
			this._log(window.location.host + ' SAVE WAKEUP DATA TO LOCAL STORAGE', JSON.stringify(wakeupData, null, 4));
			
			if (wakeupData.pluginWakeupDontRespondOn == wakeupData.pluginWakeupCount) {
				this._log(window.location.host + ' EMULATE NOT RESPONDING PLUGIN');
				return;
			}
		
			if (wakeupData.pluginWakeupCount < wakeupData.pluginWakeupMaxCount) {
				setTimeout(function() {
					this._log(window.location.host + ' SLEEP. RETRY NEEDED');
					this._sendPostMessageData({
						apiVersion: 1,
						method: 'sleep',
						wakeupNeeded: true
					});
				}.bind(this), 2000);
			} else {
				setTimeout(function() {
					this._log(window.location.host + ' SLEEP. NO RETRY');
					this._sendPostMessageData({
						apiVersion: 1,
						method: 'sleep',
						wakeupNeeded: false
					});
				}.bind(this), 12000);
			}
		},
        /**
         * Initialization function
         */
		init: function() {
			if (navigator.serviceWorker) {
				this._log(window.location.host + ' Service Worker is supported');
				navigator.serviceWorker.register('notes-service-worker.js').then(function(registration) {
					this._log(window.location.host + ' Service Worker is registered with scope: ' + registration.scope);
					registration.addEventListener('updatefound', function() {
						this._log(window.location.host + ' Service Worker update is found');
						var newServiceWorker = registration.installing;
						newServiceWorker.addEventListener('statechange', function() {
							switch (newServiceWorker.state) {
								case "installed":
									this._log(window.location.host + ' New Service Worker is installed');
									break;
							}
						}.bind(this));
					}.bind(this));
					navigator.serviceWorker.addEventListener('controllerchange', function() {
						this.notifyAboutNewVersion();
					}.bind(this));
					this.startApplication();
				}.bind(this), function(err) {
					this._log(window.location.host + ' Service Worker registration failed: ' + err);
					this.startApplication();
				}.bind(this));
				return;
			} else {
				this._log(window.location.host + ' Service Worker is not supported');
			}
			this.startApplication();
		},
		startApplication: function() {
			this._log(window.location.host + ' PLUGIN HAS BEEN STARTED');

			window.addEventListener("message", this._getPostMessageData.bind(this), false);
			var jsonToSend = {
				apiVersion: 1,
				method: 'ready',
				sendInitData: true
			};
			//parse data items
			var dataItems = JSON.parse(localStorage.getItem('dataItems'));
			if (dataItems) {
				$.extend(jsonToSend, { dataItems: dataItems });
			}
			this._sendPostMessageData(jsonToSend);
		},
		notifyAboutNewVersion: function() {
			this._log(window.location.host + ' New Service Worker is activated. Page refresh is needed');
			var footer = document.querySelector('.footer');
			var versionNotificationElement = document.createElement('div');
			versionNotificationElement.className = 'new-version-notification';
			versionNotificationElement.innerHTML = 'New version is detected. Please reopen the page';
			footer.appendChild(versionNotificationElement);
		}
	});
	window.OfscPlugin.getVersion = function() {
		return resourcesVersion;
	};
})(jQuery);