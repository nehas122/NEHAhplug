const RESOURCES_VERSION = '211.10';
const plugin_name = 'plugin-Enroute-v';
const CACHE_NAME = plugin_name + RESOURCES_VERSION;
const APP_CACHE_MANIFEST_PATH = 'manifest.appcache';

const fetchStrategies = {
    /**
     * @param {Request} request
     * @returns {Response}
     */
    cacheFirstThenNetwork: async (request) => {
        const cacheMatch = await caches.match(request);

        if (!cacheMatch) {
            return fetchStrategies.networkFirstThenCache(request);
        }

        return cacheMatch;
    },
    /**
     * @param {Request} request
     * @returns {Response}
     */
    networkFirstThenCache: async (request) => {
        try {
            const response = fetch(request);
            const clonedResponse = response && response.clone && response.clone() || null;

            if (clonedResponse) {
                caches.open(CACHE_NAME).then(cache => {
                    // Add response to cache
                    cache.put(request, clonedResponse);
                });
            }

            return response;
        } catch (e) {
            const cacheMatch = await caches.match(request);
            if (cacheMatch) {
                return cacheMatch;
            } else {
                console.log("SERVICE WORKER: no cached file for offline request " + request.url);
                throw e;
            }
        }
    },
    /**
     * @param {Request} request
     * @returns {Response}
     */
    networkOnly: async (request) => {
        return fetch(request);
    }
};

/**
 * @param {Request} request
 * @returns {Function}
 */
function chooseFetchStrategy(request) {
    if (request.method === 'GET') {
        return fetchStrategies.cacheFirstThenNetwork;
    } else if (['POST', 'PUT', 'DELETE'].includes(request.method)) {
        return fetchStrategies.networkOnly;
    }
    return fetchStrategies.networkFirstThenCache;
}

addEventListener('install', async (event) => {
    console.log('SERVICE WORKER INSTALLED: ' + location.href);

    event.waitUntil((async () => {
        try {
            const manifestFetchResult = await fetch(APP_CACHE_MANIFEST_PATH);
            const manifestText = await manifestFetchResult.text();

            const cacheAssets = getCacheAssetsFromManifest(manifestText);

            const cache = await caches.open(CACHE_NAME);

            console.log("SERVICE WORKER: Saving cache " + CACHE_NAME + ":");

            await Promise.all(
                cacheAssets.map(cacheAsset =>
                    fetch(cacheAsset, { cache: "no-store" }).then(async response => {
                        if (response.status === 200) {
                            console.log("SERVICE WORKER: Cached " + cacheAsset);
                            const processedResponse = await processCachedResponse(response);
                            return cache.put(cacheAsset, processedResponse);
                        } else {
                            console.warn("SERVICE WORKER: Unable to cache " + cacheAsset + ": " + response.status + " " + response.statusText);
                        }
                    })
                )
            );


        } catch (e) {
            console.error("Unable to preload cached resources: ", e);
        }

        return self.skipWaiting();
    })());
});

addEventListener('activate', async (event) => {
    console.log('SERVICE WORKER ACTIVATED: ' + location.href);

    // Clear outdated caches:
    event.waitUntil(
        caches.keys().then(cacheNames => {
            return Promise.all(
                cacheNames.map(cache => {
                    if (cache.substr(0, plugin_name.length) == plugin_name) {				//To check relevant plugin name
                        if (cache !== CACHE_NAME) { 										//To check plugin name with resource version
                            console.log('SERVICE WORKER: Clearing Old Cache ' + cache);
                            return caches.delete(cache);
                        }
                    }
                })
            );
        })
    );
});

addEventListener('fetch', e => {
    e.respondWith(
        (async function () {
            const fetchStrategy = chooseFetchStrategy(e.request);

            return fetchStrategy(e.request);
        }())
    );
});

function getCacheAssetsFromManifest(manifestContent) {
    const parsedManifest = parseAppCacheManifest(manifestContent);
    return parsedManifest.cache;
}

function parseAppCacheManifest(manifestContent) {
    let currentSection = 'cache';

    let result = {
        cache: [],
        network: [],
        fallback: {},
        settings: []
    };

    const lines = manifestContent.split(/\n|\r|\r\n/);
    // first line should be a header "CACHE MANIFEST"
    for (let lineNumber = 1; lineNumber < lines.length; ++lineNumber) {
        let line = lines[lineNumber].trim();

        if (!line || line[0] === '#') {
            // skip empty lines or comments
            continue;
        }

        if (['CACHE:', 'NETWORK:', 'FALLBACK:', 'SETTINGS:'].includes(line)) {
            currentSection = line.substr(0, line.length - 1).toLowerCase();
        } else if (line.substr(line.length - 1) !== ':') {
            // section content:
            if (currentSection === 'fallback') {
                const contentParts = line.split(/ +/);
                result.fallback[contentParts[0]] = contentParts[1];
            } else {
                result[currentSection].push(line);
            }
        }
    }

    return result;
}

/**
 * @param {Response} response
 */
async function processCachedResponse(response) {
    if (response.status === 200 && response.headers.get('content-type').match(/text\/html/i)) {
        // exclude appcache manifest link from the .html pages:
        const responseText = await response.text();
        const resultResponseText = responseText.replace(/\s*manifest=".*?"/g, '');
        const headersEntries = Array.from(response.headers.entries());
        const headers = headersEntries.reduce((accumulator, [key, value]) => {
            accumulator[key] = value;
            return accumulator;
        }, {});
        // the content length has been changed:
        headers['content-length'] = resultResponseText.length;

        return new Response(resultResponseText, { status: 200, headers });
    }
    return response.clone();
}