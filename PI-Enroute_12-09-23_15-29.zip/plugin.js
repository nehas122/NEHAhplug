"use strict";
(function ($) {
	window.OfscPlugin = function (debugMode) {
		this.debugMode = debugMode || false;
	};

	var now = '';
	//Added for OFSC Mobility Phase2 CHG0062368	
	var activityLog = '';
	var pluginName = 'PI-Enroute';
	//end OFSC Mobility Phase2 CHG0062368

	$.extend(window.OfscPlugin.prototype, {
		/**
		 * Dictionary of enums
		 */
		dictionary: {
			astatus: {
				pending: {
					label: 'pending',
					translation: 'Pending',
					outs: ['started', 'cancelled', 'suspended', 'enroute'],
					color: '#ffde00'
				},
				enroute: {
					label: 'enroute',
					translation: 'En Route',
					outs: ['started', 'cancelled', 'pending'],
					color: '#ff920c'
				},
				started: {
					label: 'started',
					translation: 'Started',
					outs: ['complete', 'suspended', 'notdone', 'cancelled'],
					color: '#a2de61'
				},
				complete: {
					label: 'complete',
					translation: 'Completed',
					outs: [],
					color: '#79B6EB'
				},
				suspended: {
					label: 'suspended',
					translation: 'Suspended',
					outs: [],
					color: '#9FF'
				},
				notdone: {
					label: 'notdone',
					translation: 'Not done',
					outs: [],
					color: '#60CECE'
				},
				cancelled: {
					label: 'cancelled',
					translation: 'Cancelled',
					outs: [],
					color: '#80FF80'

				}
			},
			invpool: {
				customer: {
					label: 'customer',
					translation: 'Customer',
					outs: ['deinstall'],
					color: '#04D330'
				},
				install: {
					label: 'install',
					translation: 'Installed',
					outs: ['provider'],
					color: '#00A6F0'
				},
				deinstall: {
					label: 'deinstall',
					translation: 'Deinstalled',
					outs: ['customer'],
					color: '#00F8E8'
				},
				provider: {
					label: 'provider',
					translation: 'Resource',
					outs: ['install'],
					color: '#FFE43B'
				}
			}
		},
		actions: {
			activity: [
				{
					value: '',
					translation: 'Select Action...'
				},
				{
					value: 'create',
					translation: 'Create Activity'
				}
			],
			inventory: [
				{
					value: '',
					translation: 'Select Action...'
				},
				{
					value: 'create',
					translation: 'Create Inventory'
				},
				{
					value: 'delete',
					translation: 'Delete Inventory'
				},
				{
					value: 'install',
					translation: 'Install Inventory'
				},
				{
					value: 'deinstall',
					translation: 'Deinstall Inventory'
				},
				{
					value: 'undo_install',
					translation: 'Undo Install Inventory'
				},
				{
					value: 'undo_deinstall',
					translation: 'Undo Deinstall Inventory'
				}
			],
			queue: [
				{
					value: '',
					translation: 'Select Action...'
				},
				{
					value: 'activate_queue',
					translation: 'Activate'
				},
				{
					value: 'deactivate_queue',
					translation: 'Deactivate'
				}
			]
		},
		mandatoryActionProperties: {},


		renderReadOnlyFieldsByParent: {
			data: {
				apiVersion: true,
				method: true,
				entity: true
			},
			resource: {
				pid: true,
				pname: true,
				gender: true
			}
		},

		/**
		 * Check for string is valid JSON
		 *
		 * @param {*} str - String that should be validated
		 *
		 * @returns {boolean}
		 *
		 * @private
		 */
		_isJson: function (str) {
			try {
				JSON.parse(str);
			}
			catch (e) {
				return false;
			}
			return true;
		},

		/**
		 * Return origin of URL (protocol + domain)
		 *
		 * @param {String} url
		 *
		 * @returns {String}
		 *
		 * @private
		 */
		_getOrigin: function (url) {
			if (url != '') {
				if (url.indexOf("://") > -1) {
					return 'https://' + url.split('/')[2];
				} else {
					return 'https://' + url.split('/')[0];
				}
			}

			return '';
		},

		/**
		 * Return domain of URL
		 *
		 * @param {String} url
		 *
		 * @returns {String}
		 *
		 * @private
		 */
		_getDomain: function (url) {
			if (url != '') {
				if (url.indexOf("://") > -1) {
					return url.split('/')[2];
				} else {
					return url.split('/')[0];
				}
			}

			return '';
		},
		_getDomainURL: function () {
			//return document.referrer.match(/\:\/\/([^\/]+)\.etadirect\.com\//)[1];
			//Reg Ex modified to handle both etadirect.com and fs.ocs.oraclecloud.com URLs
			return document.referrer.match(/\:\/\/([^\/]+)\.(?:etadirect.com|fs.ocs.oraclecloud.com)/)[1];
		},

		/**
		 * Sends postMessage to document.referrer
		 *
		 * @param {Object} data - Data th
		 at will be sent
		 *
		 * @private
		 */
		_sendPostMessageData: function (data) {
			var originUrl = document.referrer || (document.location.ancestorOrigins && document.location.ancestorOrigins[0]) || '';

			if (originUrl) {
				this._log(window.location.host + ' -> ' + data.method + ' ' + this._getDomain(originUrl), JSON.stringify(data, null, 4));

				parent.postMessage(JSON.stringify(data), this._getOrigin(originUrl));
			} else {
				this._log(window.location.host + ' -> ' + data.method + ' ERROR. UNABLE TO GET REFERRER');
			}
		},

		/**
		 * Handles during receiving postMessage
		 *
		 * @param {MessageEvent} event - Javascript event
		 *
		 * @private
		 */
		_getPostMessageData: function (event) {

			if (typeof event.data === 'undefined') {
				this._log(window.location.host + ' <- NO DATA ' + this._getDomain(event.origin), null, null, true);

				return false;
			}

			if (!this._isJson(event.data)) {
				this._log(window.location.host + ' <- NOT JSON ' + this._getDomain(event.origin), null, null, true);

				return false;
			}

			var data = JSON.parse(event.data);

			// Added for defect 1489 18C
			$.each(data.activityList, function (i, a) {
				a.aid = "" + a.aid + "";
			});
			// Added for defect 1489 18C

			if (!data.method) {
				this._log(window.location.host + ' <- NO METHOD ' + this._getDomain(event.origin), null, null, true);

				return false;
			}

			this._log(window.location.host + ' <- ' + data.method + ' ' + this._getDomain(event.origin), JSON.stringify(data, null, 4));

			switch (data.method) {
				case 'init':
					this.pluginInitEnd(data);
					break;

				case 'open':
					this.pluginOpen(data);
					break;

				case 'wakeup':
					this.pluginWakeup(data);
					break;

				case 'error':
					data.errors = data.errors || { error: 'Unknown error' };
					this._showError(data.errors);
					break;

				default:
					this._log(window.location.host + ' <- UNKNOWN METHOD: ' + data.method + ' ' + this._getDomain(event.origin), null, null, true);
					break;
			}
		},
		/**
		 * Show alert with error
		 *
		 * @param {Object} errorData - Object with errors
		 *
		 * @private
		 */
		_showError: function (errorData) {
			alert(JSON.stringify(errorData, null, 4));
		},

		/**
		 * Logs to console
		 *
		 * @param {String} title - Message that will be log
		 * @param {String} [data] - Formatted data that will be collapsed
		 * @param {String} [color] - Color in Hex format
		 * @param {Boolean} [warning] - Is it warning message?
		 *
		 * @private
		 */
		_log: function (title, data, color, warning) {
			if (!this.debugMode) {
				return;
			}
			if (!color) {
				color = '#0066FF';
			}
			if (!!data) {
				console.groupCollapsed('%c[Plugin API] ' + title, 'color: ' + color + '; ' + (!!warning ? 'font-weight: bold;' : 'font-weight: normal;'));
				console.log('[Plugin API] ' + data);
				console.groupEnd();
			} else {
				console.log('%c[Plugin API] ' + title, 'color: ' + color + '; ' + (!!warning ? 'font-weight: bold;' : ''));
			}
		},

		/**
		 * Business login on plugin init
		 */
		saveToLocalStorage: function (data) {
			this._log(window.location.host + ' INIT. SET DATA TO LOCAL STORAGE', JSON.stringify(data, null, 4));

			var initData = {};

			$.each(data, function (key, value) {
				if (-1 !== $.inArray(key, ['apiVersion', 'method'])) {
					return true;
				}

				initData[key] = value;
			});

			localStorage.setItem('pluginInitData', JSON.stringify(initData));
		},

		/**
		 * Business login on plugin init end
		 *
		 * @param {Object} data - JSON object that contain data from OFSC
		 */
		pluginInitEnd: function (data) {
			this.saveToLocalStorage(data);

			var messageData = {
				apiVersion: 1,
				method: 'initEnd'
			};

			if (localStorage.getItem('pluginWakeupCount') < localStorage.getItem('pluginWakeupMaxCount')) {
				this._log(window.location.host + ' UNFINISHED WAKEUP DATA FOUND IN LOCAL STORAGE');

				messageData.wakeupNeeded = true;
			}

			this._sendPostMessageData(messageData);
		},

		/**
		 * Business login on plugin open
		 *
		 * @param {Object} receivedData - JSON object that contain data from OFSC
		 */
		pluginOpen: function (receivedData) {

			this._clearWakeupData();
			if (localStorage.getItem('pluginInitData')) {
				this._log(window.location.host + ' OPEN. GET DATA FROM LOCAL STORAGE', JSON.stringify(JSON.parse(localStorage.getItem('pluginInitData')), null, 4));
				$('.json__local-storage').text(JSON.stringify(JSON.parse(localStorage.getItem('pluginInitData')), null, 4));
			}
			this.initChangeOfWakeup(document);
			this.initChangeOfDataItems();

			var domainName = this._getDomainURL();
			var nowDate = new Date();
			now = nowDate.toISOString();
			
			// CHG0080083 starts
			// var date = nowDate.toISOString().split('T')[0];		
			if (receivedData.activity.date == null || receivedData.activity.date == "") {
				var date = nowDate.toISOString().split('T')[0];
			}
			else {
				var date = receivedData.activity.date;
			}
			// CHG0080083 ends
			
			var errorLogs = receivedData.activity.A_PLUGIN_ERROR_LOG;
			var isActSheduled = "";
			var isRouteActivated = "";

			var headers = {
				'Authorization':
					'Basic ' + btoa(receivedData.securedData.clientId + "@" + domainName + ":" + receivedData.securedData.clientSecret)
			};
			$.ErrorUpdate = function (activityId, sErrorLogs) {

				this._sendPostMessageData({
					"apiVersion": 1,
					"method": "update",
					"activity": {
						"A_PLUGIN_ERROR_LOG": sErrorLogs,
						"aid": activityId
					}

				});
			}.bind(this);

			var veiwGlobalNotes = "", globalNotes = "", activityId = "", apptNumber = "";
			//Begin CHG0059173
			var veiwServiceNotes = "", serviceNotes = "";
			//End CHG0059173
			var aGNDebriefFlag = ""; // Created for STM Phase 2 CHG0068800													 
			var resourceId = receivedData.resource.external_id;
			var currentOdoMeterEnd = 0;
			var dateArr = now.split('T');
			var currentDate = dateArr[0];
			var activityStartedExist = false;
			var activityEnroutedExist = false;
			var activityEnrouted_aid = "";
			var activityStarted_aid = "";
			var activityEnrouted_startOdometer = "";
			var activityEnrouted_endOdometer = 0;
			var activityEnroutedTask_ApptNumber = "";
			var thisVar = this;

			$.urlParam = function (name) {
				try {
					var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
					return results[1] || 0;
				}
				catch (err) {
					if (name != 'date') {
						activityLog = activityLog + ';Exception in urlParam ' + name + ' :' + err.message;
						console.log(" Exception in urlParam " + name + " :" + err.message);
					}
					return '';
				}
			}
			var timeZoneName = receivedData.resource.time_zone;
			var ofscDate = decodeURIComponent($.urlParam('date'));
			var TimeZoneMapping = {
				"19": "Alaska",
				"6": "Arizona",
				"4": "Central",
				"2": "Eastern",
				"15": "GMT",
				"17": "Hawaii (Adak)",
				"18": "Hawaii (Honolulu)",
				"5": "Mountain",
				"7": "Pacific"
			};


			var timeOffset = {
				'Alaska': 9,
				'dAlaska': 8,
				'Arizona': 7,
				'dArizona': 7,
				'Central': 6,
				'dCentral': 5,
				'Eastern': 5,
				'dEastern': 4,
				'GMT': 0,
				'dGMT': 0,
				'Hawaii(Adak)': 10,
				'dHawaii(Adak)': 10,
				'Hawaii(Honolulu)': 10,
				'dHawaii(Honolulu)': 10,
				'Mountain': 7,
				'dMountain': 6,
				'Pacific': 8,
				'dPacific': 7
			}

			var timeZone = TimeZoneMapping[timeZoneName];

			Date.prototype.stdTimezoneOffset = function () {
				var jan = new Date(this.getFullYear(), 0, 1);
				var jul = new Date(this.getFullYear(), 6, 1);
				return Math.max(jan.getTimezoneOffset(), jul.getTimezoneOffset());
			}

			Date.prototype.dst = function () {
				return this.getTimezoneOffset() < this.stdTimezoneOffset();
			}

			var today = new Date();
			if (today.dst()) {
				var timeZoneId = timeOffset['d' + timeZone.replace(' ', '')];
			} else {
				var timeZoneId = timeOffset[timeZone.replace(' ', '')];
			}

			var indainDateObj = new Date();
			indainDateObj.setHours(indainDateObj.getHours() - timeZoneId);
			var dispatchTime = indainDateObj.toISOString();
			
			// CHG0080083 starts
			// var todayDate = dispatchTime.substring(0, 10);

			if (receivedData.activity.date == null || receivedData.activity.date == "") {
				var todayDate = dispatchTime.substring(0, 10);
			}
			else {
				var todayDate = receivedData.activity.date;
			}
			// CHG0080083 ends

				$('#enrouteMainDiv').addClass('cp_hidden');
				$('#pendingActvitiesSection').addClass('cp_hidden');
				$('#nonScheduledActvitiesSection').addClass('cp_hidden');
				$('#startedActvitiesSection').addClass('cp_hidden');
				$('#anotherActivityDiv').addClass('cp_hidden');
			


			
			var activityListArray = [];

			var pendingActCount = 0;
			var nonScheduleActCount = 0;

			//Phase 3 - CHG0071392 - getting time value for activating route
			var resourceTimeZone = receivedData.resource.time_zone;
			var atimeZone = TimeZoneMapping[resourceTimeZone];
			// Set the timezone to retreive the Date & time for Activate route & punch in 
			if ("Alaska" == atimeZone || "Arizona" == atimeZone || "Central" == atimeZone || "Eastern" == atimeZone || "Mountain" == atimeZone || "Pacific" == atimeZone) {
				resourceTimeZone = "US/" + atimeZone;
			}
			else if ("Hawaii (Adak)" == atimeZone) {
				resourceTimeZone = "America/Adak";
			}
			else if ("Hawaii (Honolulu)" == atimeZone) {
				resourceTimeZone = "Pacific/Honolulu";
			}
			// if the resource time zone is null, then assign to EST.
			if (resourceTimeZone == null || "" == resourceTimeZone || typeof (resourceTimeZone) == undefined) {
				resourceTimeZone = "EST";
			}
			// Current Date & Time of resource time zone
			var atodayDate;
			try {
				atodayDate = new Date(new Date().toLocaleString('en-US', { timeZone: resourceTimeZone }));
			}
			catch (err) {
				atodayDate = new Date();
			}
			var day = ("0" + atodayDate.getDate()).slice(-2);
			var month = ("0" + (atodayDate.getMonth() + 1)).slice(-2);
			var hours = ("0" + atodayDate.getHours()).slice(-2);
			var minutes = ("0" + atodayDate.getMinutes()).slice(-2);
			var seconds = ("0" + atodayDate.getSeconds()).slice(-2);
			
			// CHG0080083 starts
			// var date_YYYY_MM_DD = atodayDate.getFullYear().toString() + "-" + month + "-" + day;

			if (receivedData.activity.date == null || receivedData.activity.date == "") {
				var date_YYYY_MM_DD = atodayDate.getFullYear().toString() + "-" + month + "-" + day;
			}
			else {
				var date_YYYY_MM_DD = receivedData.activity.date;
			}
			// CHG0080083 ends
			
			var date_yyyy_MM_dd_HH_mm_ss = date_YYYY_MM_DD + " " + hours + ":" + minutes + ":" + seconds;

			//Start - Phase5 Declaring variables for storing resource inventory
			var rid = receivedData.resource.external_id;
			var dataItemsToProcess = [];
			var dataItems = ['resource'];
			var totalResults = 0;
			var offSet = 0;
			console.log("Data Items: ", dataItems);
			var resourceInventories = false;
			var InventoryData = {};
			var aDate = date_YYYY_MM_DD.concat("-"+rid);

			console.log("RI Local storage : ", localStorage.ri);
			console.log("RI Data Presents ? : ", !localStorage.ri);
			if (localStorage.storageDataItems) 
			{
				dataItemsToProcess = localStorage.storageDataItems.split(',');
			}
			function storeResourceInvToLocal() 
			{
				if ((typeof localStorage.aDate === 'undefined' || aDate != localStorage.aDate) || (dataItemsToProcess.indexOf('resourceInventories') === -1)) 
				{
					localStorage.storageDataItems = [];
					dataItemsToProcess = [];
					localStorage.ri = [];
					localStorage.di = [];
					localStorage.ii = [];
					localStorage.ci = [];
					localStorage.aDate = aDate;
					dataItems.push('customerInventories');
					dataItems.push('deinstalledInventories');
					dataItems.push('installedInventories');
					ResourceInventory();
				} 
				else 
				{
					if (dataItemsToProcess.indexOf('resourceInventories') === -1) 
					{
						dataItems.push('resourceInventories');
					}
					if (dataItemsToProcess.indexOf('customerInventories') === -1) 
					{
						dataItems.push('customerInventories');
					}
					if (dataItemsToProcess.indexOf('deinstalledInventories') === -1) 
					{
						dataItems.push('deinstalledInventories');
					}
					if (dataItemsToProcess.indexOf('installedInventories') === -1) 
					{
						dataItems.push('installedInventories');
					}
					console.log("Data Items : ", dataItems);
				}
			}

			function ResourceInventory() 
			{
				var rInventoryURL = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/resources/" + rid + "/inventories";
				$.ajax({
					url: rInventoryURL,
					method: 'GET',
					dataType: 'json',
					processData: false,
					contentType: 'application/json; charset=utf-8',
					headers: headers,
					async: false,
					crossDomain: true,
					timeout: 8000,
					success: function (successData) {
						console.log("ResourceInventory Success Data", successData);
						resourceInventories = true;
						if (dataItemsToProcess.indexOf('resourceInventories') === -1) {
							dataItemsToProcess.push('resourceInventories');
						}
						console.log(dataItemsToProcess);
						localStorage.storageDataItems = dataItemsToProcess;
						totalResults = successData.totalResults;
						ResourceInventoryBySize();
					},
					error: function (errorData) {
						console.log("ResourceInventory Error: ", errorData);
					}
				});
			}

			function ResourceInventoryBySize() 
			{
				while (totalResults > offSet) 
				{
					var rInventoryURL = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/resources/" + rid + "/inventories?offset=" + offSet + "&limit=100";
					$.ajax({
						url: rInventoryURL,
						method: 'GET',
						dataType: 'json',
						processData: false,
						contentType: 'application/json; charset=utf-8',
						headers: headers,
						async: false,
						crossDomain: true,
						timeout: 8000,
						success: function (successData) {
							console.log(successData);
							if (offSet == 0) {
								InventoryData.ri = successData.items;
							}
							if (offSet > 0) {
								$.each(successData.items, function (i, a) {
									InventoryData.ri.push(a);
								});
							}
						},
						error: function (errorData) {
							console.log(errorData);
							dataItems.push('resourceInventories');
							resourceInventories = true;
							InventoryData.ri = [];
							
						}
					});
					offSet = offSet + 100;
				}
				callReadyMethod();
			}

			function callReadyMethod() 
			{
				console.log('in Ready Method');
				if (resourceInventories) {
					//storing data to localStorage
					localStorage.ri = JSON.stringify(InventoryData.ri);
					console.log(dataItems);
					localStorage.storageDataItems = dataItemsToProcess;
				}
			}

			//End - Phase5 Declaring variables for storing resource inventory

			var resourceUpdateUrl = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/resources/" + receivedData.resource.external_id;
			var resourceRequest = {
				"resourceId": receivedData.resource.external_id,
				"status": "active",
				"language": "en",
				"name": receivedData.resource.pname,
				"R_WORKING_STATUS": "working"
			};
			var activatePayload = {
				resourceUpdateUrl: resourceUpdateUrl,
				resourceRequestParams: resourceRequest,
				activateRouteUrl: "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/resources/" + receivedData.resource.external_id + "/routes/" + date_YYYY_MM_DD + "/custom-actions/activate",
				activateRouteParams: { "time": date_yyyy_MM_dd_HH_mm_ss },
				headers: headers,
				activityId: receivedData.activity.aid,
				resourceId: receivedData.resource.external_id
			}


			/**
				* Ajax call to update the properties
			*/
			$.ajaxCall = function (resourceErrorPayload) {
				$.ajax({
					dataType: "json",
					url: url,
					data: JSON.stringify(resourceErrorPayload),
					method: "PATCH",
					crossDomain: true,
					headers: headers,
					processData: false,
					contentType: 'application/json; charset=utf-8',
					timeout: 8000,
					success: function (response) {
						console.log("Update Resource properties - Success messagae: " + JSON.stringify(response));
					}.bind(this),
					error: function (errorData) {
						console.log("Update Resource properties - Error messagae:" + JSON.stringify(errorData));
					}
				});
			}.bind(this);
			

			$.activateRoute = function () {
				try {
					$.ajax({
						dataType: "json",
						url: activatePayload.activateRouteUrl,
						data: JSON.stringify(activatePayload.activateRouteParams),
						method: "POST",
						//async: false,
						crossDomain: true,
						headers: headers,
						processData: false,
						contentType: 'application/json; charset=utf-8',
						timeout: 8000,
						success: function (response) {
							console.log("Rute Activated for the Resource :", receivedData.resource.external_id);
							isRouteActivated = "Y";
						}.bind(this),
						error: function (errorData) {
							isRouteActivated = "N";
							console.log("Activate Route - Error messagae: " + JSON.stringify(errorData));
							
						}.bind(this)
					});
				} catch (err) {
					var resourceErrorPayload = { "R_PLUGIN_ERROR": "error while Activating Route: " + err.message };
					$.ajaxCall(resourceErrorPayload);
				}
			}.bind(this);


			$.closePopUp = function () {

				this._sendPostMessageData({
					"apiVersion": 1,
					"method": "close",
					"backScreen": "activity_list",
					"wakeupNeeded": false
				});
			}.bind(this);

			$.stmWarningCheck = function () {
				// Condition to validate the Global, SR Instruction and / or STM tasks are included, If yes provide alert.  CHG0068290
				if ((receivedData.activity.A_GLOBAL_NOTES != null && receivedData.activity.A_GLOBAL_NOTES != "undefined")
					|| (receivedData.activity.A_SR_INSTRUCTIONS != null && receivedData.activity.A_SR_INSTRUCTIONS != "undefined")
					|| (receivedData.activity.A_STM_FLAG != null && receivedData.activity.A_STM_FLAG != "undefined" && receivedData.activity.A_STM_FLAG != "N")) {
					alert("Either Global Notes, SR Instructions, and/or STM tasks are included! Please review");
				}
			}.bind(this);

			//Added enrouted activity check in a function.
			$.doEnroutedActivityCheck = function () {
				console.log(' doEnroutedActivityCheck ');
				activityListArray = receivedData.activityList;
				try {
					$.each(activityListArray, function (i, a) {
						if (a.astatus == "started") {
							console.log(' Started Activity ' + a.aid);
							activityStartedExist = true;
							activityStarted_aid = a.aid;
							alert('Already another activity Id-' + a.aid + ' Started. You can\'t enroute another activity till current activity is completed.');
							console.log(' closePopUp');
							$.closePopUp();
							console.log(' after closePopUp');
						}
						else if (a.astatus === 'enroute') {
							console.log(' Enrouted Pending activity ' + a.aid);
							activityEnroutedExist = true;
							activityEnrouted_aid = a.aid;
							activityEnrouted_startOdometer = a.A_ODOMETER_START;
							activityEnrouted_endOdometer = a.A_ODOMETER_END;
							activityEnroutedTask_ApptNumber = a.appt_number;
							if (activityEnroutedTask_ApptNumber == null || activityEnroutedTask_ApptNumber == 'undefined') {
								activityEnroutedTask_ApptNumber = 'Not Available';
							}
							currentOdoMeterEnd = activityEnrouted_endOdometer;
							if (activityEnrouted_aid) {
								$('#anotherActIdSpan').text(activityEnrouted_aid);
							}
							if (activityEnroutedTask_ApptNumber) {
								$('#anotherActTaskNumber').text(activityEnroutedTask_ApptNumber);
							}
						}
						else if (a.astatus == 'complete' || a.astatus == 'suspended' || a.astatus == 'cancelled') {
							console.log(' Complete - suspended - cancelled activity ' + a.aid);
							if (a.A_ODOMETER_END) {
								if (currentOdoMeterEnd < parseInt(a.A_ODOMETER_END)) {
									currentOdoMeterEnd = parseInt(a.A_ODOMETER_END);
								}
							}
						}
						console.log(' End Loop');
					});
					console.log(' After loop');
					if (currentOdoMeterEnd) {
						$("#odoMeter").val(currentOdoMeterEnd);
					}
				}
				catch (err) {
					activityLog = activityLog + ';Exception in doEnroutedActivityCheck:' + err.message;
					console.log(" Exception in doEnroutedActivityCheck :" + err.message);
				}
			}.bind(this);
			//	end OFSC Mobility Phase2 CHG0062368


			// Start STM Phase 2 CHG0068800
			function getglobalnotes() {
				var GNheaders = {
					'accept': 'application/json',
					'Authorization':
						'Basic ' + btoa(receivedData.securedData.clientId + "@" + domainName + ":" + receivedData.securedData.clientSecret)
				}; // Added exception while fetching the global notes for activity
				try {
					var globalNotesURL = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/activities/" + receivedData.activity.aid + "/A_GLOBAL_NOTES_FILE";
					console.log(globalNotesURL);
					// Ajax call to get the global notes url
					$.ajax({
						url: globalNotesURL,
						method: "GET",
						async: false,
						headers: GNheaders,
						success: function (response) {
							if (response.aAWSGlobalNotes) {
								var globalNotesDetails = JSON.parse(response.aAWSGlobalNotes);
								localStorage.setItem('NOTES_ACT_OFFLINE_FILE',JSON.stringify(response.aAWSGlobalNotes));
								if (globalNotesDetails.All && globalNotesDetails.Enroute) {
									$.each(globalNotesDetails.Enroute, function (k, v) {
										globalNotes += v + '<br/>';
									});
									globalNotes += ' <br />';
									$.each(globalNotesDetails.All, function (k, v) {
										globalNotes += v + '<br/>';
									});
								} else if (globalNotesDetails.Enroute) {
									$.each(globalNotesDetails.Enroute, function (k, v) {
										globalNotes += v + '<br/>';
									});
								}
								else if (globalNotesDetails.All) {
									$.each(globalNotesDetails.All, function (k, v) {
										globalNotes += v + '<br/>';
									});
								}

								if (globalNotesDetails.All || globalNotesDetails.Debrief) {
									aGNDebriefFlag = 'Y';
								}
							}
						}.bind(this),
						error: function (errorData) {
							console.log("While retreiving NOTES data - Error messagae:" + JSON.stringify(errorData));
						}
					}).bind(this);
				} catch (err) {
					var notesErrorPayload = {
						"NOTES_PLUGIN_ERROR": "Error creating NOTES: " + err.message
					};

				}
			}
			// End STM Phase 2 CHG0068800
			function getstm() {
				
				var stmHeaders = {
					'Authorization': 'Basic ' + btoa(receivedData.securedData.clientId + "@" + domainName + ":" + receivedData.securedData.clientSecret),
					'content-type': 'application/json',
					'accept': 'application/octet-stream'
				};				
				
                try {
					var stmTaskURL = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/activities/" + receivedData.activity.aid + "/A_STM_TASK_FILE";
					console.log(stmTaskURL);
					var stmFileDetails = {};
					
					// Ajax call to get the tech today activities
					$.ajax({
						dataType: "json",
						url: stmTaskURL,
						method: "GET",
						async: false,
						crossDomain: true,
						headers: stmHeaders,
						processData: false,
						timeout: 15000,
						success: function (response) {
							var stmDetails = JSON.parse(response.aSTMTask);
							localStorage.setItem('STM_ACT_OFFLINE_FILE', JSON.stringify(response));
							if (response.aSTMTask) {
								stmFileDetails = response;
							} else {
								stmFileDetails = {};
							}
						}.bind(this),
						error: function (errorData) {
							console.log("While retreiving STM data - Error messagae:" + JSON.stringify(errorData));
							stmFileDetails = {};
						}
					});
				} catch (err) {
					var stmErrorPayload = {
						"STM_PLUGIN_ERROR": "Error creating STM: " + err.message
					};
				}
			}


			function callEnroute(actId) {
				
				activityId = actId; // assign actId into global activityId
				try {
					//INC1872665 - Replaced receivedData.activity.aid. with receivedData.activity.
					veiwGlobalNotes = receivedData.activity.A_VIEW_GLOBAL_NOTES;
					if ("" == globalNotes && receivedData.activity.A_GLOBAL_NOTES != null) {
						globalNotes = receivedData.activity.A_GLOBAL_NOTES;
					}
					//Begin CHG0059173
					veiwServiceNotes = receivedData.activity.A_SERVICE_NOTE_VIEW;
					serviceNotes = receivedData.activity.A_SR_INSTRUCTIONS;
					//End CHG0059173
					//end INC1872665
					apptNumber = receivedData.activity.appt_number;
					$('#activitiesListDiv').addClass('cp_hidden');
					$('#activitiesListDiv').hide();
					$('#pendingActvitiesSection').addClass('cp_hidden');
					$('#nonScheduledActvitiesSection').addClass('cp_hidden');
					$('#startedActvitiesSection').addClass('cp_hidden');
					if (receivedData.activity.position_in_route > 0 || receivedData.activity.position_in_route == -1)
					{
						$("#enrouteMainDiv").removeClass('cp_hidden');
						$("#enrouteDiv").removeClass('cp_hidden');
						$("#cpf_odometer").removeClass('cp_hidden');
						$("#moveAlert").removeClass('cp_hidden');
					}
					if (activityEnroutedExist == true) {
						alert('You are already enroute on the following Activity Id: ' + activityEnrouted_aid + ' and Task Number: ' + activityEnroutedTask_ApptNumber + '. Please Un-Enroute the Activity ' + activityEnrouted_aid + ' to proceed');
						$.closePopUp();
					} else {
						// Condition to validate the Global, SR Instruction and / or STM tasks are included, If yes provide alert. CHG0068290
						$.stmWarningCheck();
					}
					if (activityEnrouted_startOdometer) {
						$("#odoMeter").val(activityEnrouted_startOdometer);
					}

					if (globalNotes) {
						$('#veiwGlobalNotesMainDiv').removeClass('cp_hidden');
					}
					//Begin CHG0059173
					if (serviceNotes) {
						$('#veiwServiceNotesMainDiv').removeClass('cp_hidden');
					}
					//End CHG0059173
				}
				catch (err) {
					activityLog = activityLog + ';Exception in callEnroute:' + err.message;
					console.log(" Exception in callEnroute:" + err.message);
				}

			}
			/* end OFSC Mobility Phase2 CHG0062368  */
			$('#viewGlobalNotesChkBox').change(function () {
				try {
					if ($('#viewGlobalNotesChkBox').is(":checked")) {
						$('#globalNoteDetailDiv').removeClass('cp_hidden');
						$('#veiwGlobalNotesDiv').html(globalNotes);
					} else {
						$('#globalNoteDetailDiv').addClass('cp_hidden');
					}
				} catch (err) {
					activityLog = activityLog + ';Exception in viewGlobalNotesChkBox:' + err.message;
					console.log(" Exception in viewGlobalNotesChkBox:" + err.message);
				}
			});
			//Begin CHG0059173
			$('#viewServiceNotesChkBox').change(function () {
				try {
					if ($('#viewServiceNotesChkBox').is(":checked")) {
						$('#serviceNoteDetailDiv').removeClass('cp_hidden');
						$('#veiwServiceNotesDiv').text(serviceNotes);
					} else {
						$('#serviceNoteDetailDiv').addClass('cp_hidden');
					}
				} catch (err) {
					activityLog = activityLog + ';Exception in viewServiceNotesChkBox:' + err.message;
					console.log(" Exception in viewServiceNotesChkBox:" + err.message);
				}
			});
			//End CHG0059173


			$('#enRouteCancelBtn').click(function () {
				console.log('enRouteCancelBtn');
				$.closePopUp();
			}.bind(this));

			$('#anotherActSubmitBtn').click(function () {
				$("#anotherActivityDiv").addClass('cp_hidden');
				$("#enrouteDiv").removeClass('cp_hidden');
				// Condition to validate the Global, SR Instruction and / or STM tasks are included, If yes provide alert. CHG0068290
				$.stmWarningCheck();
			}),

				$('#anotherActCancelBtn').click(function () {
					$.closePopUp();
				}.bind(this));

			$('#enRouteSubmitBtn').click(function () {
				try {
					var odoMeterStart = $('#odoMeter').val();
					if (!(odoMeterStart)) {
						alert('The odometer value should not be empty');
						return false;
					}

					if (isNaN(odoMeterStart)) {
						alert('The odometer value should be numeric');
						return false;
					}
					if (parseInt(odoMeterStart) < 1) {
						alert('The odometer value has to be greater than 0');
						return false;
					}
					var viewGlobalNotes = "0";
					if ($('#viewGlobalNotesChkBox').is(":checked")) {
						viewGlobalNotes = "1";
					} else {
						if (globalNotes != null && globalNotes != "undefined" && globalNotes != "") {
							alert('Please enable global notes');
							return false;
						}
					}
					//Begin CHG0059173
					var viewServiceNotes = "0";
					if ($('#viewServiceNotesChkBox').is(":checked")) {
						viewServiceNotes = "1";
					} else {
						if (serviceNotes != null && serviceNotes != "undefined") {
							alert('Please enable service notes');
							return false;
						}
					}
					//End CHG0059173

					var dateArr = now.split('T');
					var currentDate = dateArr[0];

					if (currentOdoMeterEnd) {
						if (parseInt(odoMeterStart) < parseInt(currentOdoMeterEnd)) {
							if (!confirm('Start odometer value is less than End odometer value from previous SR(' + currentOdoMeterEnd + '). Click OK to continue.')
							) {
								return false;
							}
						}
					}
					console.log('activityEnroutedExist:', activityEnroutedExist)
					//Added for OFSC Mobility Phase2 CHG0062368
					if (receivedData.activity.A_ACTIVITY_LOG != null) {
						if (activityLog != null && activityLog != "") {
							activityLog = receivedData.activity.A_ACTIVITY_LOG + '' + activityLog;
						}
						else {
							activityLog = receivedData.activity.A_ACTIVITY_LOG;
						}
					}
					if(isActSheduled==""){
						alert("Scheduling the activity is in progress. Please wait for few seconds and Resubmit");
					}

					if (activityEnroutedExist != true && isActSheduled == 'Y') { 
						$.enrouteAPICall(activityId, receivedData.securedData.enrouteSRType, odoMeterStart, dispatchTime, timeZone, date);
					}
					
				}
				catch (err) {
					activityLog = activityLog + ';Exception in enRouteSubmitBtn:' + err.message;
					console.log(" Exception in enRouteSubmitBtn:" + err.message);
				}


			}.bind(this));


			$.closeMethod = function (activityId, odoMeterStart, dispatchTime, wakeupNeeded) {
				//Added  activityLog for OFSC Mobility Phase2 CHG0062368	, changed backScreen default to activity_list	
				////Phase 3 - CHG0071392 - removed - updating A_ORACLE_STATUS
				var activityList = "{\"apiVersion\":1, \"method\":\"close\",";
				var armsEligible = false;  
				var atRemoteTypeARMSEligibleTypes = ["Embedded", "Appliance - Hardware", "Appliance - Software"]; 
				if('Y' == receivedData.activity.A_ATREMOTE_REPORTING &&
					atRemoteTypeARMSEligibleTypes.includes(receivedData.activity.A_ATREMOTE_TYPE) &&
					'N' == receivedData.activity.A_ATREMOTE_EXCLUSION){
						armsEligible = true;
				}
				if(armsEligible){
					activityList = activityList + " \"backScreen\":\"plugin_by_label\", \"backPluginLabel\":\"ARMS-H\"";
				} else {
					activityList = activityList + " \"backScreen\":\"activity_list\"";
				}
				
				 activityList = activityList +", \"wakeupNeeded\":\"" + wakeupNeeded + "\", \"activity\":{\"aid\":\"" + activityId + "\",\"A_ODOMETER_START\":\"" + odoMeterStart + "\",\"A_ODOMETER_END\":\"" + odoMeterStart + "\", \"A_STATE\":\"EN\", \"A_DISPATCH_TIME\":\"" + dispatchTime.substring(0, 19) + "\", \"A_DISPATCH_TIME_OVERRIDE\":\"\", \"A_RESPONSE_ELIGIBLE\":\"\", \"A_EXPENSES_PLUGIN\":\"\", \"A_EXPENSES_OUTBOUND\":\"\", \"A_SUSPEND_REASON\":\"\", \"A_SITE_REFERENCE_UPDATE\":\"\", \"A_ENTER_PO_NUMBER\":\"\", \"A_STATUS\":null, \"A_NEW_EQUIPMENT_ID\":\"\", \"A_TIME_OVERNIGHT\":\"\", \"A_START_TIME\":\"\", \"A_START_TIME_OVERRIDE\":\"\", \"A_SCAN_IN_TIME\":\"\", \"A_SCAN_IN_TIME_OVERRIDE\":\"\", \"A_SCAN_OUT_TIME\":\"\", \"A_SCAN_OUT_TIME_OVERRIDE\":\"\", \"A_MACHINE_STATUS_BEFORE\":\"\", \"A_MACHINE_STATUS_AFTER\":\"\"";
				 
				if (activityLog != null && activityLog != '') {
					activityList = activityList + ",\"A_ACTIVITY_LOG\":\"" + activityLog + "\"";
				}
				if ('Y' == aGNDebriefFlag) {
					activityList = activityList + ",\"A_GN_DEBRIEF_FLAG\":\"" + aGNDebriefFlag + "\"";
				}
				activityList = activityList + "}}";
				console.log('Close Method JSON::', activityList);
				var closeJSONToSend = JSON.parse(activityList);
				this._sendPostMessageData(closeJSONToSend);
			}.bind(this);

			//Phase 3 - CHG0071392
			$.enrouteAPICall = function (activityId, srType, odoMeterStart, dispatchTime, timeZone, date) {
				var webServiceURL = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/activities/" + activityId + "/custom-actions/enroute";

				var jsonPayload = {
					date: date,
					requestType: srType,
					requestEntity: 'ACTIVITY',
					pluginName: pluginName
				}

				//CHG0069299 - Validate internet connectivity and EnRoute
				$.ajax({
					url: window.location.href,
					timeout: 8000,
					cache: false,
					type: 'GET',
					tryCount: 0,
					retryLimit: 3,
					success: function (response) {
						console.log(' online configuration')
						enrouteActivity();

					}.bind(this),
					error: function (xhr, textStatus, errorThrown) {
						if (textStatus == 'timeout') {
							this.tryCount++;
							if (this.tryCount <= this.retryLimit) {
								//try again
								$.ajax(this);
								return false;
							}
							enrouteStoreOffline();

						}
						if (xhr.status == 500) {
							enrouteStoreOffline();

						}
						else {
							enrouteStoreOffline();

						}
					}.bind(this)
				});
				function enrouteActivity() {

					$.ajax({
						url: webServiceURL,
						async: false,
						crossDomain: true,
						headers: headers,
						dataType: 'json',
						contentType: 'application/json; charset=utf-8',
						method: 'POST',
						async: false,
						data: JSON.stringify(jsonPayload),
						timeout: 8000,
						success: function (response) {
							console.log("Enroute Activity Response  - " + JSON.stringify(response));
							$.srCreateAPICall(activityId, receivedData.securedData.enrouteSRType, odoMeterStart, dispatchTime);
						}.bind(this),
						error: function (response) {
							console.log("Enroute Activity Response Hosted - " + JSON.stringify(response));
							var detail = response.responseJSON.detail;
							var status = response.responseJSON.status;
							console.log("Enroute Activity Response detail Hosted - " + detail);
							console.log("Enroute Activity Response Status Hosted- " + status);
							var now = new Date(Date.now());
							var errorTime = now.getHours() + ":" + now.getMinutes() + ":" + now.getSeconds();
							var eDetail = detail.replace(/(\r\n|\n|\r)/gm, " ");

							if (errorLogs == null) {
								errorLogs = "";
							}
							errorLogs = errorLogs + "||" + now.toString() + "|Plugin :Enroute " + "| URL:" + webServiceURL.toString() + "|Error Status:" + status + "|Error Details:" + eDetail;
							console.log(errorLogs);

							$.ErrorUpdate(activityId, errorLogs);

							if (status == 409 && detail == "Route is not activated yet") {
								//$.activateRoute(receivedData.resource.external_id, date_yyyy_MM_dd_HH_mm_ss);
								$.activateRoute();
								// Begin CHG0078102 - Enroute Plug In Change for 22C
								if(isActSheduled=="Y"){
									$.enrouteAPICall(activityId, receivedData.securedData.enrouteSRType, odoMeterStart, dispatchTime, timeZone, date);
								}
								// End CHG0078102 - Enroute Plug In Change for 22C
							}
							else {
								alert('Error Occured - enrouteActivity ' + detail);
								return false;
							}


						}.bind(this)
					});
				}
				function enrouteStoreOffline() {
					//CHG0071392 - Alert introduced in offline
					alert("Enrouting an activity is not available while in an Offline condition. Check again when network connectivity is restored.");

				}
			}.bind(this);
			//Phase 3 - CHG0071392

			$.srCreateAPICall = function (activityId, srType, odoMeterStart, dispatchTime) {
				var webServiceURL = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/serviceRequests";
				var jsonPayload = {
					date: todayDate,
					activityId: parseInt(activityId),
					requestType: srType,
					requestEntity: "ACTIVITY",
					pluginName: pluginName
				}
				//CHG0069299 - Validate internet connectivity and EnRoute
				$.ajax({
					url: window.location.href,
					timeout: 8000,
					cache: false,
					type: 'GET',
					tryCount: 0,
					retryLimit: 3,
					success: function (response) {
						console.log('online configuration - srCreateAPICall');
						srCreateEnroute();
						$.closeMethod(activityId, odoMeterStart, dispatchTime, false);

					}.bind(this),
					error: function (xhr, textStatus, errorThrown) {
						if (textStatus == 'timeout') {
							this.tryCount++;
							if (this.tryCount <= this.retryLimit) {
								//try again
								$.ajax(this);
								return false;
							}
							srCreateEnrouteOffline();
						}
						if (xhr.status == 500) {
							srCreateEnrouteOffline();
						}
						else {
							srCreateEnrouteOffline();
						}
					}.bind(this)
				});
				function srCreateEnroute() {
					$.ajax({
						url: webServiceURL,
						dataType: 'json',
						method: 'POST',
						contentType: 'application/json; charset=utf-8',
						data: JSON.stringify(jsonPayload),
						async: false,
						crossDomain: true,
						headers: headers,
						timeout: 8000,
						success: function (response) {
							console.log("Create Enroute Service Request call response:");
							console.log(response);
						}.bind(this),
						error: function (response) {
							console.log("SRCreateEnrouteActivity - errr:" + JSON.stringify(response));
							var now = new Date(Date.now());
							var errorTime = now.getHours() + ":" + now.getMinutes() + ":" + now.getSeconds();
							var errorDetails = response.responseJSON;

							var eDetail = errorDetails.detail.replace(/(\r\n|\n|\r)/gm, " ");
							var eStatus = errorDetails.status;
							if (errorLogs == null) {
								errorLogs = "";
							}
							errorLogs = errorLogs + "||" + now.toString() + "|Plugin :Enroute " + "| URL:" + webServiceURL.toString() + "|Error Status:" + eStatus + "|Error Details:" + eDetail;
							console.log(errorLogs);

							$.ErrorUpdate(activityId, errorLogs);
						}.bind(this)
					});
				}
				function srCreateEnrouteOffline() {
					//CHG0071392 - Sr create offline not required
				}
			}.bind(this);
			$.processEnrouteUnrouteRequest = function () {
				$.doEnroutedActivityCheck();
				if (activityStartedExist == false) {
					if ((receivedData.activity.astatus == 'pending') && (receivedData.activity.A_STATE == null || receivedData.activity.A_ORACLE_STATUS != 'Enroute')) {
						getglobalnotes();
						if(receivedData.activity.A_STM_FLAG== 'Y'){
							getstm();
						}
						callEnroute(receivedData.activity.aid);
					}
				}
			}.bind(this);

			$.setActivityScheduled = function (actId) {

				var setMoveRESTServiceURL = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/activities/" + activityId + "/custom-actions/move";
				var payload = {
					"pluginName": pluginName,
					"setPositionInRoute": { "position": "first" },
					"setDate": { "date": todayDate }
				}
				console.log("setActivityScheduled webservice call started URL-" + setMoveRESTServiceURL);
				console.log("setActivityScheduled Input Payload " + JSON.stringify(payload));

				$.ajax({
					url: window.location.href,
					timeout: 8000,
					cache: false,
					type: 'GET',
					tryCount: 0,
					retryLimit: 3,
					success: function (response) {
						console.log(' online configuration');
						
						storeResourceInvToLocal(); //MPF Phase 5 - Store Resource Inventory to local
						setScheduleActivity();
					}.bind(this),
					error: function (xhr, textStatus, errorThrown) {
						if (textStatus == 'timeout') {
							this.tryCount++;
							if (this.tryCount <= this.retryLimit) {
								$.ajax(this);
								return false;
							}
							setScheduledStoreOffline();
						}
						if (xhr.status == 500) {
							setScheduledStoreOffline();
						}
						else {
							setScheduledStoreOffline();
						}
					}.bind(this)
				});

				function setScheduleActivity() {
					$.ajax({
						url: setMoveRESTServiceURL,
						async: false,
						crossDomain: true,
						headers: headers,
						dataType: 'json',
						contentType: 'application/json; charset=utf-8',
						contentLength: 0,
						method: 'POST',
						async: false,
						data: JSON.stringify(payload),
						timeout: 8000,
						success: function (response) {
							console.log("*** Activity "+ actId+ " is Scheduled");
							isActSheduled = "Y";
							if (receivedData.activity.date == null || receivedData.activity.date == "") {
								alert("Non Scheduled Activity ("+actId+") has moved to Pending Queue. Please proceed to Enroute the activity from Pending Queue.");
								$.closePopUp();
							}
						}.bind(this),
						error: function (response) {
							isActSheduled = "N";
							console.log("Set Scheduled Activity - errr:" + JSON.stringify(response));
							var now = new Date(Date.now());
							var errorTime = now.getHours() + ":" + now.getMinutes() + ":" + now.getSeconds();
							var errorDetails = response.responseJSON;

							var eDetail = errorDetails.detail.replace(/(\r\n|\n|\r)/gm, " ");
							var eStatus = errorDetails.status;
							if (errorLogs == null) {
								errorLogs = "";
							}
							errorLogs = errorLogs + "||" + now.toString() + "|Plugin :Enroute " + "| URL:" + setMoveRESTServiceURL.toString() + "|Error Status:" + eStatus + "|Error Details:" + eDetail;
							errorLogs = errorLogs + "|| Position In Route Value : "+ receivedData.activity.position_in_route;
							console.log(errorLogs);

							$.ErrorUpdate(activityId, errorLogs);
							alert("Activity Scheduling Failed : ",JSON.stringify(response));
							$.closePopUp();

						}.bind(this)
					});
				}
				function setScheduledStoreOffline() {
					//CHG0071392 - Scheduling an activity in offline not required

				}
			};

			if (receivedData.activity.astatus != 'enroute') {
				$.processEnrouteUnrouteRequest();
				if (receivedData.activity.position_in_route < 0 && activityEnroutedExist == false && activityStartedExist == false) {
					$.setActivityScheduled(receivedData.activity.aid);
				} else if (receivedData.activity.astatus == 'pending' && receivedData.activity.position_in_route > 0) {
					$.setActivityScheduled(receivedData.activity.aid);

				}
			}
			$.closeMethod_UnEnroute = function (activityId, wakeupNeeded) {
				var activityList = "{\"apiVersion\":1, \"method\":\"close\", \"backScreen\":\"activity_list\", \"wakeupNeeded\":\"" + wakeupNeeded + "\", \"activity\":{\"aid\":\"" + activityId + "\",\"A_ODOMETER_START\":\"\",\"A_ODOMETER_END\":\"\", \"A_ORACLE_STATUS\":\"\", \"A_STATE\":null, \"A_DISPATCH_TIME\":\"\", \"A_DISPATCH_TIME_OVERRIDE\":\"\"";
				if (activityLog != null && activityLog != '') {
					activityList = activityList + ",\"A_ACTIVITY_LOG\":\"" + activityLog + "\"";
				}
				/*STM Phase 1 - CHG0068290*/
				if (receivedData.activity.A_PRECALL_ACCEPT_FLAG == 'Y') {
					activityList = activityList + ",\"A_PRECALL_ACCEPT_FLAG\":\"N\"";
				}
				activityList = activityList + "}}";

				console.log('closeMethod_UnEnroute Close Method JSON:' + activityList);
				var closeJSONToSend = JSON.parse(activityList);
				this._sendPostMessageData(closeJSONToSend);
				console.log(' after _sendPostMessageData');
			}.bind(this);
			$.callUnEnroute = function (actId) {
				//Added activityLog for OFSC Mobility Phase2 CHG0062368
				try {
					if (receivedData.activity.A_ACTIVITY_LOG != null) {
						if (activityLog != null) {
							activityLog = receivedData.activity.A_ACTIVITY_LOG + ';' + activityLog;
						}
						else {
							activityLog = receivedData.activity.A_ACTIVITY_LOG;
						}
					}
					
					$.unEnrouteAPICall(actId, receivedData.securedData.unEnrouteSRType, timeZone);
					$.srCreateAPICall_UnEnroute(actId, receivedData.securedData.unEnrouteSRType, timeZone);
				} catch (err) {
					activityLog = activityLog + ';Exception in callUnEnroute:' + err.message;
					console.log(" Exception in callUnEnroute:" + err.message);
				}
			}.bind(this);
			//Phase 3 - CHG0071392
			$.unEnrouteAPICall = function (activityId, srType, timeZone) {
				console.log(' unEnrouteAPICall ');
				pluginName = 'PI-UnEnroute';
				//CHG0071392 - OFSC Native Enroute - custome url defined 

				var webServiceURL = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/activities/" + activityId + "/custom-actions/stopTravel";

				//CHG0069299 - Validate internet connectivity and Un-EnRoute
				$.ajax({
					url: window.location.href,
					timeout: 8000,
					cache: false,
					type: 'GET',
					tryCount: 0,
					retryLimit: 3,
					success: function (response) {
						console.log(' online configuration');
						unEnrouteActivity();
					}.bind(this),
					error: function (xhr, textStatus, errorThrown) {
						if (textStatus == 'timeout') {
							this.tryCount++;
							if (this.tryCount <= this.retryLimit) {
								//try again
								$.ajax(this);
								return false;
							}
							storeOffline();
						}
						if (xhr.status == 500) {
							storeOffline();
						}
						else {
							storeOffline();
						}
					}
				});
				function unEnrouteActivity() {
					$.ajax({
						url: webServiceURL,
						method: 'POST',
						async: false,
						contentType: 'application/json; charset=utf-8',
						crossDomain: true,
						headers: headers,
						timeout: 8000,
						success: function (response) {
							console.log(' before closeMethod_UnEnroute - success');

						}.bind(this),
						error: function (response) {

							if (activityLog != null && activityLog != '') {
								activityLog = activityLog + ";Enroute-Error on unEnRouteAPICallQue";
							}
							else {
								activityLog = "Enroute-Error on unEnRouteAPICallQue";
							}

							var now = new Date(Date.now());
							var errorTime = now.getHours() + ":" + now.getMinutes() + ":" + now.getSeconds();
							var errorDetails = response.responseJSON;

							var eDetail = errorDetails.detail.replace(/(\r\n|\n|\r)/gm, " ");
							var eStatus = errorDetails.status;
							if (errorLogs == null) {
								errorLogs = "";
							}
							errorLogs = errorLogs + "||" + now.toString() + "|Plugin :Un-Enroute " + "| URL:" + webServiceURL.toString() + "|Error Status:" + eStatus + "|Error Details:" + eDetail;
							console.log(errorLogs);

							var errorMessage = now.toString() + "|Plugin :Un-Enroute " + "| URL:" + webServiceURL + "| Error Details:" + JSON.stringify(response);
							console.log("Error Message:" + errorMessage);
							$.ErrorUpdate(activityId, errorLogs, errorMessage);

						}.bind(this)
					});
				}
				function storeOffline() {

					console.log('Unenroute: Disabled for offline');

				}
			}.bind(this);

			//Phase 3 - CHG0071392
			$.srCreateAPICall_UnEnroute = function (activityId, srType, timeZone) {
				console.log(' srCreateAPICall_UnEnroute ');
				pluginName = 'PI-UnEnroute';
				var srWebServiceURL = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/serviceRequests";
				console.log('srCreateAPICall_UnEnroute - URL : ');
				console.log(srWebServiceURL);
				var jsonPayload = {
					"instanceName": receivedData.securedData.company,
					"date": todayDate,
					"activityId": parseInt(activityId),
					"requestType": srType,
					"requestEntity": "ACTIVITY",
					"pluginName": pluginName
				}


				$.ajax({
					url: window.location.href,
					timeout: 8000,
					cache: false,
					type: 'GET',
					tryCount: 0,
					retryLimit: 3,
					success: function (response) {
						console.log(' online configuration');
						srUnEnrouteActivity();
						$.closeMethod_UnEnroute(activityId, false);

					}.bind(this),
					error: function (xhr, textStatus, errorThrown) {
						if (textStatus == 'timeout') {
							this.tryCount++;
							if (this.tryCount <= this.retryLimit) {
								//try again
								$.ajax(this);
								return false;
							}
							srStoreOffline();
						}
						if (xhr.status == 500) {
							srStoreOffline();
						}
						else {
							srStoreOffline();

						}
					}
				});
				function srUnEnrouteActivity() {
					$.ajax({
						url: srWebServiceURL,
						method: 'POST',
						contentType: 'application/json; charset=utf-8',
						data: JSON.stringify(jsonPayload),
						async: false,
						crossDomain: true,
						headers: headers,
						timeout: 8000,

						success: function (response) {
							console.log(' srUnEnrouteActivity - success');
						}.bind(this),
						error: function (response) {

							if (activityLog != null && activityLog != '') {
								activityLog = activityLog + ";Enroute-Error on unEnRouteSRCreateAPICallQue";
							}
							else {
								activityLog = "Enroute-Error on unEnRouteSRCreateAPICallQue";
							}

							console.log(' srUnEnrouteActivity - error ');
							var srnow = new Date(Date.now());
							var srerrorTime = srnow.getHours() + ":" + srnow.getMinutes() + ":" + srnow.getSeconds();
							var srerrorDetails = response.responseJSON;

							var sreDetail = srerrorDetails.detail.replace(/(\r\n|\n|\r)/gm, " ");
							var sreStatus = srerrorDetails.status;
							if (errorLogs == null) {
								errorLogs = "";
							}
							errorLogs = errorLogs + "||" + srnow.toString() + "|Plugin :Un-Enroute " + "| URL:" + srWebServiceURL.toString() + "|Error Status:" + sreStatus + "|Error Details:" + sreDetail;
							console.log(errorLogs);

							var srerrorMessage = srnow.toString() + "|Plugin :Un-Enroute " + "| URL:" + srWebServiceURL + "| Error Details:" + JSON.stringify(response);
							console.log("Error Message:" + srerrorMessage);
							console.log(srnow);
							console.log(srerrorTime);
							console.log(srerrorDetails);
							console.log(errorLogs);
							console.log(activityId);

							$.ErrorUpdate(activityId, errorLogs, srerrorMessage);


						}.bind(this)
					});
				}
				function srStoreOffline() {
					console.log('srStoreOffline: Disabled for offline');

				}
			}.bind(this);



			if (receivedData.activity.astatus == 'enroute') {
				
				$.callUnEnroute(receivedData.activity.aid);
			}
			/* end OFSC Mobility Phase2 CHG0062368 */
		},


		/**
		 * Business login on plugin wakeup (background open for sync)
		 *
		 * @param {Object} receivedData - JSON object that contain data from OFSC
		 */
		pluginWakeup: function (receivedData) {
			this._log(window.location.host + ' WAKEUP', JSON.stringify(receivedData, null, 4));
			var thisVarOnline = this;
			var wakeupData = {
				pluginWakeupCount: +localStorage.getItem('pluginWakeupCount'),
				pluginWakeupMaxCount: +localStorage.getItem('pluginWakeupMaxCount'),
				pluginWakeupDontRespondOn: +localStorage.getItem('pluginWakeupDontRespondOn')
			};

			wakeupData.pluginWakeupCount = wakeupData.pluginWakeupCount + 1;

			localStorage.setItem('pluginWakeupCount', wakeupData.pluginWakeupCount);
			localStorage.setItem('pluginWakeupMaxCount', wakeupData.pluginWakeupMaxCount);
			localStorage.setItem('pluginWakeupDontRespondOn', wakeupData.pluginWakeupDontRespondOn);

			this._log(window.location.host + ' SAVE WAKEUP DATA TO LOCAL STORAGE', JSON.stringify(wakeupData, null, 4));



			if (wakeupData.pluginWakeupDontRespondOn == wakeupData.pluginWakeupCount) {
				this._log(window.location.host + ' EMULATE NOT RESPONDING PLUGIN');

				return;
			}

			if (wakeupData.pluginWakeupCount < wakeupData.pluginWakeupMaxCount) {
				setTimeout(function () {
					this._log(window.location.host + ' SLEEP. RETRY NEEDED');

					this._sendPostMessageData({
						apiVersion: 1,
						method: 'sleep',
						wakeupNeeded: true
					});
				}.bind(this), 2000);
			} else {
				setTimeout(function () {
					this._log(window.location.host + ' SLEEP. NO RETRY');

					this._sendPostMessageData({
						apiVersion: 1,
						method: 'sleep',
						wakeupNeeded: false
					});
				}.bind(this), 12000);
			}
		},

		/**
		 * Save configuration of wakeup (background open for sync) behavior for Plugin
		 * to Local Storage
		 *
		 * @private
		 */
		_saveWakeupData: function () {
			var wakeupData = {
				pluginWakeupCount: 0,
				pluginWakeupMaxCount: 0,
				pluginWakeupDontRespondOn: 0
			};

			if ($('#wakeup').is(':checked')) {
				wakeupData.pluginWakeupMaxCount = parseInt($('#repeat_count').val());

				if ($('#dont_respond').is(':checked')) {
					wakeupData.pluginWakeupDontRespondOn = parseInt($('#dont_respond_on').val());
				}
			}

			localStorage.setItem('pluginWakeupCount', wakeupData.pluginWakeupCount);
			localStorage.setItem('pluginWakeupMaxCount', wakeupData.pluginWakeupMaxCount);
			localStorage.setItem('pluginWakeupDontRespondOn', wakeupData.pluginWakeupDontRespondOn);

			this._log(window.location.host + ' SAVE WAKEUP DATA TO LOCAL STORAGE', JSON.stringify(wakeupData, null, 4));
		},

		/**
		 * Clear previous configuration of wakeup (background open for sync) behavior for Plugin
		 * from the Local Storage
		 *
		 * @private
		 */
		_clearWakeupData: function () {
			localStorage.removeItem('pluginWakeupCount');
			localStorage.removeItem('pluginWakeupMaxCount');
			localStorage.removeItem('pluginWakeupDontRespondOn');

			this._log(window.location.host + ' CLEAR WAKEUP DATA FROM LOCAL STORAGE');
		},

		initChangeOfWakeup: function (element) {

			function onWakeupChange(elem) {
				var isChecked = $(elem).is(':checked');

				if (isChecked) {
					$(element).find('#repeat_count').prop('disabled', false);
					$(element).find('#dont_respond').prop('disabled', false);

					$(element).find('#wakeup_row').removeClass('wakeup-form-row--disabled');

					onDontRespondChange($(element).find('#dont_respond'));
				} else {
					$(element).find('#repeat_count').prop('disabled', true);
					$(element).find('#dont_respond').prop('disabled', true);
					$(element).find('#dont_respond_on').prop('disabled', true);

					$(element).find('#wakeup_row').addClass('wakeup-form-row--disabled');
					$(element).find('#dont_respond_row').addClass('wakeup-form-row--disabled');
				}
			}

			function onDontRespondChange(elem) {
				var isChecked = $(elem).is(':checked');

				if (isChecked) {
					$(element).find('#dont_respond_on').prop('disabled', false);
					$(element).find('#dont_respond_row').removeClass('wakeup-form-row--disabled');
				} else {
					$(element).find('#dont_respond_on').prop('disabled', true);
					$(element).find('#dont_respond_row').addClass('wakeup-form-row--disabled');
				}
			}

			$(element).find('#wakeup').change(function (e) {
				onWakeupChange(e.target);
			});

			$(element).find('#dont_respond').change(function (e) {
				onDontRespondChange(e.target);
			});

			onWakeupChange($(element).find('#wakeup'));
		},

		initChangeOfDataItems: function () {
			//set checkboxes from local storage
			if (localStorage.getItem('dataItems')) {
				$('.data-items').attr('checked', true);
				$('.data-items-holder').show();

				var dataItems = JSON.parse(localStorage.getItem('dataItems'));

				$('.data-items-holder input').each(function () {
					if (dataItems.indexOf(this.value) != -1) {
						$(this).attr('checked', true);
					}
				});
			}

			//init handlers
			$('.data-items').on('change', function (e) {
				$('.data-items-holder').toggle();
			});
		},
		/**
		 * Initialization function
		 */
		init: function () {
			if (navigator.serviceWorker) {
				this._log(window.location.host + ' Service Worker is supported');
				navigator.serviceWorker.register('enroute-service-worker.js').then(function (registration) {
					this._log(window.location.host + ' Service Worker is registered with scope: ' + registration.scope);
					registration.addEventListener('updatefound', function () {
						this._log(window.location.host + ' Service Worker update is found');
						var newServiceWorker = registration.installing;
						newServiceWorker.addEventListener('statechange', function () {
							switch (newServiceWorker.state) {
								case "installed":
									this._log(window.location.host + ' New Service Worker is installed');
									break;
							}
						}.bind(this));
					}.bind(this));
					navigator.serviceWorker.addEventListener('controllerchange', function () {
						this.notifyAboutNewVersion();
					}.bind(this));
					this.startApplication();
				}.bind(this), function (err) {
					this._log(window.location.host + ' Service Worker registration failed: ' + err);
					this.startApplication();
				}.bind(this));
				return;
			} else {
				this._log(window.location.host + ' Service Worker is not supported');
			}
			this.startApplication();
		},

		startApplication: function () {

			//$("#anotherActivityDiv").hide();
			$("#veiwGlobalNotes").hide();
			//Begin CHG0059173
			$("#veiwServiceNotes").hide();
			//End CHG0059173
			this._log(window.location.host + ' PLUGIN HAS BEEN STARTED');

			$('.back_method_select').on('change', function () {
				if ($('.back_method_select').val() == 'activity_by_id') {
					$('.back_activity_id').show();
				} else {
					$('.back_activity_id').val('').hide();
				}
			});

			$('.json_local_storage_toggle').on('click', function () {
				$('.json__local-storage').toggle();
			});

			$('.json_request_toggle').on('click', function () {
				$('.column-item--request').toggle();
			});

			$('.json_response_toggle').on('click', function () {
				$('.column-item--response').toggle();
			}.bind(this));


			window.addEventListener("message", this._getPostMessageData.bind(this), false);

			var jsonToSend = {
				apiVersion: 1,
				method: 'ready',
				sendInitData: true
			};

			//parse data items
			//var dataItems = JSON.parse(localStorage.getItem('dataItems'));
			var dataItems = ["resource", "scheduledActivities", "nonScheduledActivities", "customerInventories"];
			if (dataItems) {
				$.extend(jsonToSend, { dataItems: dataItems });
			}

			this._sendPostMessageData(jsonToSend);
		},
		notifyAboutNewVersion: function () {
			this._log(window.location.host + ' New Service Worker is activated. Page refresh is needed');
			var footer = document.querySelector('.footer');
			var versionNotificationElement = document.createElement('div');
			versionNotificationElement.className = 'new-version-notification';
			versionNotificationElement.innerHTML = 'New version is detected. Please reopen the page';
			footer.appendChild(versionNotificationElement);

		}
	});

	window.OfscPlugin.getVersion = function () {
		return resourcesVersion;
	};

})(jQuery);
