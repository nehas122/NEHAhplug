"use strict";

(function($) {
    window.OfscPlugin = function(debugMode) {
        this.debugMode = debugMode || false;
    };
    
    var serverURL = window.location.origin;
    var company = '';
    var clientId = '';
    var clientSecret = '';
    var authorizationB64 = '';
	var activityJSONData;
    var hostName = window.location.hostname;
    

    $.extend(window.OfscPlugin.prototype, {
        /**
         * Dictionary of enums
         */
        dictionary: {
            astatus: {
                pending: {
                    label: 'pending',
                    translation: 'Pending',
                    outs: ['started', 'cancelled', 'suspended'],
                    color: '#FFDE00'
                },
                started: {
                    label: 'started',
                    translation: 'Started',
                    outs: ['complete', 'suspended', 'notdone', 'cancelled'],
                    color: '#A2DE61'
                },
                complete: {
                    label: 'complete',
                    translation: 'Completed',
                    outs: [],
                    color: '#79B6EB'
                },
                suspended: {
                    label: 'suspended',
                    translation: 'Suspended',
                    outs: [],
                    color: '#9FF'
                },
                notdone: {
                    label: 'notdone',
                    translation: 'Not done',
                    outs: [],
                    color: '#60CECE'
                },
                cancelled: {
                    label: 'cancelled',
                    translation: 'Cancelled',
                    outs: [],
                    color: '#80FF80'
                }
            },
            invpool: {
                customer: {
                    label: 'customer',
                    translation: 'Customer',
                    outs: ['deinstall'],
                    color: '#04D330'
                },
                install: {
                    label: 'install',
                    translation: 'Installed',
                    outs: ['provider'],
                    color: '#00A6F0'
                },
                deinstall: {
                    label: 'deinstall',
                    translation: 'Deinstalled',
                    outs: ['customer'],
                    color: '#00F8E8'
                },
                provider: {
                    label: 'provider',
                    translation: 'Resource',
                    outs: ['install'],
                    color: '#FFE43B'
                }
            }
        },

        mandatoryActionProperties: {},

        /**
         * Which field shouldn't be editable
         *
         * format:
         *
         * parent: {
         *     key: true|false
         * }
         *
         */
        renderReadOnlyFieldsByParent: {
            data: {
                apiVersion: true,
                method: true,
                entity: true
            },
            resource: {
                pid: true,
                pname: true,
                gender: true
            }
        },

        /**
         * Check for string is valid JSON
         *
         * @param {*} str - String that should be validated
         *
         * @returns {boolean}
         *
         * @private
         */
        _isJson: function(str) {
            try {
                JSON.parse(str);
            } catch (e) {
                return false;
            }
            return true;
        },

        /**
         * Return origin of URL (protocol + domain)
         *
         * @param {String} url
         *
         * @returns {String}
         *
         * @private
         */
        _getOrigin: function(url) {
            if (url != '') {
                if (url.indexOf("://") > -1) {
                    return 'https://' + url.split('/')[2];
                } else {
                    return 'https://' + url.split('/')[0];
                }
            }

            return '';
        },

        /**
         * Return domain of URL
         *
         * @param {String} url
         *
         * @returns {String}
         *
         * @private
         */
        _getDomain: function(url) {
            if (url != '') {
                if (url.indexOf("://") > -1) {
                    return url.split('/')[2];
                } else {
                    return url.split('/')[0];
                }
            }

            return '';
        },
		//added for MPF Phase 4 - CHG0069304
		_getDomainURL: function() {
			//return document.referrer.match(/\:\/\/([^\/]+)\.etadirect\.com\//)[1];
			//Reg Ex modified to handle both etadirect.com and fs.ocs.oraclecloud.com URLs
			return document.referrer.match(/\:\/\/([^\/]+)\.(?:etadirect.com|fs.ocs.oraclecloud.com)/)[1];
		},
        /**
         * Sends postMessage to document.referrer
         *
         * @param {Object} data - Data that will be sent
         *
         * @private
         */
        _sendPostMessageData: function(data) {
            var originUrl = document.referrer || (document.location.ancestorOrigins && document.location.ancestorOrigins[0]) || '';

            if (originUrl) {
                this._log(window.location.host + ' -> ' + data.method + ' ' + this._getDomain(originUrl), JSON.stringify(data, null, 4));

                parent.postMessage(data, this._getOrigin(originUrl));
            } else {
                this._log(window.location.host + ' -> ' + data.method + ' ERROR. UNABLE TO GET REFERRER');
            }
        },

        /**
         * Handles during receiving postMessage
         *
         * @param {MessageEvent} event - Javascript event
         *
         * @private
         */
        _getPostMessageData: function(event) {

            if (typeof event.data === 'undefined') {
                this._log(window.location.host + ' <- NO DATA ' + this._getDomain(event.origin), null, null, true);

                return false;
            }

            if (!this._isJson(event.data)) {
                this._log(window.location.host + ' <- NOT JSON ' + this._getDomain(event.origin), null, null, true);

                return false;
            }

            var data = JSON.parse(event.data);

            if (!data.method) {
                this._log(window.location.host + ' <- NO METHOD ' + this._getDomain(event.origin), null, null, true);

                return false;
            }

            this._log(window.location.host + ' <- ' + data.method + ' ' + this._getDomain(event.origin), JSON.stringify(data, null, 4));

            switch (data.method) {
                case 'init':
                    this.pluginInitEnd(data);
                    break;

                case 'open':
                    this.pluginOpen(data);
                    break;

                case 'wakeup':
                    this.pluginWakeup(data);
                    break;

                case 'error':
                    data.errors = data.errors || {
                        error: 'Unknown error'
                    };
                    this._showError(data.errors);
                    break;

                default:
                    this._log(window.location.host + ' <- UNKNOWN METHOD: ' + data.method + ' ' + this._getDomain(event.origin), null, null, true);
                    break;
            }
        },

        /**
         * Show alert with error
         *
         * @param {Object} errorData - Object with errors
         *
         * @private
         */
        _showError: function(errorData) {
            alert(JSON.stringify(errorData, null, 4));
        },

        /**
         * Logs to console
         *
         * @param {String} title - Message that will be log
         * @param {String} [data] - Formatted data that will be collapsed
         * @param {String} [color] - Color in Hex format
         * @param {Boolean} [warning] - Is it warning message?
         *
         * @private
         */
        _log: function(title, data, color, warning) {
            if (!this.debugMode) {
                return;
            }
            if (!color) {
                color = '#0066FF';
            }
            if (!!data) {
                console.groupCollapsed('%c[Plugin API] ' + title, 'color: ' + color + '; ' + (!!warning ? 'font-weight: bold;' : 'font-weight: normal;'));
                console.log('[Plugin API] ' + data);
                console.groupEnd();
            } else {
                console.log('%c[Plugin API] ' + title, 'color: ' + color + '; ' + (!!warning ? 'font-weight: bold;' : ''));
            }
        },

        /**
         * Business login on plugin init
         */
        saveToLocalStorage: function(data) {
            this._log(window.location.host + ' INIT. SET DATA TO LOCAL STORAGE', JSON.stringify(data, null, 4));

            if (data.attributeDescription) {
                localStorage.setItem('pluginInitData', JSON.stringify(data.attributeDescription));
            }
        },

        /**
         * Business login on plugin init end
         *
         * @param {Object} data - JSON object that contain data from OFSC
         */
        pluginInitEnd: function(data) {
            this.saveToLocalStorage(data);

            var messageData = {
                apiVersion: 1,
                method: 'initEnd'
            };

            if (localStorage.getItem('pluginWakeupCount') < localStorage.getItem('pluginWakeupMaxCount')) {
                this._log(window.location.host + ' UNFINISHED WAKEUP DATA FOUND IN LOCAL STORAGE');

                messageData.wakeupNeeded = true;
            }

            this._sendPostMessageData(messageData);
        },

        /**
         * Business login on plugin open
         *
         * @param {Object} receivedData - JSON object that contain data from OFSC
         */
        pluginOpen: function(receivedData) {
        	//$.getConfigDataFromJson(); // Added for 19C upgrade to get the Connection details from config.json
			// Changes start for CHG0069304
        	var domainName = this._getDomainURL();
        	console.log("Domain Name - "+domainName);
        	var errorLogs = receivedData.activity.A_PLUGIN_ERROR_LOG;
        	
			// Changes end for CHG0069304
            // Base 64 encryption for REST API calls
            var headers = {
				'Authorization':
					'Basic ' + btoa(receivedData.securedData.clientId + "@" + domainName + ":" + receivedData.securedData.clientSecret)
			};
			$.ErrorUpdate = function(activityId,sErrorLogs,tErrorMsg) {
				 
				this._sendPostMessageData({
						"apiVersion": 1,
						"method": "update",
						"activity": {
							"A_PLUGIN_ERROR_LOG": sErrorLogs,
							"aid": activityId
						}
						
				});
			 }.bind(this);
            
			var dataItemsToProcess = [];
			if(localStorage.storageDataItems){
				dataItemsToProcess = localStorage.storageDataItems.split(',');	
			}
			var ultimateBind = this;
            var subInventoryName = receivedData.activity.A_SUBINVENTORY_NAME;
            var aSubInventory = receivedData.activity.A_SUBINVENTORY;
            var aExcessID = receivedData.activity.A_EXCESS_ID;
            var inventoryList = receivedData.inventoryList;
            var activityId = receivedData.activity.aid;
			var resourcePID = receivedData.resource.pid;
			
			if( subInventoryName != "" || typeof(subInventoryName) != undefined || subInventoryName != null)
			{
				$("#cpf_idSubinventoryName_inner_read_only").text(subInventoryName);
				$("#cpf_idSubinventoryName_inner").val(subInventoryName);
			}
		
	//modified for  INC1478326:sort parts in alphanumeric order
			var partsarray=[];
            $.each(inventoryList, function(key, invItem) {
                var bindVar = this;
                if (invItem.inv_aid == activityId) {
                    if (invItem.invpool == "customer" && invItem.invtype == "EXCESS")
					{
						partsarray.push(invItem.I_ITEM_NUMBER);
                    }
                }
            });

		    partsarray.sort(function(item1,item2){
		    	var part1=item1.toLowerCase();
		    	var part2=item2.toLowerCase();
		    	if(part1<part2)
		    	return -1
		    	if(part1>part2)
		    	return 1
		    	return 0});
			
			var rowCount = 0; var trackingNumber = "";
			
            for(var i=0;i<partsarray.length;i++) //added for  INC1478326:sort parts in alphanumeric order
            {
			
            var rowCount = 0; var trackingNumber = "";
            $.each(inventoryList, function(key, invItem) {
				if(partsarray[i] == invItem.I_ITEM_NUMBER) //added for  INC1478326:sort parts in alphanumeric order
            	{
                var bindVar = this;
                if (invItem.inv_aid == activityId) {
                    if (invItem.invpool == "customer" && invItem.invtype == "EXCESS") {
                        rowCount += 1;
						trackingNumber = invItem.I_TRACKING_NUMBER;
                        $("#displayInventoryPartsSectionMain").append('<div id="cpf_32-0" class="inventory_lifecycle-grid-row">\
								 <div class="inventory_lifecycle-left-cell wide-row cpf_32-0">\
									<div class="inventory_lifecycle-part-number cpf_32-0-0">' + invItem.I_ITEM_NUMBER+ '</div>\
									<div class="inventory_lifecycle-description cpf_32-0-1">' + invItem.I_ITEM_DESCRIPTION + '</div>\
								 </div>\
								 <div id="inventory_lifecycle-right-cell' + invItem.I_ITEM_NUMBER.replace(/[/]/g,"") + '" class="inventory_lifecycle-right-cell">\
									<div class="inline-block-cell cpf_32-1-0">\
									   <div id="cpf_RejectReason_' + invItem.I_ITEM_NUMBER.replace(/[/]/g,"") + '" class="cp_field inline-field-text cp_error cp_hidden">\
										  <div class="cp_field_row">\
											 <div class="cp_field_label"><span class="cp_field_label_text">Reject Reason</span></div>\
											 <div class="cp_field_ismandatory">*</div>\
											 <div class="cp_field_value">\
												<div class="cp_field_value_inner_wrapper">\
												   <select id="cpf_RejectReason" class="cp_field_dropdown_component form-item">\
													  <option value=""></option>\
													  <option value="Lost">Lost</option>\
													  <option value="Used">Used</option>\
												   </select>\
												   <span id="cpf_RejectReason_inner_read_only" class="cp_aux_hide"></span>\
												</div>\
											 </div>\
										  </div>\
									   </div>\
									</div>\
									<div id="SplitSection" class="inline-block-cell cpf_32-1-1">\
									<input id="splitShipmentBtn" type="button" class="cp_plugin_button button cp_hidden" value="Split a shipment">\
									</div>\
									<div class="inline-block-cell cpf_32-1-2"><span class="inventory_lifecycle-current-quantity" id="inventory-current-quantity">0</span> of <span\ class="inventory_lifecycle-rquired-quantity" id="inventory_lifecycle_required_qty">' + invItem.quantity + '</span></div>\
								 </div>\
								 <div class="clear-row cpf_' + rowCount + '">\
									<div id="clear-row-inner-grid-' + invItem.I_ITEM_NUMBER.replace(/[/]/g,"") + '" class="cpf_grid_wrapper inner-grid">\
									   <div id="inner-grid-row-' + invItem.I_ITEM_NUMBER.replace(/[/]/g,"") + '" class="inner-grid-row">\
										  <div class="inventory_lifecycle-left-cell cpf_33-0">\
											 <div id="cpf_ARSLabel" class="cp_field inline-field-text wide-field">\
												<div class="cp_field_row">\
												   <div class="cp_field_label"><span class="cp_field_label_text">ARS Shipping label</span></div>\
												   <div class="cp_field_ismandatory"></div>\
												   <div class="cp_field_value">\
													  <div class="cp_field_value_inner_wrapper"><input id="cpf_ARSLabel_' + invItem.I_ITEM_NUMBER.replace(/[/]/g,"") + '" type="text" class="cp_field_text_component\ form-item" value=""><span id="cpf_ARSLabel_inner_read_only" class="cp_aux_hide">STANDARD</span></div>\
												   </div>\
												</div>\
											 </div>\
										  </div>\
										  <div class="inventory_lifecycle-right-cell cpf_33-1">\
										      <div class="inline-block-cell cpf_33-1-1">\
												<div id="cpf__unnamed_10" class="cp_field inline-field-text">\
												   <div class="cp_field_row">\
													  <div class="cp_field_label"><span class="cp_field_label_text">Quantity:</span></div>\
													  <div class="cp_field_ismandatory"></div>\
													  <div class="cp_field_value">\
														 <div class="cp_field_value_inner_wrapper">\
															<input id="cpf_button_decrease" type="button" class="cpf-spinner-button-decrease button" value="-">\
															<input id="cpf_entered_qty" type="text" class="cp_field_text_component cp_field_spinner_component form-item" value="0">\
															<input id="cpf_button_increase" type="button" class="cpf-spinner-button-increase button" value="+">\
															<span id="cpf__unnamed_10_inner_read_only" class="cp_aux_hide"></span><span class="cp_measure_unit" id=""> </span><span class="cp_min_max" id="cpf__unnamed_10_min_max"></span>\
															<div class="cp_error_label" id="cpf__unnamed_10_error"></div>\
														 </div>\
													  </div>\
												   </div>\
												</div>\
											 </div>\
										  </div>\
									   </div>\
									</div>\
								 </div>\
							  </div>');
                        
                        if (invItem.quantity > 1) {
                            $("#inventory_lifecycle-right-cell" + invItem.I_ITEM_NUMBER.replace(/[/]/g,"")).find('#splitShipmentBtn').removeClass("cp_hidden");
                        }
                        var splitBtnClickCount = 1;
                        $("#inventory_lifecycle-right-cell" + invItem.I_ITEM_NUMBER.replace(/[/]/g,"")).on('click', '#splitShipmentBtn', function() {
                            var totalQty = this.quantity; // get the quantity dynamically from the current item.
                            totalQty = parseInt(totalQty);
                            if (splitBtnClickCount < totalQty) {
                                splitBtnClickCount++;
                                $("#clear-row-inner-grid-" + this.I_ITEM_NUMBER.replace(/[/]/g,"")).append('<div id="inner-grid-row-' + this.I_ITEM_NUMBER.replace(/[/]/g,"") + '" class="inner-grid-row">\
							   <div class="inventory_lifecycle-left-cell cpf_2-0">\
								  <div id="cpf_ARSLabel" class="cp_field inline-field-text wide-field">\
									 <div class="cp_field_row">\
										<div class="cp_field_label"><span class="cp_field_label_text">ARS Shipping label</span></div>\
										<div class="cp_field_ismandatory"></div>\
										<div class="cp_field_value">\
										   <div class="cp_field_value_inner_wrapper"><input id="cpf_ARSLabel_' + this.I_ITEM_NUMBER.replace(/[/]/g,"") + '" type="text" class="cp_field_text_component form-item" value=""><span id="cpf_ARSLabel_inner_read_only" class="cp_aux_hide">SPLIT</span></div>\
										</div>\
									 </div>\
								  </div>\
							   </div>\
							   <div class="inventory_lifecycle-right-cell cpf_2-1">\
								  <div class="inline-block-cell cpf_2-1-0"><input id="removeBtn" type="button" class="cp_plugin_button button" value="Remove"> </div>\
								  <div class="inline-block-cell cpf_2-1-1">\
									 <div id="cpf__unnamed_52" class="cp_field inline-field-text">\
										<div class="cp_field_row">\
										   <div class="cp_field_label"><span class="cp_field_label_text">Quantity:</span></div>\
										   <div class="cp_field_ismandatory"></div>\
										   <div class="cp_field_value">\
											  <div class="cp_field_value_inner_wrapper">\
												 <input id="cpf_button_decrease" type="button" class="cpf-spinner-button-decrease button" value="-">\
												 <input id="cpf_entered_qty" type="text" class="cp_field_text_component cp_field_spinner_component form-item" value="0">\
												 <input id="cpf_button_increase" type="button" class="cpf-spinner-button-increase button" value="+">\
												 <span id="cpf__unnamed_52_inner_read_only" class="cp_aux_hide"></span>\
												 <span class="cp_measure_unit" id=""> </span><span class="cp_min_max" id="cpf__unnamed_52_min_max"></span>\
												 <div class="cp_error_label" id="cpf__unnamed_52_error"></div>\
											  </div>\
										   </div>\
										</div>\
									 </div>\
								  </div>\
							   </div>\
							</div>');
                            }
                            if (splitBtnClickCount == totalQty) {
                                $("#inventory_lifecycle-right-cell" + this.I_ITEM_NUMBER.replace(/[/]/g,"")).find('#splitShipmentBtn').addClass("cp_hidden");
                                return false;
                            }
                        }.bind(this));

                        $("#clear-row-inner-grid-" + invItem.I_ITEM_NUMBER.replace(/[/]/g,"")).on('click', '#removeBtn', function() {							
							var itemNumber = bindVar.I_ITEM_NUMBER;
                            $(this).parent().parent().parent().parent().parent().prev().find('#splitShipmentBtn').removeClass("cp_hidden");
                            $(this).parent().parent().parent().remove();
                            var removeSplitCount = splitBtnClickCount;
                            splitBtnClickCount = splitBtnClickCount - 1;
                            
							//update total selected of the maximum.	
								var totalEnteredQuantity = 0;		
							     $("div#inner-grid-row-" + itemNumber.replace(/[/]/g,"")).each(function() {
                                     totalEnteredQuantity += parseInt($(this).find("#cpf_entered_qty").val());
							     });
							     $("#inventory_lifecycle-right-cell" + itemNumber.replace(/[/]/g,"")).find('#inventory-current-quantity').text(totalEnteredQuantity);
                        });
                        
                        //Increase and decrease qty.
                        
                        $("#clear-row-inner-grid-" + invItem.I_ITEM_NUMBER.replace(/[/]/g,"")).on('click', '#cpf_button_decrease', function() {
								var itemNumber = bindVar.I_ITEM_NUMBER;
                                var cpfEnteredQty = $(this).next();
                                var prevValue = cpfEnteredQty.val();
                            
								if(isNaN(prevValue) || prevValue.indexOf(' ') >=0 || prevValue === "") {   
									cpfEnteredQty.val(0);
									//alert('Only Numeric Values Are Allowed');
								}else{
									cpfEnteredQty.val(parseInt(prevValue));
								}
								
								var incCount = parseInt(cpfEnteredQty.val());
                                if (incCount <= 0) {
                                    cpfEnteredQty.val(0);
                                } else {
                                    incCount -= 1;
                                    cpfEnteredQty.val(incCount);
                                }
                            
                                 var totalEnteredQuantity = 0;		
                                 $("div#inner-grid-row-" + itemNumber.replace(/[/]/g,"")).each(function() {								 
                                      totalEnteredQuantity += parseInt($(this).find("#cpf_entered_qty").val());
                                 });
                            
							 //Reduce the totalEnteredQuantity in the EnteredQty of totalQty section. 
							 $("#inventory_lifecycle-right-cell" + itemNumber.replace(/[/]/g,"")).find('#inventory-current-quantity').text(totalEnteredQuantity);		 
                        });
                        
                        $("#clear-row-inner-grid-" + invItem.I_ITEM_NUMBER.replace(/[/]/g,"")).on('click', '#cpf_button_increase', function() {
                            var totalQty = bindVar.quantity;
							var itemNumber = bindVar.I_ITEM_NUMBER;
                            var cpfEnteredQty = $(this).prev();
                            var prevValue = cpfEnteredQty.val();
                            var totalEnteredQuantity = 0;
							
							
							if(isNaN(prevValue) || prevValue.indexOf(' ') >=0 || prevValue === "") {   
								cpfEnteredQty.val(0);
								//alert('Only Numeric Values Are Allowed');
							}else{
								cpfEnteredQty.val(parseInt(prevValue));
							}
							var incCount = parseInt(cpfEnteredQty.val());						
							
							if (incCount < 0) {
								cpfEnteredQty.val(0);
							} else {
								incCount += 1;
								cpfEnteredQty.val(incCount);
							}
							$("div#inner-grid-row-" + itemNumber.replace(/[/]/g,"")).each(function() {	 
								  totalEnteredQuantity += parseInt($(this).find("#cpf_entered_qty").val());
							});
							 
							 if(totalEnteredQuantity <= totalQty){
								 //do nothing.
								 
							 }else{
								 
								 cpfEnteredQty.val(prevValue);
							 }						
                           
							//update total selected of the maximum.	
								var totalEnteredQuantity = 0;		
							     $("div#inner-grid-row-" + itemNumber.replace(/[/]/g,"")).each(function() {
								 totalEnteredQuantity += parseInt($(this).find("#cpf_entered_qty").val());
							 });
							 $("#inventory_lifecycle-right-cell" + itemNumber.replace(/[/]/g,"")).find('#inventory-current-quantity').text(totalEnteredQuantity);
                        });
						
						$("#clear-row-inner-grid-" + invItem.I_ITEM_NUMBER.replace(/[/]/g,"")).on("change paste keyup","#cpf_entered_qty", function() {
							
							        var totalLength = $(this).val();
									if(totalLength.length > 20)
									{
										$(this).val(0);
									}
									
									if(isNaN(totalLength) || totalLength.indexOf(' ') >=0 || totalLength === "") {   
										$(this).val(0);
										//alert('Only Numeric Values Are Allowed');
									}else{
										$(this).val(parseInt(totalLength));
									}
									
									var currentQty = parseInt($(this).val());
									var totalQty = bindVar.quantity;
									var itemNumber = bindVar.I_ITEM_NUMBER;
                            
									var totalEnteredQuantity = 0;
                            
									 $("div#inner-grid-row-" + itemNumber.replace(/[/]/g,"")).each(function() {			 
										  totalEnteredQuantity += parseInt($(this).find("#cpf_entered_qty").val());
									 });
                            
									 var maxValcanbeEntered = totalQty - (totalEnteredQuantity-currentQty);		 
									 if(currentQty <= maxValcanbeEntered)
                                         {
                                             $(this).val(currentQty);
                                         }else{
                                             $(this).val(maxValcanbeEntered);
                                         }
                            
									 var totalEnteredQuantity = 0;		
									 $("div#inner-grid-row-" + itemNumber.replace(/[/]/g,"")).each(function() {
										  totalEnteredQuantity += parseInt($(this).find("#cpf_entered_qty").val());
									 });
                            $("#inventory_lifecycle-right-cell" +itemNumber.replace(/[/]/g,"")).find('#inventory-current-quantity').text(totalEnteredQuantity);
                        });
                    }
                
				}
			}
			}
			);
			}
            // End Modification for INC1478326
            
			//set the ship to to the Tracking Number.
			if( trackingNumber != "" || typeof(trackingNumber) != undefined || trackingNumber != null)
			{
			   $("#cpf_trackingNumber").text(trackingNumber);
			}
			
            //set the found parts count
            $("#parts_count").text(rowCount);
	//Submit 
            $('#submitBtn').click(function() {
				$.ajax({
						url : window.location.href,
						timeout : 2000,	
						cache: false,				
						type : 'GET', 
						tryCount : 0,
						retryLimit : 3,
						success: function(response) 
						{
							console.log(' online configuration');
							SubmitExcessParts();
						}.bind(this),
						error : function(xhr, textStatus, errorThrown )
						{
							if (textStatus == 'timeout') {
								this.tryCount++;
								if (this.tryCount <= this.retryLimit) {
									//try again
									$.ajax(this);
									return false;
									}            
									storeOffline();
							}
							if (xhr.status == 500) {
								storeOffline();
							} 
							else 
							{
								storeOffline();
							}
						}
						});
			function storeOffline()
			{
				alert ('Excess Parts Submission is not available while in an Offline condition. Check again when network connectivity is restored.');
			    return false;
			}
			function SubmitExcessParts(){
				 var inventoryListJSONData = {};
                // inventoryListJSONData contains json of each inventory item.
                var actionsArr = [];
				 var createInventoriesArr = []; 
				  var itemNumberCarStockList = {};

                $.each(inventoryList, function(key, invItem) {
                    
						//take the car stock item as well.
						if (invItem.invpool == "provider" && invItem.invtype == "CAR_STOCK") {
							
							       var carstockItemNum = invItem.I_ITEM_NUMBER; 
                                	$.extend(itemNumberCarStockList, {
															[carstockItemNum]: {I_ITEM_NUMBER :carstockItemNum,
																				I_ITEM_DESCRIPTION: invItem.I_ITEM_DESCRIPTION,
																				I_ITEM_PRICE: invItem.I_PRICE,
																				I_SUBINVENTORY_NAME : invItem.I_SUBINVENTORY_NAME,
																				I_SUBINVENTORY: invItem.I_SUBINVENTORY,
																				inv_aid: invItem.inv_aid,
																				invtype: invItem.invtype,
																				invpool: invItem.invpool,
																				invid: invItem.invid,
																				inv_pid: invItem.inv_pid,
																				quantity: invItem.quantity
											}
										});
                        }
                });
                var isAllQtyNonZero = false; var iSARSLabelIncorrect =  false; var isARSValidationFailed = false;  var iTrackingNum = ""; var rejectReasonNotFilled = false;
				var selectedRejectReason =""; var enteredQtyArray =[]; var skipValidation = false; var islblEnteredQtyZero = false; var splitRowWithEmptyParams = false;
				var isARSDuplicateValidationFailed = false;	// Added for incident INC1580514 
				
				 $.each(inventoryList, function(key, invItem) {
					 
						var splitpartarray = [];	// Added for incident INC1580514
						
					 	if(islblEnteredQtyZero){
							return false;
						}
                     if (invItem.inv_aid == activityId) {
                        if (invItem.invpool == "customer" && invItem.invtype == "EXCESS") {
                            var itemNum = invItem.I_ITEM_NUMBER;
							var itemDesc = invItem.I_ITEM_DESCRIPTION;	
                            var itemQty	= invItem.quantity;						
							var totalEnteredQuantity = 0;									
							 $("div#inner-grid-row-" + itemNum.replace(/[/]/g,"")).each(function() {
								  totalEnteredQuantity += parseInt($(this).find("#cpf_entered_qty").val());
							 });
							 var differenceQty = parseInt(itemQty) - parseInt(totalEnteredQuantity);
						/*	if(differenceQty > 0){
								
								// if difference in qty is more than 1. Make unrecoverableReason required.
								    selectedRejectReason = $('#cpf_RejectReason_'+invItem.I_ITEM_NUMBER).find('#cpf_RejectReason').val();
									if(selectedRejectReason  == "")
									{
										//proceedWithRest = false;
										rejectReasonNotFilled = true; //alert("Please select the unrecoverable reason.");
										$('#cpf_RejectReason_'+invItem.I_ITEM_NUMBER).removeClass("cp_hidden");
										isAllQtyNonZero = true;
									
										
									}
								
							} */     // commented for INC1473395 - Excess parts reject reason issue.
                            $("div#inner-grid-row-" + itemNum.replace(/[/]/g,"")).each(function() {
                                var cpfARSLabel = $(this).find("#cpf_ARSLabel_" + itemNum.replace(/[/]/g,"")).val();
								var iMode = $(this).find("#cpf_ARSLabel_inner_read_only").text();
								var enteredQuantity = $(this).find("#cpf_entered_qty").val();
								//enteredQtyArray.push(enteredQuantity);
								
								if(iMode == "SPLIT" && enteredQuantity == 0 && cpfARSLabel == "")
								{
									 //Trigger remove button from code.
									
                                    $('#clear-row-inner-grid-' + itemNum.replace(/[/]/g,"")).find("#removeBtn").trigger('click');
									
								}else{
									
									enteredQtyArray.push(enteredQuantity);
									
								}
								
								if(enteredQuantity >0 && cpfARSLabel == ""){
									$(this).find("#cpf_ARSLabel").addClass("cp_error");
									iSARSLabelIncorrect = true; 
									isAllQtyNonZero = true;
									skipValidation = false;
									islblEnteredQtyZero =  false;
								}
								
								if(enteredQuantity == 0 && cpfARSLabel != ""){
									$(this).find("#cpf_ARSLabel").addClass("cp_error");
									islblEnteredQtyZero = true;
									skipValidation = false;
									return;
								}
								
								if(enteredQuantity == 0 && cpfARSLabel == ""){
								
									skipValidation = true;
									islblEnteredQtyZero = false;
								}else{
									skipValidation = false;
									islblEnteredQtyZero = false;
								}
								if(cpfARSLabel != "" || skipValidation )//&& enteredQuantity > 0)  // removed quantity check before ARSLabel validation.
								{
									
                                  //if (cpfARSLabel.length >= 18 || skipValidation) { // Commented for INC1647515 - Validation for ARS Label to 18 Characters
                                   if (cpfARSLabel.length == 18 || skipValidation) {   // Added for INC1647515 - Validation for ARS Label to 18 Characters
									//cpfARSLabel validation.
                                     iTrackingNum = invItem.I_TRACKING_NUMBER;
                                     cpfARSLabel= cpfARSLabel.toUpperCase(); // uppercase change done for INC1537268
                                    if ((cpfARSLabel.slice(0, 8) == iTrackingNum)||skipValidation) {
                                        var newInventoryKey = itemNum + " " + cpfARSLabel;
                                        var invID = invItem.invid;
                                        
											// Update the carStock quantity	
										  if (itemNumberCarStockList[itemNum]) {
											var carStockITEM = itemNumberCarStockList[itemNum];											
											  if(aSubInventory == carStockITEM.I_SUBINVENTORY){
												  //updateCarStockItem = true;
												  var carStockInvID = carStockITEM.invid;
												  var totalCarStockQty = carStockITEM.quantity;
												  var newCarstockQty = parseInt(totalCarStockQty) - parseInt(totalEnteredQuantity);
												  if(isNaN(newCarstockQty)){
													  newCarstockQty = "";
												  }
													$.extend(inventoryListJSONData, {
															[carStockInvID]: {														
																quantity: newCarstockQty+""
															}
													});
                                              }
										}
                                        if(selectedRejectReason == ""){
													selectedRejectReason = null;
										}
										if(iMode == 'STANDARD'){
								// Begin modification for incident INC1580514	
										
										var arspresent = $.inArray(itemNum + cpfARSLabel,splitpartarray);

										if(arspresent == -1)
										{
											splitpartarray.push(itemNum + cpfARSLabel);
										}
											
								// End modification for incident INC1580514	
											
											
											//STANDARD
											   $.extend(inventoryListJSONData, {
													[invID]: {
														I_ARS_SHIPPING_LABEL: cpfARSLabel,
														quantity: enteredQuantity+"",
														I_MODE: "STANDARD",
														I_INVENTORY_KEY: newInventoryKey,
														I_REJECT_REASON : selectedRejectReason,
														I_RETURN_QUANTITY : enteredQuantity+"",
														I_RETURNED_QUANTITY : enteredQuantity+""
													}
												});
										}else{
								// Begin modification for incident INC1580514	
										
										var arspresent = $.inArray(itemNum + cpfARSLabel,splitpartarray);

										if(arspresent == -1)
										{
											splitpartarray.push(itemNum + cpfARSLabel);
											
								// End modification for incident INC1580514	
											//SPLIT 
											if(!(iMode == "SPLIT" && enteredQuantity == 0 && cpfARSLabel == ""))
								            {
												
												
												  createInventoriesArr.push({							
																			"status": "customer",
																			"inventoryType": "EXCESS",
																			"activityId": parseInt(activityId),
																			//"activityId": activityId.toString(),	// Added .toString() for aid issue INC1580514
																			"entity": "inventory",
																			"quantity":  parseInt(enteredQuantity),
																			"I_ITEM_NUMBER": itemNum,							
																			"I_INVENTORY_KEY": newInventoryKey,
																			"I_ITEM_DESCRIPTION": itemDesc,
																			"I_EXCESS_ID": aExcessID,
																			"I_TRACKING_NUMBER": iTrackingNum,
																			"I_SHIP_TO_LOCATION": iTrackingNum,
																			"I_RETURN_QUANTITY":enteredQuantity,
																			"I_RETURNED_QUANTITY":enteredQuantity,
																			"I_MODE": "SPLIT",
																			"I_ARS_SHIPPING_LABEL": cpfARSLabel,
																			"I_REJECT_REASON":selectedRejectReason
																		});
															/* actionsArr.push({
																			"action": "create",														
																			"inv_aid": activityId,
																			"invtype": "EXCESS",
																			"quantity": enteredQuantity+'',
																			"invpool": "customer",
																			"entity": "inventory",
																			"properties": {
																			"I_ITEM_NUMBER": itemNum,
																			"I_EXCESS_ID": aExcessID,
																			"I_INVENTORY_KEY": newInventoryKey,
																			"I_MODE": "SPLIT",
																			"I_ARS_SHIPPING_LABEL": cpfARSLabel,
																			"I_ITEM_DESCRIPTION": itemDesc,
																			"I_TRACKING_NUMBER": iTrackingNum,
																			"I_REJECT_REASON" : selectedRejectReason,
																			"I_RETURNED_QUANTITY" : enteredQuantity+'',
																			"I_SHIP_TO_LOCATION"	:iTrackingNum															  
																			}			
																			});*/

											}
								// Begin modification for incident INC1580514			
										}	
										else
										{

											$(this).find("#cpf_ARSLabel").addClass("cp_error");
											isARSDuplicateValidationFailed = true;
                                       		 return;
										}
								// End modification for incident INC1580514	
                                        }
                                    } else {
                                        // add red color to the label:
                                        $(this).find("#cpf_ARSLabel").addClass("cp_error");
										isARSValidationFailed = true;
                                        return;
                                    }
                                } else {
                                    // add red color to the label:                                   
                                    $(this).find("#cpf_ARSLabel").addClass("cp_error");
									iSARSLabelIncorrect = true; 
                                    }
								}
                            });
							
						
                        }
                    }
                }); // end of inventoryList loop
                
				if(iSARSLabelIncorrect){
					alert("Some of returned parts have  ARS Shipping label not equal to 18 characters");
					return false;
				}
		
				if(isARSValidationFailed){			
					alert("ARS label doesn\'t correspond with part\'s Return Tracking: "+iTrackingNum);
					return false;
				}
				// Begin modification for incident INC1580514	
				if(isARSDuplicateValidationFailed)
				{
					alert("ARS label duplicated for Split Line for the Return Tracking: "+iTrackingNum);
					return false;
				}
				// End modification for incident INC1580514	
				if(rejectReasonNotFilled){
				   alert("Please select the reject reason.");
				   return false;
					
				}
				
				if(islblEnteredQtyZero){
				   alert("Please enter the quantity greater than zero or remove ARS Shipping label.");
				   return false;
				}
				
				console.log("inventoryListJSONData "+ JSON.stringify(inventoryListJSONData));
				//console.log("actionsArr "+ JSON.stringify(actionsArr));
				
			 /* var closeJsonToSend = {
									"apiVersion": 1,
									"method": "close",
									"backScreen": "default",
									"wakeupNeeded": false,
									"inventoryList": inventoryListJSONData,//"actions": actionsArr,
									"activity": {
											"astatus": "complete",
											"A_STATUS": "CM",
											"aid": activityId
										}
									};*/
				
				 var isEnteredQtyZeroPresent = $.inArray("0", enteredQtyArray);
				 
				 /////////////////
				 
				  $.processCreateInventoryMethod = function(createInventoriesArr) {
                    console.log("Create Inventory call started.");
					
                    //var createinventoryRestServiceURL = serverURL + "/RestTrigger/rest/activity/inventory/create";
					var createinventoryRestServiceURL = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/inventories/"
					console.log("Create Inventory call createinventoryRestServiceURL -" + createinventoryRestServiceURL);
					
					//added for logging mechanism
					var createErrorURL = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/activities/"+ activityId+"/A_ERROR_LOGS";
					console.log("update error logs property createErrorURL: "+createErrorURL);
					
                    var createInventoryPayload = {
                        "inventories": createInventoriesArr,
						};

                    console.log("Create Inventory createInventoryPayload -" + JSON.stringify(createInventoryPayload));
					for(var i=0;i<createInventoriesArr.length;i++)
					{						
							$.ajax({
								dataType: "json",
								url: createinventoryRestServiceURL,
								data: JSON.stringify(createInventoryPayload.inventories[i]),
								processData: false,
								async: false,
								crossDomain: true,
								headers: headers,
								contentType: 'application/json; charset=utf-8',
								method: "POST",
								timeout: 15000,
								success: function(responseData) {
									console.log("Create Inventory webservice success response:" + JSON.stringify(responseData));
									$.processCloseMethodFnCallBck();
								}.bind(this),
								
								error: function(errorData) {
								console.log("Create inventory webservice error:" + JSON.stringify(errorData));
								//CHnages done for MPF phase 4 Logging Mechanism
								var now = new Date(Date.now());
								var errorTime = now.getHours() + ":" + now.getMinutes() + ":" + now.getSeconds();
								var errorDetails = errorData.responseJSON;
								
								var eDetail = errorDetails.detail.replace(/(\r\n|\n|\r)/gm," ");
								var eStatus = errorDetails.status;
								if (errorLogs == null){
									errorLogs= "";
								}
								errorLogs = errorLogs+"||"+now.toString()+"|Plugin :Excess Parts "+"| URL:"+createinventoryRestServiceURL.toString()+"|Error Status:"+eStatus+"|Error Details:"+eDetail;
								console.log(errorLogs);
								$.extend(activityJSONData,{"A_PLUGIN_ERROR_LOG":errorLogs});
								var errorMessage = now.toString()+"|Plugin :Excess Parts "+"| URL:"+createinventoryRestServiceURL+"| Payload:"+createInventoryPayload+"|Error Details:"+JSON.stringify(errorData);
								console.log("Error Message:"+errorMessage);
								
								$.ErrorUpdate(activityId,errorLogs,errorMessage);
			
								
								
							}
							});
					}

                };
				
				$.processCloseMethodFnCallBck = function() {
					if(dataItemsToProcess.indexOf('resourceInventories') !== -1){
						dataItemsToProcess.splice(dataItemsToProcess.indexOf('resourceInventories'), 1);
					}
					localStorage.storageDataItems = dataItemsToProcess;

                    // close method.
                    var closeJsonToSend = {
                        "apiVersion": 1,
                        "method": "close",
                        "backScreen": "default",
                        "wakeupNeeded": false,
                        "inventoryList": inventoryListJSONData,                        
						"activity": {
									"astatus": "complete",
									"A_STATUS": "CM",
									"aid": activityId
									}
                    };

                
                    console.log("closeJsonToSend " + JSON.stringify(closeJsonToSend));
                    ultimateBind._sendPostMessageData(closeJsonToSend);

                };
				 ////////////////
				 
				 if (isEnteredQtyZeroPresent == -1) {
					 // zero qty not found. also it has passed all the other validations , so just submit.			 
				       
						 if (createInventoriesArr && createInventoriesArr.length > 0) {
                                $.processCreateInventoryMethod(createInventoriesArr);
                            } else {
                                $.processCloseMethodFnCallBck();
                            }
                          
				 }else{
					 //zero qty found.
					  if (confirm('Some of returned parts have quantity of 0. Continue?')) {	
						 if (createInventoriesArr && createInventoriesArr.length > 0) {
						        $.processCreateInventoryMethod(createInventoriesArr);
                            } else {
                                $.processCloseMethodFnCallBck();
                            }
                        } else {
                            // Do nothing
                        }					 
					 
				 }
			}
           }.bind(this));
            
            //VALIDATE BUTTON CLICK.
            $('#cpf_buttonExcessId').click(function() {
                //get the value of the excess ID:
                var vExcessID = $("#cpf_textExcessId_inner").val();
                if (vExcessID == "") {
                    alert("Some fields are filled incorrectly. \n \n Excess ID is not filled");
                    // add red color to the label:
                    $("#cpf_textExcessId").addClass("cp_error");
                    return;
                }
                if (aExcessID != vExcessID) {
                    alert("Some fields are filled incorrectly. \n  \n Incorrect Excess ID");
                    // add red color to the label:
                    $("#cpf_textExcessId").addClass("cp_error");
                    return;
                } else {
                    //remove error field.
                    $("#cpf_textExcessId").removeClass("cp_error");
                    //Hide validate Btn
                    $("#cpf_buttonExcessId").addClass("cp_hidden");
                    //show Submit Btn
                    $("#submitBtn").removeClass("cp_hidden");
                    //Display the Parts Block.
                    $("#displayPartsSection").removeClass("cp_hidden");
                }
            }.bind(this));
            this._clearWakeupData();
            if (localStorage.getItem('pluginInitData')) {
                this._log(window.location.host + ' OPEN. GET DATA FROM LOCAL STORAGE',
                          JSON.stringify(JSON.parse(localStorage.getItem('pluginInitData')), null, 4));
                $('.json__local-storage').text(JSON.stringify(JSON.parse(localStorage.getItem('pluginInitData')), null, 4));
            }
            this.initChangeOfWakeup(document);
            this.initChangeOfDataItems();
        },

        /**
         * Business login on plugin wakeup (background open for sync)
         *
         * @param {Object} receivedData - JSON object that contain data from OFSC
         */
        pluginWakeup: function(receivedData) {
            this._log(window.location.host + ' WAKEUP', JSON.stringify(receivedData, null, 4));

            var wakeupData = {
                pluginWakeupCount: +localStorage.getItem('pluginWakeupCount'),
                pluginWakeupMaxCount: +localStorage.getItem('pluginWakeupMaxCount'),
                pluginWakeupDontRespondOn: +localStorage.getItem('pluginWakeupDontRespondOn')
            };

            wakeupData.pluginWakeupCount = wakeupData.pluginWakeupCount + 1;

            localStorage.setItem('pluginWakeupCount', wakeupData.pluginWakeupCount);
            localStorage.setItem('pluginWakeupMaxCount', wakeupData.pluginWakeupMaxCount);
            localStorage.setItem('pluginWakeupDontRespondOn', wakeupData.pluginWakeupDontRespondOn);

            this._log(window.location.host + ' SAVE WAKEUP DATA TO LOCAL STORAGE', JSON.stringify(wakeupData, null, 4));

            if (wakeupData.pluginWakeupDontRespondOn == wakeupData.pluginWakeupCount) {
                this._log(window.location.host + ' EMULATE NOT RESPONDING PLUGIN');

                return;
            }

            if (wakeupData.pluginWakeupCount < wakeupData.pluginWakeupMaxCount) {
                setTimeout(function() {
                    this._log(window.location.host + ' SLEEP. RETRY NEEDED');

                    this._sendPostMessageData({
                        apiVersion: 1,
                        method: 'sleep',
                        wakeupNeeded: true
                    });
                }.bind(this), 2000);
            } else {
                setTimeout(function() {
                    this._log(window.location.host + ' SLEEP. NO RETRY');

                    this._sendPostMessageData({
                        apiVersion: 1,
                        method: 'sleep',
                        wakeupNeeded: false
                    });
                }.bind(this), 12000);
            }
        },

        /**
         * Save configuration of wakeup (background open for sync) behavior for Plugin
         * to Local Storage
         *
         * @private
         */
        _saveWakeupData: function() {
            var wakeupData = {
                pluginWakeupCount: 0,
                pluginWakeupMaxCount: 0,
                pluginWakeupDontRespondOn: 0
            };

            if ($('#wakeup').is(':checked')) {
                wakeupData.pluginWakeupMaxCount = parseInt($('#repeat_count').val());

                if ($('#dont_respond').is(':checked')) {
                    wakeupData.pluginWakeupDontRespondOn = parseInt($('#dont_respond_on').val());
                }
            }

            localStorage.setItem('pluginWakeupCount', wakeupData.pluginWakeupCount);
            localStorage.setItem('pluginWakeupMaxCount', wakeupData.pluginWakeupMaxCount);
            localStorage.setItem('pluginWakeupDontRespondOn', wakeupData.pluginWakeupDontRespondOn);

            this._log(window.location.host + ' SAVE WAKEUP DATA TO LOCAL STORAGE', JSON.stringify(wakeupData, null, 4));
        },

        /**
         * Clear previous configuration of wakeup (background open for sync) behavior for Plugin
         * from the Local Storage
         *
         * @private
         */
        _clearWakeupData: function() {
            localStorage.removeItem('pluginWakeupCount');
            localStorage.removeItem('pluginWakeupMaxCount');
            localStorage.removeItem('pluginWakeupDontRespondOn');

            this._log(window.location.host + ' CLEAR WAKEUP DATA FROM LOCAL STORAGE');
        },
        
        initChangeOfWakeup: function(element) {

            function onWakeupChange(elem) {
                var isChecked = $(elem).is(':checked');

                if (isChecked) {
                    $(element).find('#repeat_count').prop('disabled', false);
                    $(element).find('#dont_respond').prop('disabled', false);

                    $(element).find('#wakeup_row').removeClass('wakeup-form-row--disabled');

                    onDontRespondChange($(element).find('#dont_respond'));
                } else {
                    $(element).find('#repeat_count').prop('disabled', true);
                    $(element).find('#dont_respond').prop('disabled', true);
                    $(element).find('#dont_respond_on').prop('disabled', true);

                    $(element).find('#wakeup_row').addClass('wakeup-form-row--disabled');
                    $(element).find('#dont_respond_row').addClass('wakeup-form-row--disabled');
                }
            }

            function onDontRespondChange(elem) {
                var isChecked = $(elem).is(':checked');

                if (isChecked) {
                    $(element).find('#dont_respond_on').prop('disabled', false);
                    $(element).find('#dont_respond_row').removeClass('wakeup-form-row--disabled');
                } else {
                    $(element).find('#dont_respond_on').prop('disabled', true);
                    $(element).find('#dont_respond_row').addClass('wakeup-form-row--disabled');
                }
            }

            $(element).find('#wakeup').change(function(e) {
                onWakeupChange(e.target);
            });

            $(element).find('#dont_respond').change(function(e) {
                onDontRespondChange(e.target);
            });

            onWakeupChange($(element).find('#wakeup'));
        },

        initChangeOfDataItems: function() {
            //set checkboxes from local storage
            if (localStorage.getItem('dataItems')) {
                $('.data-items').attr('checked', true);
                $('.data-items-holder').show();

                var dataItems = JSON.parse(localStorage.getItem('dataItems'));

                $('.data-items-holder input').each(function() {
                    if (dataItems.indexOf(this.value) != -1) {
                        $(this).attr('checked', true);
                    }
                });
            }

            //init handlers
            $('.data-items').on('change', function(e) {
                $('.data-items-holder').toggle();
            });
        },

        initLocalStorageOption: function(localStorageKey) {
            if (localStorage.getItem(localStorageKey) === null) {
                localStorage.setItem(localStorageKey, 'true');
            }
        },
        
        /**
         * Initialization function
         */
        init: function() {
			
			if (navigator.serviceWorker) {
				this._log(window.location.host + ' Service Worker is supported');
				navigator.serviceWorker.register('excessParts-service-worker.js').then(function(registration) {
					this._log(window.location.host + ' Service Worker is registered with scope: ' + registration.scope);
					registration.addEventListener('updatefound', function() {
						this._log(window.location.host + ' Service Worker update is found');
						var newServiceWorker = registration.installing;
						newServiceWorker.addEventListener('statechange', function() {
							switch (newServiceWorker.state) {
								case "installed":
									this._log(window.location.host + ' New Service Worker is installed');
									break;
							}
						}.bind(this));
					}.bind(this));
					navigator.serviceWorker.addEventListener('controllerchange', function() {
						this.notifyAboutNewVersion();
					}.bind(this));
					this.startApplication();
				}.bind(this), function(err) {
					this._log(window.location.host + ' Service Worker registration failed: ' + err);
					this.startApplication();
				}.bind(this));
				return;
			} else {
				this._log(window.location.host + ' Service Worker is not supported');
			}
			this.startApplication();
		},
		startApplication: function() {	
			
            this._log(window.location.host + ' PLUGIN HAS BEEN STARTED');
            $('.back_method_select').on('change', function() {
                var selectValue = $('.back_method_select').val();
                if (
                    selectValue == 'activity_by_id' ||
                    selectValue == 'end_activity' ||
                    selectValue == 'cancel_activity' ||
                    selectValue == 'notdone_activity' ||
                    selectValue == 'start_activity' ||
                    selectValue == 'suspend_activity' ||
                    selectValue == 'delay_activity'
                ) {
                    $('.back_activity_id').show();
                } else {
                    $('.back_activity_id').val('').hide();
                }
            });

            $('.json_local_storage_toggle').on('click', function() {
                $('.json__local-storage').toggle();
            });

            $('.json_request_toggle').on('click', function() {
                $('.column-item--request').toggle();
            });

            $('.json_response_toggle').on('click', function() {
                $('.column-item--response').toggle();
            }.bind(this));


            window.addEventListener("message", this._getPostMessageData.bind(this), false);

            this.initLocalStorageOption('showHeader');
            this.initLocalStorageOption('backNavigationFlag');

            var jsonToSend = {
                apiVersion: 1,
                method: 'ready',
                sendInitData: true,
                showHeader: !!localStorage.getItem('showHeader'),
                enableBackButton: !!localStorage.getItem('backNavigationFlag')
            };

       
			  //parse data items
           // var dataItems = JSON.parse(localStorage.getItem('dataItems'));
			var dataItems = ['resource','resourceInventories','customerInventories'];

            if (dataItems) {
                $.extend(jsonToSend, {
                    dataItems: dataItems
                });
            }

            this._sendPostMessageData(jsonToSend);
        },
		notifyAboutNewVersion: function() {
			this._log(window.location.host + ' New Service Worker is activated. Page refresh is needed');
			var footer = document.querySelector('.footer');
			var versionNotificationElement = document.createElement('div');
			versionNotificationElement.className = 'new-version-notification';
			versionNotificationElement.innerHTML = 'New version is detected. Please reopen the page';
			footer.appendChild(versionNotificationElement);
		}
    });
	window.OfscPlugin.getVersion = function() {
		return resourcesVersion;
	};
})(jQuery);