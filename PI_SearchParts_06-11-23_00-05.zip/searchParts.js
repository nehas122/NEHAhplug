"use strict";

(function ($) {
	window.OfscPlugin = function (debugMode) {
		this.debugMode = debugMode || false;
	};

	// CHG0075659 - MPF Phase 5 - Declaring Global variables
	var partssearchcallID = "";
	var linkedcallID = "";
	var compatibleCallID = ""; //CHG0082493
	let compatibleObj = null ; //CHG0082493
	var partsContinueSearchCallId = "";
	var searchflag = 0;
	var searchArray = [];
	var multipleFieldsArray = [];
	var currItemNumber =0;

	$.extend(window.OfscPlugin.prototype, {
		/**
		 * Dictionary of enums
		 */
		dictionary: {
			astatus: {
				pending: {
					label: 'pending',
					translation: 'Pending',
					outs: ['started', 'cancelled', 'suspended'],
					color: '#FFDE00'
				},
				started: {
					label: 'started',
					translation: 'Started',
					outs: ['complete', 'suspended', 'notdone', 'cancelled'],
					color: '#A2DE61'
				},
				complete: {
					label: 'complete',
					translation: 'Completed',
					outs: [],
					color: '#79B6EB'
				},
				suspended: {
					label: 'suspended',
					translation: 'Suspended',
					outs: [],
					color: '#9FF'
				},
				notdone: {
					label: 'notdone',
					translation: 'Not done',
					outs: [],
					color: '#60CECE'
				},
				cancelled: {
					label: 'cancelled',
					translation: 'Cancelled',
					outs: [],
					color: '#80FF80'
				}
			},
			invpool: {
				customer: {
					label: 'customer',
					translation: 'Customer',
					outs: ['deinstall'],
					color: '#04D330'
				},
				install: {
					label: 'install',
					translation: 'Installed',
					outs: ['provider'],
					color: '#00A6F0'
				},
				deinstall: {
					label: 'deinstall',
					translation: 'Deinstalled',
					outs: ['customer'],
					color: '#00F8E8'
				},
				provider: {
					label: 'provider',
					translation: 'Resource',
					outs: ['install'],
					color: '#FFE43B'
				}
			}
		},

		mandatoryActionProperties: {},

		/**
		 * Which field shouldn't be editable
		 *
		 * format:
		 *
		 * parent: {
		 *     key: true|false
		 * }
		 *
		 */
		renderReadOnlyFieldsByParent: {
			data: {
				apiVersion: true,
				method: true,
				entity: true
			},
			resource: {
				pid: true,
				pname: true,
				gender: true
			}
		},

		/**
		 * Check for string is valid JSON
		 *
		 * @param {*} str - String that should be validated
		 *
		 * @returns {boolean}
		 *
		 * @private
		 */
		_isJson: function (str) {
			try {
				JSON.parse(str);
			} catch (e) {
				return false;
			}
			return true;
		},

		/**
		 * Return origin of URL (protocol + domain)
		 *
		 * @param {String} url
		 *
		 * @returns {String}
		 *
		 * @private
		 */
		_getOrigin: function (url) {
			if (url != '') {
				if (url.indexOf("://") > -1) {
					return 'https://' + url.split('/')[2];
				} else {
					return 'https://' + url.split('/')[0];
				}
			}

			return '';
		},

		/**
		 * Return domain of URL
		 *
		 * @param {String} url
		 *
		 * @returns {String}
		 *
		 * @private
		 */
		_getDomain: function (url) {
			if (url != '') {
				if (url.indexOf("://") > -1) {
					return url.split('/')[2];
				} else {
					return url.split('/')[0];
				}
			}

			return '';
		},

		// Phase5 - getdomainurl implement
		_getDomainURL: function () {

			return document.referrer.match(/\:\/\/([^\/]+)\.(?:etadirect.com|fs.ocs.oraclecloud.com)/)[1];
		},

		/**
		 * Sends postMessage to document.referrer
		 *
		 * @param {Object} data - Data th
		 at will be sent
		 *
		 * @private
		 */
		_sendPostMessageData: function (data) {
			var originUrl = document.referrer || (document.location.ancestorOrigins && document.location.ancestorOrigins[0]) || '';

			if (originUrl) {
				this._log(window.location.host + ' -> ' + data.method + ' ' + this._getDomain(originUrl), JSON.stringify(data, null, 4));

				parent.postMessage(JSON.stringify(data), this._getOrigin(originUrl));
			} else {
				this._log(window.location.host + ' -> ' + data.method + ' ERROR. UNABLE TO GET REFERRER');
			}
		},

		/**
		 * Handles during receiving postMessage
		 *
		 * @param {MessageEvent} event - Javascript event
		 *
		 * @private
		 */
		_getPostMessageData: function (event) {

			if (typeof event.data === 'undefined') {
				this._log(window.location.host + ' <- NO DATA ' + this._getDomain(event.origin), null, null, true);

				return false;
			}

			if (!this._isJson(event.data)) {
				this._log(window.location.host + ' <- NOT JSON ' + this._getDomain(event.origin), null, null, true);

				return false;
			}

			var data = JSON.parse(event.data);

			if (!data.method) {
				this._log(window.location.host + ' <- NO METHOD ' + this._getDomain(event.origin), null, null, true);

				return false;
			}

			this._log(window.location.host + ' <- ' + data.method + ' ' + this._getDomain(event.origin), JSON.stringify(data, null, 4));

			switch (data.method) {
				case 'init':
					this.pluginInitEnd(data);
					break;

				case 'open':
					this.pluginOpen(data);
					break;

				case 'wakeup':
					this.pluginWakeup(data);
					break;

				case 'error':
					data.errors = data.errors || {
						error: 'Unknown error'
					};
					this._showError(data.errors);
					break;
				// CHG0075659 - MPF Phase 5 - To use Call Procedure Plugin API
				case 'callProcedureResult':
					this.finishCallIdCallbacks(event.data);
					break;

				default:
					this._log(window.location.host + ' <- UNKNOWN METHOD: ' + data.method + ' ' + this._getDomain(event.origin), null, null, true);
					break;
			}
		},

		/**
		 * Show alert with error
		 *
		 * @param {Object} errorData - Object with errors
		 *
		 * @private
		 */
		_showError: function (errorData) {
			alert(JSON.stringify(errorData, null, 4));
		},

		/**
		 * Logs to console
		 *
		 * @param {String} title - Message that will be log
		 * @param {String} [data] - Formatted data that will be collapsed
		 * @param {String} [color] - Color in Hex format
		 * @param {Boolean} [warning] - Is it warning message?
		 *
		 * @private
		 */
		_log: function (title, data, color, warning) {
			if (!this.debugMode) {
				return;
			}
			if (!color) {
				color = '#0066FF';
			}
			if (!!data) {
				console.groupCollapsed('%c[Plugin API] ' + title, 'color: ' + color + '; ' + (!!warning ? 'font-weight: bold;' : 'font-weight: normal;'));
				console.log('[Plugin API] ' + data);
				console.groupEnd();
			} else {
				console.log('%c[Plugin API] ' + title, 'color: ' + color + '; ' + (!!warning ? 'font-weight: bold;' : ''));
			}
		},

		/**
		 * Business login on plugin init
		 */
		saveToLocalStorage: function (data) {
			this._log(window.location.host + ' INIT. SET DATA TO LOCAL STORAGE', JSON.stringify(data, null, 4));

			if (data.attributeDescription) {
				localStorage.setItem('pluginInitData', JSON.stringify(data.attributeDescription));
			}
		},

		/**
		 * Business login on plugin init end
		 *
		 * @param {Object} data - JSON object that contain data from OFSC
		 */
		pluginInitEnd: function (data) {
			this.saveToLocalStorage(data);

			var messageData = {
				apiVersion: 1,
				method: 'initEnd'
			};

			if (localStorage.getItem('pluginWakeupCount') < localStorage.getItem('pluginWakeupMaxCount')) {
				this._log(window.location.host + ' UNFINISHED WAKEUP DATA FOUND IN LOCAL STORAGE');

				messageData.wakeupNeeded = true;
			}

			this._sendPostMessageData(messageData);
		},

		/**
		 * Business login on plugin open
		 *
		 * @param {Object} receivedData - JSON object that contain data from OFSC
		 */
		pluginOpen: function (receivedData) {
			
			// CHG0075659 - MPF Phase 5 - Logging Mechanism
			var actId = receivedData.activity.aid;
			var errorLogs = receivedData.activity.A_PLUGIN_ERROR_LOG;
			$.ErrorUpdate = function (activityId, sErrorLogs) {

				this._sendPostMessageData({
					"apiVersion": 1,
					"method": "update",
					"activity": {
						"A_PLUGIN_ERROR_LOG": sErrorLogs,
						"aid": activityId
					}

				});
			}.bind(this);

			var searchFieldCount = 5;
			var domainName = this._getDomainURL();
			if (!$.trim($('#cpf_SerachRequestField').html()).length) {
				for (var i = 1; i <= searchFieldCount; i++) {
					var container = $('<div />').attr("id", "searchFieldRow" + i);
					container.addClass('cp_field_row');

					if (i != 1) {
						container.addClass('cp_hidden');
					}

					var searchField = $('<div/>').addClass('cp_field_value');
					searchField.append($('<input/>').attr({ "id": "searchKeyword" + i, "type": "search", "placeholder": "Search by keyword" }).addClass("cp_field_text_component form-item text-uppercase"));
					container.append(searchField);

					if (i != searchFieldCount) {
						var plusField = $('<div/>').addClass('cp_field_plus');
						plusField.append($('<input/>').attr({ "id": "plusBun", "type": "button", "value": "+", "data-next": i + 1 }).addClass("cp_plugin_button button add-inventory-search-button cl-fld-plus"));
						container.append(plusField);
					}

					$('#cpf_SerachRequestField').append(container);
				}
			}

			$('.cl-fld-plus').click(function () {
				var next = $(this).attr("data-next");
				$('#searchFieldRow' + next).removeClass('cp_hidden');
			});

			var TimeZoneMapping = {
				"19": "Alaska",
				"6": "Arizona",
				"4": "Central",
				"2": "Eastern",
				"15": "GMT",
				"17": "Hawaii (Adak)",
				"18": "Hawaii (Honolulu)",
				"5": "Mountain",
				"7": "Pacific"
			};
            var resourceTimeZone = receivedData.resource.time_zone;
            
			var atimeZone = TimeZoneMapping[resourceTimeZone];
			// Set the timezone to retreive the Date & time for Activate route & punch in 
			if ("Alaska" == atimeZone || "Arizona" == atimeZone || "Central" == atimeZone || "Eastern" == atimeZone || "Mountain" == atimeZone || "Pacific" == atimeZone) {
				resourceTimeZone = "US/" + atimeZone;
			}
			else if ("Hawaii (Adak)" == atimeZone) {
				resourceTimeZone = "America/Adak";
			}
			else if ("Hawaii (Honolulu)" == atimeZone) {
				resourceTimeZone = "Pacific/Honolulu";
			}
			// if the resource time zone is null, then assign to EST.
			if (resourceTimeZone == null || "" == resourceTimeZone || typeof (resourceTimeZone) == undefined) {
				resourceTimeZone = "EST";
			}
			// Current Date & Time of resource time zone
			var atodayDate;
			try {
				atodayDate = new Date(new Date().toLocaleString('en-US', { timeZone: resourceTimeZone }));
			}
			catch (err) {
				atodayDate = new Date();
			}
			var day = ("0" + atodayDate.getDate()).slice(-2);
			var month = ("0" + (atodayDate.getMonth() + 1)).slice(-2);
			
			var date_YYYY_MM_DD = atodayDate.getFullYear().toString() + "-" + month + "-" + day;
			var rid = receivedData.resource.external_id;
			var aDate = date_YYYY_MM_DD.concat("-"+rid);

			//local arrays to manipulate loca data
			var ciData = [];
			var riData = [];
			var iiData = [];
			var diData = [];
			var globalInstallItems = {};

			//localStorage data-items
			var dataItemsToProcess = [];
			if (localStorage.storageDataItems) {
				dataItemsToProcess = localStorage.storageDataItems.split(',');
			}

			//resourceInventories updation to localStorage
			if ((typeof localStorage.aDate === 'undefined' || aDate != localStorage.aDate) || (dataItemsToProcess.indexOf('resourceInventories') === -1)){ 
				$.each(receivedData.inventoryList, function (i, v) {
					if (v.invpool === 'provider') {
						riData.push(v);
					}
				});
				localStorage.ri = JSON.stringify(riData);
				localStorage.aDate = aDate;
				dataItemsToProcess.push('resourceInventories');
			} else {
				riData = JSON.parse(localStorage.ri);
			}

			//resourceInventories updation to localStorage
			if ((typeof localStorage.aDate === 'undefined' || aDate != localStorage.aDate) || (dataItemsToProcess.indexOf('customerInventories') === -1)){ 
				$.each(receivedData.inventoryList, function (i, v) {
					if (v.invpool === 'customer') {
						ciData.push(v);
					}
				});
				localStorage.ci = JSON.stringify(ciData);
				localStorage.aDate = aDate;
				dataItemsToProcess.push('customerInventories');
			} else {
				ciData = JSON.parse(localStorage.ci);
			}

			//resourceInventories updation to localStorage
			if ((typeof localStorage.aDate === 'undefined' || aDate != localStorage.aDate) || (dataItemsToProcess.indexOf('deinstalledInventories') === -1)){ 
				$.each(receivedData.inventoryList, function (i, v) {
					if (v.invpool === 'deinstall') {
						diData.push(v);
					}
				});
				localStorage.di = JSON.stringify(diData);
				localStorage.aDate = aDate;
				dataItemsToProcess.push('deinstalledInventories');
			} else {
				diData = JSON.parse(localStorage.di);
			}

			//resourceInventories updation to localStorage
			if ((typeof localStorage.aDate === 'undefined' || aDate != localStorage.aDate) || (dataItemsToProcess.indexOf('installedInventories') === -1)){ 
				$.each(receivedData.inventoryList, function (i, v) {
					if (v.invpool === 'install') {
						iiData.push(v);
					}
				});
				localStorage.ii = JSON.stringify(iiData);
				localStorage.aDate = aDate;
				dataItemsToProcess.push('installedInventories');
			} else {
				iiData = JSON.parse(localStorage.ii);
			}
			//re assigning data items to localStorage
			localStorage.storageDataItems = dataItemsToProcess;

			//concat results in open method instead of init
			console.log("RI Data : ", JSON.parse(localStorage.ri));
			console.log("CI Data : ", JSON.parse(localStorage.ci));
			console.log("DI Data : ", JSON.parse(localStorage.di));
			console.log("LI Data : ", JSON.parse(localStorage.ii));


			//building searchPartsJson with ri, ci, di, & ii to process further
			var searchPartsJson = JSON.parse(localStorage.ri).concat(JSON.parse(localStorage.ci), JSON.parse(localStorage.di), JSON.parse(localStorage.ii));
			console.log("searchPartsJson : ", searchPartsJson);

			//bind localStorage data to receivedData
			$.each(searchPartsJson, function (i, v) {
				receivedData.inventoryList[v.invid] = v;
			});

			console.log("receivedData : ", receivedData);


			var ultimateBind = this;

			var inventoryList = receivedData.inventoryList;
			var resourceID = receivedData.resource.external_id;
			var resource_pid = receivedData.resource.pid;

			var area = receivedData.resource.R_AREA;
			var managerResourceId = receivedData.resource.R_MGR_RESOURCE_NUMBER;

			// Activity Fields
			var activityId = receivedData.activity.aid;

			var serverURL = window.location.origin;
			console.log("WindLocatOrigin " + window.location.origin);



			var deinstall_Arr = "";
			var fslRequest = receivedData.activity.A_FSL_REQUEST;
			var warehouseRequest = receivedData.activity.A_WAREHOUSE_REQUEST;

			var inventoryListJSONData = {};
			var itemNumberActionsListJSONData = {};
			var displayManualAdditionSection = false;

			var lineCountForItems = 0;

			// Search Button behavior
			$('#searchButton').click(function (event) {
				event.stopImmediatePropagation();
				var inventoryListFilteredGrouped = {};
				var uiRowCount = 0;
				var minShowParts = 0, maxShowParts = 15;
				var btnSearch = true; //added for  INC1499701.
				var searchKeywordOrig = "";

				for (var i = 1; i <= searchFieldCount; i++) {
					if ($.trim($('#searchKeyword' + i).val())) {
						if (searchKeywordOrig != null && searchKeywordOrig != "") {
							searchKeywordOrig = searchKeywordOrig + "," + $.trim($('#searchKeyword' + i).val());
						} else {
							searchKeywordOrig = $.trim($('#searchKeyword' + i).val());
						}
					}
				}

				if (searchKeywordOrig == "" || typeof searchKeywordOrig === undefined || searchKeywordOrig == null) {

					alert("Please enter a search term.");
					return false;

				} else {

					if (searchKeywordOrig.length < 3) {

						alert("Please enter a search term more than 3 characters");
						return false;

					}
				}

				var searchKeyword = searchKeywordOrig.toLowerCase();

				// CHG0082471 starts

				var alertMap= {
					"D8692225": "Alert: Cost Savings Action for D8692225. "+"\n"+"Recommendation: Rebuild the PCU. "+"\n"+"Parts Required: AD027034-Charge Roller, D1979510-OPC Drum, AD041162-Cleaning Blade. "+"\n"+"Reference the Field Guide-Rebuild vs Replace document located on the Parts Management Site on Sharepoint.",
					"D2416006": "Alert: Cost Savings Action for D2416006. "+"\n"+"Recommendation: Rebuild the transfer unit. "+"\n"+"Parts Required: D2416097-Flat Belt, D0BQ6141-Cleaning Assembly. "+"\n"+"Reference the Field Guide-Rebuild vs Replace document located on the Parts Management Site on Sharepoint.",
					"D2704417": "Alert: Cost Savings Action for D2704417. "+"\n"+"Recommendation: Rebuild the fusing unit. "+"\n"+"Parts Required: AE020220-Pressure Roller, AE030049-Ball Bearing Qty. 2, D1794197-Flat Belt, AE010130-Hot Roller, AE030086-Ball Bearing Qty.4. "+"\n"+"Reference the Field Guide-Rebuild vs Replace document located on the Parts Management Site on Sharepoint.",
					"D0CQ4020": "Alert: Cost Savings Action for D0CQ4020. "+"\n"+"Recommendation: Rebuild the fusing unit. "+"\n"+"Parts Required: D0CQ4227-Pressure Roller, D0CQ4159-Hot Roller, D2614440-Flat Belt, D2614036-Polish Roller. "+"\n"+"Reference the Field Guide-Rebuild vs Replace document located on the Parts Management Site on Sharepoint.",
					"D0BQ4031": "Alert: Cost Saving Action for D0BQ4031. "+"\n"+"Recommendation: Replace fusing assembly OEM New. "+"\n"+"Reference the Field Guide-Rebuild vs Replace document located on the Parts Management Site on Sharepoint.",
					"PMD197120K-A": "Alert: Labor Saving Action for PMD197120K-A. "+"\n"+"Recommendation: Use D2020127 PCDU for Labor Savings. "+"\n"+"Reference the Field Guide-Rebuild vs Replace document located on the Parts Management Site on Sharepoint.",
					"D2020127": "Alert: Cost Saving Action for D2020127. "+"\n"+"Recommendation: Replace the PCU Assembly or Rebuild the PCU Assembly. "+"\n"+"Parts Required: D8692225-PCU Assembly, Or AD027034-Charge Roller, D1979510-OPC Drum, AD041162-Cleaning Blade. "+"\n"+"Reference the Field Guide-Rebuild vs Replace document located on the Parts Management Site on Sharepoint.",
					"HD2424055": "Alert: Cost Saving Action for HD2424055. "+"\n"+"Recommendation: Rebuild the Fusing Unit. "+"\n"+"Parts Required: D2424041-Fusing Sleeve, AE020282- Pressure Roller, AE030074-Ball Bearing(2). "+"\n"+"Reference the Field Guide-Rebuild vs Replace document located on the Parts Management Site on Sharepoint.",
					"M1604018": "Alert: Cost Saving Action for M1604018. "+"\n"+"Recommendation: Replace fusing assembly OEM New. "+"\n"+"Reference the Field Guide-Rebuild vs Replace document located on the Parts Management Site on Sharepoint.",
					"D0DL1640": "Alert: A performance Issue has been identified  with the Optical  Reading Unit D0DL1640 causing SC142-12. "+"\n"+"Reference document SC142-12 Optical Reading Unit before ordering parts. This procedure requires no parts and has proven to be 95% effective.",
					"VV33F8354": "Alert: Do not order VV33F8354 as a part. This is a supply item. Order CR2032RIC Battery from Image Supply Service. "+"\n"+"Reference document VV33F8354_CR2032RIC Battery Process",
					"TECN-822456": "Alert: Cost Savings Action for TECN-822456 Feature Item, to be ordered by customer, "+"\n"+"Recommendation use repair kit part number TECN-507990",
					"TECN-822468": "Alert: Cost Savings Action for TECN-822468 Feature Item, to be ordered by customer, "+"\n"+"Recommendation use repair kit part number TECN-507991",
					"HUNK-7529-90047": "Alert: Cost Savings Action for HUNK-7529-90047 Feature Item, to be ordered by customer, "+"\n"+"Recommendation use repair kit part number VV40U8802",
					"HUNK-7529-90048": "Alert: Cost Savings Action for HUNK-7529-90048 Feature Item, to be ordered by customer, "+"\n"+"Recommendation use repair kit part number VV40U8803",
					"HUNK-7529-90049": "Alert: Cost Savings Action for HUNK-7529-90049 Feature Item, to be ordered by customer, "+"\n"+"Recommendation use repair kit part numberVV40U8804",
					"VV0003609": "Alert: Cost Savings Action for VV0003609 Feature Item, to be ordered by customer, "+"\n"+"Recommendation use repair kit part number VV40U8805",
					"VV23L1775": "Alert: Cost Savings Action for VV23L1775 Feature Item, to be ordered by customer, "+"\n"+"Recommendation use repair kit part number VV41P6821",
					"TECN-822475": "Alert: Cost Savings Action for TECN-822475 These are features that are ordered by customer. "+"\n"+"Recommendation: Rebuild with component parts",
					"TECN-822561": "Alert: Cost Savings Action for TECN-822561 These are features that are ordered by customer. "+"\n"+"Recommendaton rebuild with component parts",
					"HUNK-7198/00432": "Alert: Cost Savings Action for HUNK-7198/00432 These are features that are ordered by customer. "+"\n"+"Recommendaton rebuild with component parts",
					"10P0103": "Alert: Cost Savings Action for 10P0103 These are features that are ordered by customer. "+"\n"+"Recommendaton rebuild with component parts",
					"10P0104": "Alert: Cost Savings Action for 10P0104 These are features that are ordered by customer. "+"\n"+"Recommendaton rebuild with component parts",
					"36R5999": "Alert: Cost Savings Action for 36R5999 These are features that are ordered by customer. "+"\n"+"Recommendaton rebuild with component parts",
					"TECN-822552": "Alert: Cost Savings Action for TECN-822552 These are features that are ordered by customer. "+"\n"+"Recommendaton rebuild with component parts",
					"TECN-822558": "Alert: Cost Savings Action for TECN-822558 These are features that are ordered by customer. "+"\n"+"Recommendaton rebuild with component parts",
					"TECN-822559": "Alert: Cost Savings Action for TECN-822559 These are features that are ordered by customer. "+"\n"+"Recommendaton rebuild with component parts",
					"TP-HUNK-7122/02314": "Alert: Cost Savings Action for TP-HUNK-7122/02314 These are features that are ordered by customer. "+"\n"+"Recommendaton rebuild with component parts",
					"VV0003610": "Alert: Cost Savings Action for VV0003610 These are features that are ordered by customer. "+"\n"+"Recommendaton rebuild with component parts",
					"VV0003611": "Alert: Cost Savings Action for VV0003611 These are features that are ordered by customer. "+"\n"+"Recommendaton rebuild with component parts",
					"VV23L1774": "Alert: Cost Savings Action for VV23L1774 These are features that are ordered by customer. "+"\n"+"Recommendaton rebuild with component parts",
					"VV39P5236": "Alert: Cost Savings Action for VV39P5236 These are features that are ordered by customer. "+"\n"+"Recommendaton rebuild with component parts",
					"VV40E7562": "Alert: Cost Savings Action for VV40E7562 These are features that are ordered by customer. "+"\n"+"Recommendaton rebuild with component parts",
					"VV41P6821": "Alert: Cost Savings Action for VV41P6821 These are features that are ordered by customer. "+"\n"+"Recommendaton rebuild with component parts",
					"VV74H6866": "Alert: Cost Savings Action for VV74H6866 These are features that are ordered by customer. "+"\n"+"Recommendaton rebuild with component parts",
					"TECN-507944": "Alert: Cost Savings Action for TECN-507944 This is a complete assembly note recommended component part to order TECN-50794101",
					"VV40T2997": "Alert: Cost Savings Action for VV40T2997 This is a complete assembly note recommended component part to order VV0000284",
					"HUNK-7191-00019": "Alert: Cost Savings Action for HUNK-7191-00019 This is a complete assembly note recommended component part to order  40E0716",
					"TECN-50794201": "Alert: Cost Savings Action for TECN-50794201 This is a complete assembly note recommended component part to order TECN-50794101",
					"VV0005607": "Alert: Cost Savings Action for VV0005607 This is a complete assembly note recommended component part to order TP-HUNK-7184/01544 ",
					"HUNK-7170/00817": "Alert: Cost Savings Action for HUNK-7170/00817 This is a complete assembly note recommended component part to order 40E0716",
					"HUNK-7533-00701": "Alert: Cost Savings Action for HUNK-7533-00701 This is a complete assembly note recommended component part to order HUNK-7533-00703",
					"HUNK-7184/00424": "Alert: Cost Savings Action for HUNK-7184/00424 This is a complete assembly note recommended component part to order VV40U8792",
					"VV0005282": "Alert: Cost Savings Action for VV0005282 This is a complete assembly note recommended component part to order VV36R5742",
					"HUNK-7534-00270": "Alert: Cost Savings Action for HUNK-7534-00270 Hunkeler OEM spur pinion gear.    Note recommended Simprint part SIMP-7534-00270-G this is just the gear only, see Simprint part number SIMP-7534-00270-A for complete hub gear assembly",
					"SIMP-7534-00270-A": "Alert: Cost Savings Action for SIMP-7534-00270-A Conversion kit for the Gen 8 airshaft. Order this part (gear and hub) only once per airshaft",
					"SIMP-7534-00270-G": "Alert: Cost Savings Action for SIMP-7534-00270-G New gear (spur pinion gear) only. Order this part if the shaft has the new hub.",
					"VV23L2404": "Alert: Cost Savings Action for VV23L2404 Hunkeler OEM spur pinion gear.    Note recommended Simprint part SIMP-7119-00036-3G this is just the gear only see Simprint part number SIMP-7119-00036-3B for complete hub gear assembly",
					"SIMP-7119-00036-3B": "Alert: Cost Savings Action for SIMP-7119-00036-3B Conversion kit for the Pop 6 airshaft. Order this part  (gear and hub) only once per airshaft",
					"SIMP-7119-00036-3G": "Alert: Cost Savings Action for SIMP-7119-00036-3G New gear (spur pinion gear) only. Order this part if the shaft has the new hub.",
					"D2706570": "This part is a CUSTOMER RESPONSIBILITY to order. If you are ordering for a specific reason please contact your manager before ordering for approval.",
					"D2706590": "This part is a CUSTOMER RESPONSIBILITY to order. If you are ordering for a specific reason please contact your manager before ordering for approval.",
					"D1796590": "This part is a CUSTOMER RESPONSIBILITY to order. If you are ordering for a specific reason please contact your manager before ordering for approval.",   
					"H-D1796590": "This part is a CUSTOMER RESPONSIBILITY to order. If you are ordering for a specific reason please contact your manager before ordering for approval."
				};

				var alertURL = {
					"D8692225":"https://rsharepoint.sharepoint.com/sites/rus-rse/Service%20Excellence/Forms/AllItems.aspx?id=%2Fsites%2Frus%2Drse%2FService%20Excellence%2FOperations%20%26%20Best%20Practices%2FTech%20Connect%2FProcess%20Document%20Repository%2FBP%5FField%20Guide%2DRebuild%20vs%20Replace%2Epdf&parent=%2Fsites%2Frus%2Drse%2FService%20Excellence%2FOperations%20%26%20Best%20Practices%2FTech%20Connect%2FProcess%20Document%20Repository",
					"D2416006":"https://rsharepoint.sharepoint.com/sites/rus-rse/Service%20Excellence/Forms/AllItems.aspx?id=%2Fsites%2Frus%2Drse%2FService%20Excellence%2FOperations%20%26%20Best%20Practices%2FTech%20Connect%2FProcess%20Document%20Repository%2FBP%5FField%20Guide%2DRebuild%20vs%20Replace%2Epdf&parent=%2Fsites%2Frus%2Drse%2FService%20Excellence%2FOperations%20%26%20Best%20Practices%2FTech%20Connect%2FProcess%20Document%20Repository",
					"D2704417":"https://rsharepoint.sharepoint.com/sites/rus-rse/Service%20Excellence/Forms/AllItems.aspx?id=%2Fsites%2Frus%2Drse%2FService%20Excellence%2FOperations%20%26%20Best%20Practices%2FTech%20Connect%2FProcess%20Document%20Repository%2FBP%5FField%20Guide%2DRebuild%20vs%20Replace%2Epdf&parent=%2Fsites%2Frus%2Drse%2FService%20Excellence%2FOperations%20%26%20Best%20Practices%2FTech%20Connect%2FProcess%20Document%20Repository",
					"D0CQ4020":"https://rsharepoint.sharepoint.com/sites/rus-rse/Service%20Excellence/Forms/AllItems.aspx?id=%2Fsites%2Frus%2Drse%2FService%20Excellence%2FOperations%20%26%20Best%20Practices%2FTech%20Connect%2FProcess%20Document%20Repository%2FBP%5FField%20Guide%2DRebuild%20vs%20Replace%2Epdf&parent=%2Fsites%2Frus%2Drse%2FService%20Excellence%2FOperations%20%26%20Best%20Practices%2FTech%20Connect%2FProcess%20Document%20Repository",
					"D0BQ4031":"https://rsharepoint.sharepoint.com/sites/rus-rse/Service%20Excellence/Forms/AllItems.aspx?id=%2Fsites%2Frus%2Drse%2FService%20Excellence%2FOperations%20%26%20Best%20Practices%2FTech%20Connect%2FProcess%20Document%20Repository%2FBP%5FField%20Guide%2DRebuild%20vs%20Replace%2Epdf&parent=%2Fsites%2Frus%2Drse%2FService%20Excellence%2FOperations%20%26%20Best%20Practices%2FTech%20Connect%2FProcess%20Document%20Repository",
					"PMD197120K-A":"https://rsharepoint.sharepoint.com/sites/rus-rse/Service%20Excellence/Forms/AllItems.aspx?id=%2Fsites%2Frus%2Drse%2FService%20Excellence%2FOperations%20%26%20Best%20Practices%2FTech%20Connect%2FProcess%20Document%20Repository%2FBP%5FField%20Guide%2DRebuild%20vs%20Replace%2Epdf&parent=%2Fsites%2Frus%2Drse%2FService%20Excellence%2FOperations%20%26%20Best%20Practices%2FTech%20Connect%2FProcess%20Document%20Repository",
					"D2020127":"https://rsharepoint.sharepoint.com/sites/rus-rse/Service%20Excellence/Forms/AllItems.aspx?id=%2Fsites%2Frus%2Drse%2FService%20Excellence%2FOperations%20%26%20Best%20Practices%2FTech%20Connect%2FProcess%20Document%20Repository%2FBP%5FField%20Guide%2DRebuild%20vs%20Replace%2Epdf&parent=%2Fsites%2Frus%2Drse%2FService%20Excellence%2FOperations%20%26%20Best%20Practices%2FTech%20Connect%2FProcess%20Document%20Repository",
					"HD2424055":"https://rsharepoint.sharepoint.com/sites/rus-rse/Service%20Excellence/Forms/AllItems.aspx?id=%2Fsites%2Frus%2Drse%2FService%20Excellence%2FOperations%20%26%20Best%20Practices%2FTech%20Connect%2FProcess%20Document%20Repository%2FBP%5FField%20Guide%2DRebuild%20vs%20Replace%2Epdf&parent=%2Fsites%2Frus%2Drse%2FService%20Excellence%2FOperations%20%26%20Best%20Practices%2FTech%20Connect%2FProcess%20Document%20Repository",
					"M1604018":"https://rsharepoint.sharepoint.com/sites/rus-rse/Service%20Excellence/Forms/AllItems.aspx?id=%2Fsites%2Frus%2Drse%2FService%20Excellence%2FOperations%20%26%20Best%20Practices%2FTech%20Connect%2FProcess%20Document%20Repository%2FBP%5FField%20Guide%2DRebuild%20vs%20Replace%2Epdf&parent=%2Fsites%2Frus%2Drse%2FService%20Excellence%2FOperations%20%26%20Best%20Practices%2FTech%20Connect%2FProcess%20Document%20Repository",
					"D0DL1640":"https://rsharepoint.sharepoint.com/sites/rus-rse/Service%20Excellence/Forms/AllItems.aspx?id=%2Fsites%2Frus%2Drse%2FService%20Excellence%2FOperations%20%26%20Best%20Practices%2FTech%20Connect%2FProcess%20Document%20Repository%2FBP%5FSC142%2D12%20Optical%20Reading%20Unit%20Failure%2Epdf&parent=%2Fsites%2Frus%2Drse%2FService%20Excellence%2FOperations%20%26%20Best%20Practices%2FTech%20Connect%2FProcess%20Document%20Repository",
					"VV33F8354":"https://rsharepoint.sharepoint.com/sites/rus-rse/Service%20Excellence/Forms/AllItems.aspx?id=%2Fsites%2Frus%2Drse%2FService%20Excellence%2FOperations%20%26%20Best%20Practices%2FTech%20Connect%2FProcess%20Document%20Repository%2FFS333%5FVV33F8354%5FCR2032RIC%20Battery%20Process%2Epdf&parent=%2Fsites%2Frus%2Drse%2FService%20Excellence%2FOperations%20%26%20Best%20Practices%2FTech%20Connect%2FProcess%20Document%20Repository",
					"TECN-822456":"https://tscpro.custhelp.com/app/answers/detail/a_id/232570/p/7463/kw/trimmer",
					"TECN-822468":"https://tscpro.custhelp.com/app/answers/detail/a_id/232570/p/7463/kw/trimmer",
					"HUNK-7529-90047":"https://tscpro.custhelp.com/app/answers/detail/a_id/232570/p/7463/kw/trimmer",
					"HUNK-7529-90048":"https://tscpro.custhelp.com/app/answers/detail/a_id/232570/p/7463/kw/trimmer",
					"HUNK-7529-90049":"https://tscpro.custhelp.com/app/answers/detail/a_id/232570/p/7463/kw/trimmer",
					"VV0003609":"https://tscpro.custhelp.com/app/answers/detail/a_id/232570/p/7463/kw/trimmer",
					"VV23L1775":"https://tscpro.custhelp.com/app/answers/detail/a_id/232570/p/7463/kw/trimmer",
					"HUNK-7534-00270":"https://tscpro.custhelp.com/app/answers/detail/a_id/283515/p/7462/kw/spur%20pinion%20gear",
					"SIMP-7534-00270-A":"https://tscpro.custhelp.com/app/answers/detail/a_id/283515/p/7462/kw/spur%20pinion%20gear",
					"SIMP-7534-00270-G":"https://tscpro.custhelp.com/app/answers/detail/a_id/283515/p/7462/kw/spur%20pinion%20gear",
					"VV23L2404":"https://tscpro.custhelp.com/app/answers/detail/a_id/283515/p/7462/kw/spur%20pinion%20gear",
					"SIMP-7119-00036-3B":"https://tscpro.custhelp.com/app/answers/detail/a_id/283515/p/7462/kw/spur%20pinion%20gear",
					"SIMP-7119-00036-3G":"https://tscpro.custhelp.com/app/answers/detail/a_id/283515/p/7462/kw/spur%20pinion%20gear",
					"D2706570":"https://rsharepoint.sharepoint.com/sites/rus-rse/Service%20Excellence/Forms/AllItems.aspx?id=%2Fsites%2Frus%2Drse%2FService%20Excellence%2FOperations%20%26%20Best%20Practices%2FTech%20Connect%2FProcess%20Document%20Repository%2FBP%5FField%20Guide%2DRebuild%20vs%20Replace%2Epdf&parent=%2Fsites%2Frus%2Drse%2FService%20Excellence%2FOperations%20%26%20Best%20Practices%2FTech%20Connect%2FProcess%20Document%20Repository",
					"D2706590":"https://rsharepoint.sharepoint.com/sites/rus-rse/Service%20Excellence/Forms/AllItems.aspx?id=%2Fsites%2Frus%2Drse%2FService%20Excellence%2FOperations%20%26%20Best%20Practices%2FTech%20Connect%2FProcess%20Document%20Repository%2FBP%5FField%20Guide%2DRebuild%20vs%20Replace%2Epdf&parent=%2Fsites%2Frus%2Drse%2FService%20Excellence%2FOperations%20%26%20Best%20Practices%2FTech%20Connect%2FProcess%20Document%20Repository",
					"D1796590":"https://rsharepoint.sharepoint.com/sites/rus-rse/Service%20Excellence/Forms/AllItems.aspx?id=%2Fsites%2Frus%2Drse%2FService%20Excellence%2FOperations%20%26%20Best%20Practices%2FTech%20Connect%2FProcess%20Document%20Repository%2FBP%5FField%20Guide%2DRebuild%20vs%20Replace%2Epdf&parent=%2Fsites%2Frus%2Drse%2FService%20Excellence%2FOperations%20%26%20Best%20Practices%2FTech%20Connect%2FProcess%20Document%20Repository",
					"H-D1796590":"https://rsharepoint.sharepoint.com/sites/rus-rse/Service%20Excellence/Forms/AllItems.aspx?id=%2Fsites%2Frus%2Drse%2FService%20Excellence%2FOperations%20%26%20Best%20Practices%2FTech%20Connect%2FProcess%20Document%20Repository%2FBP%5FField%20Guide%2DRebuild%20vs%20Replace%2Epdf&parent=%2Fsites%2Frus%2Drse%2FService%20Excellence%2FOperations%20%26%20Best%20Practices%2FTech%20Connect%2FProcess%20Document%20Repository"
				} 

				$.generateCallIdTemp = function () {
					return btoa(String.fromCharCode.apply(null, window.crypto.getRandomValues(new Uint8Array(16))));
				},

				$.openURLinkNewTab = function (aURL){
					var uniquecallid = $.generateCallIdTemp();
					var jsonToSend = {
						"apiVersion": 1,
						"callId": uniquecallid,
						"method": "callProcedure",
						"procedure": "openLink",
						"params": {
							"url": aURL
						}
					}
					console.log("Opening New tab" + jsonToSend);
					ultimateBind._sendPostMessageData(jsonToSend);
				};

				var searchKeyArray1 = searchKeyword.toUpperCase().split(',');
				$.each(searchKeyArray1, function (key, searchKeyValue) {
					if(alertMap[searchKeyValue]) {
						if(alertURL[searchKeyValue])
						{
							if(confirm(alertMap[searchKeyValue]+"\n\n"+"Click on OK to review the Reference Document"))
							{
								$.openURLinkNewTab(alertURL[searchKeyValue]);
							}
						}
						else{
							alert(alertMap[searchKeyValue]);
						}
					}

				});
				
				// CHG0082471 ends

				//CHG0075659 - MPF Phase 5 - LOGIC TO GET MULTIPLE SEARCH ITEMS into an array
				searchArray = [];
				if (searchKeywordOrig.indexOf(',') != -1) {
					searchArray = searchKeywordOrig.split(',');
				}



				//clear the previous search results
				$("#activityInventoryGrid").empty();
				$("#manualPartsAdditionSection").empty();

				$("#activityInventoryGrid").removeClass("cp_hidden");
				$("#activityInventoryGrid").append("<span style='padding:10px;font-style: italic;'>Loading....</span>");
				var firstTimeLoopItemsTrue = true;
				$("#activityInventoryGridFooter").addClass("cp_hidden");

				// CHG0075659 - MPF Phase 5 - commenting parts catalog api logic to implement plugin Call Procedure api
				// var partsCatalogRestServiceURL = serverURL + "/PartsCatalog/rest/parts/search/items";
				//var selectedSourceSubInventory = null; //added for INC1505861 -  Unable to transfer from another tech's subinventory to himself
				// //var partsCatalogRestServiceURL = "https://jcsd.ricohonline.net/PartsCatalog/rest/parts/search/items";
				// console.log("REST -partsCatalogRestServiceURL " + partsCatalogRestServiceURL);
				// var partsCatalogPayload = {
				// 	/* "authorization": icsauthorizationB64,
				// 	"apiURL": icsBaseURL,*/ //commented during 19c upgrade as these are no more used
				// 	"searchKeyword": searchKeywordOrig,
				// 	"subInvCode": selectedSourceSubInventory //added for INC1505861 -  Unable to transfer from another tech's subinventory to himself
				// };
				//console.log(" partsCatalogPayload " + JSON.stringify(partsCatalogPayload));

				// CHG0075659 - MPF Phase 5 - Search Parts Plugin API logic

				$.generateCallId = function () {
					return btoa(String.fromCharCode.apply(null, window.crypto.getRandomValues(new Uint8Array(16))));
				},
					//getting PartsCatalog
					$.getPartsCatalog = function (searchValue) {
						try {
							if (searchValue != 1) {
								searchKeywordOrig = searchValue;
							}

							//Parts Catalog Call started
							console.log("Parts Catalog call started");
							var uniquecallid = $.generateCallId();
							partssearchcallID = uniquecallid;
							var jsonSearchToSend = {
								"apiVersion": 1,
								"method": "callProcedure",
								"callId": uniquecallid,
								"procedure": "searchParts",
								"params": {
									"limit": 100,
									"query": searchKeywordOrig,
									"cacheOnly": false
								}
							}
							console.log("Parts Catalog search call:" + jsonSearchToSend);
							ultimateBind._sendPostMessageData(jsonSearchToSend);

						}
						catch (err) {

							console.log("Error occurred" + err);
							var now = new Date(Date.now());
							if (errorLogs == null) {
								errorLogs = "";
							}
							errorLogs = errorLogs + "||" + now.toString() + "|Plugin :Search Parts  - Error Details:" + err.message;
							console.log("Plugin Error Log", errorLogs);
							$.ErrorUpdate(actId, errorLogs);
						}
						// CHG0075659 - MPF Phase 5 - commenting parts catalog api logic to implement plugin Call Procedure api
						// $.ajax({
						// 	dataType: "json",
						// 	url: partsCatalogRestServiceURL,
						// 	data: JSON.stringify(partsCatalogPayload),
						// 	processData: false,
						// 	contentType: 'application/json; charset=utf-8',
						// 	method: "POST",
						// 	timeout: 20000,
						// 	success: function (partsCatalogResponseData) {

						// 		console.log("Parts Catalog webservice response:" + JSON.stringify(partsCatalogResponseData));
						// 		$.processSearchResultsFnCallBck(partsCatalogResponseData);

						// 	}.bind(this),
						// 	error: function (errorData) {
						// 		console.log("Parts Catalog webservice error:" + JSON.stringify(errorData));
						// 		var partsCatalogResponseData = { "element": [], "status": "" };
						// 		$.processSearchResultsFnCallBck(partsCatalogResponseData);
						// 	}

						// });

					};

				
					$.getPartsCatalogContinue = function (searchId) {
						try {
							
							//Parts Catalog Call started
							console.log("Parts Catalog Continue call started");
							var uniquecallid = $.generateCallId();
							partsContinueSearchCallId = uniquecallid;
							var jsonSearchContinueToSend = {
								"apiVersion": 1,
								"method": "callProcedure",
								"callId": uniquecallid,
								"procedure": "searchPartsContinue",
								"params": {
									"searchId": searchId
								}
							}
							console.log("Parts Catalog search call:" + jsonSearchContinueToSend);
							ultimateBind._sendPostMessageData(jsonSearchContinueToSend);

						}
						catch (err) {

							console.log("Error occurred" + err);
							var now = new Date(Date.now());
							if (errorLogs == null) {
								errorLogs = "";
							}
							errorLogs = errorLogs + "||" + now.toString() + "|Plugin :Search Parts Continue Process  - Error Details:" + err.message;
							console.log("Plugin Error Log", errorLogs);
							$.ErrorUpdate(actId, errorLogs);
						}
						
					};
					

				// CHG0075659 - MPF Phase 5 - getting linkedParts catalog
				$.getLinkedPartsRestService = function (parentItemNumber) {
					console.log("Linked Parts call started");
					try {
						//Parts Catalog Call started
						console.log("Parts Catalog call started");
						var uniquecallid = $.generateCallId();
						linkedcallID = uniquecallid;
						var jsonSearchToSend = {
							"apiVersion": 1,
							"method": "callProcedure",
							"callId": uniquecallid,
							"procedure": "searchParts",
							"params": {
								"limit": 100,
								"query": parentItemNumber,
								"cacheOnly": false
							}
						}
						$('#cpf_LinkedItems_'+parentItemNumber).empty();

						console.log("Sending to browser tab" + jsonSearchToSend);
						ultimateBind._sendPostMessageData(jsonSearchToSend);
					}

					catch (e) {

						console.log("Error occurred" + err);
						var now = new Date(Date.now());
						if (errorLogs == null) {
							errorLogs = "";
						}
						errorLogs = errorLogs + "||" + now.toString() + "|Plugin :Search Linked Parts  - Error Details:" + err.message;
						console.log("Plugin Error Log", errorLogs);
						$.ErrorUpdate(actId, errorLogs);
					}

					// CHG0075659 - MPF Phase 5 - commenting parts catalog api (Linked Items) logic to implement plugin Call Procedure api
					// var linkedRestServiceURL = serverURL + "/PartsCatalog/rest/parts/search/linkedParts";
					// //var linkedRestServiceURL = "https://jcsd.ricohonline.net/PartsCatalog/rest/parts/search/linkedParts";
					// var linkedPartsPayload = {
					// 	/* "authorization": icsauthorizationB64,
					// 	"apiURL": icsBaseURL,*/ //commented during 19c upgrade as these are no more used
					// 	"searchKeyword": parentItemNumber
					// };

					// console.log(" linkedPartsPayload " + JSON.stringify(linkedPartsPayload));
					// $.ajax({
					// 	dataType: "json",
					// 	url: linkedRestServiceURL,
					// 	data: JSON.stringify(linkedPartsPayload),
					// 	processData: false,
					// 	contentType: 'application/json; charset=utf-8',
					// 	method: "POST",
					// 	timeout: 15000,
					// 	success: function (linkeditemsResponseData) {

					// 		console.log("Linked Items webservice response:" + JSON.stringify(linkeditemsResponseData));
					// 		$.processLinkedItemsResultsFnCallBck(linkeditemsResponseData, parentItemNumber);

					// 	}.bind(this),
					// 	error: function (errorData) {
					// 		console.log("Linked Items webservice error:" + JSON.stringify(errorData));
					// 		var linkeditemsResponseData = { "linked_items": {}, "status": 500 };
					// 		$.processLinkedItemsResultsFnCallBck(linkeditemsResponseData, parentItemNumber);
					// 	}

					// });
				};
					// Begin CHG0082493
				
				$.getCompatiblePartDetails = function (compatibleItemNumber) {
					console.log("Compatible Parts call started");
					try {
						//Parts Catalog Call started
						console.log("Parts Catalog call started");
						var uniquecallid = $.generateCallId();
						compatibleCallID = uniquecallid;
						var jsonSearchToSend = {
							"apiVersion": 1,
							"method": "callProcedure",
							"callId": uniquecallid,
							"procedure": "searchParts",
							"params": {
								"limit": 100,
								"query": compatibleItemNumber,
								"cacheOnly": false
							}
						}
					//	$('#cpf_LinkedItems_'+parentItemNumber).empty();

						console.log("Compatible Part send" + jsonSearchToSend);
						ultimateBind._sendPostMessageData(jsonSearchToSend);
					}

					catch (e) {

						console.log("Error occurred" + err);
						var now = new Date(Date.now());
						if (errorLogs == null) {
							errorLogs = "";
						}
						errorLogs = errorLogs + "||" + now.toString() + "|Plugin :Search Linked Parts  - Error Details:" + err.message;
						console.log("Plugin Error Log", errorLogs);
						$.ErrorUpdate(actId, errorLogs);
					}

					
				};
				
				// End CHG0082493
				

				// CHG0075659 - MPF Phase 5 - Condition to call multiple search items 
				if (searchArray.length > 1) {
					$.each(searchArray, function (i, v) {
						searchflag += 1;
						console.log("Parts Catalog for Multiple parts: " + v);
						$.getPartsCatalog(v);
					});
				}
				else {
					// CHG0075659 - MPF Phase 5 - Condition to call single search item
					$.getPartsCatalog(1);
				}

				//processing the calls
				$.processSearchResultsFnCallBck = function (partsCatalogResponseData) {
					//added for  INC1499701

					searchflag = 0;
					if (btnSearch) {

						var subInventoryListNames = receivedData.resource.R_SUBINVENTORY_NAME;
						var subInventoryList = "";
						var subInventoryListEmpty = true;
						//var addressList = receivedData.resource.R_ADDRESS;
						// Building the Sub-Inventory Drop Down:
						var subInventoryListSelectDropDown = $('<select id="subInventoryListSelectDropDown"  class="cp_field_dropdown_component form-item"/>');
						//subInventoryListSelectDropDown.append($('<option value=""/>').html(""));  // Navaz commented to remove the empty first item from the Drop Down.
						subInventoryListSelectDropDown.append($('<option value="CAR_STOCK" selected="selected"/>').html(resourceID));
						$("#subInvDD").empty();//added for  INC1499701
						$("#subInvDD").append(subInventoryListSelectDropDown);
						$("#subInventoryListSelectDropDown").attr('disabled', true);

						//restructuring subinventory names
						if (typeof subInventoryListNames != 'undefined') {
							if (subInventoryListNames != null) // change done for Defect 1526
								subInventoryList = subInventoryListNames.split(";");
							//console.log('subInventoryList from SearchParts:' + JSON.stringify(subInventoryList, null, 4));
							subInventoryListEmpty = false;
							// populate the sub Inventory Drop down list with the values.

							for (var i in subInventoryList) {
								var subInventoryName = subInventoryList[i].split(",");
								$("#subInventoryListSelectDropDown").append($('<option value="' + subInventoryName[0] + '"/>').html(subInventoryList[i]));
								$("#subInventoryListSelectDropDown").attr('disabled', false);
							}
						}

						//end modification for  INC1499701
						//clear the previous search results
						$("#activityInventoryGrid").empty();
						$("#manualPartsAdditionSection").empty();
						//re structuring the element array
						// $.each(partsCatalogResponseData.resultData.items, function (i, a) {
						// 	console.log(a.fields);
						// 	fieldsarray.push(a.fields);							
						// 	a.fields.LINKED_COUNT= a.linkedItems.length;
						// });
						// if(partsCatalogResponseData.resultData.items.linkedItems){
						// 	var compatibleLinkCount = partsCatalogResponseData.resultData.items.linkedItems.length;
						// }
						var elementArray = partsCatalogResponseData;
						var partsCatalogJSON = {};
						if (elementArray) {
							for (var i = 0; i < elementArray.length; i++) {

								var obj = elementArray[i];
								console.log("ITEM_NUMBER : ", obj.ITEM_NUMBER);
								partsCatalogJSON[obj.ITEM_NUMBER] = {
									InStock: 0,
									OntheWay: 0,
									InstalledQty: 0,
									ReqQty: 0,
									Compatible: obj.LINKED_COUNT,
									I_ITEM_NUMBER: obj.ITEM_NUMBER,
									I_ITEM_DESCRIPTION: obj.ITEM_DESCRIPTION,
									I_PRICE: obj.ITEM_PRICE,
									I_SUBINVENTORY: "",
									I_SUBINVENTORY_NAME: "",
									I_RETURN_VENDOR: obj.VENDOR,
									I_ITEM_DISPOSITION: obj.ITEM_DISPOSITION,
									I_ITEM_COST: obj.ITEM_COST,
									I_CURRENT_MAX: "",
									I_CURRENT_MIN: "",
									inv_aid: "",
									invtype: "",
									invpool: "",
									invid: "",
									inv_pid: "",
									quantity: "",
									I_SUB_INV_NAMES: ""
								};
							}
						}

						console.log("partsCatalogJSON : ", JSON.stringify(partsCatalogJSON));


						//Parts Catalog Call End

						var rowCount = 0;
						var searchRowCount = 0;
						var inventoryListFiltered = {};
						var partsCatalogListFiltered = {};

						//processing inventory data
						var searchKeywordArray = searchKeyword.split(",");
						$.each(inventoryList, function (key, invItem) {
							var itemNumber = invItem.I_ITEM_NUMBER;
							var itemDescKey = invItem.I_ITEM_DESCRIPTION;
							var invPostion = '';
							var itemPostion = -1;
							var itemDescPosition = -1;

							if ((invItem.inv_aid == "" || invItem.inv_aid == null || typeof invItem.inv_aid === undefined) || (invItem.inv_aid == activityId)) {
								if (invItem.invpool == "provider" || invItem.invpool == "customer" || invItem.invpool == "install" || invItem.invpool == "deinstall") {

									if (invItem.invtype == "SUBINVENTORY" || invItem.invtype == "CAR_STOCK" || invItem.invtype == "OPEN" || invItem.invtype == "EXPECTED") {
										$.each(searchKeywordArray, function (kiy, searchKeyValue) {
											if (itemNumber != null && itemNumber != '' && itemNumber != undefined) {
												itemPostion = itemNumber.toLowerCase().indexOf(searchKeyValue);
											}
											if (itemDescKey != null && itemDescKey != '' && itemDescKey != undefined) {
												itemDescPosition = itemDescKey.toLowerCase().indexOf(searchKeyValue);
											}

											if ((itemPostion > -1) || (itemDescPosition > -1)) {
												var inventoryId = invItem.invid;
												inventoryListFiltered[inventoryId] = {
													I_ITEM_NUMBER: invItem.I_ITEM_NUMBER,
													I_ITEM_DESCRIPTION: invItem.I_ITEM_DESCRIPTION,
													I_PRICE: invItem.I_PRICE,
													I_SUBINVENTORY: invItem.I_SUBINVENTORY,
													I_SUBINVENTORY_NAME: invItem.I_SUBINVENTORY_NAME,
													inv_aid: invItem.inv_aid,
													invtype: invItem.invtype,
													invpool: invItem.invpool,
													invid: invItem.invid,
													inv_pid: invItem.inv_pid,
													quantity: invItem.quantity,
													I_RETURN_VENDOR: invItem.I_RETURN_VENDOR,
													I_ITEM_DISPOSITION: invItem.I_ITEM_DISPOSITION,
													I_ITEM_COST: invItem.I_ITEM_COST,
													// Modification for INC1474651 - Min Max display issue
													//I_CURRENT_MAX:invItem.I_CURRENT_MAX,
													//I_CURRENT_MIN:invItem.I_CURRENT_MIN
													I_CURRENT_MAX: invItem.I_MAX,
													I_CURRENT_MIN: invItem.I_MIN,
													// End Modification for INC1474651 - Min Max display issue
													
													// Start added for CHG0075456 - Bin Locations for Field Service
													I_PRIMARY_BIN_NAME: invItem.I_PRIMARY_BIN_NAME,
													I_PRIMARY_BIN_QTY: invItem.I_PRIMARY_BIN_QTY,
													I_SECONDARY_BIN_NAME: invItem.I_SECONDARY_BIN_NAME,
													I_SECONDARY_BIN_QTY: invItem.I_SECONDARY_BIN_QTY,
													I_OUTOFBOX_BIN_NAME: invItem.I_OUTOFBOX_BIN_NAME,
													I_OUTOFBOX_BIN_QTY: invItem.I_OUTOFBOX_BIN_QTY
													// End added for CHG0075456 - Bin Locations for Field Service
												};


											}
										});

									}
								}
							}
						});


						//processing filtered inventories

						$.each(inventoryListFiltered, function (key, invItem) {

							console.log("Key:" + key);
							console.log("invItem" + invItem);
							var itemNum = invItem.I_ITEM_NUMBER;
							var currentQty = parseInt(invItem.quantity);
							var subInvName = "";
							if (invItem.I_SUBINVENTORY == resourceID) {
								subInvName = "CAR_STOCK";
							} else {
								subInvName = invItem.I_SUBINVENTORY
							}
							if (inventoryListFilteredGrouped[itemNum]) {


								if ((invItem.invpool == "provider") && (invItem.invtype == "SUBINVENTORY" || invItem.invtype == "CAR_STOCK")) {

									inventoryListFilteredGrouped[itemNum].InStock = parseInt(inventoryListFilteredGrouped[itemNum].InStock) + currentQty;

									if (currentQty > 0) {
										if ("" == inventoryListFilteredGrouped[itemNum].I_SUB_INV_NAMES) {
											inventoryListFilteredGrouped[itemNum].I_SUB_INV_NAMES = subInvName + "(" + currentQty + ")";
										} else {
											inventoryListFilteredGrouped[itemNum].I_SUB_INV_NAMES = inventoryListFilteredGrouped[itemNum].I_SUB_INV_NAMES + ", " + subInvName + "(" + currentQty + ")";
										}
									}

								}
								if (invItem.invpool == "customer" && (invItem.invtype == "OPEN" || invItem.invtype == "EXPECTED")) {

									inventoryListFilteredGrouped[itemNum].OntheWay = parseInt(inventoryListFilteredGrouped[itemNum].OntheWay) + currentQty;
								}
								if (invItem.invpool == "deinstall" && (invItem.invtype == "SUBINVENTORY" || invItem.invtype == "CAR_STOCK")) {

									inventoryListFilteredGrouped[itemNum].ReqQty = parseInt(inventoryListFilteredGrouped[itemNum].ReqQty) + currentQty;

								}
								if (invItem.invpool == "install" && (invItem.invtype == "SUBINVENTORY" || invItem.invtype == "CAR_STOCK")) {

									inventoryListFilteredGrouped[itemNum].InstalledQty = parseInt(inventoryListFilteredGrouped[itemNum].InstalledQty) + currentQty;
								}

								console.log("inventoryfiletredgrouped: " + inventoryListFilteredGrouped);

							} else {
								// console.log("Item not found. Adding " + itemNum);
								var instock_qty = 0;
								var ontheway_qty = 0;
								var installed_qty = 0;
								var required_qty = 0;
								var compatible_qty = 0;
								var itemQty = parseInt(invItem.quantity);
								

								var subInvNames = "";
								var binNames = ""; //Added for CHG0075456 - Bin Locations for Field Service

								if (invItem.invpool == "provider" && (invItem.invtype == "SUBINVENTORY" || invItem.invtype == "CAR_STOCK")) {

									if (isNaN(itemQty)) {

										instock_qty = 0; //parseInt(invItem.quantity);
									} else {
										instock_qty += itemQty; //parseInt(invItem.quantity);
									}
									if (instock_qty > 0) {
										// Added for CHG0075456 - Bin Locations for Field Service
										var binNames = "";
										if(invItem.I_PRIMARY_BIN_NAME != null){
											binNames += invItem.I_PRIMARY_BIN_NAME;
										}
										if(invItem.I_PRIMARY_BIN_QTY != null && "" != invItem.I_PRIMARY_BIN_QTY){
											binNames +='('+invItem.I_PRIMARY_BIN_QTY+'),';
										}
										if(invItem.I_SECONDARY_BIN_NAME != null){
											binNames += invItem.I_SECONDARY_BIN_NAME;
										}
										if(invItem.I_SECONDARY_BIN_QTY != null && "" != invItem.I_SECONDARY_BIN_QTY){
											binNames +='('+invItem.I_SECONDARY_BIN_QTY+'),';
										}
										if(invItem.I_OUTOFBOX_BIN_NAME != null){
											binNames += invItem.I_OUTOFBOX_BIN_NAME;
										}
										if(invItem.I_OUTOFBOX_BIN_QTY != null && "" != invItem.I_OUTOFBOX_BIN_QTY){
											binNames +='('+invItem.I_OUTOFBOX_BIN_QTY+')';
										}
										subInvNames = subInvName + "(" + instock_qty +("" != binNames ? " - "+binNames: "") + ")";
										// End added for CHG0075456 - Bin Locations for Field Service
									}

								}
								if (invItem.invpool == "customer" && (invItem.invtype == "OPEN" || invItem.invtype == "EXPECTED")) {

									if (isNaN(itemQty)) {
										ontheway_qty = 0;
									} else {
										ontheway_qty += itemQty;
									}


								}
								if (invItem.invpool == "deinstall" && (invItem.invtype == "SUBINVENTORY" || invItem.invtype == "CAR_STOCK")) {

									if (isNaN(itemQty)) {
										required_qty = 0;
									} else {
										required_qty += itemQty;
									}


								}
								if (invItem.invpool == "install" && (invItem.invtype == "SUBINVENTORY" || invItem.invtype == "CAR_STOCK")) {

									if (isNaN(itemQty)) {
										installed_qty = 0;
									} else {
										installed_qty += itemQty;
									}


								}

								console.log(instock_qty);
								inventoryListFilteredGrouped[itemNum] = {
									InStock: instock_qty,
									OntheWay: ontheway_qty,
									InstalledQty: installed_qty,
									ReqQty: required_qty,
									Compatible: compatible_qty,
									I_ITEM_NUMBER: invItem.I_ITEM_NUMBER,
									I_ITEM_DESCRIPTION: invItem.I_ITEM_DESCRIPTION,
									I_PRICE: invItem.I_PRICE,
									I_SUBINVENTORY: invItem.I_SUBINVENTORY,
									I_SUBINVENTORY_NAME: invItem.I_SUBINVENTORY_NAME,
									inv_aid: invItem.inv_aid,
									invtype: invItem.invtype,
									invpool: invItem.invpool,
									invid: invItem.invid,
									inv_pid: invItem.inv_pid,
									quantity: invItem.quantity,
									I_RETURN_VENDOR: invItem.I_RETURN_VENDOR,
									I_ITEM_DISPOSITION: invItem.I_ITEM_DISPOSITION,
									I_ITEM_COST: invItem.I_ITEM_COST,
									I_CURRENT_MAX: invItem.I_CURRENT_MAX,
									I_CURRENT_MIN: invItem.I_CURRENT_MIN,
									I_SUB_INV_NAMES: subInvNames,
									binNames:binNames // Added for CHG0075456 - Bin Locations for Field Service

								};
							}
						});



						//Search for PartsCatalog JSON and add the append if item found. and get the compatible count.

						$.each(inventoryListFilteredGrouped, function (key, invListFiltGrp) {

							var itemNumb = invListFiltGrp.I_ITEM_NUMBER;
							if (partsCatalogJSON[itemNumb]) {

								var compatibleQty = partsCatalogJSON[itemNumb].Compatible;
								//update the same qty to the main List.
								if (inventoryListFilteredGrouped[itemNumb]) {

									inventoryListFilteredGrouped[itemNumb].Compatible = compatibleQty;
									//since a match Found already in sub inventory list remove the item from partsCatalogJSON
									delete partsCatalogJSON[itemNumb];

								}

							}


						});
						//modified for  INC1470911:for displaying car-stock items first.
						var partsArray = [];
						$.each(inventoryListFilteredGrouped, function (key, invListFiltGrp) {
							partsArray.push(invListFiltGrp.I_ITEM_NUMBER);
						}
						);
						$.each(partsCatalogJSON, function (key, invList) {
							partsArray.push(invList.I_ITEM_NUMBER);
						}
						);

						//The left over partsCatalogJSON should be merged with the main subinventory list.
						$.extend(inventoryListFilteredGrouped, partsCatalogJSON);
						// Build the Dynamic UI
						// append the Found Parts header.

						//removed the submit button as a part of change request CHG0070441 
						$("#activityInventoryGrid").append('<div id="foundPartsHeaderDiv" class="activity-inventory-header">\
													  <div class="grid-header-icon cpf_1-0" style="">\
														 <div class="icon icon-provider">\
															<div class="inner"></div>\
														 </div>\
													  </div>\
													  <div class="activity-inventory-header-title cpf_1-1" style="">Found parts (<span id="found_parts_count"></span>)<span style="font-size:10pt"> The max quantity that can be installed/ordered is 999</span></div>\
												  </div>');


						//dynamicBuildInstallPartsElementFunction for manual parts
						$.dynamicBuildInstallPartsElementFunction = function (inventoryListFilteredGrouped, min, max, linkedItemsTrue, parentItemNumber) {
							for (var i = 0; i < partsArray.length; i++) {
								$.each(inventoryListFilteredGrouped, function (key, invItem) {

									var bindVar = this; var checkMatchingaid = true;
									if ((partsArray[i] == invItem.I_ITEM_NUMBER && !linkedItemsTrue) || (partsArray[i] == parentItemNumber && linkedItemsTrue)) {
										if ((invItem.inv_aid == "" || invItem.inv_aid == null || typeof invItem.inv_aid === undefined) || (invItem.inv_aid == activityId)) {
											var itemNumber = invItem.I_ITEM_NUMBER;
											var currRowIndex = Object.keys(inventoryListFilteredGrouped).indexOf(key);
											if ((currRowIndex > min && currRowIndex <= max) || (linkedItemsTrue && currRowIndex == 0) || (firstTimeLoopItemsTrue && currRowIndex == 0)) {

												var instQtydisplay = "";
												var neededQtydisplay = "";
												var instQtyEnter = 0;
												var neededQtyEnter = 0;


												firstTimeLoopItemsTrue = false;
												uiRowCount = uiRowCount + 1;

												if (invItem.InstalledQty > 0) {
													instQtydisplay = '(' + invItem.InstalledQty + ')';
													instQtyEnter = invItem.InstalledQty;
												}
												if (invItem.ReqQty > 0) {
													neededQtydisplay = '(' + invItem.ReqQty + ')'; //'+neededQtydisplay+'
													neededQtyEnter = invItem.ReqQty;
												}
												var className = "cp_hidden";
												if (invItem.Compatible > 0) {
													className = "";
												}
												var returnableClassname = "cp_hidden";
												var disposition = invItem.I_ITEM_DISPOSITION;
												if (disposition) {
													if (disposition.toLowerCase() == "returnable" || disposition.toLowerCase() == "repairable") {
														returnableClassname = "";
													}
												}
												var priceDisplayForItem = "";
												if (invItem.I_PRICE) {

													priceDisplayForItem = '(Price: $' + invItem.I_PRICE + ')';
												}
												var item_Description = "";
												if (invItem.I_ITEM_DESCRIPTION) {
													item_Description = invItem.I_ITEM_DESCRIPTION;
												}
												var iCurrentMax = "";

												if (invItem.I_CURRENT_MAX) {
													iCurrentMax = invItem.I_CURRENT_MAX;
												}
												//CHG0080805 start
												if(invItem.I_MAX){
													iCurrentMax = invItem.I_MAX;
												}
												////CHG0080805 end

												var iCurrentMin = "";

												if (invItem.I_CURRENT_MIN) {
													iCurrentMin = invItem.I_CURRENT_MIN;
												}
													//CHG0080805 start
												if(invItem.I_MIN){
													iCurrentMin = invItem.I_MIN;
													
												}
												var qty = parseInt(invItem.quantity);
												
												if (isNaN(qty)) {

														qty = 0; 
													} 
													else{
												
														qty = parseInt(invItem.quantity);
													}
														//CHG0080805 end
											

												var itemNumberHTML = '<div id="cpf_' + itemNumber.replace(/[/]/g, "") + '" class="activity-inventory-grid-row">\
							  <div id="activity-inventory-left-cell-'+ lineCountForItems + '-' + itemNumber.replace(/[/]/g, "") + '" class="activity-inventory-left-cell cpf_0-0">\
							  <div class="activity-inventory-part-number cpf_0-0-0">' + itemNumber + '</div>\
							  <div class="activity-inventory-description cpf_0-0-1">' + item_Description + '</div>\
							  <div class="activity-inventory-price cpf_0-0-2">' + priceDisplayForItem + '</div>\
							  <div class="activity-inventory-item-is-returnable cpf_0-0-3 '+ returnableClassname + '">(This part is returnable)</div>\
							  <div class="activity-inventory-price cpf_0-0-2">Max: <b>' + iCurrentMax + '</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Min: <b>' + iCurrentMin + '</b></div>\
							  <div class="activity-inventory-price cpf_0-0-2"><b>&nbsp;&nbsp;' + invItem.I_SUB_INV_NAMES + '</b></div>\
							  <div class="activity-inventory-quantity-data cpf_0-0-4">\
								 <div class="activity-inventory-qunatity activity-inventory-qunatity-car-stock cpf_0-0-4-0">\
									<div class="activity-inventory-quantity-label cpf_0-0-4-0-0">In Stock:</div>\
									<div class="activity-inventory-quantity-value cpf_0-0-4-0-1">' + qty + '</div>\
								 </div>\
								 <div class="activity-inventory-qunatity activity-inventory-qunatity-on-the-way cpf_0-0-4-1">\
									<div class="activity-inventory-quantity-label cpf_0-0-4-1-0">On the Way:</div>\
									<div class="activity-inventory-quantity-value cpf_0-0-4-1-1">' + invItem.OntheWay + '</div>\
								 </div>\
								 <div class="activity-inventory-qunatity activity-inventory-qunatity-on-the-way cpf_0-0-4-2">\
									<div class="activity-inventory-quantity-label cpf_0-0-4-2-0">Installed:</div>\
									<div id="installedQtyDisplay" class="activity-inventory-quantity-value cpf_0-0-4-2-1">' + invItem.InstalledQty + '</div>\
									<div id="OriginalinstalQty" class="activity-inventory-quantity-value cp_hidden">' + invItem.InstalledQty + '</div>\
								 </div>\
								 <div class="activity-inventory-qunatity activity-inventory-qunatity-on-the-way cpf_0-0-4-3">\
									<div class="activity-inventory-quantity-label cpf_0-0-4-3-0">Required:</div>\
									<div id="neededQtyDisplay" class="activity-inventory-quantity-value cpf_0-0-4-3-1">' + invItem.ReqQty + '</div>\
									<div id="OriginalneededQty" class="activity-inventory-quantity-value cp_hidden">' + invItem.ReqQty + '</div>\
								 </div>\
								 <div class="activity-inventory-qunatity activity-inventory-qunatity-compatible cpf_0-0-4-4">\
									<span  id="compatibleLink" class="cp_plugin_link activity-inventory-dashed-link ' + className + '">Compatible: ' + invItem.Compatible + '</span>\
								 </div>\
								 <div class="activity-inventory-qunatity activity-inventory-qunatity-sub-inventory cpf_0-0-4-7">\
									<div class="activity-inventory-quantity-label cpf_0-0-4-7-0">Sub-Inventory:*</div>\
									<div id="subInventoryList'+ itemNumber.replace(/[/]/g, "") + '" class="activity-inventory-quantity-value cpf_0-0-4-7-1">\
										' + $("#subInvDD").html() +
													'</div>\
								 </div>\
								 <div class="activity-inventory-qunatity activity-inventory-qunatity-install-quantity cpf_0-0-4-5">\
									<div class="activity-inventory-quantity-label cpf_0-0-4-5-0">Install Quantity:</div>\
									<div id="neededQtyDisplay" class="activity-inventory-quantity-value cpf_0-0-4-5-1">\
										<input id="cpf_entered_install_qty" type="number" class="max-width-70 cp_field_text_component cp_field_spinner_component form-item install-item-quantity" maxlength="3" value="0" data-return-vendor = "'+ bindVar.I_RETURN_VENDOR + '"  data-item-disposition = "' + bindVar.I_ITEM_DISPOSITION + '" data-item-cost="' + bindVar.I_ITEM_COST + '" data-item-price= "' + bindVar.I_PRICE + '" data-item-description="' + bindVar.I_ITEM_DESCRIPTION + '" data-item-number="' + bindVar.I_ITEM_NUMBER + '" line-count-items="' + lineCountForItems + '">\
									</div>\
								 </div>\
								 <div class="activity-inventory-qunatity activity-inventory-qunatity-required-quantity cpf_0-0-4-6">\
									<div class="activity-inventory-quantity-label cpf_0-0-4-6-0">Required Quantity:</div>\
									<div id="neededQtyDisplay" class="activity-inventory-quantity-value cpf_0-0-4-6-1">\
									<input id="cpf_entered_needed_qty" type="number" class="max-width-70 cp_field_text_component cp_field_spinner_component form-item required-item-quantity" maxlength="3" value="0" data-return-vendor = "'+ bindVar.I_RETURN_VENDOR + '"  data-item-disposition = "' + bindVar.I_ITEM_DISPOSITION + '" data-item-cost="' + bindVar.I_ITEM_COST + '" data-item-price= "' + bindVar.I_PRICE + '" data-item-description="' + bindVar.I_ITEM_DESCRIPTION + '" data-item-number="' + bindVar.I_ITEM_NUMBER + '" line-count-items="' + lineCountForItems + '">\
									</div>\
								 </div>\
							  </div>\
							  <div class="activity-inventory-err-msg cpf_0-0-5">\
								  <div id="qtyGreaterErrorMsg" class="cp_wrapper activity-inventory-warning-msg cp_hidden">\
										<div id="message" class="cp_text_block">Input quantity is greater than quantity in sub-inventory.</div>\
								  </div>\
							  </div>\
						   </div>\
							 <div class=" cpf_0-2">\
								  <div id="cpf_LinkedItems_' + itemNumber.replace(/[/]/g, "") + '" class="cpf_grid_wrapper activity-inventory-inner-grid cp_hidden"></div>\
							   </div>\
							</div>';
												if (!linkedItemsTrue) {
													$("#activityInventoryGrid").append(itemNumberHTML);
												} else {
													$("#cpf_LinkedItems_" + parentItemNumber.replace(/[/]/g, "")).append(itemNumberHTML);
													$("#cpf_LinkedItems_" + parentItemNumber.replace(/[/]/g, "")).removeClass("cp_hidden");
												}


												// on change of DD:
												$('#activity-inventory-left-cell-' + lineCountForItems + '-' + itemNumber.replace(/[/]/g, "")).find('#subInventoryListSelectDropDown').on('change', function (e) {
													var selectediSubInventory = $(this).val();
													var itemN = bindVar.I_ITEM_NUMBER;
													var subInventory_provider_qty = "NA";
													// perform a search on the inventory list to get the quantity.
													$.each(inventoryList, function (kiy, invItems) {
														if (invItems.I_ITEM_NUMBER == itemN) {
															if ((invItems.invpool == "provider") && (invItems.I_SUBINVENTORY == selectediSubInventory)) {
																subInventory_provider_qty = invItems.quantity;
															}
														}
													});
													// set the "of" quantity for each sub-inventory selected from the DD.
													subInventory_provider_qty = parseInt(subInventory_provider_qty);
													if (isNaN(subInventory_provider_qty)) {
														subInventory_provider_qty = "NA";
													}
													$(this).parentsUntil('#activity-inventory-left-cell-' + lineCountForItems + '-' + itemNumber.replace(/[/]/g, "")).find("#cpf_entered_install_qty, #cpf_entered_needed_qty").attr('data-sub-inv-quantity', subInventory_provider_qty);
												});

												//compatible link clicked:
												$('#activity-inventory-left-cell-' + lineCountForItems + '-' + itemNumber.replace(/[/]/g, "")).on('click', '#compatibleLink', function () {
													currItemNumber = bindVar.I_ITEM_NUMBER;
													$.getLinkedPartsRestService(currItemNumber);
												});

												$('#activity-inventory-left-cell-' + lineCountForItems + '-' + itemNumber.replace(/[/]/g, "")).find('.install-item-quantity').on('change keyup paste', function () {
													var enteredQty = parseInt($(this).val());
													// resetting to 0 if user entered value is more than 999
													if (enteredQty > 999) {
														$(this).val(0);
														return false;
													}

													//modification done for CHG0060956
													if (enteredQty > 100) {
														alert("Value is greater than 100. Please notice.")
													}
													//modification done for CHG0060956

													// resetting to 0 for negative values
													if (enteredQty < 0 || isNaN(enteredQty)) {
														$(this).val(0);
														return false;
													} else {
														// To remove leading zeros
														$(this).val(enteredQty);
													}

													var itemN = bindVar.I_ITEM_NUMBER;
													var itemMaxQuantity = $(this).attr('data-sub-inv-quantity');
													var currentIntalledQuantity = $(this).parentsUntil('#activity-inventory-left-cell-' + lineCountForItems + '-' + itemNumber.replace(/[/]/g, "")).find('#installedQtyDisplay').html();
													enteredQty = parseInt(currentIntalledQuantity) + enteredQty;
													if (!isNaN(itemMaxQuantity) && enteredQty > itemMaxQuantity) {
														$(this).parentsUntil('#cpf_' + itemNumber.replace(/[/]/g, "")).find('#qtyGreaterErrorMsg').removeClass('cp_hidden');
													} else {
														$(this).parentsUntil('#cpf_' + itemNumber.replace(/[/]/g, "")).find('#qtyGreaterErrorMsg').addClass('cp_hidden');
													}
												});

												//Trigger on change of sub-inventory DD from code.
												$('#activity-inventory-left-cell-' + lineCountForItems + '-' + itemNumber.replace(/[/]/g, "")).find('#subInventoryListSelectDropDown').trigger('change');

												$('#activity-inventory-left-cell-' + lineCountForItems + '-' + itemNumber.replace(/[/]/g, "")).find('.required-item-quantity').on('change keyup paste', function () {
													var itemN = bindVar.I_ITEM_NUMBER;
													var enteredQty = parseInt($(this).val());
													// resetting to 0 if user entered value is more than 999
													if (enteredQty > 999) {
														$(this).val(0);
														return false;
													}

													//modification done for CHG0060956
													if (enteredQty > 100) {
														alert("Value is greater than 100. Please notice.")
													}
													//modification done for CHG0060956

													// resetting to 0 for negative values
													if (enteredQty < 0 || isNaN(enteredQty)) {
														$(this).val(0);
														return false;
													}
													// To remove leading zeros
													$(this).val(enteredQty);
												});
												lineCountForItems = lineCountForItems + 1;
											}//RowIndex if-
										}// aid
									}
									
								
							});
							}
						}
						// End Modification for INC1470911
						//-----
						$.dynamicBuildInstallPartsElementFunction(inventoryListFilteredGrouped, 0, 15, false, null);

						//set the found parts count // Yet to append the count from the parts catalog items.
						// $("#found_parts_count").text(Object.keys(inventoryListFilteredGrouped).length);
						$("#found_parts_count").text(uiRowCount);
						var totalPartsLength = Object.keys(inventoryListFilteredGrouped).length;
						if (Object.keys(inventoryListFilteredGrouped).length > 15) {

							$("#activityInventoryGridFooter").removeClass("cp_hidden");
							//Load More Button:

							$('#LoadMoreButton').click(function () {
								minShowParts = maxShowParts;
								maxShowParts = maxShowParts + 15;
								console.log("minShowParts " + minShowParts);
								console.log("maxShowParts " + maxShowParts);
								$.dynamicBuildInstallPartsElementFunction(inventoryListFilteredGrouped, minShowParts, maxShowParts, false, null);
								if (maxShowParts > totalPartsLength) {

									//Hide Load more button.
									$("#activityInventoryGridFooter").addClass("cp_hidden");

								}

								$("#found_parts_count").text(uiRowCount);

							});
						}

						// Displaying Logic for MANUAL DIV - Search if a exact search term if found:
						var searchKeyArray = searchKeyword.toUpperCase().split(',');
						var manualPartsElements = "";
						displayManualAdditionSection = false;
						$.each(searchKeyArray, function (key, searchKeyValue) {
							if (!inventoryListFilteredGrouped[searchKeyValue]) {
								displayManualAdditionSection = true;
								manualPartsElements = manualPartsElements + '<div id="cpf_' + searchKeyValue.replace(/[/]/g, "") + '" class="cp_wrapper">\
							<div id="activity-inventory-left-cell-' + searchKeyValue.replace(/[/]/g, "") + '" class="activity-inventory-left-cell cpf_0-0">\
							  <div class="activity-inventory-part-number cpf_0-0-0">' + searchKeyValue + '</div>\
							  <div class="activity-inventory-quantity-data cpf_0-0-4">\
								 <div class="activity-inventory-qunatity activity-inventory-qunatity-car-stock cpf_0-0-4-0">\
									<div class="activity-inventory-quantity-label cpf_0-0-4-0-0">In Stock:</div>\
									<div class="activity-inventory-quantity-value cpf_0-0-4-0-1">0</div>\
								 </div>\
								 <div class="activity-inventory-qunatity activity-inventory-qunatity-sub-inventory cpf_0-0-4-4">\
									<div class="activity-inventory-quantity-label cpf_0-0-4-4-0">Sub-Inventory:*</div>\
									<div id="neededQtyDisplay" class="activity-inventory-quantity-value cpf_0-0-4-4-1">\
										' + $("#subInvDD").html() +
									'</div>\
								 </div>\
								 <div class="activity-inventory-qunatity activity-inventory-qunatity-install-quantity cpf_0-0-4-5">\
									<div class="activity-inventory-quantity-label cpf_0-0-4-5-0">Install Quantity:</div>\
									<div id="neededQtyDisplay" class="activity-inventory-quantity-value cpf_0-0-4-5-1">\
										<input id="cpf_entered_qty" type="number" class="max-width-70 cp_field_text_component cp_field_spinner_component form-item install-item-quantity" maxlength="3" value="0" data-item-num = '+ searchKeyValue + '>\
									</div>\
								 </div>\
								 <div class="activity-inventory-qunatity activity-inventory-qunatity-required-quantity cpf_0-0-4-6">\
									<div class="activity-inventory-quantity-label cpf_0-0-4-6-0">Required Quantity:</div>\
									<div id="neededQtyDisplay" class="activity-inventory-quantity-value cpf_0-0-4-6-1">\
									<input id="cpf_entered_qty" type="number" class="max-width-70 cp_field_text_component cp_field_spinner_component form-item required-item-quantity" maxlength="3" value="0" data-item-num = '+ searchKeyValue + '>\
									</div>\
								 </div>\
							  </div>\
							</div>\
							</div>';
							}
						});
						var ItemNumber_searchKeyword = searchKeywordOrig;
						if (displayManualAdditionSection) {
							$("#manualPartsAdditionSection").append('<div id="manual-part-addition" class="cp_section manual-part-addition">\
								<div id="cpf__unnamed_6_header" class="cp_section_header">Manual addition\
                        			<div id="cpf__unnamed_7" class="cp_text_block invitation-text">Part(s) Not found, please validate part number and proceed with debrief/order if valid.</div>\
                        		</div>\
								<div id="cpf__unnamed_6_body" class="cp_section_body">\
                        			'+ manualPartsElements + '\
                        		</div>\
                        	</div>');
						}

						$('#manual-part-addition .install-item-quantity').on('change keyup paste', function () {
							var enteredQty = parseInt($(this).val());
							// resetting to 0 if user entered value is more than 999
							if (enteredQty > 999) {
								$(this).val(0);
								return false;
							}

							//modification done for CHG0060956
							if (enteredQty > 100) {
								alert("Value is greater than 100. Please notice.")
							}
							//modification done for CHG0060956

							// resetting to 0 for negative values
							if (enteredQty < 0 || isNaN(enteredQty)) {
								$(this).val(0);
								return false;
							}

							// To remove leading zeros
							$(this).val(enteredQty);

							var installItemNumber = $(this).attr("data-item-num");
							var itemKey = installItemNumber + "_install";
							if (enteredQty > 0) {
								if (dataItemsToProcess.indexOf('installedInventories') !== -1) {
									dataItemsToProcess.splice(dataItemsToProcess.indexOf('installedInventories'), 1);
								}

								var selectediSubInventory = $(this).parentsUntil('#activity-inventory-left-cell-' + installItemNumber.replace(/[/]/g, "")).find("#subInventoryListSelectDropDown").val();
								var inventoryType = "SUBINVENTORY";
								if (selectediSubInventory == "CAR_STOCK") {
									inventoryType = "CAR_STOCK";
								} else {
									inventoryType = "SUBINVENTORY";
								}

								var invKey = resourceID + installItemNumber + selectediSubInventory;
								var inventoryType = "CAR_STOCK";
								$.extend(itemNumberActionsListJSONData, {
									[itemKey]: {
										"action": "create",
										"inv_pid": resource_pid + '',
										"inv_aid": activityId,
										"invtype": inventoryType,
										"quantity": enteredQty + '',
										"invpool": "install",
										"entity": "inventory",
										"properties": {
											"I_ITEM_NUMBER": installItemNumber,
											"I_INVENTORY_KEY": invKey
										}
									}
								});
								console.log("itemNumberActionsListJSONData " + JSON.stringify(itemNumberActionsListJSONData));
							} else {
								delete itemNumberActionsListJSONData[itemKey];
							}
						});

						$('#manual-part-addition .required-item-quantity').on('change paste keyup', function () {
							var enteredQty = parseInt($(this).val());
							// resetting to 0 if user entered value is more than 999
							if (enteredQty > 999) {
								$(this).val(0);
								return false;
							}

							//modification done for CHG0060956
							if (enteredQty > 100) {
								alert("Value is greater than 100. Please notice.")
							}
							//modification done for CHG0060956

							// resetting to 0 for negative values
							if (enteredQty < 0 || isNaN(enteredQty)) {
								$(this).val(0);
								return false;
							}

							// To remove leading zeros
							$(this).val(enteredQty);

							var installItemNumber = $(this).attr("data-item-num");
							var itemKey = installItemNumber + "_deinstall";
							if (enteredQty > 0) {
								if (dataItemsToProcess.indexOf('deinstalledInventories') !== -1) {
									dataItemsToProcess.splice(dataItemsToProcess.indexOf('deinstalledInventories'), 1);
								}

								var selectediSubInventory = $(this).parentsUntil('#activity-inventory-left-cell-' + installItemNumber.replace(/[/]/g, "")).find("#subInventoryListSelectDropDown").val();
								var inventoryType = "SUBINVENTORY";
								if (selectediSubInventory == "CAR_STOCK") {
									inventoryType = "CAR_STOCK";
								} else {
									inventoryType = "SUBINVENTORY";
								}

								var invKey = resourceID + installItemNumber + selectediSubInventory;
								$.extend(itemNumberActionsListJSONData, {
									[itemKey]: {
										"action": "create",
										"inv_pid": resource_pid + '',
										"inv_aid": activityId,
										"invtype": inventoryType,
										"quantity": enteredQty + '',
										"invpool": "deinstall",
										"entity": "inventory",
										"properties": {
											"I_ITEM_NUMBER": installItemNumber,
											"I_INVENTORY_KEY": invKey
										}
									}
								});
								console.log("itemNumberActionsListJSONData " + JSON.stringify(itemNumberActionsListJSONData));
							} else {
								delete itemNumberActionsListJSONData[itemKey];
							}
						});

						$("#submitAllParts").click(function () {
							console.log("itemNumberActionsListJSONData : ", itemNumberActionsListJSONData);
							console.log("inventoryListJSONData : ", inventoryListJSONData);
							console.log("actionsArr : ", actionsArr);

							$('.activity-inventory-grid-row .activity-inventory-left-cell .install-item-quantity').each(function () {
								var enteredQty = parseInt($(this).val());
								if (enteredQty > 0) {
									var dataItemNumber = $(this).attr('data-item-number');
									var dataItemDescription = $(this).attr('data-item-description');
									if (dataItemDescription == null || 'undefined' == dataItemDescription || 'null' == dataItemDescription) {
										dataItemDescription = "";
									}
									var dataReturnVendor = $(this).attr('data-return-vendor');
									if (dataReturnVendor == null || 'undefined' == dataReturnVendor || 'null' == dataReturnVendor) {
										dataReturnVendor = "";
									}
									var dataItemDisposition = $(this).attr('data-item-disposition');
									if (dataItemDisposition == null || 'undefined' == dataItemDisposition || 'null' == dataItemDisposition) {
										dataItemDisposition = "";
									}
									var dataItemCost = $(this).attr('data-item-cost');
									if (dataItemCost == null || 'undefined' == dataItemCost || 'null' == dataItemCost) {
										dataItemCost = "";
									}
									var dataItemPrice = $(this).attr('data-item-price');
									if (dataItemPrice == null || 'undefined' == dataItemPrice || 'null' == dataItemPrice) {
										dataItemPrice = "";
									}
									var dataLineCountItems = $(this).attr('line-count-items');

									var currentIntalledQuantity = $(this).parentsUntil('#activity-inventory-left-cell-' + dataLineCountItems + '-' + dataItemNumber.replace(/[/]/g, "")).find('#installedQtyDisplay').html();
									enteredQty = parseInt(currentIntalledQuantity) + enteredQty;
									if (dataItemsToProcess.indexOf('installedInventories') !== -1) {
										dataItemsToProcess.splice(dataItemsToProcess.indexOf('installedInventories'), 1);
									}
									var selectediSubInventory = $(this).parentsUntil('#activity-inventory-left-cell-' + dataLineCountItems + '-' + dataItemNumber.replace(/[/]/g, "")).find('#subInventoryListSelectDropDown').val();
									var iSubInventoryName = $(this).parentsUntil('#activity-inventory-left-cell-' + dataLineCountItems + '-' + dataItemNumber.replace(/[/]/g, "")).find('#subInventoryListSelectDropDown option:selected').text();
									var subInventory_install_qty = "NA",
										subInventory_resource_qty = 0;
									var matchInstallItemFound = false,
										matchResourceItemFound = false;
									var newInstallQty = 0,
										newResourceQty = 0;
									var installItemInvID = null,
										resourceItemInvID = null;
									var inventoryType = "SUBINVENTORY";
									if (selectediSubInventory == "CAR_STOCK") {
										inventoryType = "CAR_STOCK";
									} else {
										inventoryType = "SUBINVENTORY";
									}
									$.each(inventoryList, function (kiy, invItems) {
										if (invItems.I_ITEM_NUMBER == dataItemNumber) {
											if ((invItems.invpool == "install") && (invItems.I_SUBINVENTORY == selectediSubInventory) && (invItems.inv_aid == receivedData.activity.aid)) {
												subInventory_install_qty = parseInt(invItems.quantity);
												matchInstallItemFound = true;
												newInstallQty = enteredQty + subInventory_install_qty;
												installItemInvID = invItems.invid;
											}
											if ((invItems.invpool == "provider") && (invItems.I_SUBINVENTORY == selectediSubInventory)) {
												subInventory_resource_qty = parseInt(invItems.quantity);
												matchResourceItemFound = true;
												newResourceQty = subInventory_resource_qty - enteredQty;
												resourceItemInvID = invItems.invid;
											}
										}
									});

									var itemKey = dataItemNumber + "_install";
									var invKey = resourceID + dataItemNumber + selectediSubInventory;
									var invID = installItemInvID;

									if (matchResourceItemFound) {
										if (subInventory_install_qty === 'NA') {
											subInventory_install_qty = 0;
										}

										if (subInventory_install_qty > enteredQty) {
											//undo install of difference
											var diff = subInventory_install_qty - enteredQty;
											$.extend(globalInstallItems, {
												[dataItemNumber]: {
													subInv: selectediSubInventory,
													quantity: -Math.abs(diff)
												}
											});
											$.extend(itemNumberActionsListJSONData, {
												[resourceItemInvID]: {
													"action": "undo_install",
													"quantity": diff + '',
													"invid": installItemInvID,
													"entity": "inventory"
												}
											});
										}

										if (subInventory_install_qty < enteredQty) {
											// install of difference
											if (subInventory_install_qty == 0) {
												enteredQty = enteredQty - parseInt(currentIntalledQuantity);
											}
											var diff = enteredQty - subInventory_install_qty;
											$.extend(globalInstallItems, {
												[dataItemNumber]: {
													subInv: selectediSubInventory,
													quantity: diff
												}
											});
											$.extend(itemNumberActionsListJSONData, {
												[resourceItemInvID]: {
													"action": "install",
													"inv_pid": resource_pid + '',
													"inv_aid": activityId,
													"invtype": inventoryType,
													"quantity": diff + '',
													"invid": resourceItemInvID,
													"entity": "inventory",
													"properties": {
														"I_ITEM_NUMBER": dataItemNumber,
														"I_SUBINVENTORY": selectediSubInventory,
														"I_SUBINVENTORY_NAME": iSubInventoryName,
														"I_RETURN_VENDOR": dataReturnVendor,
														"I_ITEM_DISPOSITION": dataItemDisposition,
														"I_ITEM_COST": dataItemCost,
														"I_PRICE": dataItemPrice,
														"I_ITEM_DESCRIPTION": dataItemDescription,
														"I_INVENTORY_KEY": invKey
													}
												}
											});
										}
									} else {
										if (matchInstallItemFound) {
											$.extend(inventoryListJSONData, {
												[installItemInvID]: {
													"quantity": enteredQty + ''
												}
											});
											invID = installItemInvID;
										} else {
											enteredQty = enteredQty - parseInt(currentIntalledQuantity);
											$.extend(itemNumberActionsListJSONData, {
												[itemKey]: {
													"action": "create",
													"inv_pid": resource_pid + '',
													"inv_aid": activityId,
													"invtype": inventoryType,
													"quantity": enteredQty + '',
													"invpool": "install",
													"entity": "inventory",
													"properties": {
														"I_ITEM_NUMBER": dataItemNumber,
														"I_SUBINVENTORY": selectediSubInventory,
														"I_SUBINVENTORY_NAME": iSubInventoryName,
														"I_RETURN_VENDOR": dataReturnVendor,
														"I_ITEM_DISPOSITION": dataItemDisposition,
														"I_ITEM_COST": dataItemCost,
														"I_PRICE": dataItemPrice,
														"I_ITEM_DESCRIPTION": dataItemDescription,
														"I_INVENTORY_KEY": invKey
													}
												}
											});
										}
									}
								}
							});


							$('.activity-inventory-grid-row .activity-inventory-left-cell .required-item-quantity').each(function () {
								var enteredQty = parseInt($(this).val());
								if (enteredQty > 0) {
									var dataItemNumber = $(this).attr('data-item-number');
									var dataItemDescription = $(this).attr('data-item-description');
									if (dataItemDescription == null || 'undefined' == dataItemDescription || 'null' == dataItemDescription) {
										dataItemDescription = "";
									}
									var dataReturnVendor = $(this).attr('data-return-vendor');
									if (dataReturnVendor == null || 'undefined' == dataReturnVendor || 'null' == dataReturnVendor) {
										dataReturnVendor = "";
									}
									var dataItemDisposition = $(this).attr('data-item-disposition');
									if (dataItemDisposition == null || 'undefined' == dataItemDisposition || 'null' == dataItemDisposition) {
										dataItemDisposition = "";
									}
									var dataItemCost = $(this).attr('data-item-cost');
									if (dataItemCost == null || 'undefined' == dataItemCost || 'null' == dataItemCost) {
										dataItemCost = "";
									}
									var dataItemPrice = $(this).attr('data-item-price');
									if (dataItemPrice == null || 'undefined' == dataItemPrice || 'null' == dataItemPrice) {
										dataItemPrice = "";
									}
									var dataLineCountItems = $(this).attr('line-count-items');

									var currentNeededQuantity = $(this).parentsUntil('#activity-inventory-left-cell-' + dataLineCountItems + '-' + dataItemNumber.replace(/[/]/g, "")).find('#neededQtyDisplay').html();
									enteredQty = parseInt(currentNeededQuantity) + enteredQty;
									if (dataItemsToProcess.indexOf('deinstalledInventories') !== -1) {
										dataItemsToProcess.splice(dataItemsToProcess.indexOf('deinstalledInventories'), 1);
									}
									var selectediSubInventory = $(this).parentsUntil('.activity-inventory-left-cell').find('#subInventoryListSelectDropDown').val();
									var iSubInventoryName = $(this).parentsUntil('.activity-inventory-left-cell').find('#subInventoryListSelectDropDown option:selected').text();
									var subInventory_deinstall_qty = "NA",
										subInventory_resource_qty = 0;
									var matchDeInstallItemFound = false,
										matchResourceItemFound = false;
									var newDeInstallQty = 0,
										newResourceQty = 0;
									var deinstallItemInvID = '',
										resourceItemInvID = '';
									var inventoryType = "SUBINVENTORY";
									if (selectediSubInventory == "CAR_STOCK") {
										inventoryType = "CAR_STOCK";
									} else {
										inventoryType = "SUBINVENTORY";
									}
									$.each(inventoryList, function (kiy, invItems) {
										if (invItems.I_ITEM_NUMBER == dataItemNumber) {
											if ((invItems.invpool == "deinstall") && (invItems.I_SUBINVENTORY == selectediSubInventory) && (invItems.inv_aid == receivedData.activity.aid)) {
												subInventory_deinstall_qty = parseInt(invItems.quantity);
												matchDeInstallItemFound = true;
												newDeInstallQty = enteredQty + subInventory_deinstall_qty;
												deinstallItemInvID = invItems.invid;
											}
											if ((invItems.invpool == "provider") && (invItems.I_SUBINVENTORY == selectediSubInventory)) {
												subInventory_resource_qty = parseInt(invItems.quantity);
												matchResourceItemFound = true;
												newResourceQty = subInventory_resource_qty - enteredQty;
												resourceItemInvID = invItems.invid;
											}
										}
									});

									var itemKey = dataItemNumber + "_deinstall";
									var invKey = resourceID + dataItemNumber + selectediSubInventory;
									var invID = deinstallItemInvID;
									if (matchDeInstallItemFound) {
										$.extend(inventoryListJSONData, {
											[deinstallItemInvID]: {
												quantity: enteredQty + ''
											}
										});
									} else {
										enteredQty = enteredQty - parseInt(currentNeededQuantity);
										$.extend(itemNumberActionsListJSONData, {
											[itemKey]: {
												"action": "create",
												"inv_pid": resource_pid + '',
												"inv_aid": activityId,
												"invtype": inventoryType,
												"quantity": enteredQty + '',
												"invpool": "deinstall",
												"entity": "inventory",
												"properties": {
													"I_ITEM_NUMBER": dataItemNumber,
													"I_SUBINVENTORY": selectediSubInventory,
													"I_SUBINVENTORY_NAME": iSubInventoryName,
													"I_RETURN_VENDOR": dataReturnVendor,
													"I_ITEM_DISPOSITION": dataItemDisposition,
													"I_ITEM_COST": dataItemCost,
													"I_PRICE": dataItemPrice,
													"I_ITEM_DESCRIPTION": dataItemDescription,
													"I_INVENTORY_KEY": invKey
												}
											}
										});
									}
									console.log("inventoryListJSONData " + JSON.stringify(inventoryListJSONData));
									console.log("itemNumberActionsListJSONData " + JSON.stringify(itemNumberActionsListJSONData));
								}
							});

							console.log("itemNumberActionsListJSONData : ", itemNumberActionsListJSONData);
							console.log("inventoryListJSONData : ", inventoryListJSONData);
							console.log("actionsArr : ", actionsArr);

							//on submit
							$.each(globalInstallItems, function (i, v) {
								$.each(riData, function (k, val) {
									if (i === val.I_ITEM_NUMBER && v.subInv === val.I_SUBINVENTORY) {
										val.quantity -= v.quantity;
									}
								});
							});

							localStorage.ri = JSON.stringify(riData);
							localStorage.storageDataItems = dataItemsToProcess;
							var actionsArr = [];
							$.each(itemNumberActionsListJSONData, function (kiy, actionArrItems) {
								actionsArr.push(actionArrItems);
							});

							// close method.
							var closeJsonToSend = {
								"apiVersion": 1,
								"method": "close",
								"backScreen": "default",
								"wakeupNeeded": false,
								"inventoryList": inventoryListJSONData,
								"actions": actionsArr
							};
							
								// start CHG0082493
							
							var flagone;
				
	
						
							
							for (flagone in closeJsonToSend.actions)
							{
						
									if (closeJsonToSend.actions[flagone].properties.I_ITEM_DISPOSITION == "Repairable"
									|| closeJsonToSend.actions[flagone].properties.I_ITEM_DISPOSITION == "Returnable")
									{
										 
										 alert("The part " + closeJsonToSend.actions[flagone].properties.I_ITEM_NUMBER  + " debriefed is a Repairable/Returnable item.");
										
                                       
									}
							}
							
							// End CHG0082493

							if (fslRequest) {
								fslRequest = fslRequest.replace(/\<\/items\>/g, ''); //fix made for INC1572970 
								fslRequest = fslRequest + "</items>";
							}
							$.extend(closeJsonToSend, {
								"activity": {
									"aid": activityId,
									"A_FSL_REQUEST": fslRequest,
									"A_WAREHOUSE_REQUEST": fslRequest
								}
							});
							//Need to update 2 activity fields as well.
							console.log("closeJsonToSend " + JSON.stringify(closeJsonToSend));

							ultimateBind._sendPostMessageData(closeJsonToSend);

						}.bind(this));

						btnSearch = false;
						//added for  INC1499701
					} //added for  INC1499701


				}; // entire big function call back close.

				$.processLinkedItemsResultsFnCallBck = function (linkeditemsResponseData) {

					var linkedItemsArray = [];
					$.each(linkeditemsResponseData.resultData.items, function (i, a) {

						
						if(a.fields.ITEM_NUMBER==currItemNumber){
							linkedItemsArray.push(a.linkedItems);
							console.log("Linked Items : ", a.linkedItems);
						}
						

					});
					var linkedItemArray = linkedItemsArray;
					var parentItemNumber = currItemNumber;
					
					

					var linkedItemsJSON = {};

					//only if valid response proceed.
					if (linkedItemArray) {
						$("#cpf_LinkedItems_" + parentItemNumber.replace(/[/]/g, "")).html('');
						for (var i = 0; i < linkedItemArray[0].length; i++) {

							var obj = linkedItemArray[0][i];
							var linkedItemNumber = obj.label;
							console.log("Label : ", obj.label); // item Number
							 $.getCompatiblePartDetails(linkedItemNumber);   //CHG0082493 

							linkedItemsJSON[linkedItemNumber] = {
								InStock: 0,
								OntheWay: 0,
								InstalledQty: 0,
								ReqQty: 0,
								Compatible: 0,
								I_ITEM_NUMBER: linkedItemNumber,
								I_ITEM_DESCRIPTION: compatibleObj.resultData.items[0].fields.ITEM_DESCRIPTION,        //CHG0082493
								I_PRICE: compatibleObj.resultData.items[0].fields.ITEM_PRICE,                         // CHG0082493
								I_SUBINVENTORY: "",
								I_SUBINVENTORY_NAME: "",
								I_RETURN_VENDOR: compatibleObj.resultData.items[0].fields.VENDOR,                      // CHG0082493
								I_ITEM_DISPOSITION: compatibleObj.resultData.items[0].fields.ITEM_DISPOSITION,          // CHG0082493
								I_ITEM_COST: compatibleObj.resultData.items[0].fields.ITEM_COST,                       // CHG0082493
								I_CURRENT_MAX: "",                                  // CHG0082493
								I_CURRENT_MIN: "",                                  // CHG0082493
								inv_aid: "",
								invtype: "",
								invpool: "",
								invid: "",
								inv_pid: "",
								quantity: "NA",
								I_SUB_INV_NAMES: ""
								
							};
							

						
						}
							
							//CHG0080805 start
							$.each(linkedItemsJSON, function(resInvkey, resInvItem) {
		    				var itemExistCount = 0;
		    				$.each(inventoryList,function(invkey,invItem){
		    					var subInvName = "";
		                        if(invItem.I_SUBINVENTORY == resourceID){
		                        	subInvName = "CAR_STOCK";
									console.log(1);
		                        }else{
		                        	subInvName = invItem.I_SUBINVENTORY
									console.log(2);
		                        }
		    					if(resInvkey == invItem.I_ITEM_NUMBER){
									console.log(3);
		    						if(itemExistCount == 0){
										console.log(4);
		    							linkedItemsJSON[resInvkey].I_MIN = invItem.I_MIN;
		    							linkedItemsJSON[resInvkey].I_MAX = invItem.I_MAX;
		    						}
		    						var resInvItemQty = parseInt(resInvItem.Quantity);
	    							if(isNaN(resInvItemQty)){
	    								resInvItemQty = 0;
										console.log(5);
	    							}
	    							var invItemQty = parseInt(invItem.quantity);
	    							if(isNaN(invItemQty)){
	    								invItemQty = 0;
										console.log(6);
	    							}
									if ((invItem.invpool == "provider") && (invItem.invtype == "SUBINVENTORY" || invItem.invtype == "CAR_STOCK")) {
		    							linkedItemsJSON[resInvkey].quantity = resInvItemQty + invItemQty;
										console.log(7);
									    if(invItemQty > 0){
											console.log(8);
									     	if("" == linkedItemsJSON[resInvkey].I_SUB_INV_NAMES){
												console.log(9);
									     		linkedItemsJSON[resInvkey].I_SUB_INV_NAMES = subInvName+"("+invItemQty+")";
									     	}else{
												console.log(10);
									     		linkedItemsJSON[resInvkey].I_SUB_INV_NAMES = linkedItemsJSON[resInvkey].I_SUB_INV_NAMES+", "+subInvName+"("+invItemQty+")";
									     	}
									    }
									}
		    						if (invItem.invpool == "customer" && (invItem.invtype == "OPEN" || invItem.invtype == "EXPECTED")) {
		    							linkedItemsJSON[resInvkey].OnTheWay = resInvItemQty + invItemQty;
										console.log(11);
		    						}
		    						
		    						itemExistCount = itemExistCount + 1;
		    					}
		    				});
		    				if(itemExistCount = 0){
		    					linkedItemsJSON[resInvkey].I_MIN = "";
		    					linkedItemsJSON[resInvkey].I_MAX = "";
		    				}
		    			});
						
						console.log("linkedItemsJSON " + JSON.stringify(linkedItemsJSON));
						
						// CHG0080805 End
						
						$.dynamicBuildInstallPartsElementFunction(linkedItemsJSON, 0, 15, true, parentItemNumber);
					} else {
						console.log("Some error in response " + JSON.stringify(linkeditemsResponseData));
					}
				};
				$('.searchOthers').removeClass('cp_hidden');
			}.bind(this));

			$("#searchOthers").click(function (event) {

				$.ajax({
					url: window.location.href,
					timeout: 2000,
					cache: false,
					type: 'GET',
					tryCount: 0,
					retryLimit: 3,
					success: function (successData) {
						console.log("online configuration - OtherInventories");
						var searchKeywordOrig = "";
						for (var i = 1; i <= searchFieldCount; i++) {
							if ($.trim($('#searchKeyword' + i).val())) {
								if (searchKeywordOrig != null && searchKeywordOrig != "") {
									searchKeywordOrig = searchKeywordOrig + "," + $.trim($('#searchKeyword' + i).val());
								} else {
									searchKeywordOrig = $.trim($('#searchKeyword' + i).val());
								}
							}
						}

						var urlParameters = "searchKeys=" + searchKeywordOrig + "&searchFieldCount=" + searchFieldCount + "&resourceId=" + resourceID + "&area=" + area + "&managerResourceId=" + managerResourceId;
						var encodeURLParameters = btoa(urlParameters);
						// CHG0075659 - MPF Phase 5 - Logic for Other Inventories navigation on button click
						var otherURL = "";
						if (domainName == "ricoh2.test") {
							otherURL = "https://jcsd.ricohonline.net";
						}

						if (domainName == "ricoh3.test") {
							otherURL = "https://jcsq.ricohonline.net";
						}

						if (domainName == "ricoh4.test") {
							otherURL = "https://jcst.ricohonline.net";
						}

						if (domainName == "ricoh") {
							otherURL = "https://jcsp.ricohonline.net";
						}

						var searchOthersURL = otherURL + "/OFSCSearchParts/RACOFSCSearchParts.jsp?" + encodeURLParameters;
						event.preventDefault();
						event.stopPropagation();

						window.open(searchOthersURL, '_system');
					},
					error: function (xhr, textStatus, errorThrown) {
						if (textStatus == 'timeout') {
							this.tryCount++;
							if (this.tryCount <= this.retryLimit) {
								//try again
								$.ajax(this);
								return false;
							}
							console.log("Offline configuration - OtherInventories");
							OtherInventoriesOffline();
						}
						if (xhr.status == 500) {
							console.log("Offline configuration - OtherInventories");
							OtherInventoriesOffline();
						}
						else {
							console.log("Offline configuration - OtherInventories");
							OtherInventoriesOffline();
						}
					}
				});
				function OtherInventoriesOffline() {
					alert("Parts Search in Others Inventory is not available while in an Offline condition. Check again when network connectivity is restored.");
				}
			}.bind(this));

			this.initAddButtons(document);
			this._clearWakeupData();
			this.initCollapsableKeys(document);
			this.initChangeOfValue(document);
			this.initChangeOfInventoryAction(document);
			this.initChangeOfWakeup(document);
			this.initChangeOfDataItems();

		},



		/**
		 * Business login on plugin wakeup (background open for sync)
		 *
		 * @param {Object} receivedData - JSON object that contain data from OFSC
		 */
		pluginWakeup: function (receivedData) {
			this._log(window.location.host + ' WAKEUP', JSON.stringify(receivedData, null, 4));

			var wakeupData = {
				pluginWakeupCount: +localStorage.getItem('pluginWakeupCount'),
				pluginWakeupMaxCount: +localStorage.getItem('pluginWakeupMaxCount'),
				pluginWakeupDontRespondOn: +localStorage.getItem('pluginWakeupDontRespondOn')
			};

			wakeupData.pluginWakeupCount = wakeupData.pluginWakeupCount + 1;

			localStorage.setItem('pluginWakeupCount', wakeupData.pluginWakeupCount);
			localStorage.setItem('pluginWakeupMaxCount', wakeupData.pluginWakeupMaxCount);
			localStorage.setItem('pluginWakeupDontRespondOn', wakeupData.pluginWakeupDontRespondOn);

			this._log(window.location.host + ' SAVE WAKEUP DATA TO LOCAL STORAGE', JSON.stringify(wakeupData, null, 4));

			if (wakeupData.pluginWakeupDontRespondOn == wakeupData.pluginWakeupCount) {
				this._log(window.location.host + ' EMULATE NOT RESPONDING PLUGIN');

				return;
			}

			if (wakeupData.pluginWakeupCount < wakeupData.pluginWakeupMaxCount) {
				setTimeout(function () {
					this._log(window.location.host + ' SLEEP. RETRY NEEDED');

					this._sendPostMessageData({
						apiVersion: 1,
						method: 'sleep',
						wakeupNeeded: true
					});
				}.bind(this), 2000);
			} else {
				setTimeout(function () {
					this._log(window.location.host + ' SLEEP. NO RETRY');

					this._sendPostMessageData({
						apiVersion: 1,
						method: 'sleep',
						wakeupNeeded: false
					});
				}.bind(this), 12000);
			}
		},

		/**
		 * Save configuration of wakeup (background open for sync) behavior for Plugin
		 * to Local Storage
		 *
		 * @private
		 */
		_saveWakeupData: function () {
			var wakeupData = {
				pluginWakeupCount: 0,
				pluginWakeupMaxCount: 0,
				pluginWakeupDontRespondOn: 0
			};

			if ($('#wakeup').is(':checked')) {
				wakeupData.pluginWakeupMaxCount = parseInt($('#repeat_count').val());

				if ($('#dont_respond').is(':checked')) {
					wakeupData.pluginWakeupDontRespondOn = parseInt($('#dont_respond_on').val());
				}
			}

			localStorage.setItem('pluginWakeupCount', wakeupData.pluginWakeupCount);
			localStorage.setItem('pluginWakeupMaxCount', wakeupData.pluginWakeupMaxCount);
			localStorage.setItem('pluginWakeupDontRespondOn', wakeupData.pluginWakeupDontRespondOn);

			this._log(window.location.host + ' SAVE WAKEUP DATA TO LOCAL STORAGE', JSON.stringify(wakeupData, null, 4));
		},

		/**
		 * Clear previous configuration of wakeup (background open for sync) behavior for Plugin
		 * from the Local Storage
		 *
		 * @private
		 */
		_clearWakeupData: function () {
			localStorage.removeItem('pluginWakeupCount');
			localStorage.removeItem('pluginWakeupMaxCount');
			localStorage.removeItem('pluginWakeupDontRespondOn');

			this._log(window.location.host + ' CLEAR WAKEUP DATA FROM LOCAL STORAGE');
		},

		addMandatoryParam: function (target, key, value) {
			key = key || '';
			value = value || '';

			var clonedElement = $('.example-property').clone().removeClass('example-property').addClass('item--mandatory');

			clonedElement.find('.key').removeClass('writable').removeAttr('contenteditable').text(key);
			clonedElement.find('.value').text(value);

			this.initChangeOfValue(clonedElement);
			this.initItemRemove(clonedElement);

			$(target).parent('.item').after(clonedElement);
		},

		initChangeOfWakeup: function (element) {

			function onWakeupChange(elem) {
				var isChecked = $(elem).is(':checked');

				if (isChecked) {
					$(element).find('#repeat_count').prop('disabled', false);
					$(element).find('#dont_respond').prop('disabled', false);

					$(element).find('#wakeup_row').removeClass('wakeup-form-row--disabled');

					onDontRespondChange($(element).find('#dont_respond'));
				} else {
					$(element).find('#repeat_count').prop('disabled', true);
					$(element).find('#dont_respond').prop('disabled', true);
					$(element).find('#dont_respond_on').prop('disabled', true);

					$(element).find('#wakeup_row').addClass('wakeup-form-row--disabled');
					$(element).find('#dont_respond_row').addClass('wakeup-form-row--disabled');
				}
			}

			function onDontRespondChange(elem) {
				var isChecked = $(elem).is(':checked');

				if (isChecked) {
					$(element).find('#dont_respond_on').prop('disabled', false);
					$(element).find('#dont_respond_row').removeClass('wakeup-form-row--disabled');
				} else {
					$(element).find('#dont_respond_on').prop('disabled', true);
					$(element).find('#dont_respond_row').addClass('wakeup-form-row--disabled');
				}
			}

			$(element).find('#wakeup').change(function (e) {
				onWakeupChange(e.target);
			});

			$(element).find('#dont_respond').change(function (e) {
				onDontRespondChange(e.target);
			});

			onWakeupChange($(element).find('#wakeup'));
		},

		initChangeOfInventoryAction: function (element) {
			$(element).find('.select-inventory-action').on('change', function (e) {

				$(e.target).parents('.items').first().find('.item--mandatory').remove();

				switch ($(e.target).val()) {
					case 'create':
						this.addMandatoryParam(e.target, 'invpool');
						this.addMandatoryParam(e.target, 'quantity');
						this.addMandatoryParam(e.target, 'invtype');
						this.addMandatoryParam(e.target, 'inv_aid');
						this.addMandatoryParam(e.target, 'inv_pid');
						break;

					case 'delete':
						this.addMandatoryParam(e.target, 'invid');
						break;

					case 'install':
						this.addMandatoryParam(e.target, 'invid');
						this.addMandatoryParam(e.target, 'inv_aid');
						this.addMandatoryParam(e.target, 'quantity');
						break;

					case 'deinstall':
						this.addMandatoryParam(e.target, 'invid');
						this.addMandatoryParam(e.target, 'inv_pid');
						this.addMandatoryParam(e.target, 'quantity');
						break;

					case 'undo_install':
						this.addMandatoryParam(e.target, 'invid');
						this.addMandatoryParam(e.target, 'quantity');
						break;

					case 'undo_deinstall':
						this.addMandatoryParam(e.target, 'invid');
						this.addMandatoryParam(e.target, 'quantity');
						break;
				}

				this._updateResponseJSON();
			}.bind(this));
		},

		initChangeOfDataItems: function () {
			//set checkboxes from local storage
			if (localStorage.getItem('dataItems')) {
				$('.data-items').attr('checked', true);
				$('.data-items-holder').show();

				var dataItems = JSON.parse(localStorage.getItem('dataItems'));

				$('.data-items-holder input').each(function () {
					if (dataItems.indexOf(this.value) != -1) {
						$(this).attr('checked', true);
					}
				});
			}

			//init handlers
			$('.data-items').on('change', function (e) {
				$('.data-items-holder').toggle();
			});
		},

		initChangeOfValue: function (element) {
			$(element).find('.value__item.writable, .key.writable, #wakeup').on('input change', function (e) {
				$(e.target).parents('.item').addClass('edited');

				this._updateResponseJSON();
			}.bind(this));
		},

		initItemRemove: function (element) {
			$(element).find('.button--remove-item').on('click', function (e) {
				//remove item
				$(e.target).parents('.item').first().remove();

				//reindex actions
				if ($(e.target).parents('.item').first().find('.action-key').length > 0) {
					$('.item:not(.example-action) .action-key').each(function (index) {
						$(this).text(index);
					});
				}

				this._updateResponseJSON();
			}.bind(this));
		},

		initCollapsableKeys: function (element) {
			$(element).find('.key').each(function (index, item) {
				if ($(item).siblings('.value').has('.items').length !== 0) {
					$(item).addClass('clickable');
				}
			});

			$(element).find('.key').on('click', function () {
				if ($(this).siblings('.value').has('.items').length !== 0) {
					$(this).siblings('.value').toggle();
					$(this).toggleClass('collapsed');
				}
			});

			$(element).find('.item-expander').on('click', function (e) {
				var key = $(e.target).parents('.value').first().siblings('.key').first();

				if (key.hasClass('clickable')) {
					key.trigger('click');
				}
			});
		},

		initAddButtons: function (element) {
			$(element).find('.button--add-property').click(function (e) {
				var clonedElement = $('.example-property').clone().removeClass('example-property');

				this.initChangeOfValue(clonedElement);
				this.initItemRemove(clonedElement);

				$(e.target).parent('.item').before(clonedElement);

				$(e.target).parents('.item').addClass('edited');

				this._updateResponseJSON();
			}.bind(this));

			$(element).find('.button--add-action').click(function (e) {
				var clonedElement = $('.example-action').clone().removeClass('example-action');
				var actionsCount = +$(e.target).parents('.item:not(.item--excluded)').find('.action-key').length;

				clonedElement.find('.action-key').text(actionsCount);

				this.initAddButtons(clonedElement);
				this.initCollapsableKeys(clonedElement);
				this.initChangeOfValue(clonedElement);
				this.initChangeOfInventoryAction(clonedElement);
				this.initItemRemove(clonedElement);

				$(e.target).parent('.item').before(clonedElement);

				$(e.target).parents('.item').addClass('edited');

				this._updateResponseJSON();
			}.bind(this));
		},

		/**
		 * Render JSON object to DOM
		 *
		 * @param {Object} data - JSON object
		 *
		 * @returns {jQuery}
		 */
		renderForm: function (data) {
			return this.renderCollection('data', data, true);
		},

		/**
		 * Render JSON object to follow HTML:
		 *
		 * <div class="item">
		 *     <div class="key">{key}</div>
		 *     <div class="value">{value}</div>
		 * </div>
		 * <div class="item">
		 *     <div class="key">{key}</div>
		 *     <div class="value">
		 *         <div class="items">
		 *              <div class="item">
		 *                  <div class="key">{key}</div>
		 *                  <div class="value">{value}</div>
		 *              </div>
		 *              <div class="item">
		 *                  <div class="key">{key}</div>
		 *                  <div class="value">{value}</div>
		 *              </div>
		 *              ...
		 *         </div>
		 *     </div>
		 * </div>
		 * ...
		 *
		 * @param {String} key - Collection name
		 * @param {Object} items - Child items of collection
		 * @param {Boolean} [isWritable] - Will render as writable?
		 * @param {number} [level] - Level of recursion
		 * @param {string} [parentKey] - parent Key
		 *
		 * @returns {jQuery}
		 */
		renderCollection: function (key, items, isWritable, level, parentKey) {
			var render_item = $('<div>').addClass('item');
			var render_key = $('<div>').addClass('key').text(key);
			var render_value = $('<div>').addClass('value value__collection');
			var render_items = $('<div>').addClass('items');

			isWritable = isWritable || false;
			level = level || 1;
			parentKey = parentKey || '';

			var newParentKey = key;

			if (items) {
				$.each(items, function (key, value) {
					if (value && typeof value === 'object') {
						render_items.append(this.renderCollection(key, value, isWritable, level + 1, newParentKey));
					} else {
						render_items.append(this.renderItem(key, value, isWritable, level + 1, newParentKey).get(0));
					}
				}.bind(this));
			}

			render_item.append('<div class="item-expander"></div>');
			render_item.append(render_key);

			render_value.append(render_items);
			render_item.append($('<br>'));
			render_item.append(render_value);

			return render_item;
		},

		/**
		 * Render key and value to follow HTML:
		 *
		 * <div class="item">
		 *     <div class="key">{key}</div>
		 *     <div class="value">{value}</div>
		 * </div>
		 *
		 * @param {String} key - Key
		 * @param {String} value - Value
		 * @param {Boolean} [isWritable] - Will render as writable?
		 * @param {number} [level] - Level of recursion
		 * @param {string} [parentKey] - parent Key
		 *
		 * @returns {jQuery}
		 */
		renderItem: function (key, value, isWritable, level, parentKey) {
			var render_item = $('<div>').addClass('item');
			var render_value;
			var render_key;

			isWritable = isWritable || false;
			level = level || 1;
			parentKey = parentKey || '';

			render_key = $('<div>').addClass('key').text(key);
			render_item.append('<div class="item-expander"></div>')
				.append(render_key)
				.append('<span class="delimiter">: </span>');

			if (value === null) {
				value = '';
			}

			if (
				typeof this.renderReadOnlyFieldsByParent[parentKey] !== 'undefined' &&
				typeof this.renderReadOnlyFieldsByParent[parentKey][key] !== 'undefined' &&
				this.renderReadOnlyFieldsByParent[parentKey][key] === true
			) {
				isWritable = false;
			}

			switch (key) {
				case "csign":
					if (isWritable) {
						render_value = $('<button>').addClass('button button--item-value button--generate-sign').text('Generate');
					}
					break;
				default:

					var pluginInitData = false;

					if (this._isJson(localStorage.getItem('pluginInitData'))) {
						pluginInitData = JSON.parse(localStorage.getItem('pluginInitData'));
					}

					if (this.dictionary[key]) {
						render_value = this.renderSelect(this.dictionary, key, value, isWritable).addClass('value value__item');
					} else if (
						pluginInitData &&
						pluginInitData[key] &&
						"enum" == pluginInitData[key].type &&
						pluginInitData[key].enum
					) {
						render_value = this.renderEnumSelect(pluginInitData[key].enum, key, value, isWritable).addClass('value value__item');
					} else {
						render_value = $('<div>').addClass('value value__item').text(value);

						if (isWritable) {
							render_value.addClass('writable').attr('contenteditable', true);
						}
					}

					break;
			}

			render_item.append(render_value);

			return render_item;
		},

		/**
		 * Render enums with validate of outs values
		 *
		 * <select class="value [writable]" [disabled]>
		 *     <option value="{value}" [selected]>{dictionary}</option>
		 *     ...
		 * </select>
		 *
		 * @param {Object} dictionary - Dictionary that will be used for Enum rendering
		 * @param {String} key - Just field name
		 * @param {String} value - Selected value
		 * @param {Boolean} isWritable - Will render as writable?
		 *
		 * @returns {HTMLElement}
		 */
		renderSelect: function (dictionary, key, value, isWritable) {
			var render_value;

			var outs = dictionary[key][value].outs;
			var allowedValues = [value].concat(outs);
			var disabled = '';

			render_value = $('<select>').css({
				background: dictionary[key][value].color
			});

			if (!outs.length || !isWritable) {
				render_value.attr('disabled', true);
			} else {
				render_value.addClass('writable');
			}

			$.each(allowedValues, function (index, label) {
				render_value.append('<option' + (label === value ? ' selected' : '') + ' value="' + dictionary[key][label].label + '">' + dictionary[key][label].translation + '</option>');
			});

			return render_value;
		},

		/**
		 * Render enums
		 *
		 * <select class="value [writable]" [disabled]>
		 *     <option value="{value}" [selected]>{dictionary}</option>
		 *     ...
		 * </select>
		 *
		 * @param {Object} dictionary - Dictionary that will be used for Enum rendering
		 * @param {String} key - Just field name
		 * @param {String} value - Selected value
		 * @param {Boolean} isWritable - Will render as writable?
		 *
		 * @returns {HTMLElement}
		 */
		renderEnumSelect: function (dictionary, key, value, isWritable) {
			var render_value;

			var disabled = '';

			render_value = $('<select>');

			if (isWritable) {
				render_value.addClass('writable');
			} else {
				render_value.attr('disabled', true);
			}

			$.each(dictionary, function (index, label) {
				render_value.append('<option' + (index === value ? ' selected' : '') + ' value="' + index + '">' + label.text + '</option>');
			});

			return render_value;
		},

		/**
		 * Convert HTML elements to JSON
		 *
		 * @param {HTMLElement} rootElement - Root element that should be parsed recursively
		 * @param {Boolean} [parseAllExceptExcluded] - Need to parse all elements except excluded
		 *
		 * @returns {Object}
		 *
		 * <div class="key">activity</div>
		 * <div class="value value__collection">
		 *     <div class="items"> <-------------------------------- rootElement !!!
		 *         <div class="item edited">
		 *             <div class="key">WO_COMMENTS</div>
		 *             <div class="value">text_comments</div>
		 *         </div>
		 *         <div class="item">
		 *             <div class="key">aid</div>
		 *             <div class="value">4225274</div>
		 *         </div>
		 *         <div class="item">
		 *             <div class="key">caddress</div>
		 *             <div class="value">text_address</div>
		 *         </div>
		 *     </div>
		 * </div>
		 *
		 * converts to:
		 *
		 * {
		 *     "aid": "4225274",
		 *     "WO_COMMENTS": "text_comments"
		 * }
		 *
		 */
		parseCollection: function (rootElement, parseAllExceptExcluded) {
			parseAllExceptExcluded = parseAllExceptExcluded || false;

			var returnObject;

			if ($(rootElement).hasClass('items--without-key')) {
				returnObject = [];
			} else {
				returnObject = {};
			}

			$(rootElement).children('.item').each(function (itemIndex, item) {
				var parentKey;
				var valueKey;
				var value;
				var mandatoryField = false;

				parentKey = $(rootElement).parent().siblings('.key').get(0);
				valueKey = $(item).children('.key').get(0);

				//Logic of mandatory fields
				if ((parentKey !== undefined) && (
					($(parentKey).text() == 'activity' && $(valueKey).text() == 'aid') || ($(parentKey).text() == 'inventory' && $(valueKey).text() == 'invid')
				)) {
					mandatoryField = true;
				}

				if (
					$(item).hasClass('item') === true &&
					(
						$(item).hasClass('edited') === true || parseAllExceptExcluded || mandatoryField
					) &&
					$(item).hasClass('item--excluded') === false
				) {

					value = $(item).children('.value').get(0);

					if ($(value).children('.items').length > 0) {
						var parsedChild = this.parseCollection($(value).children('.items').get(0), parseAllExceptExcluded);

						if ($(rootElement).hasClass('items--without-key')) {
							returnObject.push(parsedChild);
						} else {
							returnObject[$(valueKey).text()] = parsedChild;
						}
					} else {
						switch ($(value).prop("tagName")) {
							case 'SELECT':
								returnObject[$(valueKey).text()] = $(value).val();
								break;

							case 'CANVAS':
								returnObject[$(valueKey).text()] = value.toDataURL();
								break;

							default:
								returnObject[$(valueKey).text()] = $(value).text();
								break;
						}
					}
				}
			}.bind(this));

			return returnObject;
		},

		/**
		 * Update JSON
		 *
		 * @private
		 */
		_updateResponseJSON: function () {
			var jsonToSend = this.generateJson();

			$('.json__response').text(JSON.stringify(jsonToSend, null, 4));
		},

		// CHG0075659 - MPF Phase 5 - Function to handle Call Procedure api result
		finishCallIdCallbacks: function (receivedJson) {
			let jsonObject = null;
			console.log("Call procedure:" + receivedJson);
			jsonObject = JSON.parse(receivedJson);
			console.log("Call Procedure JSONobject" + JSON.stringify(jsonObject));
			var jsonObjectItemLength= jsonObject.resultData.items.length;

			if(jsonObjectItemLength!=0){
			$.each(jsonObject.resultData.items, function (i, a) {

				console.log("Field Details", a.fields);
				multipleFieldsArray.push(a.fields);
				a.fields.LINKED_COUNT = a.linkedItems.length;
	
			});
		}

			if(jsonObject.resultData.isContinueAvailable == true){
				$.getPartsCatalogContinue(jsonObject.resultData.searchId);
			}



			if (searchflag == searchArray.length && jsonObject.resultData.isContinueAvailable == false) {
				if (jsonObject.callId == partsContinueSearchCallId) {
					console.log("*********PROCESS SEARCH RESULT CALLED");
					$.processSearchResultsFnCallBck(multipleFieldsArray);
					multipleFieldsArray = [];
				}
				// CHG0078235 - Change Starts
				if (jsonObject.callId == partssearchcallID) {
					console.log("*********PROCESS SEARCH RESULT CALLED for Parts Catalogue");
					$.processSearchResultsFnCallBck(multipleFieldsArray);
					multipleFieldsArray = [];
				}
				// CHG0078235 - Change ends
			}
			if (jsonObject.callId == linkedcallID) {
				$.processLinkedItemsResultsFnCallBck(jsonObject);
			}
			// Begin CHG0082493
			if (jsonObject.callId == compatibleCallID) {
				
				compatibleObj = jsonObject;
				
			 
			}
            // End CHG0082493
		},

		/**
		 * Initialization function
		 */
		init: function () {
			if (navigator.serviceWorker) {
				this._log(window.location.host + ' Service Worker is supported');
				navigator.serviceWorker.register('searchParts-service-worker.js').then(function (registration) {
					this._log(window.location.host + ' Service Worker is registered with scope: ' + registration.scope);
					registration.addEventListener('updatefound', function () {
						this._log(window.location.host + ' Service Worker update is found');
						var newServiceWorker = registration.installing;
						newServiceWorker.addEventListener('statechange', function () {
							switch (newServiceWorker.state) {
								case "installed":
									this._log(window.location.host + ' New Service Worker is installed');
									break;
							}
						}.bind(this));
					}.bind(this));
					navigator.serviceWorker.addEventListener('controllerchange', function () {
						this.notifyAboutNewVersion();
					}.bind(this));
					this.startApplication();
				}.bind(this), function (err) {
					this._log(window.location.host + ' Service Worker registration failed: ' + err);
					this.startApplication();
				}.bind(this));
				return;
			} else {
				this._log(window.location.host + ' Service Worker is not supported');
			}
			this.startApplication();
		},
		startApplication: function () {
			//$.getConfigDataFromJson(); // Added to get the config.json values for 19C upgrade

			//default ofsc function
			window.addEventListener("message", this._getPostMessageData.bind(this), false);
			this._log(window.location.host + ' PLUGIN HAS BEEN STARTED');

			//default data variables
			 var thisVar = this;
			// var dataItemsToProcess = [];
			// var dataItems = ['resource'];
			// // var count = 0;   //added for  INC1499701.
			// console.log("dataItems : ", dataItems);
			// // $.urlParam = function (name) {
			// // 	var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
			// // 	return results[1] || 0;
			// // }

			// //var resourceloginName = decodeURIComponent($.urlParam('ulogin'));

			var jsonToSend = {
				apiVersion: 1,
				method: 'ready',
				sendInitData: true
			};

			// var resourceInventories = false;
			// var InventoryData = {};
			// var configData;
			// console.log("Local Storage RI : ", localStorage.ri);
			// console.log(!localStorage.ri);

			// if (localStorage.storageDataItems) {
			// 	dataItemsToProcess = localStorage.storageDataItems.split(',');
			// }
			// console.log("data items to process:" + dataItemsToProcess);
			//else {
			// 	count = 1; //added for  INC1499701.
			// 	//storeResourceInvToLocal();
			// }

			//localStorage data updation if date and ri is not updated on current day
			//if((localStorage.dataUpdatedDate !== dateInUserZone) || (!localStorage.ri)){
			// if (dataItemsToProcess.indexOf('resourceInventories') === -1) {
			// 	localStorage.storageDataItems = [];
			// 	dataItemsToProcess = [];
			// 	localStorage.ri = [];
			// 	localStorage.di = [];
			// 	localStorage.ii = [];
			// 	localStorage.ci = [];
			// 	dataItems.push('customerInventories');
			// 	dataItems.push('deinstalledInventories');
			// 	dataItems.push('installedInventories');
			// 	dataItems.push('resourceInventories');
			// 	//count = 1; //added for  INC1499701.
			// 	//storeResourceInvToLocal();
			// } 
			// else {
			// if (dataItemsToProcess.indexOf('resourceInventories') === -1) {
			// 	dataItems.push('resourceInventories');
			// }

			// if (dataItemsToProcess.indexOf('customerInventories') === -1) {
			// 	dataItems.push('customerInventories');
			// }

			// if (dataItemsToProcess.indexOf('deinstalledInventories') === -1) {
			// 	dataItems.push('deinstalledInventories');
			// }

			// if (dataItemsToProcess.indexOf('installedInventories') === -1) {
			// 	dataItems.push('installedInventories');
			// }
			// console.log(dataItems);
			// if (dataItems) {
			// 	$.extend(jsonToSend, { dataItems: dataItems });
			// }
			thisVar._sendPostMessageData(jsonToSend);

			//}
			// //added for  INC1499701.
			// if (count === 0) {
			// 	//storeResourceInvToLocal();
			// }
			// //end modification for  INC1499701.


			// //Function to initialise resource inventory data updation
			// function storeResourceInvToLocal() {
			// 	getUserId(); // Modified function definition as part of 19C upgrade
			// }


			// //get user/resource info
			// //function getUserId(auth){ Modified function definition as part of 19C upgrade
			// function getUserId() {
			// 	$.ajax({
			// 		url: window.location.origin + '/RestTrigger/rest/resource/userDetails',
			// 		//url:'https://jcsd.ricohonline.net/RestTrigger/rest/resource/userDetails',
			// 		method: 'POST',
			// 		dataType: 'json',
			// 		processData: false,
			// 		contentType: 'application/json; charset=utf-8',
			// 		timeout: 15000,
			// 		data: JSON.stringify({
			// 			"login": resourceloginName,
			// 			"authorization": authorizationB64,
			// 			"pluginName": pluginName, //to add log message. CHG0065188
			// 			//CHG0069299 - Added below for Domain change request
			// 			"instanceName": company
			// 		}),
			// 		success: function (successData) {
			// 			console.log(successData);
			// 			//callApi(successData.resourceId,auth) Modified function definition as part of 19C upgrade
			// 			callApi(successData.resourceId);
			// 		},
			// 		error: function (errorData) {
			// 			console.log(errorData);
			// 			callApi()

			// 		}
			// 	});
			// }


			// //get resourceInventories
			// //function callApi(resourceId, authorizationB64){ Modified function definition as part of 19C upgrade
			// function callApi(resourceId) {
			// 	var rIPayLoad = {
			// 		"resourceId": resourceId,
			// 		"authorization": authorizationB64,
			// 		"pluginName": pluginName, //to add log message. CHG0065188
			// 		//CHG0069299 - Added below for Domain change request
			// 		"instanceName": company
			// 	}
			// 	$.ajax({
			// 		url: window.location.href,
			// 		timeout: 2000,
			// 		cache: false,
			// 		type: 'GET',
			// 		tryCount: 0,
			// 		retryLimit: 3,
			// 		success: function (response) {
			// 			console.log(' online configuration');
			// 			ResourceInventory();
			// 		}.bind(this),
			// 		error: function (xhr, textStatus, errorThrown) {
			// 			if (textStatus == 'timeout') {
			// 				this.tryCount++;
			// 				if (this.tryCount <= this.retryLimit) {
			// 					//try again
			// 					$.ajax(this);
			// 					return false;
			// 				}
			// 				console.log(' Offline configuration');
			// 				$.showNoDataFound();

			// 			}
			// 			if (xhr.status == 500) {
			// 				console.log(' Offline configuration');
			// 				$.showNoDataFound();
			// 			}
			// 			else {
			// 				console.log(' Offline configuration');
			// 				$.showNoDataFound();
			// 			}
			// 		}.bind(this)
			// 	});

			// 	function ResourceInventory() {
			// 		$.ajax({
			// 			url: window.location.origin + '/RestTrigger/rest/activity/resourceInventories',
			// 			//url:'https://jcsd.ricohonline.net/RestTrigger/rest/activity/resourceInventories',
			// 			method: 'POST',
			// 			dataType: 'json',
			// 			processData: false,
			// 			contentType: 'application/json; charset=utf-8',
			// 			timeout: 15000,
			// 			data: JSON.stringify(rIPayLoad),
			// 			success: function (successData) {
			// 				console.log(successData);
			// 				resourceInventories = true;
			// 				if (dataItemsToProcess.indexOf('resourceInventories') === -1) {
			// 					dataItemsToProcess.push('resourceInventories');
			// 				}
			// 				localStorage.storageDataItems = dataItemsToProcess;
			// 				InventoryData.ri = successData.items;
			// 				callReadyMethod();
			// 			},
			// 			error: function (errorData) {
			// 				console.log(errorData);
			// 				dataItems.push('resourceInventories');
			// 				resourceInventories = true;
			// 				InventoryData.ri = [];
			// 				callReadyMethod();
			// 			}
			// 		});
			// 	}
			// 	$.showNoDataFound = function () {
			// 		$('#context-body').append("<tr class=\"cl-row\">\n" +
			// 			"    <td class=\"cl-fld\">\n" +
			// 			"        <div class=\"cl-fld-outer\">\n" +
			// 			"            No data found.\n" +
			// 			"        </div>\n" +
			// 			"    </td>\n" +
			// 			"</tr>");
			// 	};


			// }

			// //calling ready method on success/error call-back of resourceInventories
			// function callReadyMethod() {
			// 	console.log('in Ready Method');
			// 	if (resourceInventories) {
			// 		//storing data to localStorage
			// 		localStorage.ri = JSON.stringify(InventoryData.ri);
			// 		//passing consolidated data-items
			// 		console.log(dataItems);
			// 		localStorage.storageDataItems = dataItemsToProcess;
			// 		if (dataItems) {
			// 			$.extend(jsonToSend, { dataItems: dataItems });
			// 		}
			// 		thisVar._sendPostMessageData(jsonToSend);
			// 	}
			//}
		},
		notifyAboutNewVersion: function () {
			this._log(window.location.host + ' New Service Worker is activated. Page refresh is needed');
			var footer = document.querySelector('.footer');
			var versionNotificationElement = document.createElement('div');
			versionNotificationElement.className = 'new-version-notification';
			versionNotificationElement.innerHTML = 'New version is detected. Please reopen the page';
			footer.appendChild(versionNotificationElement);
		}
	});
	window.OfscPlugin.getVersion = function () {
		return resourcesVersion;
	};

})(jQuery);