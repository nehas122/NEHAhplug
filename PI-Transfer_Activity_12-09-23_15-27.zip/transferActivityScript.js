"use strict";

(function ($) {
    window.OfscPlugin = function (debugMode) {
        this.debugMode = debugMode || false;
    };
    
    var authorizationB64 = '';
	var nowDate = new Date();
	var now = nowDate.toISOString();
    $.extend(window.OfscPlugin.prototype, {
        /**
         * Dictionary of enums
         */
        dictionary: {
            astatus: {
                pending: {
                    label: 'pending',
                    translation: 'Pending',
                    outs: ['started', 'cancelled', 'suspended'],
                    color: '#FFDE00'
                },
                started: {
                    label: 'started',
                    translation: 'Started',
                    outs: ['complete', 'suspended', 'notdone', 'cancelled'],
                    color: '#A2DE61'
                },
                complete: {
                    label: 'complete',
                    translation: 'Completed',
                    outs: [],
                    color: '#79B6EB'
                },
                suspended: {
                    label: 'suspended',
                    translation: 'Suspended',
                    outs: [],
                    color: '#9FF'
                },
                notdone: {
                    label: 'notdone',
                    translation: 'Not done',
                    outs: [],
                    color: '#60CECE'
                },
                cancelled: {
                    label: 'cancelled',
                    translation: 'Cancelled',
                    outs: [],
                    color: '#80FF80'
                }
            },
            invpool: {
                customer: {
                    label: 'customer',
                    translation: 'Customer',
                    outs: ['deinstall'],
                    color: '#04D330'
                },
                install: {
                    label: 'install',
                    translation: 'Installed',
                    outs: ['provider'],
                    color: '#00A6F0'
                },
                deinstall: {
                    label: 'deinstall',
                    translation: 'Deinstalled',
                    outs: ['customer'],
                    color: '#00F8E8'
                },
                provider: {
                    label: 'provider',
                    translation: 'Resource',
                    outs: ['install'],
                    color: '#FFE43B'
                }
            }
        },

        mandatoryActionProperties: {},

        /**
         * Which field shouldn't be editable
         *
         * format:
         *
         * parent: {
         *     key: true|false
         * }
         *
         */
        renderReadOnlyFieldsByParent: {
            data: {
                apiVersion: true,
                method: true,
                entity: true
            },
            resource: {
                pid: true,
                pname: true,
                gender: true
            }
        },

        /**
         * Check for string is valid JSON
         *
         * @param {*} str - String that should be validated
         *
         * @returns {boolean}
         *
         * @private
         */
        _isJson: function (str) {
            try {
                JSON.parse(str);
            }
            catch (e) {
                return false;
            }
            return true;
        },

        /**
         * Return origin of URL (protocol + domain)
         *
         * @param {String} url
         *
         * @returns {String}
         *
         * @private
         */
        _getOrigin: function (url) {
            if (url != '') {
                if (url.indexOf("://") > -1) {
                    return 'https://' + url.split('/')[2];
                } else {
                    return 'https://' + url.split('/')[0];
                }
            }

            return '';
        },

        /**
         * Return domain of URL
         *
         * @param {String} url
         *
         * @returns {String}
         *
         * @private
         */
        _getDomain: function (url) {
            if (url != '') {
                if (url.indexOf("://") > -1) {
                    return url.split('/')[2];
                } else {
                    return url.split('/')[0];
                }
            }

            return '';
        },

        //added for MPF Phase 4 - CHG0069304
		_getDomainURL: function() {
			//return document.referrer.match(/\:\/\/([^\/]+)\.etadirect\.com\//)[1];
			//Reg Ex modified to handle both etadirect.com and fs.ocs.oraclecloud.com URLs
			return document.referrer.match(/\:\/\/([^\/]+)\.(?:etadirect.com|fs.ocs.oraclecloud.com)/)[1];
		},
		//

        /**
         * Sends postMessage to document.referrer
         *
         * @param {Object} data - Data th
		 at will be sent
         *
         * @private
         */
        _sendPostMessageData: function (data) {
            var originUrl = document.referrer || (document.location.ancestorOrigins && document.location.ancestorOrigins[0]) || '';

            if (originUrl) {
                this._log(window.location.host + ' -> ' + data.method + ' ' + this._getDomain(originUrl), JSON.stringify(data, null, 4));

                parent.postMessage(JSON.stringify(data), this._getOrigin(originUrl));
            } else {
                this._log(window.location.host + ' -> ' + data.method + ' ERROR. UNABLE TO GET REFERRER');
            }
        },

        /**
         * Handles during receiving postMessage
         *
         * @param {MessageEvent} event - Javascript event
         *
         * @private
         */
        _getPostMessageData: function (event) {

            if (typeof event.data === 'undefined') {
                this._log(window.location.host + ' <- NO DATA ' + this._getDomain(event.origin), null, null, true);

                return false;
            }

            if (!this._isJson(event.data)) {
                this._log(window.location.host + ' <- NOT JSON ' + this._getDomain(event.origin), null, null, true);

                return false;
            }

            var data = JSON.parse(event.data);

            if (!data.method) {
                this._log(window.location.host + ' <- NO METHOD ' + this._getDomain(event.origin), null, null, true);

                return false;
            }

            this._log(window.location.host + ' <- ' + data.method + ' ' + this._getDomain(event.origin), JSON.stringify(data, null, 4));

            switch (data.method) {
                case 'init':
                    this.pluginInitEnd(data);
                    break;

                case 'open':
                    this.pluginOpen(data);
                    break;

                case 'wakeup':
                    this.pluginWakeup(data);
                    break;

                case 'error':
                    data.errors = data.errors || {error: 'Unknown error'};
                    this._showError(data.errors);
                    break;

                default:
                    this._log(window.location.host + ' <- UNKNOWN METHOD: ' + data.method + ' ' + this._getDomain(event.origin), null, null, true);
                    break;
            }
        },

        /**
         * Show alert with error
         *
         * @param {Object} errorData - Object with errors
         *
         * @private
         */
        _showError: function (errorData) {
            alert(JSON.stringify(errorData, null, 4));
        },

        /**
         * Logs to console
         *
         * @param {String} title - Message that will be log
         * @param {String} [data] - Formatted data that will be collapsed
         * @param {String} [color] - Color in Hex format
         * @param {Boolean} [warning] - Is it warning message?
         *
         * @private
         */
        _log: function (title, data, color, warning) {
            if (!this.debugMode) {
                return;
            }
            if (!color) {
                color = '#0066FF';
            }
            if (!!data) {
                console.groupCollapsed('%c[Plugin API] ' + title, 'color: ' + color + '; ' + (!!warning ? 'font-weight: bold;' : 'font-weight: normal;'));
                console.log('[Plugin API] ' + data);
                console.groupEnd();
            } else {
                console.log('%c[Plugin API] ' + title, 'color: ' + color + '; ' + (!!warning ? 'font-weight: bold;' : ''));
            }
        },

        /**
         * Business login on plugin init
         */
        saveToLocalStorage: function (data) {
            this._log(window.location.host + ' INIT. SET DATA TO LOCAL STORAGE', JSON.stringify(data, null, 4));

            if (data.attributeDescription) {
                localStorage.setItem('pluginInitData', JSON.stringify(data.attributeDescription));
            }
        },

        /**
         * Business login on plugin init end
         *
         * @param {Object} data - JSON object that contain data from OFSC
         */
        pluginInitEnd: function (data) {
            this.saveToLocalStorage(data);

            var messageData = {
                apiVersion: 1,
                method: 'initEnd'
            };

            if (localStorage.getItem('pluginWakeupCount') < localStorage.getItem('pluginWakeupMaxCount')) {
                this._log(window.location.host + ' UNFINISHED WAKEUP DATA FOUND IN LOCAL STORAGE');

                messageData.wakeupNeeded = true;
            }

            this._sendPostMessageData(messageData);
        },

        /**
         * Business login on plugin open
         *
         * @param {Object} receivedData - JSON object that contain data from OFSC
         */
        pluginOpen: function (receivedData) {
			            console.log(receivedData);

            /*Declaration of Variables*/
            var subInventoryDropDown, searchInput, searchButton, subInventoryListNames, subInventoryOwners,ownersList,
                queData, apiCalls, tempArr, subInventoryList, subInventoryForm, resourceIdOfTechn, existingOwnerIndexes; // Cleaned unused variables for 19C upgrade
                      
            var serverURL = window.location.origin; 
            var pluginName = 'PI-TransferActivity';  
            // Changes start for CHG0069304
            var resourceId = receivedData.resource.external_id;
        	var domainName = this._getDomainURL();
        	console.log("Domain Name - "+domainName);
        	
            // Base 64 encryption for REST API calls
            //authorizationB64 = btoa(receivedData.securedData.clientId+"@"+receivedData.securedData.company+":" + receivedData.securedData.clientSecret);

            var headers = {
				'Authorization':
					'Basic ' + btoa(receivedData.securedData.clientId + "@" + domainName + ":" + receivedData.securedData.clientSecret)
			};

           
            //Changes end for CHG0069304
            /*Getting Elements from view*/
            subInventoryDropDown = $('#search__sub_inventory');
            searchInput = $('#search__string');
            searchButton = $('#search__btn');
            subInventoryForm = $('#subInventory_form');
            resourceIdOfTechn = receivedData.resource.external_id;
            existingOwnerIndexes = [];
            queData = [];
            apiCalls = [];
            tempArr = [];

            /*Getting Inventory owners*/
            subInventoryOwners = receivedData.resource.R_SUBINVENTORY_OWNER;
            if(subInventoryOwners !== undefined){
                ownersList = subInventoryOwners.split(',');
            }

            /*Getting Indexes of same resource as owner*/
            $.each(ownersList, function (i, v) {
                if(resourceIdOfTechn === v){
                    existingOwnerIndexes.push(i)
                }
            });
			console.log(ownersList);
			if(existingOwnerIndexes !== []){
				existingOwnerIndexes.reverse();
				$.each(existingOwnerIndexes, function(i,v){
					ownersList.splice(v,1);
				});
			}
			console.log(ownersList);
			

            /*Assigning Inventory List to Inventory Dropdown*/
            subInventoryListNames = receivedData.resource.R_SUBINVENTORY_NAME;
            if(subInventoryListNames !== undefined){
            	try{
	                subInventoryList = subInventoryListNames.split(";");
	                //existingOwnerIndexes.reverse();
	                $.each(existingOwnerIndexes, function (i, v) {
	                    subInventoryList.splice(v,1);
	                });
	                $.each(subInventoryList, function (i, v) {
	                    subInventoryDropDown.append("<option name='"+v+"' value='"+i+"'>"+v+"</option>");
	                });
            	}
            	catch(err){
					
					//$.logErrorMessages('500', "Exception in fetching subInventoryList: "+err.message);		
				 	console.log(" Exception in fetching subInventoryList :"+err.message);
				}
            }

            /*Enabling Input Field on selection of Dropdown*/
            subInventoryDropDown.change(function () {
                searchInput.attr('disabled', false);
                searchButton.attr('disabled', false);
                searchButton.addClass('submit');
            });

            /*Submitting inventory Form*/
            searchButton.click(function () {
                var selectedInventoryOwner = ownersList[subInventoryDropDown.val()];
                var searchParams = searchInput.val();
                // utilizing global variables as part of 19C upgrade
                now = now.replace('+', '%2B');
                var inventoryDetails = {                    
                    "authorization":authorizationB64,  /*Added for CHG0065188 SOAP to REST conversion */
                    "instanceName": receivedData.securedData.company,
                    "searchParam": searchParams,
                    "inventoryOwner": selectedInventoryOwner, 
                    "resourceId": receivedData.resource.external_id,
                    "pluginName" : pluginName //to add log message. CHG0065188
                };
				/* CHG0069299 - Commenting the below section to improve online offline check
                if(!navigator.onLine){
                    var offlineQue = {
                        url:window.location.origin+'/RestTrigger/rest/activity/transferActivityList',
                        method:'POST',
                        data: inventoryDetails
                    };
                    localStorage.apiQue.push(JSON.stringify(offlineQue));
                }
                $.ajax({
                    url:window.location.origin+'/RestTrigger/rest/activity/transferActivityList',
					processData: false,
					contentType: 'application/json; charset=utf-8',
                    method:'POST',
                    data: JSON.stringify(inventoryDetails),
                    success: function (successData) {
                    	if(successData.status === 200){
                    		$.processFnCallBk(successData);  
                    	}
                    	else{
                    		$.showNoDataFound();
                    	}
                    },
                    error: function (errorData) {
                        console.log(errorData);
                        $.showNoDataFound();
                    }
                });*/

                // Changes done for CHG0069304
                var activityFields = "apptNumber,status,resourceId,activityType,activityId,A_TRACKING_NUMBER,A_RECEIVING_DOCUMENT_NUMBER,A_EXPECTED_DATE";
                var transferURL =  "https://"+ domainName +".fs.ocs.oraclecloud.com/rest/ofscCore/v1/activities/?includeNonScheduled=true&limit=1000&resources="+selectedInventoryOwner+"&includeChildren=all&q=status=='pending' and activityType in ['RCT']&fields="+activityFields;
				//Changes end for CHG0069304	
                //*********************CHG0069299 - Validate internet connectivity and TransferActivity***********************
						$.ajax({
						url : window.location.href,
						timeout : 2000,	
						cache: false,				
						type : 'GET', 
						tryCount : 0,
						retryLimit : 3,
						success: function (successData) {
							console.log("online configuration");
							transferActivityElement();
						},
						error : function(xhr, textStatus, errorThrown )
						{
							if (textStatus == 'timeout') {
								this.tryCount++;
								if (this.tryCount <= this.retryLimit) {
									//try again
									$.ajax(this);
									return false;
								}            
								storeOffline();
							}
							if (xhr.status == 500) {
								storeOffline();
							} 
							else 
							{
								storeOffline();
							}
						}
				});
				function storeOffline()
				{
					var offlineQue = {
										url:transferURL,
										method:'GETT',
										data: inventoryDetails
									};
					// CHG0069299 - Commenting because transfer activity is offline disabled
					//localStorage.apiQue.push(JSON.stringify(offlineQue));
				}
				function transferActivityElement()
				{
                
                    
//changes done for CHG0069304
				 $.ajax({
						url:transferURL,
                        dataType: 'json',
                        processData: false,
                        async: false,
                        crossDomain: true,
                        headers: headers,
                        contentType: 'application/json; charset=utf-8',
						method:'GET',
						data: JSON.stringify(inventoryDetails), //chnages end for CHG0069304
						success: function (successData) {
							if(successData.items){
								$.processFnCallBk(successData);  
							}
							else{
								$.showNoDataFound();
							}
						},
						error: function (errorData) {
							console.log(errorData);
							$.showNoDataFound();
						}
					});
				}
            });
        	$.showNoDataFound = function(){
            	$('#context-body').append("<tr class=\"cl-row\">\n" +
                        "    <td class=\"cl-fld\">\n" +
                        "        <div class=\"cl-fld-outer\">\n" +
                        "            No data found.\n" +
                        "        </div>\n" +
                        "    </td>\n" +
                        "</tr>");
            };
            
            $.processFnCallBk = function(responseJSON) {
            	var activities = [];
            	activities = responseJSON.items;
            	
            	subInventoryForm.append("<table id='context-layout'></table>");
                $('#context-layout').append("<tbody id='context-body'></tbody>");
				$('#context-body').empty();
				var selectedSubInventory = $("#search__sub_inventory option:selected").text().split(',')[0];
				var finalisedActivities = [];
				$.each(activities, function(i,v){
					if(v.apptNumber.indexOf(selectedSubInventory) !== -1){
						finalisedActivities.push(v);
					}
				});
				console.log(finalisedActivities);
				
				if(finalisedActivities.length === 0){
					$.showNoDataFound();
				}else{
					 $.each(finalisedActivities, function (i, v) {						 
                    $('#context-body').append("<tr class=\"cl-row\">\n" +
                        "            <td class=\"cl-fld\">\n" +
                        "                <div class=\"cl-fld-outer\">\n" +
                        "                    <input type=\"button\" selectedActivity='"+JSON.stringify(v)+"' class=\"button submit assign\" value=\"Move\">\n" +
                        "\n" +
                        "                    <span class=\"A_RECEIVING_DOCUMENT_NUMBER\">Receiving Doc: "+(v.A_RECEIVING_DOCUMENT_NUMBER != null && 'undefined' != v.A_RECEIVING_DOCUMENT_NUMBER ? v.A_RECEIVING_DOCUMENT_NUMBER : '')+"</span>\n" +
                        "                    <span class=\"A_EXPECTED_DATE\">"+(v.A_EXPECTED_DATE != null && 'undefined' != v.A_EXPECTED_DATE ? v.A_EXPECTED_DATE : '') +"</span>\n" +
                        "                    <div class=\"A_TRACKING_NUMBER\">Tracking "+(v.A_TRACKING_NUMBER != null && 'undefined' != v.A_TRACKING_NUMBER ? v.A_TRACKING_NUMBER : '')+"</div>\n" +                        
                        "                </div>\n" +
                        "            </td>\n" +
                        "        </tr>");
                });
				}
            };
			
            /*Assigning Activity*/
            $(document).on("click", "input.button.submit.assign" , function() {
            /*$('#update__btn').click(function(){*/
               var confirmAssign = confirm("Please confirm activity assignment");
               // var setMoveRESTServiceURL = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/activities/"+activityId+"/custom-actions/move";
                var selectedActivityElement = this;
                var activityId="";
                if(confirmAssign){
                    
                	//Utilizing global variables for 19C upgrade
                    var selectedActivity = JSON.parse($(this).attr('selectedActivity'));
                    console.log(selectedActivity);
                    var activityId= selectedActivity.activityId;
                    var movableActivityDetails = {
                        "setResource" : {"resourceId":resourceId}    
                    };
                    //changed url for CHG0069304
                    var setMoveRESTServiceURL = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/activities/"+activityId+"/custom-actions/move";
					
		      //*******************CHG0069299 - Validate internet connectivity **********************************			
				$.ajax({
							url : window.location.href,
							timeout : 2000,	
							cache: false,				
							type : 'GET', 
							tryCount : 0,
							retryLimit : 3,
							success: function (successData) 
							{
                                
								console.log("online configuration");
								moveActivityElement();  
							},
							error : function(xhr, textStatus, errorThrown )
							{
                                
								if (textStatus == 'timeout') {
									this.tryCount++;
									if (this.tryCount <= this.retryLimit) {
										//try again
										$.ajax(this);
										return false;
									}            
									storeOfflineMove();
								}
								if (xhr.status == 500) {
									storeOfflineMove();
								} 
								else 
								{
									storeOfflineMove();
								}
							}
					});
					function storeOfflineMove()
					{
						var offlineQue =	{
											url:setMoveRESTServiceURL,
											method:'POST',
											data:movableActivityDetails
											};
						// CHG0069299 - Commenting because transfer activity is offline disabled
						//localStorage.apiQue.push(JSON.stringify(offlineQue));
					}
					
                    //CHnages done for CHG0069304
					function moveActivityElement(){
                        
					$.ajax({
                            url:setMoveRESTServiceURL,
                            method:'POST',
                            data:JSON.stringify(movableActivityDetails),
							async: false,
                            crossDomain: true,
                            headers: headers,
                            dataType: 'json',
                            contentType: 'application/json; charset=utf-8',
                            contentLength: 0,
                            timeout: 10000, //Changes end for CHG0069304
                            success: function (successData) {
                                
                                $(selectedActivityElement).removeClass('submit');
                                $(selectedActivityElement).val('Appointment has been moved');
                            },
                            error:function (errorData) {
                               
                                console.log(errorData);
                            
                            }
                        });
				}			

               }
            });
			
			this._clearWakeupData();
			this.initChangeOfWakeup(document);
			this.initChangeOfDataItems();
			if (localStorage.getItem('pluginInitData')) {
				this._log(window.location.host + ' OPEN. GET DATA FROM LOCAL STORAGE', JSON.stringify(JSON.parse(localStorage.getItem('pluginInitData')), null, 4));
				$('.json__local-storage').text(JSON.stringify(JSON.parse(localStorage.getItem('pluginInitData')), null, 4));
				}



        },
		
		 

        /**
         * Business login on plugin wakeup (background open for sync)
         *
         * @param {Object} receivedData - JSON object that contain data from OFSC
         */
        pluginWakeup: function (receivedData) {
            this._log(window.location.host + ' WAKEUP', JSON.stringify(receivedData, null, 4));

            var wakeupData = {
                pluginWakeupCount: +localStorage.getItem('pluginWakeupCount'),
                pluginWakeupMaxCount: +localStorage.getItem('pluginWakeupMaxCount'),
                pluginWakeupDontRespondOn: +localStorage.getItem('pluginWakeupDontRespondOn')
            };

            wakeupData.pluginWakeupCount = wakeupData.pluginWakeupCount + 1;

            localStorage.setItem('pluginWakeupCount', wakeupData.pluginWakeupCount);
            localStorage.setItem('pluginWakeupMaxCount', wakeupData.pluginWakeupMaxCount);
            localStorage.setItem('pluginWakeupDontRespondOn', wakeupData.pluginWakeupDontRespondOn);

            this._log(window.location.host + ' SAVE WAKEUP DATA TO LOCAL STORAGE', JSON.stringify(wakeupData, null, 4));

            if (wakeupData.pluginWakeupDontRespondOn == wakeupData.pluginWakeupCount) {
                this._log(window.location.host + ' EMULATE NOT RESPONDING PLUGIN');

                return;
            }

            if (wakeupData.pluginWakeupCount < wakeupData.pluginWakeupMaxCount) {
                setTimeout(function () {
                    this._log(window.location.host + ' SLEEP. RETRY NEEDED');

                    this._sendPostMessageData({
                        apiVersion: 1,
                        method: 'sleep',
                        wakeupNeeded: true
                    });
                }.bind(this), 2000);
            } else {
                setTimeout(function () {
                    this._log(window.location.host + ' SLEEP. NO RETRY');

                    this._sendPostMessageData({
                        apiVersion: 1,
                        method: 'sleep',
                        wakeupNeeded: false
                    });
                }.bind(this), 12000);
            }
        },

        /**
         * Save configuration of wakeup (background open for sync) behavior for Plugin
         * to Local Storage
         *
         * @private
         */
        _saveWakeupData: function () {
            var wakeupData = {
                pluginWakeupCount: 0,
                pluginWakeupMaxCount: 0,
                pluginWakeupDontRespondOn: 0
            };

            if ($('#wakeup').is(':checked')) {
                wakeupData.pluginWakeupMaxCount = parseInt($('#repeat_count').val());

                if ($('#dont_respond').is(':checked')) {
                    wakeupData.pluginWakeupDontRespondOn = parseInt($('#dont_respond_on').val());
                }
            }

            localStorage.setItem('pluginWakeupCount', wakeupData.pluginWakeupCount);
            localStorage.setItem('pluginWakeupMaxCount', wakeupData.pluginWakeupMaxCount);
            localStorage.setItem('pluginWakeupDontRespondOn', wakeupData.pluginWakeupDontRespondOn);

            this._log(window.location.host + ' SAVE WAKEUP DATA TO LOCAL STORAGE', JSON.stringify(wakeupData, null, 4));
        },

        /**
         * Clear previous configuration of wakeup (background open for sync) behavior for Plugin
         * from the Local Storage
         *
         * @private
         */
        _clearWakeupData: function () {
            localStorage.removeItem('pluginWakeupCount');
            localStorage.removeItem('pluginWakeupMaxCount');
            localStorage.removeItem('pluginWakeupDontRespondOn');

            this._log(window.location.host + ' CLEAR WAKEUP DATA FROM LOCAL STORAGE');
        },

        addMandatoryParam: function (target, key, value) {
            key = key || '';
            value = value || '';

            var clonedElement = $('.example-property').clone().removeClass('example-property').addClass('item--mandatory');

            clonedElement.find('.key').removeClass('writable').removeAttr('contenteditable').text(key);
            clonedElement.find('.value').text(value);

            this.initChangeOfValue(clonedElement);
            this.initItemRemove(clonedElement);

            $(target).parent('.item').after(clonedElement);
        },

        initChangeOfWakeup: function (element) {

            function onWakeupChange(elem) {
                var isChecked = $(elem).is(':checked');

                if (isChecked) {
                    $(element).find('#repeat_count').prop('disabled', false);
                    $(element).find('#dont_respond').prop('disabled', false);

                    $(element).find('#wakeup_row').removeClass('wakeup-form-row--disabled');

                    onDontRespondChange($(element).find('#dont_respond'));
                } else {
                    $(element).find('#repeat_count').prop('disabled', true);
                    $(element).find('#dont_respond').prop('disabled', true);
                    $(element).find('#dont_respond_on').prop('disabled', true);

                    $(element).find('#wakeup_row').addClass('wakeup-form-row--disabled');
                    $(element).find('#dont_respond_row').addClass('wakeup-form-row--disabled');
                }
            }

            function onDontRespondChange(elem) {
                var isChecked = $(elem).is(':checked');

                if (isChecked) {
                    $(element).find('#dont_respond_on').prop('disabled', false);
                    $(element).find('#dont_respond_row').removeClass('wakeup-form-row--disabled');
                } else {
                    $(element).find('#dont_respond_on').prop('disabled', true);
                    $(element).find('#dont_respond_row').addClass('wakeup-form-row--disabled');
                }
            }

            $(element).find('#wakeup').change(function (e) {
                onWakeupChange(e.target);
            });

            $(element).find('#dont_respond').change(function (e) {
                onDontRespondChange(e.target);
            });

            onWakeupChange($(element).find('#wakeup'));
        },

        initChangeOfInventoryAction: function (element) {
            $(element).find('.select-inventory-action').on('change', function (e) {

                $(e.target).parents('.items').first().find('.item--mandatory').remove();

                switch ($(e.target).val()) {
                    case 'create':
                        this.addMandatoryParam(e.target, 'invpool');
                        this.addMandatoryParam(e.target, 'quantity');
                        this.addMandatoryParam(e.target, 'invtype');
                        this.addMandatoryParam(e.target, 'inv_aid');
                        this.addMandatoryParam(e.target, 'inv_pid');
                        break;

                    case 'delete':
                        this.addMandatoryParam(e.target, 'invid');
                        break;

                    case 'install':
                        this.addMandatoryParam(e.target, 'invid');
                        this.addMandatoryParam(e.target, 'inv_aid');
                        this.addMandatoryParam(e.target, 'quantity');
                        break;

                    case 'deinstall':
                        this.addMandatoryParam(e.target, 'invid');
                        this.addMandatoryParam(e.target, 'inv_pid');
                        this.addMandatoryParam(e.target, 'quantity');
                        break;

                    case 'undo_install':
                        this.addMandatoryParam(e.target, 'invid');
                        this.addMandatoryParam(e.target, 'quantity');
                        break;

                    case 'undo_deinstall':
                        this.addMandatoryParam(e.target, 'invid');
                        this.addMandatoryParam(e.target, 'quantity');
                        break;
                }

                this._updateResponseJSON();
            }.bind(this));
        },

        initChangeOfDataItems: function () {
            //set checkboxes from local storage
            if (localStorage.getItem('dataItems')) {
                $('.data-items').attr('checked', true);
                $('.data-items-holder').show();

                var dataItems = JSON.parse(localStorage.getItem('dataItems'));

                $('.data-items-holder input').each(function () {
                    if (dataItems.indexOf(this.value) != -1) {
                        $(this).attr('checked', true);
                    }
                });
            }

            //init handlers
            $('.data-items').on('change', function (e) {
                $('.data-items-holder').toggle();
            });
        },

        initChangeOfValue: function (element) {
            $(element).find('.value__item.writable, .key.writable, #wakeup').on('input change', function (e) {
                $(e.target).parents('.item').addClass('edited');

                this._updateResponseJSON();
            }.bind(this));
        },

        initItemRemove: function (element) {
            $(element).find('.button--remove-item').on('click', function (e) {
                //remove item
                $(e.target).parents('.item').first().remove();

                //reindex actions
                if ($(e.target).parents('.item').first().find('.action-key').length > 0) {
                    $('.item:not(.example-action) .action-key').each(function (index) {
                        $(this).text(index);
                    });
                }

                this._updateResponseJSON();
            }.bind(this));
        },

        initCollapsableKeys: function (element) {
            $(element).find('.key').each(function (index, item) {
                if ($(item).siblings('.value').has('.items').length !== 0) {
                    $(item).addClass('clickable');
                }
            });

            $(element).find('.key').on('click', function () {
                if ($(this).siblings('.value').has('.items').length !== 0) {
                    $(this).siblings('.value').toggle();
                    $(this).toggleClass('collapsed');
                }
            });

            $(element).find('.item-expander').on('click', function (e) {
                var key = $(e.target).parents('.value').first().siblings('.key').first();

                if (key.hasClass('clickable')) {
                    key.trigger('click');
                }
            });
        },

        initAddButtons: function (element) {
            $(element).find('.button--add-property').click(function (e) {
                var clonedElement = $('.example-property').clone().removeClass('example-property');

                this.initChangeOfValue(clonedElement);
                this.initItemRemove(clonedElement);

                $(e.target).parent('.item').before(clonedElement);

                $(e.target).parents('.item').addClass('edited');

                this._updateResponseJSON();
            }.bind(this));

            $(element).find('.button--add-action').click(function (e) {
                var clonedElement = $('.example-action').clone().removeClass('example-action');
                var actionsCount = +$(e.target).parents('.item:not(.item--excluded)').find('.action-key').length;

                clonedElement.find('.action-key').text(actionsCount);

                this.initAddButtons(clonedElement);
                this.initCollapsableKeys(clonedElement);
                this.initChangeOfValue(clonedElement);
                this.initChangeOfInventoryAction(clonedElement);
                this.initItemRemove(clonedElement);

                $(e.target).parent('.item').before(clonedElement);

                $(e.target).parents('.item').addClass('edited');

                this._updateResponseJSON();
            }.bind(this));
        },

        /**
         * Render JSON object to DOM
         *
         * @param {Object} data - JSON object
         *
         * @returns {jQuery}
         */
        renderForm: function (data) {
            return this.renderCollection('data', data, true);
        },

        /**
         * Render JSON object to follow HTML:
         *
         * <div class="item">
         *     <div class="key">{key}</div>
         *     <div class="value">{value}</div>
         * </div>
         * <div class="item">
         *     <div class="key">{key}</div>
         *     <div class="value">
         *         <div class="items">
         *              <div class="item">
         *                  <div class="key">{key}</div>
         *                  <div class="value">{value}</div>
         *              </div>
         *              <div class="item">
         *                  <div class="key">{key}</div>
         *                  <div class="value">{value}</div>
         *              </div>
         *              ...
         *         </div>
         *     </div>
         * </div>
         * ...
         *
         * @param {String} key - Collection name
         * @param {Object} items - Child items of collection
         * @param {Boolean} [isWritable] - Will render as writable?
         * @param {number} [level] - Level of recursion
         * @param {string} [parentKey] - parent Key
         *
         * @returns {jQuery}
         */
        renderCollection: function (key, items, isWritable, level, parentKey) {
            var render_item = $('<div>').addClass('item');
            var render_key = $('<div>').addClass('key').text(key);
            var render_value = $('<div>').addClass('value value__collection');
            var render_items = $('<div>').addClass('items');

            isWritable = isWritable || false;
            level = level || 1;
            parentKey = parentKey || '';

            var newParentKey = key;

            if (items) {
                $.each(items, function (key, value) {
                    if (value && typeof value === 'object') {
                        render_items.append(this.renderCollection(key, value, isWritable, level + 1, newParentKey));
                    } else {
                        render_items.append(this.renderItem(key, value, isWritable, level + 1, newParentKey).get(0));
                    }
                }.bind(this));
            }

            render_item.append('<div class="item-expander"></div>');
            render_item.append(render_key);

            render_value.append(render_items);
            render_item.append($('<br>'));
            render_item.append(render_value);

            return render_item;
        },

        /**
         * Render key and value to follow HTML:
         *
         * <div class="item">
         *     <div class="key">{key}</div>
         *     <div class="value">{value}</div>
         * </div>
         *
         * @param {String} key - Key
         * @param {String} value - Value
         * @param {Boolean} [isWritable] - Will render as writable?
         * @param {number} [level] - Level of recursion
         * @param {string} [parentKey] - parent Key
         *
         * @returns {jQuery}
         */
        renderItem: function (key, value, isWritable, level, parentKey) {
            var render_item = $('<div>').addClass('item');
            var render_value;
            var render_key;

            isWritable = isWritable || false;
            level = level || 1;
            parentKey = parentKey || '';

            render_key = $('<div>').addClass('key').text(key);
            render_item.append('<div class="item-expander"></div>')
                .append(render_key)
                .append('<span class="delimiter">: </span>');

            if (value === null) {
                value = '';
            }

            if (
                typeof this.renderReadOnlyFieldsByParent[parentKey] !== 'undefined' &&
                typeof this.renderReadOnlyFieldsByParent[parentKey][key] !== 'undefined' &&
                this.renderReadOnlyFieldsByParent[parentKey][key] === true
            ) {
                isWritable = false;
            }

            switch (key) {
                case "csign":
                    if (isWritable) {
                        render_value = $('<button>').addClass('button button--item-value button--generate-sign').text('Generate');
                    }
                    break;
                default:

                    var pluginInitData = false;

                    if (this._isJson(localStorage.getItem('pluginInitData'))) {
                        pluginInitData = JSON.parse(localStorage.getItem('pluginInitData'));
                    }

                    if (this.dictionary[key]) {
                        render_value = this.renderSelect(this.dictionary, key, value, isWritable).addClass('value value__item');
                    } else if (
                        pluginInitData &&
                        pluginInitData[key] &&
                        "enum" == pluginInitData[key].type &&
                        pluginInitData[key].enum
                    ) {
                        render_value = this.renderEnumSelect(pluginInitData[key].enum, key, value, isWritable).addClass('value value__item');
                    } else {
                        render_value = $('<div>').addClass('value value__item').text(value);

                        if (isWritable) {
                            render_value.addClass('writable').attr('contenteditable', true);
                        }
                    }

                    break;
            }

            render_item.append(render_value);

            return render_item;
        },

        /**
         * Render enums with validate of outs values
         *
         * <select class="value [writable]" [disabled]>
         *     <option value="{value}" [selected]>{dictionary}</option>
         *     ...
         * </select>
         *
         * @param {Object} dictionary - Dictionary that will be used for Enum rendering
         * @param {String} key - Just field name
         * @param {String} value - Selected value
         * @param {Boolean} isWritable - Will render as writable?
         *
         * @returns {HTMLElement}
         */
        renderSelect: function (dictionary, key, value, isWritable) {
            var render_value;

            var outs = dictionary[key][value].outs;
            var allowedValues = [value].concat(outs);
            var disabled = '';

            render_value = $('<select>').css({ background: dictionary[key][value].color });

            if (!outs.length || !isWritable) {
                render_value.attr('disabled', true);
            } else {
                render_value.addClass('writable');
            }

            $.each(allowedValues, function (index, label) {
                render_value.append('<option' + (label === value ? ' selected' : '') + ' value="' + dictionary[key][label].label + '">' + dictionary[key][label].translation + '</option>');
            });

            return render_value;
        },

        /**
         * Render enums
         *
         * <select class="value [writable]" [disabled]>
         *     <option value="{value}" [selected]>{dictionary}</option>
         *     ...
         * </select>
         *
         * @param {Object} dictionary - Dictionary that will be used for Enum rendering
         * @param {String} key - Just field name
         * @param {String} value - Selected value
         * @param {Boolean} isWritable - Will render as writable?
         *
         * @returns {HTMLElement}
         */
        renderEnumSelect: function (dictionary, key, value, isWritable) {
            var render_value;

            var disabled = '';

            render_value = $('<select>');

            if (isWritable) {
                render_value.addClass('writable');
            } else {
                render_value.attr('disabled', true);
            }

            $.each(dictionary, function (index, label) {
                render_value.append('<option' + (index === value ? ' selected' : '') + ' value="' + index + '">' + label.text + '</option>');
            });

            return render_value;
        },

        /**
         * Generate output JSON
         *
         * @returns {Object}
         */
        generateJson: function () {
            var outputJson = {
                apiVersion: 1,
                method: 'close',
                backScreen: $('.back_method_select').val(),
                wakeupNeeded: $('#wakeup').is(':checked')
            };

            if (outputJson.backScreen === 'activity_by_id') {
                $.extend(outputJson, {
                    backActivityId: $('.back_activity_id').val()
                });
            }

            //parse entity
            $.extend(outputJson, this.parseCollection($('.form')).data);

            //parse actions
            var actionsJson = this.parseCollection($('.actions-form'), true);

            if (actionsJson.actions.length > 0) {
                $.extend(outputJson, actionsJson);
            }

            delete outputJson.entity;
            delete outputJson.resource;

            return outputJson;
        },

        /**
         * Convert HTML elements to JSON
         *
         * @param {HTMLElement} rootElement - Root element that should be parsed recursively
         * @param {Boolean} [parseAllExceptExcluded] - Need to parse all elements except excluded
         *
         * @returns {Object}
         *
         * <div class="key">activity</div>
         * <div class="value value__collection">
         *     <div class="items"> <-------------------------------- rootElement !!!
         *         <div class="item edited">
         *             <div class="key">WO_COMMENTS</div>
         *             <div class="value">text_comments</div>
         *         </div>
         *         <div class="item">
         *             <div class="key">aid</div>
         *             <div class="value">4225274</div>
         *         </div>
         *         <div class="item">
         *             <div class="key">caddress</div>
         *             <div class="value">text_address</div>
         *         </div>
         *     </div>
         * </div>
         *
         * converts to:
         *
         * {
         *     "aid": "4225274",
         *     "WO_COMMENTS": "text_comments"
         * }
         *
         */
        parseCollection: function (rootElement, parseAllExceptExcluded) {
            parseAllExceptExcluded = parseAllExceptExcluded || false;

            var returnObject;

            if ($(rootElement).hasClass('items--without-key')) {
                returnObject = [];
            } else {
                returnObject = {};
            }

            $(rootElement).children('.item').each(function (itemIndex, item) {
                var parentKey;
                var valueKey;
                var value;
                var mandatoryField = false;

                parentKey = $(rootElement).parent().siblings('.key').get(0);
                valueKey = $(item).children('.key').get(0);

                //Logic of mandatory fields
                if ((parentKey !== undefined) && (
                        ($(parentKey).text() == 'activity' && $(valueKey).text() == 'aid') || ($(parentKey).text() == 'inventory' && $(valueKey).text() == 'invid')
                    )) {
                    mandatoryField = true;
                }

                if (
                    $(item).hasClass('item') === true &&
                    (
                        $(item).hasClass('edited') === true || parseAllExceptExcluded || mandatoryField
                    ) &&
                    $(item).hasClass('item--excluded') === false
                ) {

                    value = $(item).children('.value').get(0);

                    if ($(value).children('.items').length > 0) {
                        var parsedChild = this.parseCollection($(value).children('.items').get(0), parseAllExceptExcluded);

                        if ($(rootElement).hasClass('items--without-key')) {
                            returnObject.push(parsedChild);
                        } else {
                            returnObject[$(valueKey).text()] = parsedChild;
                        }
                    } else {
                        switch ($(value).prop("tagName")) {
                            case 'SELECT':
                                returnObject[$(valueKey).text()] = $(value).val();
                                break;

                            case 'CANVAS':
                                returnObject[$(valueKey).text()] = value.toDataURL();
                                break;

                            default:
                                returnObject[$(valueKey).text()] = $(value).text();
                                break;
                        }
                    }
                }
            }.bind(this));

            return returnObject;
        },

        /**
         * Update JSON
         *
         * @private
         */
        _updateResponseJSON: function () {
            var jsonToSend = this.generateJson();

            $('.json__response').text(JSON.stringify(jsonToSend, null, 4));
        },

        /**
         * Initialization function
         */
       /**
         * Initialization function
         */
		init: function() {
			if (navigator.serviceWorker) {
				this._log(window.location.host + ' Service Worker is supported');
				navigator.serviceWorker.register('transferActivity-service-worker.js').then(function(registration) {
					this._log(window.location.host + ' Service Worker is registered with scope: ' + registration.scope);
					registration.addEventListener('updatefound', function() {
						this._log(window.location.host + ' Service Worker update is found');
						var newServiceWorker = registration.installing;
						newServiceWorker.addEventListener('statechange', function() {
							switch (newServiceWorker.state) {
								case "installed":
									this._log(window.location.host + ' New Service Worker is installed');
									break;
							}
						}.bind(this));
					}.bind(this));
					navigator.serviceWorker.addEventListener('controllerchange', function() {
						this.notifyAboutNewVersion();
					}.bind(this));
					this.startApplication();
				}.bind(this), function(err) {
					this._log(window.location.host + ' Service Worker registration failed: ' + err);
					this.startApplication();
				}.bind(this));
				return;
			} else {
				this._log(window.location.host + ' Service Worker is not supported');
			}
			this.startApplication();
		},
		startApplication: function() {

			$("#searchingDiv").hide();
			$("#manualAdditionDiv").hide();
			$("#resultsDynamicDiv2").hide();
			
			
            this._log(window.location.host + ' PLUGIN HAS BEEN STARTED');

            $('.back_method_select').on('change', function () {
                if ($('.back_method_select').val() == 'activity_by_id') {
                    $('.back_activity_id').show();
                } else {
                    $('.back_activity_id').val('').hide();
                }
            });

            $('.json_local_storage_toggle').on('click', function () {
                $('.json__local-storage').toggle();
            });

            $('.json_request_toggle').on('click', function () {
                $('.column-item--request').toggle();
            });

            $('.json_response_toggle').on('click', function () {
                $('.column-item--response').toggle();
            }.bind(this));


            window.addEventListener("message", this._getPostMessageData.bind(this), false);

            var jsonToSend = {
                apiVersion: 1,
                method: 'ready',
                sendInitData: true
            };

            //parse data items
            var dataItems = ['resource','customerInventories']; //changed by PSN-20/01/2018 .. took out deinstalledinventory
            /*var dataItems = JSON.parse(localStorage.getItem('dataItems'));*/

            if (dataItems) {
                $.extend(jsonToSend, {dataItems: dataItems});
            }

            this._sendPostMessageData(jsonToSend);
		},
		notifyAboutNewVersion: function() {
			this._log(window.location.host + ' New Service Worker is activated. Page refresh is needed');
			var footer = document.querySelector('.footer');
			var versionNotificationElement = document.createElement('div');
			versionNotificationElement.className = 'new-version-notification';
			versionNotificationElement.innerHTML = 'New version is detected. Please reopen the page';
			footer.appendChild(versionNotificationElement);
		}		
    });
	window.OfscPlugin.getVersion = function() {
		return resourcesVersion;
	};
})(jQuery);