"use strict";

(function ($) {
	window.OfscPlugin = function (debugMode) {
		this.debugMode = debugMode || false;
	};

	var pluginInitData = {};
	var pluginOpenData = {};
	var stmFileDetails = {};

	var resourcesVersion = '215.0.3+1614692810930';

	$.extend(window.OfscPlugin.prototype, {
		/**
		 * Dictionary of enums
		 */
		dictionary: {
			astatus: {
				pending: {
					label: 'pending',
					translation: 'Pending',
					outs: ['started', 'cancelled', 'suspended', 'enroute'],
					color: '#ffde00'
				},
				enroute: {
					label: 'enroute',
					translation: 'En Route',
					outs: ['started', 'cancelled', 'pending'],
					color: '#ff920c'
				},
				started: {
					label: 'started',
					translation: 'Started',
					outs: ['complete', 'suspended', 'notdone', 'cancelled'],
					color: '#a2de61'
				},
				complete: {
					label: 'complete',
					translation: 'Completed',
					outs: [],
					color: '#79B6EB'
				},
				suspended: {
					label: 'suspended',
					translation: 'Suspended',
					outs: [],
					color: '#9FF'
				},
				notdone: {
					label: 'notdone',
					translation: 'Not done',
					outs: [],
					color: '#60CECE'
				},
				cancelled: {
					label: 'cancelled',
					translation: 'Cancelled',
					outs: [],
					color: '#80FF80'
				}
			},
			invpool: {
				customer: {
					label: 'customer',
					translation: 'Customer',
					outs: ['deinstall'],
					color: '#04D330'
				},
				install: {
					label: 'install',
					translation: 'Installed',
					outs: ['provider'],
					color: '#00A6F0'
				},
				deinstall: {
					label: 'deinstall',
					translation: 'Deinstalled',
					outs: ['customer'],
					color: '#00F8E8'
				},
				provider: {
					label: 'provider',
					translation: 'Resource',
					outs: ['install'],
					color: '#FFE43B'
				}
			}
		},

		actions: {
			activity: [{
					value: '',
					translation: 'Select Action...'
				},
				{
					value: 'create',
					translation: 'Create Activity'
				}
			],
			inventory: [{
					value: '',
					translation: 'Select Action...'
				},
				{
					value: 'create',
					translation: 'Create Inventory'
				},
				{
					value: 'delete',
					translation: 'Delete Inventory'
				},
				{
					value: 'install',
					translation: 'Install Inventory'
				},
				{
					value: 'deinstall',
					translation: 'Deinstall Inventory'
				},
				{
					value: 'undo_install',
					translation: 'Undo Install Inventory'
				},
				{
					value: 'undo_deinstall',
					translation: 'Undo Deinstall Inventory'
				}
			],
			queue: [{
					value: '',
					translation: 'Select Action...'
				},
				{
					value: 'activate_queue',
					translation: 'Activate'
				},
				{
					value: 'deactivate_queue',
					translation: 'Deactivate'
				}
			]
		},

		mandatoryActionProperties: {},

		/**
		 * Which field shouldn't be editable
		 *
		 * format:
		 *
		 * parent: {
		 *     key: true|false
		 * }
		 *
		 */
		renderReadOnlyFieldsByParent: {
			data: {
				apiVersion: true,
				method: true,
				entity: true
			},
			resource: {
				pid: true,
				pname: true,
				gender: true
			}
		},

		/**
		 * Check for string is valid JSON
		 *
		 * @param {*} str - String that should be validated
		 *
		 * @returns {boolean}
		 *
		 * @private
		 */
		_isJson: function (str) {
			try {
				JSON.parse(str);
			} catch (e) {
				return false;
			}
			return true;
		},

		/**
		 * Return origin of URL (protocol + domain)
		 *
		 * @param {String} url
		 *
		 * @returns {String}
		 *
		 * @private
		 */
		_getOrigin: function (url) {
			if (url != '') {
				if (url.indexOf("://") > -1) {
					return 'https://' + url.split('/')[2];
				} else {
					return 'https://' + url.split('/')[0];
				}
			}

			return '';
		},

		/**
		 * Return domain of URL
		 *
		 * @param {String} url
		 *
		 * @returns {String}
		 *
		 * @private
		 */
		_getDomain: function (url) {
			if (url != '') {
				if (url.indexOf("://") > -1) {
					return url.split('/')[2];
				} else {
					return url.split('/')[0];
				}
			}

			return '';
		},

		/**
		 * get domain / company name
		 */
		_getDomainURL: function () {
			//return document.referrer.match(/\:\/\/([^\/]+)\.etadirect\.com\//)[1];
			//Reg Ex modified to handle both etadirect.com and fs.ocs.oraclecloud.com URLs
			return document.referrer.match(/\:\/\/([^\/]+)\.(?:etadirect.com|fs.ocs.oraclecloud.com)/)[1];
		},

		/**
		 * Sends postMessage to document.referrer
		 *
		 * @param {Object} data - Data that will be sent
		 *
		 * @private
		 */
		_sendPostMessageData: function (data) {
			var isString = 'string' === typeof data;

			var originUrl = document.referrer || (document.location.ancestorOrigins && document.location.ancestorOrigins[0]) || '';
			var domain = originUrl ? this._getDomain(originUrl) : '*OFS*';
			var targetOrigin = originUrl ? this._getOrigin(originUrl) : '*';
			// var targetOrigin = this._getOrigin('https://example.com'); // Use URL of OFS App here to protect from unauthorized embedding

			if (targetOrigin) {
				this._log(window.location.host + ' -> ' + (isString ? '' : data.method) + ' ' + domain, isString ? data : JSON.stringify(data, null, 4));

				parent.postMessage(data, targetOrigin);
			} else {
				this._log(window.location.host + ' -> ' + (isString ? '' : data.method) + ' ERROR. UNABLE TO GET REFERRER');
			}
		},

		/**
		 * Handles during receiving postMessage
		 *
		 * @param {MessageEvent} event - Javascript event
		 *
		 * @private
		 */
		_getPostMessageData: function (event) {

			if (typeof event.data === 'undefined') {
				this._log(window.location.host + ' <- NO DATA ' + this._getDomain(event.origin), null, null, true);

				return false;
			}

			if (!this._isJson(event.data)) {
				this._log(window.location.host + ' <- NOT JSON ' + this._getDomain(event.origin), null, null, true);

				return false;
			}

			var data = JSON.parse(event.data);

			if (!data.method) {
				this._log(window.location.host + ' <- NO METHOD ' + this._getDomain(event.origin), null, null, true);

				return false;
			}

			this._log(window.location.host + ' <- ' + data.method + ' ' + this._getDomain(event.origin), JSON.stringify(data, null, 4));

			switch (data.method) {
				case 'init':
					this.pluginInitEnd(data);
					break;

				case 'open':
					this.pluginOpen(data);
					break;

				case 'wakeup':
					this.pluginWakeup(data);
					break;

				case 'error':
					data.errors = data.errors || {
						error: 'Unknown error'
					};
					this.processProcedureResult(document, event.data);
					this._showError(data.errors);
					break;

				case 'callProcedureResult':
					this.processProcedureResult(document, event.data);
					break;

				default:
					this.processProcedureResult(document, event.data);
					this._log(window.location.host + ' <- UNKNOWN METHOD: ' + data.method + ' ' + this._getDomain(event.origin), null, null, true);
					break;
			}
		},

		/**
		 * Show alert with error
		 *
		 * @param {Object} errorData - Object with errors
		 *
		 * @private
		 */
		_showError: function (errorData) {
			alert(JSON.stringify(errorData, null, 4));
		},

		/**
		 * Logs to console
		 *
		 * @param {String} title - Message that will be log
		 * @param {String} [data] - Formatted data that will be collapsed
		 * @param {String} [color] - Color in Hex format
		 * @param {Boolean} [warning] - Is it warning message?
		 *
		 * @private
		 */
		_log: function (title, data, color, warning) {
			if (!this.debugMode) {
				return;
			}
			if (!color) {
				color = '#0066FF';
			}
			if (!!data) {
				console.groupCollapsed('%c[Plugin API] ' + title, 'color: ' + color + '; ' + (!!warning ? 'font-weight: bold;' : 'font-weight: normal;'));
				console.log('[Plugin API] ' + data);
				console.groupEnd();
			} else {
				console.log('%c[Plugin API] ' + title, 'color: ' + color + '; ' + (!!warning ? 'font-weight: bold;' : ''));
			}
		},

		_getBlob: function (url) {
			return new Promise(function (resolve, reject) {
				var xhr = new XMLHttpRequest();

				xhr.responseType = 'blob';
				xhr.open('GET', url, true);

				xhr.onreadystatechange = function () {
					if (xhr.readyState === xhr.DONE) {
						if (200 == xhr.status || 201 == xhr.status) {
							try {
								return resolve(xhr.response);
							} catch (e) {
								return reject(e);
							}
						}

						return reject(new Error(
							'Server returned an error. HTTP Status: ' + xhr.status
						));
					}
				};

				xhr.send();
			});
		},

		/**
		 * Business login on plugin init
		 */
		saveToLocalStorage: function (data) {
			this._log(window.location.host + ' INIT. SET DATA TO LOCAL STORAGE', JSON.stringify(data, null, 4));

			var initData = {};

			$.each(data, function (key, value) {
				if (-1 !== $.inArray(key, ['apiVersion', 'method'])) {
					return true;
				}

				initData[key] = value;
			});

			localStorage.setItem('pluginInitData', JSON.stringify(initData));
		},

		/**
		 * Business login on plugin init end
		 *
		 * @param {Object} data - JSON object that contain data from OFS
		 */
		pluginInitEnd: function (data) {
			this.saveToLocalStorage(data);

			var messageData = {
				apiVersion: 1,
				method: 'initEnd'
			};

			if (localStorage.getItem('pluginWakeupCount') < localStorage.getItem('pluginWakeupMaxCount')) {
				this._log(window.location.host + ' UNFINISHED WAKEUP DATA FOUND IN LOCAL STORAGE');

				messageData.wakeupNeeded = true;
			}

			this._sendPostMessageData(messageData);
		},
		/**
		 * Ajax call to update the properties
		 */
		ajaxCall: function (url, payload, method, headers) {
			$.ajax({
				dataType: "json",
				url: url,
				data: JSON.stringify(payload),
				method: method,
				//async: false,
				crossDomain: true,
				headers: headers,
				processData: false,
				contentType: 'application/json; charset=utf-8',
				timeout: 15000,
				success: function (response) {
					console.log("Update Resource properties - Success messagae: " + JSON.stringify(response));
				}.bind(this),
				error: function (errorData) {
					console.log("Update Resource properties - Error messagae:" + JSON.stringify(errorData));
				}
			});
		},
		/**
		 * Business login on plugin open
		 *
		 * @param {Object} receivedData - JSON object that contain data from OFS
		 */
		pluginOpen: function (receivedData) {
			this._clearWakeupData();
			if (localStorage.getItem('pluginInitData')) {
				this._log(window.location.host + ' OPEN. GET DATA FROM LOCAL STORAGE', JSON.stringify(JSON.parse(localStorage.getItem('pluginInitData')), null, 4));
			}

			pluginOpenData = receivedData;
			console.log(pluginOpenData.activity.aid);
			// Get the domain name from the URL
			var domainName = this._getDomainURL();
			var activityID = pluginOpenData.activity.aid;
			
			var blnIsTechOnline = false;
			
			// Building Authorization headers
			var headers = {
				'Authorization': 'Basic ' + btoa(pluginOpenData.securedData.clientId + "@" + domainName + ":" + pluginOpenData.securedData.clientSecret),
				'content-type': 'application/json',
				'accept': 'application/octet-stream',
			};
			
			// Start changes for CHG0073271_STM_Phase1_Enhancements
			var $parentThis = this; 
			var readOnlyView = false;
			var activityStatus = pluginOpenData.activity.astatus;
			var activityState = pluginOpenData.activity.A_STATE;
			var confirmDebrief = pluginOpenData.activity.A_CONFIRM;
			
			if(activityStatus != null && "" != activityStatus){
				activityStatus = activityStatus.toUpperCase();
			}
			
			if(activityState != null && "" != activityState){
				activityState = activityState.toUpperCase();
			}
			
			if((confirmDebrief == null || "" == confirmDebrief || "COMPLETE" == activityStatus) 
					&& ("SI" != activityState || "COMPLETE" == activityStatus) && "STARTED" != activityStatus){
				readOnlyView = true;
			}
			
			if('Y' == pluginOpenData.openParams.READ_ONLY){
				readOnlyView = true;
			}
			// End Changes for CHG0073271_STM_Phase1_Enhancements			
			
			//----- added for CHG# -- FY23 ----
			var stmFileDetails = {};
			
			checkIfTechIsOnline();
			
			if(blnIsTechOnline == false){
				var offlineDataAttr = "STM_ACT_OFFLINE_FILE";
				
				if( localStorage.getItem(offlineDataAttr) !== null && 
					localStorage.getItem(offlineDataAttr) !== undefined && 
					localStorage.getItem(offlineDataAttr) !== '')
				{
					stmFileDetails = JSON.parse(localStorage.getItem(offlineDataAttr));
				}
			}else{
				try {
					var stmTaskURL = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/activities/" + activityID + "/A_STM_TASK_FILE";
					console.log(stmTaskURL);
					
					// Ajax call to get the tech today activities
					$.ajax({
						dataType: "json",
						url: stmTaskURL,
						method: "GET",
						async: false,
						crossDomain: true,
						headers: headers,
						processData: false,
						timeout: 15000,
						success: function (response) {
							if (response.aSTMTask) {
								stmFileDetails = response;
							} else {
								stmFileDetails = {};
							}
						}.bind(this),
						error: function (errorData) {
							console.log("While retreiving STM data - Error messagae:" + JSON.stringify(errorData));
							stmFileDetails = {};
						}
					});
				} catch (err) {
					var stmErrorPayload = {
						"STM_PLUGIN_ERROR": "Error creating STM: " + err.message
					};
				}
			}

			if (stmFileDetails.aSTMTask != null) {
				
				var stmDetails = JSON.parse(stmFileDetails.aSTMTask);
				localStorage.setItem('stmData', JSON.stringify(stmDetails));
				var web_txt = "<table width='100%' class='table' >";
				web_txt += "<tr class='table-row'>";
				web_txt += "<th class='table-header-cell'><div class='table-header-column-title'>Number</div></th>";
				web_txt += "<th class='table-header-cell'><div class='table-header-column-title'>Category</div> </th>";
				web_txt += "<th class='table-header-cell'><div class='table-header-column-title'>Note</div></th>";
				web_txt += "<th class='table-header-cell'><div class='table-header-column-title'>Link</div></th>";
				web_txt += "<th class='table-header-cell'><div class='table-header-column-title'>Duration</div></th>";
				web_txt += "<th class='table-header-cell'><div class='table-header-column-title'>Disposition</div></th>";
				web_txt += "<th class='table-header-cell'><div class='table-header-column-title'>Comment</div></th>";
				web_txt += "</tr>";
				var mob_txt = '<table class="table" > <tbody class="section" >';
				var selectMenuOption = "", workNoteInput = "",STMWorkNote = "", durationInput = "";
				$.each(stmDetails, function (i, task) {
					selectMenuOption = "", workNoteInput = "",STMWorkNote = "", durationInput = "";
					web_txt += '<tr class="table-row">';
					web_txt += '<td class="table-cell"><div class="table-cell-text">' + task.aSTMTaskNumber + '</div></td>';
					web_txt += '<td class="table-cell"><div class="table-cell-text">' + task.aSTMCategory + '</div></td>';
					web_txt += '<td class="table-cell"><div class="table-cell-text">' + task.aSTMTaskNote + '</div></td>';
					web_txt += '<td class="table-cell"><div class="table-cell-text"><a href=' + task.aSTMTaskLink + ' target="_blank">Link</a></div></td>';
					// Start Chagnes for CHG0073271_STM_Phase1_Enhancements
					if (task.aSTMCategory.substr(0,3) == "CBM" || 'TCRU' == task.aSTMCategory.substr(0,4)) { // changes for CHG0075477  - TCRU
						if('35' == task.aSTMStatus || '40' == task.aSTMStatus || '4' == task.aSTMStatus){
							durationInput = '<input style="width: 100px;background:#F9F8F8" disabled name="cbm-' + i + '" type=number onchange="setValDuration(this)" min="0" class="form-item cbm-' + i + '" value="' + task.aSTMTimeWorked + '">';
						} else{
							durationInput = '<input style="width: 100px;" name="cbm-' + i + '" type=number onchange="setValDuration(this)" min="0" class="form-item cbm-' + i + '" value="' + task.aSTMTimeWorked + '">';
						}
						web_txt += '<td class="table-cell"><div class="table-cell-text"> '+durationInput+'Minutes</div></td>';
					} else {
						web_txt += '<td class="table-cell"><div class="table-cell-text"></div></td>';
					}
					selectMenuOption = '<select name="' + i + '" onchange="setValDisposition(this)" class="form-item" style="" value="' + task.aSTMStatus + '"> <option value="1" selected>Open</option>';
					
					if(task.aSTMStatus == "3"){
						selectMenuOption += '<option value="3" selected>Closed Complete</option>';
					}else{
						selectMenuOption += '<option value="3">Closed Complete</option>';
					}
					
					if(task.aSTMStatus == "4"){
						selectMenuOption += '<option value="4" selected>Closed Incomplete</option>';
					}else{
						selectMenuOption += '<option value="4">Closed Incomplete</option>';
					}
					if(task.aSTMCategory.substr(0,3) == "CBM"){
						if(task.aSTMStatus == "35"){
							selectMenuOption += '<option value="35" selected>Closed Break/Fix Resolved</option>';
						}else{
							selectMenuOption += '<option value="35">Closed Break/Fix Resolved</option>';
						}
						
						if(task.aSTMStatus == "40"){
							selectMenuOption += '<option value="40" selected>Closed Customer Resolved</option>';
						}else{
							selectMenuOption += '<option value="40">Closed Customer Resolved</option>';
						}
					}
					selectMenuOption += '</select>';
					if(task.aSTMWorkNote != null){
						STMWorkNote = task.aSTMWorkNote;
					}
					
					workNoteInput = '<input name="comment-'+i+'" onchange="setComment(this)"  type="text" value="' + STMWorkNote  + '" class="form-item comment-'+i+'" /><span class="comment-error-'+i+'" style="color:red"></span>';
					
					/*if (task.aSTMStatus == "3") {
						web_txt += '<td class="table-cell"><div class="table-cell-text"> <select name="' + i + '" onchange="setValDisposition(this)" class="form-item" style="" value="' + task.aSTMStatus + '"><option value="1">open</option><option value="3" selected>Closed Complete</option><option value="4">Closed Incomplete</option></select></div> </td>';
					} else if (task.aSTMStatus == "4") {
						web_txt += '<td class="table-cell"><div class="table-cell-text"> <select name="' + i + '" onchange="setValDisposition(this)" class="form-item" style="" value="' + task.aSTMStatus + '"><option value="1">open</option><option value="3">Closed Complete</option><option value="4" selected>Closed Incomplete</option></select></div> </td>';
					} else {
						web_txt += '<td class="table-cell"><div class="table-cell-text"> <select name="' + i + '" onchange="setValDisposition(this)" class="form-item" style="" value="' + task.aSTMStatus + '"><option value="1" selected>open</option><option value="3">Closed Complete</option><option value="4">Closed Incomplete</option></select></div> </td>';
					}*/
					
					web_txt += '<td class="table-cell"><div class="table-cell-text"> '+selectMenuOption+' </div> </td>'
					web_txt += '<td class="table-cell"><div class="table-cell-text" style="max-width:210px;"> '+workNoteInput+' </div></td>';
					// End changes for CHG0073271_STM_Phase1_Enhancements

					web_txt += '</tr>';

					mob_txt += '<tr class="table-row table-row--mobile table-row--clickable table-row--subitem"> <td class="table-cell table-cell--identifier table-cell--group-identifier"  >';
					mob_txt += '<div class="table-cell-text"><span class="grid-identifier" style="color: #D42151">Number :' + task.aSTMTaskNumber + '</span></br>';
					mob_txt += '<span class="grid-identifier" style="color: #3112FF">Category:' + task.aSTMCategory + '</span></br><span class="grid-identifier" style="color: #672b2b">Note :' + task.aSTMTaskNote + '</span></br>';
					mob_txt += '<span class="grid-identifier">URL:<a href=# class="stmTaskLink" data-url=' + task.aSTMTaskLink + '>Link</a></span></br>';
					// Start changes for CHG0073271_STM_Phase1_Enhancements
					if (task.aSTMCategory.substr(0,3) == "CBM" || "TCRU" == task.aSTMCategory.substr(0,4)) { // Modified for CHG0075477  - TCRU
						mob_txt += '<span class="grid-identifier" style="color: #000000">Duration:'+durationInput+' </span> </br> ';
					}
					
					/*if (task.aSTMStatus == "3") {
						mob_txt += '<span class="grid-identifier" style="color: #000000">Disposition:<select name="' + i + '" onchange="setValDisposition(this)" class="form-item" style="" value="' + task.aSTMStatus + '"><option value="1">open</option><option value="3" selected>Closed Complete</option><option value="4">Closed Incomplete</option></select></span> </div></td></tr>';
					} else if (task.aSTMStatus == "4") {
						mob_txt += '<span class="grid-identifier" style="color: #000000">Disposition:<select name="' + i + '" onchange="setValDisposition(this)" class="form-item" style="" value="' + task.aSTMStatus + '"><option value="1">open</option><option value="3">Closed Complete</option><option value="4" selected>Closed Incomplete</option></select></span> </div></td></tr>';
					} else {
						mob_txt += '<span class="grid-identifier" style="color: #000000">Disposition:<select name="' + i + '" onchange="setValDisposition(this)" class="form-item" style="" value="' + task.aSTMStatus + '"><option value="1" selected>open</option><option value="3">Closed Complete</option><option value="4">Closed Incomplete</option></select></span> </div></td></tr>';
					}*/
					mob_txt += '<span class="grid-identifier" style="color: #000000">Disposition:'+selectMenuOption+'</span> </br>';
					mob_txt += '<span class="grid-identifier" style="color: #672b2b">Comment :'+workNoteInput+'</span>';
					mob_txt += '</div></td></tr>';
					// End changes for CHG0073271_STM_Phase1_Enhancements
				});
				web_txt += '</table></br>';
				mob_txt += '</tbody></table></br>';
				document.getElementById('web_ui').innerHTML = web_txt;
				document.getElementById('mobile_ui').innerHTML = mob_txt;
			} else {
				this._showError("Data Error, Kindly Contact System Administrator.");

			}
			// Start changes for CHG0073271_STM_Phase1_Enhancements
			if(readOnlyView){
				$('#web_ui, #mobile_ui').find('input, select').each(function(){
					$(this).prop('disabled', true);
					$(this).css('background','#F9F8F8');
					$('#stmSubmitBtn_1, #stmSubmitBtn').hide();
				});
			} // End changes for CHG0073271_STM_Phase1_Enhancements
			
			var parentBindThis=this;
			$('.stmTaskLink').click(function () {
				var taskLink= $(this).attr('data-url');
				var callIdValue=btoa(String.fromCharCode.apply(null, window.crypto.getRandomValues(new Uint8Array(16))));
				parentBindThis._sendPostMessageData({
                    "apiVersion": 1,
					"method": "callProcedure",
					"procedure": "openLink",
					"callId": callIdValue,
					"params": {
					"url": taskLink
					}
				});
			});
			
			$('#stmCancelBtn,#stmCancelBtn_1').click(function () {
				this._sendPostMessageData({
                    apiVersion: 1,
                    method: 'close',
                    wakeupNeeded: false,
                    backScreen: 'default',
				});
			}.bind(this));

			$('#stmSubmitBtn,#stmSubmitBtn_1').click(function () {
				//saveaction here
				try {
					var stmInstallStatus, stmInstallComments=""; // Added for CHG0073271_STM_Phase1_Enhancements
					var stmInstallDL;
					var stmTaskStatus=0;
					var cbmStatus=0;
					var proccedFurther = true;
					var stmJSONData = JSON.parse(localStorage.getItem('stmData'));
					$.each(stmJSONData, function (i, task) {
						// Start changes for CHG0073271_STM_Phase1_Enhancements
						if("4" == task.aSTMStatus && (task.aSTMWorkNote == null || "" == task.aSTMWorkNote)){
							$('.comment-error-'+i).html('Required when disposition is set to Closed Incomplete');
							proccedFurther = false;
							return false;
						} // End changes for CHG0073271_STM_Phase1_Enhancements
						
						// For one activity only one or none install task would be added. 
						// So, adding install checklist values to Activity properties for Message scenario.  
						if (task.aSTMCategory == "INSTALL" && task.aSTMStatus == "3") {
							stmInstallStatus = 'Closed Complete';
							stmInstallDL = task.aReportingDL;
							stmInstallComments = task.aSTMWorkNote; // Added for CHG0073271_STM_Phase1_Enhancements
						} else if (task.aSTMCategory == "INSTALL" && task.aSTMStatus == "4") {
							stmInstallStatus = 'Closed InComplete';
							stmInstallDL = task.aReportingDL;
						}
						if (task.aSTMCategory.substr(0,3) == "CBM" || "TCRU" == task.aSTMCategory.substr(0,4)) // Modified for CHG0075477  - TCRU
						{
							if (task.aSTMTimeWorked=="")
							{
							   cbmStatus=1;	
							}
							else if (Math.sign(task.aSTMTimeWorked) == -1)
							{
								cbmStatus=2;
							}
						}
						if (task.aSTMStatus == "1") {
							stmTaskStatus=1;
						}
					});
					if(!proccedFurther){
						return false;
					}
					if (cbmStatus==1)
					{
						this._showError("Please enter duration for Task."); // Modified for CHG0075477  - TCRU
						return false;
					}
					if (cbmStatus==2)
					{
						this._showError("Enter only postive values.");
						return false;
					}
					if (stmTaskStatus==1)
					{
						this._showError("Please close all STM Tasks");
						return false;
					}
					var stmData = localStorage.getItem('stmData');
					var stmUpdateFileDetails = {};
					stmUpdateFileDetails.aSTMTask = stmData;
					var domainName = this._getDomainURL();
					var activityID = pluginOpenData.activity.aid;
					
					//----- added for CHG# -- FY23 ---------------------------------------------
					checkIfTechIsOnline();
					
					var offlineUpdateAttr = "STM_ACT_UPDATE_FILE";
					if(blnIsTechOnline == false){
						localStorage.setItem(offlineUpdateAttr, JSON.stringify(stmUpdateFileDetails));
						localStorage.setItem("CONS_OFFLINE_ACT_ID", activityID);						
						
						var closeParams = {
							apiVersion: 1,
							method: 'close',
							wakeupNeeded: true,
							backScreen: 'default',
							"activity": {
								"aid": activityID,
								"A_STM_INSTALL_STATUS": stmInstallStatus,
								"A_STM_INSTALL_DL": stmInstallDL,
								"A_STM_INSTALL_COMMENTS": stmInstallComments,
								"A_STM_COMPLETE_FLAG": "Y"
							}
						}
						
						this._sendPostMessageData(closeParams);
					//--------------------------------------------------------------------------
					}else{
						try {
							var stmTaskUpdateURL = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/activities/" + activityID + "/A_STM_TASK_FILE";
							// Ajax call to get the tech today activities
							$.ajax({
								dataType: "json",
								url: stmTaskUpdateURL,
								method: "PUT",
								async: false,
								crossDomain: true,
								headers: headers,
								processData: false,
								contentType: 'application/json; charset=utf-8',
								accept: '*/*',
								timeout: 15000,
								data: JSON.stringify(stmUpdateFileDetails),
								success: function (response) {
									console.log(response);
								}.bind(this),
								error: function (errorData) {
									console.log("While retreiving STM data - Error messagae:" + JSON.stringify(errorData));
									stmFileDetails = {};
								}
							});
							this._sendPostMessageData({
								apiVersion: 1,
								method: 'close',
								wakeupNeeded: false,
								backScreen: 'default',
								"activity": {
									"aid": activityID,
									"A_STM_INSTALL_STATUS": stmInstallStatus,
									"A_STM_INSTALL_DL": stmInstallDL,
									"A_STM_INSTALL_COMMENTS": stmInstallComments, // Added for CHG0073271_STM_Phase1_Enhancements
									"A_STM_COMPLETE_FLAG": "Y"
								}
							});
						} catch (err) {
							var stmErrorPayload = {
								"STM_PLUGIN_ERROR": "Error creating STM: " + err.message
							}
						}
					}

				} catch (err) {

					console.log(" Exception in submit  :" + err.message);
				}

			}.bind(this));
			
			//-----------------------------------------------------------
			//Added for offline capability
			function checkIfTechIsOnline() {
				var domainLink = window.location.href;				
				$.ajax({
					url : domainLink,
					timeout : 2000,	
					cache: false,				
					type : 'GET', 
					async: false,
					tryCount : 0,
					retryLimit : 3,
					success: function(response)	{
						console.log(' online');
						blnIsTechOnline = true;
						return true;
					}.bind(this),
					error : function(xhr, textStatus, errorThrown )	{
						if (textStatus == 'timeout') {
							this.tryCount++;
							if (this.tryCount <= this.retryLimit) {
								//try again
								$.ajax(this);
								console.log(' offline');
								blnIsTechOnline = false;
								return false;
							}            
						}
						if(xhr.status == 500){
							console.log(' offline');
							blnIsTechOnline = false;
							return false;
						}else {
							console.log(' offline');
							blnIsTechOnline = false;
							return false;
						}
					}
				});
			}
			//-----------------------------------------------------------
		},

		/**
		 * Business login on plugin wakeup (background open for sync)
		 *
		 * @param {Object} receivedData - JSON object that contain data from OFS
		 */
		pluginWakeup: function (receivedData) {
			this._log(window.location.host + ' WAKEUP', JSON.stringify(receivedData, null, 4));

			var wakeupData = {
				pluginWakeupCount: +localStorage.getItem('pluginWakeupCount'),
				pluginWakeupMaxCount: +localStorage.getItem('pluginWakeupMaxCount'),
				pluginWakeupDontRespondOn: +localStorage.getItem('pluginWakeupDontRespondOn'),
				pluginWakeupChangeIcon: JSON.parse(localStorage.getItem('pluginWakeupChangeIcon'))
			};
			
			//--------------------------------------------------------------------------------------------
			//---- added for offline capable
			var activityId = "";
			if( localStorage.getItem("CONS_OFFLINE_ACT_ID") !== null && 
				localStorage.getItem("CONS_OFFLINE_ACT_ID") !== undefined && 
				localStorage.getItem("CONS_OFFLINE_ACT_ID") !== '')
			{
				activityId = localStorage.getItem("CONS_OFFLINE_ACT_ID");
			}
				
			var domainName = this._getDomainURL();
			
			var stmHeaders = {
				'Authorization': 'Basic ' + btoa(receivedData.securedData.clientId + "@" + domainName + ":" + receivedData.securedData.clientSecret),
				'content-type': 'application/json',
				'accept': 'application/octet-stream',
			};
			
			console.log("Wakeup receivedData = " + receivedData);
			var offlineDataAttr = "STM_ACT_UPDATE_FILE";
			
			if( localStorage.getItem(offlineDataAttr) !== null && 
				localStorage.getItem(offlineDataAttr) !== undefined && 
				localStorage.getItem(offlineDataAttr) !== '')
			{
				console.log("found the local storage attr in wakup");
				
				var offlineData = JSON.parse(localStorage.getItem(offlineDataAttr));
				
				try {
					var stmTaskUpdateURL = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/activities/" + activityId + "/A_STM_TASK_FILE";
					// Ajax call to get the tech today activities
					$.ajax({
						dataType: "json",
						url: stmTaskUpdateURL,
						method: "PUT",
						async: false,
						crossDomain: true,
						headers: stmHeaders,
						processData: false,
						contentType: 'application/json; charset=utf-8',
						accept: '*/*',
						timeout: 15000,
						data: JSON.stringify(offlineData),
						success: function (response) {
							console.log(response);
							
							localStorage.setItem('STM_ACT_OFFLINE_FILE', JSON.stringify(offlineData));
						}.bind(this),
						error: function (errorData) {
							console.log("While retreiving STM data - Error messagae:" + JSON.stringify(errorData));
						}
					});
				} catch (err) {
					var stmErrorPayload = {
						"STM_PLUGIN_ERROR": "Error creating STM: " + err.message
					}
				}
				
				localStorage.setItem(offlineDataAttr, '');
				localStorage.setItem("CONS_OFFLINE_ACT_ID", '');
			}
			//--------------------------------------------------------------------------------------------

			wakeupData.pluginWakeupCount = wakeupData.pluginWakeupCount + 1;

			localStorage.setItem('pluginWakeupCount', wakeupData.pluginWakeupCount);
			localStorage.setItem('pluginWakeupMaxCount', wakeupData.pluginWakeupMaxCount);
			localStorage.setItem('pluginWakeupDontRespondOn', wakeupData.pluginWakeupDontRespondOn);
			localStorage.setItem('pluginWakeupChangeIcon', wakeupData.pluginWakeupChangeIcon);

			this._log(window.location.host + ' SAVE WAKEUP DATA TO LOCAL STORAGE', JSON.stringify(wakeupData, null, 4));

			if (wakeupData.pluginWakeupDontRespondOn == wakeupData.pluginWakeupCount) {
				this._log(window.location.host + ' EMULATE NOT RESPONDING PLUGIN');

				return;
			}

			var iconUrl = './online.svg';
			var iconPromise = wakeupData.pluginWakeupChangeIcon ? this._getBlob(iconUrl) : Promise.resolve(null);

			iconPromise.then(function (iconFile) {
				var iconDataParams = {};

				if (iconFile) {
					iconDataParams.iconData = {
						text: '' + wakeupData.pluginWakeupCount,
						image: iconFile
					};
				}

				if (wakeupData.pluginWakeupCount < wakeupData.pluginWakeupMaxCount) {
					setTimeout(function () {
						this._log(window.location.host + ' SLEEP. RETRY NEEDED');

						this._sendPostMessageData($.extend({
							apiVersion: 1,
							method: 'sleep',
							wakeupNeeded: true
						}, iconDataParams));
					}.bind(this), 2000);
				} else {
					setTimeout(function () {
						this._log(window.location.host + ' SLEEP. NO RETRY');

						this._sendPostMessageData($.extend({
							apiVersion: 1,
							method: 'sleep',
							wakeupNeeded: false
						}, iconDataParams));
					}.bind(this), 12000);
				}
			}.bind(this)).catch(function () {
				this._log('Unable to load icon file "' + iconUrl + '"', null, null, true);
			}.bind(this));
		},

		/**
		 * Save configuration of wakeup (background open for sync) behavior for Plugin
		 * to Local Storage
		 *
		 * @private
		 */
		_saveWakeupData: function () {
			var wakeupData = {
				pluginWakeupCount: 0,
				pluginWakeupMaxCount: 0,
				pluginWakeupDontRespondOn: 0,
				pluginWakeupChangeIcon: false
			};

			if ($('#wakeup').is(':checked')) {
				wakeupData.pluginWakeupMaxCount = parseInt($('#repeat_count').val());

				if ($('#dont_respond').is(':checked')) {
					wakeupData.pluginWakeupDontRespondOn = parseInt($('#dont_respond_on').val());
				}

				if ($('#wakeup_change_icon').is(':checked')) {
					wakeupData.pluginWakeupChangeIcon = true;
				}
			}

			localStorage.setItem('pluginWakeupCount', wakeupData.pluginWakeupCount);
			localStorage.setItem('pluginWakeupMaxCount', wakeupData.pluginWakeupMaxCount);
			localStorage.setItem('pluginWakeupDontRespondOn', wakeupData.pluginWakeupDontRespondOn);
			localStorage.setItem('pluginWakeupChangeIcon', wakeupData.pluginWakeupChangeIcon);

			this._log(window.location.host + ' SAVE WAKEUP DATA TO LOCAL STORAGE', JSON.stringify(wakeupData, null, 4));
		},

		/**
		 * Clear previous configuration of wakeup (background open for sync) behavior for Plugin
		 * from the Local Storage
		 *
		 * @private
		 */
		_clearWakeupData: function () {
			localStorage.removeItem('pluginWakeupCount');
			localStorage.removeItem('pluginWakeupMaxCount');
			localStorage.removeItem('pluginWakeupDontRespondOn');
			localStorage.removeItem('pluginWakeupChangeIcon');

			this._log(window.location.host + ' CLEAR WAKEUP DATA FROM LOCAL STORAGE');
		},

		/**
		 * Update JSON
		 *
		 * @private
		 */
		_updateResponseJSON: function () {
			var jsonToSend = this.generateJson();

			$('.json__response').text(JSON.stringify(jsonToSend, null, 4));
		},

		/**
		 * Initialization function
		 */
		init: function () {
			if (navigator.serviceWorker) {
				this._log(window.location.host + ' Service Worker is supported');

				navigator.serviceWorker.register('stm-service-worker.js').then(function (registration) {
					this._log(window.location.host + ' Service Worker is registered with scope: ' + registration.scope);

					registration.addEventListener('updatefound', function () {
						this._log(window.location.host + ' Service Worker update is found');
						var newServiceWorker = registration.installing;
						newServiceWorker.addEventListener('statechange', function () {
							switch (newServiceWorker.state) {
								case "installed":
									this._log(window.location.host + ' New Service Worker is installed');
									break;
							}
						}.bind(this));
					}.bind(this));

					navigator.serviceWorker.addEventListener('controllerchange', function () {
						this.notifyAboutNewVersion();
					}.bind(this));

					this.startApplication();
				}.bind(this), function (err) {
					this._log(window.location.host + ' Service Worker registration failed: ' + err);
					this.startApplication();
				}.bind(this));

				return;
			} else {
				this._log(window.location.host + ' Service Worker is not supported');
			}

			this.startApplication();
		},

		startApplication: function () {
			this._log(window.location.host + ' PLUGIN HAS BEEN STARTED');

			window.addEventListener("message", this._getPostMessageData.bind(this), false);

			var jsonToSend = {
				apiVersion: 1,
				method: 'ready',
				sendInitData: true
			};

			//parse data items
			var dataItems = JSON.parse(localStorage.getItem('dataItems'));

			if (dataItems) {
				$.extend(jsonToSend, {
					dataItems: dataItems
				});
			}

			this._sendPostMessageData(jsonToSend);
		},

		notifyAboutNewVersion: function () {
			this._log(window.location.host + ' New Service Worker is activated. Page refresh is needed');
			var footer = document.querySelector('.footer');
			var versionNotificationElement = document.createElement('div');
			versionNotificationElement.className = 'new-version-notification';
			versionNotificationElement.innerHTML = 'New version is detected. Please reopen the page';
			footer.appendChild(versionNotificationElement);
		}
	});

	window.OfscPlugin.getVersion = function () {
		return resourcesVersion;
	};

	function getPositionInRouteEnum() {
		var result = [{
				label: '{"position": "first"}',
				text: 'First'
			},
			{
				label: '{"position": "last"}',
				text: 'Last'
			},
			{
				label: '{"position": "notOrdered"}',
				text: 'Not Ordered'
			}
		];

		if (pluginOpenData && pluginOpenData.activityList) {
			Object.keys(pluginOpenData.activityList).forEach(function (aid) {
				result.push({
					label: '{"position": "afterActivity", "activityId": "' + aid + '"}',
					text: 'After activity ' + aid
				});
			});
		}

		return result;
	}

	function getCurrentDateIso() {
		var date = new Date();
		var result = [date.getFullYear(), date.getMonth() + 1, date.getDate()];

		if (result[1] < 10) {
			result[1] = '0' + result[1];
		}

		if (result[2] < 10) {
			result[2] = '0' + result[2];
		}

		return result.join('-');
	}

	/**
	 * @returns {ResourceTimeObject}
	 */
	function getResourceTimeObject() {
		var resource = (pluginOpenData && pluginOpenData.resource) || {};

		return {
			browserTimeDiffMs: resource.browserTimeDiffMs || 0,
			pluginOpenTime: resource.currentTime || null
		};
	}

	/**
	 * @typedef {{
	 *     browserTimeDiffMs: number,
	 *     pluginOpenTime: string|null
	 * }} ResourceTimeObject
	 */

})(jQuery);