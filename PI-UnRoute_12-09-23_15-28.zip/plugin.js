"use strict";
(function ($) {
    window.OfscPlugin = function (debugMode) {
        this.debugMode = debugMode || false;
    };
     
	//Added for OFSC Mobility Phase2 CHG0062368	
	var activityLog = '';
	var pluginName = 'PI-Enroute';
	//end OFSC Mobility Phase2 CHG0062368
	
    $.extend(window.OfscPlugin.prototype, {
        /**
         * Dictionary of enums
         */
        dictionary: {
            astatus: {
                pending: {
                    label: 'pending',
                    translation: 'Pending',
                    outs: ['started', 'cancelled', 'suspended', 'enroute'],
                    color: '#FFDE00'
                },
				enroute: {
                    label: 'enroute',
                    translation: 'En Route',
                    outs: ['started', 'cancelled', 'pending'],
                    color: '#ff920c'
                },
				started: {
                    label: 'started',
                    translation: 'Started',
                    outs: ['complete', 'suspended', 'notdone', 'cancelled'],
                    color: '#A2DE61'
                },
                complete: {
                    label: 'complete',
                    translation: 'Completed',
                    outs: [],
                    color: '#79B6EB'
                },
                suspended: {
                    label: 'suspended',
                    translation: 'Suspended',
                    outs: [],
                    color: '#9FF'
                },
                notdone: {
                    label: 'notdone',
                    translation: 'Not done',
                    outs: [],
                    color: '#60CECE'
                },
                cancelled: {
                    label: 'cancelled',
                    translation: 'Cancelled',
                    outs: [],
                    color: '#80FF80'
                }
            },
            invpool: {
                customer: {
                    label: 'customer',
                    translation: 'Customer',
                    outs: ['deinstall'],
                    color: '#04D330'
                },
                install: {
                    label: 'install',
                    translation: 'Installed',
                    outs: ['provider'],
                    color: '#00A6F0'
                },
                deinstall: {
                    label: 'deinstall',
                    translation: 'Deinstalled',
                    outs: ['customer'],
                    color: '#00F8E8'
                },
                provider: {
                    label: 'provider',
                    translation: 'Resource',
                    outs: ['install'],
                    color: '#FFE43B'
                }
            }
        },
		actions: {
					activity: [
						{
							value: '',
							translation: 'Select Action...'
						},
						{
							value: 'create',
							translation: 'Create Activity'
						}
					],
					inventory: [
						{
							value: '',
							translation: 'Select Action...'
						},
						{
							value: 'create',
							translation: 'Create Inventory'
						},
						{
							value: 'delete',
							translation: 'Delete Inventory'
						},
						{
							value: 'install',
							translation: 'Install Inventory'
						},
						{
							value: 'deinstall',
							translation: 'Deinstall Inventory'
						},
						{
							value: 'undo_install',
							translation: 'Undo Install Inventory'
						},
						{
							value: 'undo_deinstall',
							translation: 'Undo Deinstall Inventory'
						}
					],
					queue: [
						{
							value: '',
							translation: 'Select Action...'
						},
						{
							value: 'activate_queue',
							translation: 'Activate'
						},
						{
							value: 'deactivate_queue',
							translation: 'Deactivate'
						}
					]
				},
        mandatoryActionProperties: {},

        /**
         * Which field shouldn't be editable
         *
         * format:
         *
         * parent: {
         *     key: true|false
         * }
         *
         */
        renderReadOnlyFieldsByParent: {
            data: {
                apiVersion: true,
                method: true,
                entity: true
            },
            resource: {
                pid: true,
                pname: true,
                gender: true
            }
        },

        /**
         * Check for string is valid JSON
         *
         * @param {*} str - String that should be validated
         *
         * @returns {boolean}
         *
         * @private
         */
        _isJson: function (str) {
            try {
                JSON.parse(str);
            }
            catch (e) {
                return false;
            }
            return true;
        },

        /**
         * Return origin of URL (protocol + domain)
         *
         * @param {String} url
         *
         * @returns {String}
         *
         * @private
         */
        _getOrigin: function (url) {
            if (url != '') {
                if (url.indexOf("://") > -1) {
                    return 'https://' + url.split('/')[2];
                } else {
                    return 'https://' + url.split('/')[0];
                }
            }

            return '';
        },

        /**
         * Return domain of URL
         *
         * @param {String} url
         *
         * @returns {String}
         *
         * @private
         */
        _getDomain: function (url) {
            if (url != '') {
                if (url.indexOf("://") > -1) {
                    return url.split('/')[2];
                } else {
                    return url.split('/')[0];
                }
            }

            return '';
        },
		
		_getDomainURL: function() {
			//return document.referrer.match(/\:\/\/([^\/]+)\.etadirect\.com\//)[1];
			//Reg Ex modified to handle both etadirect.com and fs.ocs.oraclecloud.com URLs
			return document.referrer.match(/\:\/\/([^\/]+)\.(?:etadirect.com|fs.ocs.oraclecloud.com)/)[1];
		},

        /**
         * Sends postMessage to document.referrer
         *
         * @param {Object} data - Data th
		 at will be sent
         *
         * @private
         */
        _sendPostMessageData: function (data) {
            var originUrl = document.referrer || (document.location.ancestorOrigins && document.location.ancestorOrigins[0]) || '';

            if (originUrl) {
                this._log(window.location.host + ' -> ' + data.method + ' ' + this._getDomain(originUrl), JSON.stringify(data, null, 4));

                parent.postMessage(JSON.stringify(data), this._getOrigin(originUrl));
            } else {
                this._log(window.location.host + ' -> ' + data.method + ' ERROR. UNABLE TO GET REFERRER');
            }
        },
                    
        /**
         * Handles during receiving postMessage
         *
         * @param {MessageEvent} event - Javascript event
         *
         * @private
         */
        _getPostMessageData: function (event) {

            if (typeof event.data === 'undefined') {
                this._log(window.location.host + ' <- NO DATA ' + this._getDomain(event.origin), null, null, true);

                return false;
            }

            if (!this._isJson(event.data)) {
                this._log(window.location.host + ' <- NOT JSON ' + this._getDomain(event.origin), null, null, true);

                return false;
            }

            var data = JSON.parse(event.data);
			
			// Added for defect 1489 18C
			$.each(data.activityList, function (i, a) {
            	a.aid = "" + a.aid +"";
            });
			// Added for defect 1489 18C

            if (!data.method) {
                this._log(window.location.host + ' <- NO METHOD ' + this._getDomain(event.origin), null, null, true);

                return false;
            }

            this._log(window.location.host + ' <- ' + data.method + ' ' + this._getDomain(event.origin), JSON.stringify(data, null, 4));

            switch (data.method) {
                case 'init':
                    this.pluginInitEnd(data);
                    break;

                case 'open':
                    this.pluginOpen(data);
                    break;

                case 'wakeup':
                    this.pluginWakeup(data);
                    break;

                case 'error':
                    data.errors = data.errors || {error: 'Unknown error'};
                    this._showError(data.errors);
                    break;

                default:
                    this._log(window.location.host + ' <- UNKNOWN METHOD: ' + data.method + ' ' + this._getDomain(event.origin), null, null, true);
                    break;
            }
        },
        /**
         * Show alert with error
         *
         * @param {Object} errorData - Object with errors
         *
         * @private
         */
        _showError: function (errorData) {
			alert(JSON.stringify(errorData, null, 4));
			},

        /**
         * Logs to console
         *
         * @param {String} title - Message that will be log
         * @param {String} [data] - Formatted data that will be collapsed
         * @param {String} [color] - Color in Hex format
         * @param {Boolean} [warning] - Is it warning message?
         *
         * @private
         */
        _log: function (title, data, color, warning) {
            if (!this.debugMode) {
                return;
            }
            if (!color) {
                color = '#0066FF';
            }
            if (!!data) {
                console.groupCollapsed('%c[Plugin API] ' + title, 'color: ' + color + '; ' + (!!warning ? 'font-weight: bold;' : 'font-weight: normal;'));
                console.log('[Plugin API] ' + data);
                console.groupEnd();
            } else {
                console.log('%c[Plugin API] ' + title, 'color: ' + color + '; ' + (!!warning ? 'font-weight: bold;' : ''));
            }
        },

        /**
         * Business login on plugin init
         */
        saveToLocalStorage: function (data) {
            this._log(window.location.host + ' INIT. SET DATA TO LOCAL STORAGE', JSON.stringify(data, null, 4));

            var initData = {};
 
            $.each(data, function (key, value) {
                if (-1 !== $.inArray(key, ['apiVersion', 'method'])) {
                    return true;
                }
 
                initData[key] = value;
            });
 
            localStorage.setItem('pluginInitData', JSON.stringify(initData));
        },

        /**
         * Business login on plugin init end
         *
         * @param {Object} data - JSON object that contain data from OFSC
         */
        pluginInitEnd: function (data) {
            this.saveToLocalStorage(data);

            var messageData = {
                apiVersion: 1,
                method: 'initEnd'
            };

            if (localStorage.getItem('pluginWakeupCount') < localStorage.getItem('pluginWakeupMaxCount')) {
                this._log(window.location.host + ' UNFINISHED WAKEUP DATA FOUND IN LOCAL STORAGE');

                messageData.wakeupNeeded = true;
            }

            this._sendPostMessageData(messageData);
        },

        /**
         * Business login on plugin open
         *
         * @param {Object} receivedData - JSON object that contain data from OFSC
         */
        pluginOpen: function (receivedData) {         	  
             var domainName = this._getDomainURL();
			 var errorLogs = receivedData.activity.A_PLUGIN_ERROR_LOG;
        	var nowDate = new Date();
			var now = nowDate.toISOString();
			            
			var headers = {
				'Authorization':
					'Basic ' + btoa(receivedData.securedData.clientId + "@" + domainName + ":" + receivedData.securedData.clientSecret)
			};
						
			var timeZoneName = receivedData.resource.time_zone;
			//var ofscDate      = decodeURIComponent($.urlParam('date')); 
			
			var TimeZoneMapping = {
				"19": "Alaska",
				"6": "Arizona",
				"4": "Central",
				"2": "Eastern",
				"15": "GMT",
				"17": "Hawaii (Adak)",
				"18": "Hawaii (Honolulu)",
				"5": "Mountain",
				"7": "Pacific"
			};
			
												
			var timeOffset = {
				'Alaska':9,
				'dAlaska':8,
				'Arizona':7,
				'dArizona':7,
				'Central':6,
				'dCentral':5,
				'Eastern':5,
				'dEastern':4,
				'GMT':0,
				'dGMT':0,
				'Hawaii(Adak)':10,
				'dHawaii(Adak)':10,
				'Hawaii(Honolulu)':10,
				'dHawaii(Honolulu)':10,
				'Mountain':7,
				'dMountain':6,
				'Pacific':8,
				'dPacific':7
			}
		
			var timeZone = TimeZoneMapping[timeZoneName];
			
			Date.prototype.stdTimezoneOffset = function() {
				var jan = new Date(this.getFullYear(), 0, 1);
				var jul = new Date(this.getFullYear(), 6, 1);
				return Math.max(jan.getTimezoneOffset(), jul.getTimezoneOffset());
			}
			
			Date.prototype.dst = function() {
				return this.getTimezoneOffset() < this.stdTimezoneOffset();
			}
			
			var today = new Date();
			if(today.dst()){
				var timeZoneId = timeOffset['d'+timeZone.replace(' ','')];
			}else{
				var timeZoneId = timeOffset[timeZone.replace(' ','')];
			}

			var indainDateObj = new Date();
			indainDateObj.setHours(indainDateObj.getHours() - timeZoneId);
			var dispatchTime = indainDateObj.toISOString();
			
			var todayDate = dispatchTime.substring(0,10);
			
					
			$('#enrouteMainDiv').addClass('cp_hidden');
			$('#pendingActvitiesSection').addClass('cp_hidden');
			$('#nonScheduledActvitiesSection').addClass('cp_hidden');
			$('#startedActvitiesSection').addClass('cp_hidden');
			$('#anotherActivityDiv').addClass('cp_hidden');			
		
			//Phase 3 - CHG0071392 - getting time value for activating route
			var resourceTimeZone = receivedData.resource.time_zone;
			var atimeZone = TimeZoneMapping[resourceTimeZone];
			// Set the timezone to retreive the Date & time for Activate route & punch in 
			if ("Alaska" == atimeZone || "Arizona" == atimeZone || "Central" == atimeZone || "Eastern" == atimeZone || "Mountain" == atimeZone || "Pacific" == atimeZone) 
			{
				resourceTimeZone = "US/" + atimeZone;
			} 
			else if ("Hawaii (Adak)" == atimeZone) 
			{
				resourceTimeZone = "America/Adak";
			} 
			else if ("Hawaii (Honolulu)" == atimeZone) 
			{
				resourceTimeZone = "Pacific/Honolulu";
			}
			// if the resource time zone is null, then assign to EST.
			if (resourceTimeZone == null || "" == resourceTimeZone || typeof (resourceTimeZone) == undefined) 
			{
				resourceTimeZone = "EST";
			}
			// Current Date & Time of resource time zone
			var atodayDate;
			try
			{
				atodayDate = new Date(new Date().toLocaleString('en-US', { timeZone: resourceTimeZone }));
			}
			catch(err)
			{
					atodayDate = new Date();						
			}
			
			$.ErrorUpdate = function(activityId,sErrorLogs,tErrorMsg) {
				 
				this._sendPostMessageData({
						"apiVersion": 1,
						"method": "update",
						"activity": {
							"A_PLUGIN_ERROR_LOG": sErrorLogs,
							"aid": activityId
						}
						
				});
			 }.bind(this);
			
			/* OFSC Mobility Phase2 CHG0062368 */
			$.callUnEnroute = function(actId){
				//Added activityLog for OFSC Mobility Phase2 CHG0062368
				try{
					if(receivedData.activity.A_ACTIVITY_LOG != null){
						if(activityLog != null){
							activityLog = receivedData.activity.A_ACTIVITY_LOG + ';' + activityLog;
						}
						else{
							activityLog = receivedData.activity.A_ACTIVITY_LOG;
						}
					}					
					$.unEnrouteAPICall(actId,receivedData.securedData.unEnrouteSRType, timeZone);
					$.srCreateAPICall_UnEnroute(actId,receivedData.securedData.unEnrouteSRType, timeZone);
				}catch(err){
					activityLog = activityLog + ';Exception in callUnEnroute:'+err.message;
				 	console.log(" Exception in callUnEnroute:"+err.message);
				}
			}.bind(this);

            this._clearWakeupData();
            if (localStorage.getItem('pluginInitData')) {
                this._log(window.location.host + ' OPEN. GET DATA FROM LOCAL STORAGE', JSON.stringify(JSON.parse(localStorage.getItem('pluginInitData')), null,4));
                $('.json__local-storage').text(JSON.stringify(JSON.parse(localStorage.getItem('pluginInitData')), null, 4));
            }
            this.initChangeOfWakeup(document);
            this.initChangeOfDataItems();
			
			
			
			/* OFSC Mobility Phase2 CHG0062368  */
			
			$.closeMethod_UnEnroute = function(activityId, wakeupNeeded) {				
				var activityList = "{\"apiVersion\":1, \"method\":\"close\", \"backScreen\":\"activity_list\", \"wakeupNeeded\":\"" + wakeupNeeded + "\", \"activity\":{\"aid\":\"" + activityId + "\",\"A_ODOMETER_START\":\"\",\"A_ODOMETER_END\":\"\", \"A_ORACLE_STATUS\":\"\", \"A_STATE\":null, \"A_DISPATCH_TIME\":\"\", \"A_DISPATCH_TIME_OVERRIDE\":\"\"";
				if(activityLog != null && activityLog != ''){
					activityList = activityList + ",\"A_ACTIVITY_LOG\":\""+activityLog+"\"";
				}
				/*STM Phase 1 - CHG0068290*/
				if(receivedData.activity.A_PRECALL_ACCEPT_FLAG =='Y'){
					activityList = activityList + ",\"A_PRECALL_ACCEPT_FLAG\":\"N\"";
				}
				activityList = activityList + "}}";
				
				console.log('closeMethod_UnEnroute Close Method JSON:'+ activityList);
				var closeJSONToSend = JSON.parse(activityList);
				this._sendPostMessageData(closeJSONToSend);
				console.log(' after _sendPostMessageData');
			}.bind(this);

	//Phase 3 - CHG0071392
			$.unEnrouteAPICall = function(activityId, srType, timeZone) {				
				console.log(' unEnrouteAPICall ');				
				pluginName = 'PI-UnEnroute';
				//CHG0071392 - OFSC Native Enroute - custome url defined 
				
				var webServiceURL = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/activities/"+activityId+"/custom-actions/stopTravel";
			
				//CHG0069299 - Validate internet connectivity and Un-EnRoute
				$.ajax({
						url : window.location.href,
						timeout : 2000,	
						cache: false,				
						type : 'GET', 
						tryCount : 0,
						retryLimit : 3,
						success: function(response) 
						{
							console.log(' online configuration');
							unEnrouteActivity();
						}.bind(this),
						error : function(xhr, textStatus, errorThrown )
						{
							if (textStatus == 'timeout') {
								this.tryCount++;
								if (this.tryCount <= this.retryLimit) {
									//try again
									$.ajax(this);
									return false;
								}            
								storeOffline();
							}
							if (xhr.status == 500) {
								storeOffline();
							} 
							else 
							{
								storeOffline();
							}
						}
				});
				function unEnrouteActivity()
				{
					$.ajax({
						url: webServiceURL,
						method:'POST',
						async : false,
						contentType: 'application/json; charset=utf-8',
						crossDomain: true,
						headers: headers,
						timeout: 15000,
						success: function(response) {
							console.log(' before closeMethod_UnEnroute - success');
							
						}.bind(this),
						error: function(response) {
							
							if(activityLog != null && activityLog != ''){
								activityLog = activityLog + ";Enroute-Error on unEnRouteAPICallQue";
							}
							else{
								activityLog = "Enroute-Error on unEnRouteAPICallQue";
							}

							var now = new Date(Date.now());
							var errorTime = now.getHours() + ":" + now.getMinutes() + ":" + now.getSeconds();
							var errorDetails = response.responseJSON;
							
							var eDetail = errorDetails.detail.replace(/(\r\n|\n|\r)/gm," ");
							var eStatus = errorDetails.status;
							if (errorLogs == null){
								errorLogs= "";
							}
							errorLogs = errorLogs+"||"+now.toString()+"|Plugin :Un-Enroute "+"| URL:"+webServiceURL.toString()+"|Error Status:"+eStatus+"|Error Details:"+eDetail;
							console.log(errorLogs);
							
							var errorMessage = now.toString()+"|Plugin :Un-Enroute "+"| URL:"+webServiceURL+"| Error Details:"+JSON.stringify(response);
							console.log("Error Message:"+errorMessage);
							$.ErrorUpdate(activityId,errorLogs,errorMessage);
													
						}.bind(this)
					});
				}
				function storeOffline()
				{
					
					console.log('Unenroute: Disabled for offline');
					
				}
			}.bind(this);
	//Phase 3 - CHG0071392
			$.srCreateAPICall_UnEnroute = function(activityId, srType, timeZone) {				
				console.log(' srCreateAPICall_UnEnroute ');				
				pluginName = 'PI-UnEnroute';
				var srWebServiceURL = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/serviceRequests";
				console.log('srCreateAPICall_UnEnroute - URL : ');		
				console.log(srWebServiceURL);
				var jsonPayload = {
						"instanceName": receivedData.securedData.company,
						"date": todayDate,
						"activityId": parseInt(activityId),
						"requestType": srType,
						"requestEntity": "ACTIVITY",
						"pluginName": pluginName
				}
				
				
				$.ajax({
						url : window.location.href,
						timeout : 2000,	
						cache: false,				
						type : 'GET', 
						tryCount : 0,
						retryLimit : 3,
						success: function(response) 
						{
							console.log(' online configuration');
                            srUnEnrouteActivity();
							$.closeMethod_UnEnroute(activityId, false);
							
						}.bind(this),
						error : function(xhr, textStatus, errorThrown )
						{
							if (textStatus == 'timeout') {
								this.tryCount++;
								if (this.tryCount <= this.retryLimit) {
									//try again
									$.ajax(this);
									return false;
								}            
								srStoreOffline();
							}
							if (xhr.status == 500) {
								srStoreOffline();
							} 
							else 
							{
								srStoreOffline();
								
							}
						}
				});
				function srUnEnrouteActivity()
				{
					$.ajax({
						url: srWebServiceURL,
						method:'POST',
						contentType: 'application/json; charset=utf-8',
						data: JSON.stringify(jsonPayload),
						async: false,
						crossDomain: true,
						headers: headers,
						timeout: 15000,
						
						success: function(response) {
							console.log(' srUnEnrouteActivity - success');
						}.bind(this),
						error: function(response) {
							
							if(activityLog != null && activityLog != ''){
								activityLog = activityLog + ";Enroute-Error on unEnRouteSRCreateAPICallQue";
							}
							else{
								activityLog = "Enroute-Error on unEnRouteSRCreateAPICallQue";
							}
							
							console.log(' srUnEnrouteActivity - error ');
							var srnow = new Date(Date.now());
							var srerrorTime = srnow.getHours() + ":" + srnow.getMinutes() + ":" + srnow.getSeconds();
							var srerrorDetails = response.responseJSON;
							
							var sreDetail = srerrorDetails.detail.replace(/(\r\n|\n|\r)/gm," ");
							var sreStatus = srerrorDetails.status;
							if (errorLogs == null){
								errorLogs= "";
							}
							errorLogs = errorLogs+"||"+srnow.toString()+"|Plugin :Un-Enroute "+"| URL:"+srWebServiceURL.toString()+"|Error Status:"+sreStatus+"|Error Details:"+sreDetail;
							console.log(errorLogs);
							
							var srerrorMessage = srnow.toString()+"|Plugin :Un-Enroute "+"| URL:"+srWebServiceURL+"| Error Details:"+JSON.stringify(response);
							console.log("Error Message:"+srerrorMessage);
                            console.log(srnow);
                            console.log(srerrorTime);
                            console.log(srerrorDetails);
                            console.log(errorLogs);
                            console.log(activityId);
                            
							$.ErrorUpdate(activityId,errorLogs,srerrorMessage);

							
						}.bind(this)
					});
				}
				function srStoreOffline()
				{
					console.log('srStoreOffline: Disabled for offline');
					
				}
			}.bind(this);
			
			
			if (receivedData.activity.astatus== 'enroute'){
				$.callUnEnroute(receivedData.activity.aid);
			}
			
        },	

		
		 /** Function to call the SOAP trigger using REST API hosted in JCS.*/
        
		
		// added on 06-06-2018	
        
		
        /**
         * Business login on plugin wakeup (background open for sync)
         *
         * @param {Object} receivedData - JSON object that contain data from OFSC
         */
        pluginWakeup: function (receivedData) {
            this._log(window.location.host + ' WAKEUP', JSON.stringify(receivedData, null, 4));
			var thisVarOnline = this;
            var wakeupData = {
                pluginWakeupCount: +localStorage.getItem('pluginWakeupCount'),
                pluginWakeupMaxCount: +localStorage.getItem('pluginWakeupMaxCount'),
                pluginWakeupDontRespondOn: +localStorage.getItem('pluginWakeupDontRespondOn')
            };

            wakeupData.pluginWakeupCount = wakeupData.pluginWakeupCount + 1;

            localStorage.setItem('pluginWakeupCount', wakeupData.pluginWakeupCount);
            localStorage.setItem('pluginWakeupMaxCount', wakeupData.pluginWakeupMaxCount);
            localStorage.setItem('pluginWakeupDontRespondOn', wakeupData.pluginWakeupDontRespondOn);

            this._log(window.location.host + ' SAVE WAKEUP DATA TO LOCAL STORAGE', JSON.stringify(wakeupData, null, 4));
									
            if (wakeupData.pluginWakeupDontRespondOn == wakeupData.pluginWakeupCount) {
                this._log(window.location.host + ' EMULATE NOT RESPONDING PLUGIN');

                return;
            }

            if (wakeupData.pluginWakeupCount < wakeupData.pluginWakeupMaxCount) {
                setTimeout(function () {
                    this._log(window.location.host + ' SLEEP. RETRY NEEDED');

                    this._sendPostMessageData({
                        apiVersion: 1,
                        method: 'sleep',
                        wakeupNeeded: true
                    });
                }.bind(this), 2000);
            } else {
                setTimeout(function () {
                    this._log(window.location.host + ' SLEEP. NO RETRY');

                    this._sendPostMessageData({
                        apiVersion: 1,
                        method: 'sleep',
                        wakeupNeeded: false
                    });
                }.bind(this), 12000);
            }
        },

        /**
         * Save configuration of wakeup (background open for sync) behavior for Plugin
         * to Local Storage
         *
         * @private
         */
        _saveWakeupData: function () {
            var wakeupData = {
                pluginWakeupCount: 0,
                pluginWakeupMaxCount: 0,
                pluginWakeupDontRespondOn: 0
            };

            if ($('#wakeup').is(':checked')) {
                wakeupData.pluginWakeupMaxCount = parseInt($('#repeat_count').val());

                if ($('#dont_respond').is(':checked')) {
                    wakeupData.pluginWakeupDontRespondOn = parseInt($('#dont_respond_on').val());
                }
            }

            localStorage.setItem('pluginWakeupCount', wakeupData.pluginWakeupCount);
            localStorage.setItem('pluginWakeupMaxCount', wakeupData.pluginWakeupMaxCount);
            localStorage.setItem('pluginWakeupDontRespondOn', wakeupData.pluginWakeupDontRespondOn);

            this._log(window.location.host + ' SAVE WAKEUP DATA TO LOCAL STORAGE', JSON.stringify(wakeupData, null, 4));
        },

        /**
         * Clear previous configuration of wakeup (background open for sync) behavior for Plugin
         * from the Local Storage
         *
         * @private
         */
        _clearWakeupData: function () {
            localStorage.removeItem('pluginWakeupCount');
            localStorage.removeItem('pluginWakeupMaxCount');
            localStorage.removeItem('pluginWakeupDontRespondOn');

            this._log(window.location.host + ' CLEAR WAKEUP DATA FROM LOCAL STORAGE');
        },

        initChangeOfWakeup: function (element) {

            function onWakeupChange(elem) {
                var isChecked = $(elem).is(':checked');

                if (isChecked) {
                    $(element).find('#repeat_count').prop('disabled', false);
                    $(element).find('#dont_respond').prop('disabled', false);

                    $(element).find('#wakeup_row').removeClass('wakeup-form-row--disabled');

                    onDontRespondChange($(element).find('#dont_respond'));
                } else {
                    $(element).find('#repeat_count').prop('disabled', true);
                    $(element).find('#dont_respond').prop('disabled', true);
                    $(element).find('#dont_respond_on').prop('disabled', true);

                    $(element).find('#wakeup_row').addClass('wakeup-form-row--disabled');
                    $(element).find('#dont_respond_row').addClass('wakeup-form-row--disabled');
                }
            }

            function onDontRespondChange(elem) {
                var isChecked = $(elem).is(':checked');

                if (isChecked) {
                    $(element).find('#dont_respond_on').prop('disabled', false);
                    $(element).find('#dont_respond_row').removeClass('wakeup-form-row--disabled');
                } else {
                    $(element).find('#dont_respond_on').prop('disabled', true);
                    $(element).find('#dont_respond_row').addClass('wakeup-form-row--disabled');
                }
            }

            $(element).find('#wakeup').change(function (e) {
                onWakeupChange(e.target);
            });

            $(element).find('#dont_respond').change(function (e) {
                onDontRespondChange(e.target);
            });

            onWakeupChange($(element).find('#wakeup'));
        },

        initChangeOfDataItems: function () {
            //set checkboxes from local storage
            if (localStorage.getItem('dataItems')) {
                $('.data-items').attr('checked', true);
                $('.data-items-holder').show();

                var dataItems = JSON.parse(localStorage.getItem('dataItems'));

                $('.data-items-holder input').each(function () {
                    if (dataItems.indexOf(this.value) != -1) {
                        $(this).attr('checked', true);
                    }
                });
            }

            //init handlers
            $('.data-items').on('change', function (e) {
                $('.data-items-holder').toggle();
            });
        },
        /**
         * Initialization function
         */
        init: function () {
			if (navigator.serviceWorker) {
              this._log(window.location.host + ' Service Worker is supported');
              navigator.serviceWorker.register('unenroute-service-worker.js').then(function(registration) {
                this._log(window.location.host + ' Service Worker is registered with scope: ' + registration.scope);
                registration.addEventListener('updatefound', function() {
                  this._log(window.location.host + ' Service Worker update is found');
                  var newServiceWorker = registration.installing;
                  newServiceWorker.addEventListener('statechange', function() {
                    switch (newServiceWorker.state) {
                      case "installed":
                        this._log(window.location.host + ' New Service Worker is installed');
						break;
                    }
                   }.bind(this));
				}.bind(this));
                navigator.serviceWorker.addEventListener('controllerchange', function() {
					this.notifyAboutNewVersion();
				}.bind(this));
					this.startApplication();
				}.bind(this), function(err) {
					this._log(window.location.host + ' Service Worker registration failed: ' + err);
					this.startApplication();
				    }.bind(this));
                return;
            } else {
                this._log(window.location.host + ' Service Worker is not supported');
			        }
			this.startApplication();
		},
            
        startApplication: function() {
			
			//$("#anotherActivityDiv").hide();
			$("#veiwGlobalNotes").hide();
         //Begin CHG0059173
          $("#veiwServiceNotes").hide();
         //End CHG0059173
            this._log(window.location.host + ' PLUGIN HAS BEEN STARTED');

            $('.back_method_select').on('change', function () {
                if ($('.back_method_select').val() == 'activity_by_id') {
                    $('.back_activity_id').show();
                } else {
                    $('.back_activity_id').val('').hide();
                }
            });

            $('.json_local_storage_toggle').on('click', function () {
                $('.json__local-storage').toggle();
            });

            $('.json_request_toggle').on('click', function () {
                $('.column-item--request').toggle();
            });

            $('.json_response_toggle').on('click', function () {
                $('.column-item--response').toggle();
            }.bind(this));


            window.addEventListener("message", this._getPostMessageData.bind(this), false);

            var jsonToSend = {
                apiVersion: 1,
                method: 'ready',
                sendInitData: true
            };

            //parse data items
            //var dataItems = JSON.parse(localStorage.getItem('dataItems'));
			var dataItems = ["resource", "scheduledActivities", "nonScheduledActivities", "customerInventories"];
            if (dataItems) {
                $.extend(jsonToSend, {dataItems: dataItems});
            }

            this._sendPostMessageData(jsonToSend);
        },
		notifyAboutNewVersion: function() {
			    this._log(window.location.host + ' New Service Worker is activated. Page refresh is needed');
			    var footer = document.querySelector('.footer');
			    var versionNotificationElement = document.createElement('div');
			    versionNotificationElement.className = 'new-version-notification';
			    versionNotificationElement.innerHTML = 'New version is detected. Please reopen the page';
			    footer.appendChild(versionNotificationElement);	
		
        }
    });
	
	window.OfscPlugin.getVersion = function() {
			return resourcesVersion;
	};

})(jQuery);

