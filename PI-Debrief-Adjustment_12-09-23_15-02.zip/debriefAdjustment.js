"use strict";

(function($) {
	window.OfscPlugin = function(debugMode) {
		this.debugMode = debugMode || false;
	};
	var multipleFieldsArray = [];
	var itemNumberActionsListJSONData = {};
	var inventoryListJSONData = {};
	var debAdjPartDetailListDebValidation4 = [];
	var sharedSuvInvInventoryListJSON = [];

	$.extend(window.OfscPlugin.prototype, {
		/**
		 * Dictionary of enums
		 */
		dictionary: {
			astatus: {
				pending: {
					label: 'pending',
					translation: 'Pending',
					outs: ['started', 'cancelled', 'suspended'],
					color: '#FFDE00'
				},
				started: {
					label: 'started',
					translation: 'Started',
					outs: ['complete', 'suspended', 'notdone', 'cancelled'],
					color: '#A2DE61'
				},
				complete: {
					label: 'complete',
					translation: 'Completed',
					outs: [],
					color: '#79B6EB'
				},
				suspended: {
					label: 'suspended',
					translation: 'Suspended',
					outs: [],
					color: '#9FF'
				},
				notdone: {
					label: 'notdone',
					translation: 'Not done',
					outs: [],
					color: '#60CECE'
				},
				cancelled: {
					label: 'cancelled',
					translation: 'Cancelled',
					outs: [],
					color: '#80FF80'
				}
			},
			invpool: {
				customer: {
					label: 'customer',
					translation: 'Customer',
					outs: ['deinstall'],
					color: '#04D330'
				},
				install: {
					label: 'install',
					translation: 'Installed',
					outs: ['provider'],
					color: '#00A6F0'
				},
				deinstall: {
					label: 'deinstall',
					translation: 'Deinstalled',
					outs: ['customer'],
					color: '#00F8E8'
				},
				provider: {
					label: 'provider',
					translation: 'Resource',
					outs: ['install'],
					color: '#FFE43B'
				}
			}
		},

		mandatoryActionProperties: {},

		/**
		 * Which field shouldn't be editable
		 *
		 * format:
		 *
		 * parent: {
		 *     key: true|false
		 * }
		 *
		 */
		renderReadOnlyFieldsByParent: {
			data: {
				apiVersion: true,
				method: true,
				entity: true
			},
			resource: {
				pid: true,
				pname: true,
				gender: true
			}
		},

		/**
		 * Check for string is valid JSON
		 *
		 * @param {*} str - String that should be validated
		 *
		 * @returns {boolean}
		 *
		 * @private
		 */
		_isJson: function(str) {
			try {
				JSON.parse(str);
			} catch (e) {
				return false;
			}
			return true;
		},

		/**
		 * Return origin of URL (protocol + domain)
		 *
		 * @param {String} url
		 *
		 * @returns {String}
		 *
		 * @private
		 */
		_getOrigin: function(url) {
			if (url != '') {
				if (url.indexOf("://") > -1) {
					return 'https://' + url.split('/')[2];
				} else {
					return 'https://' + url.split('/')[0];
				}
			}

			return '';
		},

		/**
		 * Return domain of URL
		 *
		 * @param {String} url
		 *
		 * @returns {String}
		 *
		 * @private
		 */
		_getDomain: function(url) {
			if (url != '') {
				if (url.indexOf("://") > -1) {
					return url.split('/')[2];
				} else {
					return url.split('/')[0];
				}
			}

			return '';
		},

		// Phase5 - getdomainurl implement
		_getDomainURL: function() {

			return document.referrer.match(/\:\/\/([^\/]+)\.(?:etadirect.com|fs.ocs.oraclecloud.com)/)[1];
		},

		/**
		 * Sends postMessage to document.referrer
		 *
		 * @param {Object} data - Data th
		 at will be sent
		 *
		 * @private
		 */
		_sendPostMessageData: function(data) {
			var originUrl = document.referrer || (document.location.ancestorOrigins && document.location.ancestorOrigins[0]) || '';

			if (originUrl) {
				this._log(window.location.host + ' -> ' + data.method + ' ' + this._getDomain(originUrl), JSON.stringify(data, null, 4));

				parent.postMessage(JSON.stringify(data), this._getOrigin(originUrl));
			} else {
				this._log(window.location.host + ' -> ' + data.method + ' ERROR. UNABLE TO GET REFERRER');
			}
		},

		/**
		 * Handles during receiving postMessage
		 *
		 * @param {MessageEvent} event - Javascript event
		 *
		 * @private
		 */
		_getPostMessageData: function(event) {

			if (typeof event.data === 'undefined') {
				this._log(window.location.host + ' <- NO DATA ' + this._getDomain(event.origin), null, null, true);

				return false;
			}

			if (!this._isJson(event.data)) {
				this._log(window.location.host + ' <- NOT JSON ' + this._getDomain(event.origin), null, null, true);

				return false;
			}

			var data = JSON.parse(event.data);

			if (!data.method) {
				this._log(window.location.host + ' <- NO METHOD ' + this._getDomain(event.origin), null, null, true);

				return false;
			}

			this._log(window.location.host + ' <- ' + data.method + ' ' + this._getDomain(event.origin), JSON.stringify(data, null, 4));

			switch (data.method) {
				case 'init':
					this.pluginInitEnd(data);
					break;

				case 'open':
					this.pluginOpen(data);
					break;

				case 'wakeup':
					this.pluginWakeup(data);
					break;

				case 'error':
					data.errors = data.errors || {
						error: 'Unknown error'
					};
					this._showError(data.errors);
					break;
				// CHG0075659 - MPF Phase 5 - To use Call Procedure Plugin API
				case 'callProcedureResult':

					this.finishCallIdCallbacks(event.data);
					break;

				default:
					this._log(window.location.host + ' <- UNKNOWN METHOD: ' + data.method + ' ' + this._getDomain(event.origin), null, null, true);
					break;
			}
		},

		/**
		 * Show alert with error
		 *
		 * @param {Object} errorData - Object with errors
		 *
		 * @private
		 */
		_showError: function(errorData) {
			alert(JSON.stringify(errorData, null, 4));
		},

		/**
		 * Logs to console
		 *
		 * @param {String} title - Message that will be log
		 * @param {String} [data] - Formatted data that will be collapsed
		 * @param {String} [color] - Color in Hex format
		 * @param {Boolean} [warning] - Is it warning message?
		 *
		 * @private
		 */
		_log: function(title, data, color, warning) {
			if (!this.debugMode) {
				return;
			}
			if (!color) {
				color = '#0066FF';
			}
			if (!!data) {
				console.groupCollapsed('%c[Plugin API] ' + title, 'color: ' + color + '; ' + (!!warning ? 'font-weight: bold;' : 'font-weight: normal;'));
				console.log('[Plugin API] ' + data);
				console.groupEnd();
			} else {
				console.log('%c[Plugin API] ' + title, 'color: ' + color + '; ' + (!!warning ? 'font-weight: bold;' : ''));
			}
		},

		/**
		 * Business login on plugin init
		 */
		saveToLocalStorage: function(data) {
			this._log(window.location.host + ' INIT. SET DATA TO LOCAL STORAGE', JSON.stringify(data, null, 4));
			var initData = {};
			$.each(data, function(key, value) {
				if (-1 !== $.inArray(key, ['apiVersion', 'method'])) {
					return true;
				}
				initData[key] = value;
			});
			localStorage.setItem('pluginInitData', JSON.stringify(initData));
		},

		/**
		 * Business login on plugin init end
		 *
		 * @param {Object} data - JSON object that contain data from OFSC
		 */
		pluginInitEnd: function(data) {
			this.saveToLocalStorage(data);

			var messageData = {
				apiVersion: 1,
				method: 'initEnd'
			};

			if (localStorage.getItem('pluginWakeupCount') < localStorage.getItem('pluginWakeupMaxCount')) {
				this._log(window.location.host + ' UNFINISHED WAKEUP DATA FOUND IN LOCAL STORAGE');

				messageData.wakeupNeeded = true;
			}
			this._sendPostMessageData(messageData);
		},
		/**
		 * Clear previous configuration of wakeup (background open for sync) behavior for Plugin
		 * from the Local Storage
		 *
		 * @private
		 */
		_clearWakeupData: function() {
			localStorage.removeItem('pluginWakeupCount');
			localStorage.removeItem('pluginWakeupMaxCount');
			localStorage.removeItem('pluginWakeupDontRespondOn');
			localStorage.removeItem('pluginWakeupChangeIcon');

			this._log(window.location.host + ' CLEAR WAKEUP DATA FROM LOCAL STORAGE');
		},
		/**
		 * Business login on plugin open
		 *
		 * @param {Object} receivedData - JSON object that contain data from OFSC
		 */
		pluginOpen: function(receivedData) {

			var errorLogs = receivedData.activity != null ? receivedData.activity.A_PLUGIN_ERROR_LOG : 'null';

			var multipleFieldsArray = [];
			var debAdjPartDetailAddList = [];

			var activityId = receivedData.activity != null ? receivedData.activity.aid : 'null';
			var debAdjPartDetailList = [];
			var inventoryList = receivedData.inventoryList;
			var invActivityId;
			$.each(inventoryList, function(key, invItem) {
				invActivityId = invItem.inv_aid;
				if (invItem.inv_aid == activityId) {
					if (invItem.invpool == "customer") {
						if (invItem.invtype == "DEBRIEF_INV_ADJUSTMENT") {
							debAdjPartDetailList.push(invItem);
						}
					}
				}
			});
			var acttivityList = receivedData.activityList;
			var ultimateBind = this;
			if (localStorage.getItem('pluginInitData')) {
				this._log(window.location.host + ' OPEN. GET DATA FROM LOCAL STORAGE', JSON.stringify(JSON.parse(localStorage.getItem('pluginInitData')), null, 4));
			}
			$.processSearchResultsFnCallBck = function(data) {
				try {
					var resultantInvList;
					var resultantInvArray = {};
					resultantInvList = data;
					var Quantity = 0;
					var adjqtyval = 0;
					var finalval = 0;
					$.each(resultantInvList, function(invkey, invItem) {
						resultantInvArray[invItem.ITEM_NUMBER] = {
							I_ITEM_NUMBER: invItem.ITEM_NUMBER,
							I_ITEM_DESCRIPTION: invItem.ITEM_DESCRIPTION,
							I_PRICE: invItem.ITEM_PRICE,
							I_ITEM_COST: invItem.ITEM_COST,
							Quantity: Quantity,
							I_DEBRIEF_ADJ_QUANTITY: adjqtyval,
							I_DEBRIEF_FINAL_DEBRIEF: finalval
						}
					});

					$('.found_parts_count').html(Object.keys(resultantInvArray).length);
					$("#searchPartaddData").empty();
					$.buildPartsDiv(resultantInvArray);
					var search = 1;
				}
				catch (err) {
					console.log(" Exception in processSearchResultsFnCallBck :" + err.message);
				}
			};

			$.buildPartsDiv = function(resultantInvArray) {
				try {
					$("#searchPartaddData").hide();
					$("#searchPartaddData").empty();
					$("#searchPartaddContent").hide();
					$("#searchPartaddContent").empty();
					$("#searchPartaddData").remove();
					var numItems = $('.custom-btn-plus').length;
					var ii = numItems;
					var Addcontainer1 = $('<div />').attr("id", "searchPartaddData").addClass("cp_section manual-part-addition");
					var NewpartinfoDiv = $('<div/>').attr("id", "searchPartaddContent");
					var partinfoDiv1 = $('<div/>').addClass('cp_text_block invitation-text pedDiv');
					var AddButtonDiv = $('<div/>').addClass('flex-container');
					var adddiv1 = $('<div/>').addClass('SearchDiv');
					var addButton = $('<button/>', {
						text: "Add", //set text 1 to 10
						id: 'btn_add',
						click: function() { AddData(resultantInvArray, debAdjPartDetailList); }
					}).addClass("cp_plugin_button custom-btn custom-btn-add");
					adddiv1.append(addButton);
					let iterations = Object.keys(resultantInvArray).length;
					var i = 0;
					$.each(resultantInvArray, function(key, invItem) {
						ii++;
						i++;
						var partNumDiv = $('<div/>').addClass('flex-container').attr("id", "partnoDiv");
						var partDescDiv = $('<div/>').addClass('flex-container').attr("id", "partdesc");
						var partQuaDiv = $('<div/>').addClass('flex-container').attr("id", "partQty");
						var partnodiv1 = $('<div/>').addClass('ContainerDiv');
						var partnoval = $('<div/>').addClass('ContainerVal');
						var partchkbx = $('<div/>');
						var partDescdiv1 = $('<div/>').addClass('ContainerDiv');
						var partDescval = $('<div/>').addClass('ContainerVal');
						var partQtydiv1 = $('<div/>').addClass('ContainerDiv');
						var partQtyval = $('<div/>').attr("id", "partQtyval" + ii).addClass('ContainerVal');

						var partcheckbox = $('<input/>').attr({
							"id": "chkbx_" + i,
							"type": "checkbox",
							"value": invItem.I_ITEM_NUMBER
						}).addClass("bin-chk form-item");


						partNumDiv.append(partnodiv1);
						partNumDiv.append(partnoval);

						partNumDiv.append(partchkbx);

						partDescDiv.append(partDescdiv1);
						partDescDiv.append(partDescval);

						partQuaDiv.append(partQtydiv1);
						partQuaDiv.append(partQtyval);

						partnodiv1.append('Part No: ');
						partnoval.append(invItem.I_ITEM_NUMBER);

						partchkbx.append(partcheckbox);

						partDescdiv1.append('Part Description: ');
						partDescval.append(invItem.I_ITEM_DESCRIPTION);

						partQtydiv1.append('Original Quantity: ');
						partQtyval.append(invItem.quantity);

						partNumDiv.appendTo(partinfoDiv1);
						partDescDiv.appendTo(partinfoDiv1);
						partQuaDiv.appendTo(partinfoDiv1);

						var hr1 = $('<hr>').addClass('hr-line');
						partinfoDiv1.append(hr1);

						partinfoDiv1.append(adddiv1);
						NewpartinfoDiv.append(partinfoDiv1);

						Addcontainer1.append(NewpartinfoDiv);
						Addcontainer1.append();
						$("#searchPart").append(Addcontainer1);

					});

				}
				catch (err) {
					console.log(" Exception in buildParts :" + err.message);
				}
			}


			function AddData(filteredData, invlist) {
				$('#searchPartadd').hide();
				$('#searchPart').hide();
				var found = jQuery.inArray(filteredData, debAdjPartDetailList);
				if (found >= 0) {
					alert("Already the Part is Added in Inventory List");
				} else {
					$('input[type=checkbox]').each(function() {
						if (this.checked) {
							var partno = $(this).val();
							const found = debAdjPartDetailList.some(el => el.I_ITEM_NUMBER === partno);
							$.each(filteredData, function(key1, invItem1) {
								if (!found) {
									if (invItem1.I_ITEM_NUMBER == partno) {
										var adjqtyval = 0;
										var finalval = '';
										debAdjPartDetailList.push({ I_ITEM_NUMBER: invItem1.I_ITEM_NUMBER, I_ITEM_DESCRIPTION: invItem1.I_ITEM_DESCRIPTION, quantity: invItem1.Quantity, I_DEBRIEF_ADJ_QUANTITY: adjqtyval, I_DEBRIEF_FINAL_DEBRIEF: finalval, search: 1 });
									}
								}

							});
							$.each(debAdjPartDetailList, function(key, invItem) {
								if (found) {
									if (invItem.I_ITEM_NUMBER == partno) {
										alert(invItem.I_ITEM_NUMBER + " already exists");
									}
								}
							});
						}
						else {
							var partno = $(this).val();
						}
					});
					var search = 0;
					$("#searchPart").empty();
					addPartInfo(debAdjPartDetailList, search);
				}
				var NewAddedPartArray = $.map(debAdjPartDetailList, function(obj) {
					return $.extend(true, {}, obj);
				});
				localStorage.setItem("NewAddedPartArray1", JSON.stringify(NewAddedPartArray));
				var storedData = JSON.parse(localStorage.NewAddedPartArray1);
			}

			function addPartInfo(filteredData, search) {

				var debAdjPartDetailListDebValidation2 = [];
				var inventoryListDebValidation2 = [];
				inventoryListDebValidation2 = receivedData.inventoryList;
				$.each(inventoryListDebValidation2, function(key, invItem) {
					if (invItem.invpool == "provider") {
						debAdjPartDetailListDebValidation2.push(invItem);
					}
				});
				$.each(filteredData, function(key4, invItem4) {

					if (debAdjPartDetailListDebValidation2.length > 0) {
						$.each(debAdjPartDetailListDebValidation2, function(key5, invItem5) {
							if (invItem4.I_ITEM_NUMBER == invItem5.I_ITEM_NUMBER && (invItem4.I_SUBINVENTORY == invItem5.I_SUBINVENTORY || invItem4.I_SUBINVENTORY == invItem5.I_SUBINVENTORY_NAME)) {
								$.extend(filteredData[key4], { I_ONHAND_QUANTITY: invItem5.quantity });
							}
						});
					}

				});

				var subInventoryListNames = receivedData.resource.R_SUBINVENTORY_NAME;

				$('#searchPartadd').hide();
				var filteredData = filteredData;
				var numItems = $('.custom-btn-plus').length;
				var ii = 0;
				$("#visitList2").empty();
				var Addcontainer1 = $('<div />').attr("id", "searchPartadd").addClass("cp_section manual-part-addition");
				var NewpartinfoDiv = $('<div/>').attr("id", "searchPartaddContent");
				var partinfoDiv1 = $('<div/>').addClass('cp_text_block invitation-text pedDiv');
				var AddSubmitButtonDiv = $('<div/>').addClass('adjBtnDiv1');

				var partinfoLbl = $("<label>").text('Part Information : ').addClass('refno').attr("id", "partdetailsAdd");
				NewpartinfoDiv.append(partinfoLbl);

				var cancliterations = 0;
				$.each(filteredData, function(key, invItem) {
					if (invItem.search == 1) {
						cancliterations++;
					}

				});

				var addSubmitButton = $('<button/>', {
					text: "Review", //set text 1 to 10
					id: 'btn_tech_rev',
					click: function() { ReviewFunctionality2(debAdjPartDetailAddList); }
				}).addClass("cp_plugin_button custom-btn custom-btn-primary").attr("disabled", true);

				if (cancliterations > 0) {
					var CancelButton = $('<button/>', {
						text: "Remove", //set text 1 to 10
						id: 'remove_btn',
						click: function() { RemoveData(filteredData, debAdjPartDetailAddList); }
					}).addClass("cancelbtn custom-btn custom-btn-primary");
				}

				AddSubmitButtonDiv.append(CancelButton);
				AddSubmitButtonDiv.append(addSubmitButton);
				let iterations = filteredData.length;

				var i = 0;
				$.each(filteredData, function(key, invItem) {
					ii = key;
					i++;
					$("#partdetailsBeforeAdd").empty();
					var subInventoryList = "";
					var subInventoryListEmpty = true;
					var subInventoryListSelectDropDown = $('<select />', {
						id: "subInventoryListSelectDropDown" + key,
						change: function() { ddOnchangedFunction(invItem.I_ITEM_NUMBER, this.id, invItem.search == 1 ? 1 : 0, key, key); }
					}).addClass('cp_field_dropdown_component form-item dropone');
					subInventoryListSelectDropDown.append($('<option value="" />').html("Select Sub Inventory"));
					subInventoryListSelectDropDown.append($('<option value="CAR_STOCK"/>').html(receivedData.resource.external_id));
					if (typeof subInventoryListNames != 'undefined') {
						if (subInventoryListNames != null) // change done for Defect 1526
							subInventoryList = subInventoryListNames.split(";");
						subInventoryListEmpty = false;
						for (var x in subInventoryList) {
							var subInventoryName = subInventoryList[x].split(",");
							subInventoryListSelectDropDown.append($('<option value="' + subInventoryName[0] + '"/>').html(subInventoryList[x]));
							$("#subInventoryListSelectDropDown").attr('disabled', false);
						}
					}
					var partNumDiv = $('<div/>').addClass('flex-container').attr("id", "partnoDiv");
					var partDescDiv = $('<div/>').addClass('flex-container').attr("id", "partdesc");
					var partQuaDiv = $('<div/>').addClass('flex-container').attr("id", "partQty");
					var partnodiv1 = $('<div/>').addClass('ContainerDiv');
					var partnoval = $('<div/>').addClass('ContainerVal');
					var partchkbx = $('<div/>');
					var partDescdiv1 = $('<div/>').addClass('ContainerDiv');
					var partDescval = $('<div/>').addClass('ContainerVal');
					var partQtydiv1 = $('<div/>').addClass('ContainerDiv');
					var partQtyval = $('<div/>').attr("id", "partQtyval" + ii).addClass('ContainerVal');

					var SelectDiv1 = $('<div/>').addClass('flex-container');
					var QtyFieldDiv1 = $('<div/>').addClass('flex-container');
					var Selectlbl1 = $('<div/>').addClass('Selectlbl1');
					var QtyFieldlbl1 = $('<div/>').addClass('Selectlbl1');
					var selectboxdiv1 = $('<div/>').addClass('Selectdiv1');
					var plusdiv1 = $('<div/>').addClass('plusdiv1');
					var inputdiv1 = $('<div/>').addClass('inputdiv1');
					var minusdiv1 = $('<div/>').addClass('minusdiv1');
					var Qtydiv1 = $('<div/>').attr("id", "Qtydiv" + ii).addClass('Qtydiv1');

					var partSubInvDiv = $('<div/>').addClass('flex-container').attr("id", "partSubInvDiv");
					var partSubInvDivLbl = $('<div/>').addClass('ContainerDiv');
					var partSubInvDivVal = $('<div/>').addClass('ContainerVal');

					var onHandQuantityDiv = $('<div/>').addClass('flex-container').attr("id", "onHandQuantityDiv1");
					var onHandQuantityLbl = $('<div/>').addClass('ContainerDiv');
					var onHandQuantityVal = $('<div/>').addClass('ContainerVal').attr("id", "onHandQuantityValue1" + key);

					let checkKeyPresenceInArray = key => filteredData.some(obj => Object.keys(obj).includes(key));
					var isKeyPresent = checkKeyPresenceInArray(invItem.I_TASK_NUMBER);

					if (invItem.search == 1) {
						var partcheckbox = $('<input/>', {
							id: "chkbx_" + i,
							type: "checkbox",
							value: invItem.I_ITEM_NUMBER,
							click: function() { ckeckchangedFunction(this.id, invItem.I_ITEM_NUMBER); }
						}).addClass("bin-chk form-item remove_chk");
					}
					partNumDiv.append(partnodiv1);
					partNumDiv.append(partnoval);
					if (invItem.search == 1) {
						partNumDiv.append(partchkbx);
					}
					partDescDiv.append(partDescdiv1);
					partDescDiv.append(partDescval);
					partQuaDiv.append(partQtydiv1);
					partQuaDiv.append(partQtyval);
					partnodiv1.append('Part No: ');
					partnoval.append(invItem.I_ITEM_NUMBER);
					if (invItem.search == 1) {
						partchkbx.append(partcheckbox);
					}
					partDescdiv1.append('Part Description: ');
					partDescval.append(invItem.I_ITEM_DESCRIPTION);
					partSubInvDivLbl.append('Sub Inventory: ');
					if (invItem.search == 1) {
						partSubInvDivVal.append(subInventoryListSelectDropDown);
					} else {
						partSubInvDivVal.append(invItem.I_SUBINVENTORY);
					}
					partSubInvDiv.append(partSubInvDivLbl);
					partSubInvDiv.append(partSubInvDivVal);
					onHandQuantityLbl.append('On Hand Quantity: ');
					if (invItem.search == 1) {
						onHandQuantityVal.append("0");
					} else {
						onHandQuantityVal.append(invItem.I_ONHAND_QUANTITY != null ? invItem.I_ONHAND_QUANTITY : "0");
					}
					onHandQuantityDiv.append(onHandQuantityLbl);
					onHandQuantityDiv.append(onHandQuantityVal);
					partQtydiv1.append('Original Quantity: ');
					partQtyval.append(invItem.quantity);

					Selectlbl1.append('Adjust by: ');
					QtyFieldlbl1.append('Final Debrief Quantity: ');

					var plusButton = $('<button/>', {
						text: "+", //set text 1 to 10
						id: 'plus' + ii,
						click: function() { plusbtn(this.id, invItem.I_ITEM_NUMBER, invItem.search == 1 ? $('#subInventoryListSelectDropDown' + key).val() : invItem.I_SUBINVENTORY, invItem.search == 1 ? 1 : 0, key); }
					}).addClass("cp_plugin_button custom-btn custom-btn-plus");

					var minusButton = $('<button/>', {
						text: "-", //set text 1 to 10
						id: 'minus' + ii,
						click: function() { minusbtn(this.id, invItem.I_ITEM_NUMBER); }
					}).addClass("cp_plugin_button custom-btn custom-btn-minus");

					if (invItem.I_DEBRIEF_ADJ_QUANTITY) {
						var FinaldebriefQty = $('<input/>', {
							value: invItem.I_DEBRIEF_ADJ_QUANTITY,
							type: "text",
							id: 'debAdjQuantity' + ii,
							keyup: function() { keyup(this.id, invItem.I_ITEM_NUMBER, invItem.search == 1 ? $('#subInventoryListSelectDropDown' + key).val() : invItem.I_SUBINVENTORY, invItem.search == 1 ? 1 : 0, key); }
						}).addClass("bin-qty form-item dev_adj_add_part_ip_field");
					}
					else {
						var FinaldebriefQty = $('<input/>', {
							value: "0",
							type: "text",
							id: 'debAdjQuantity' + ii,
							keyup: function() { keyup(this.id, invItem.I_ITEM_NUMBER, invItem.search == 1 ? $('#subInventoryListSelectDropDown' + key).val() : invItem.I_SUBINVENTORY, invItem.search == 1 ? 1 : 0, key); }
						}).addClass("bin-qty form-item dev_adj_add_part_ip_field");
					}

					minusdiv1.append(minusButton);
					inputdiv1.append(FinaldebriefQty);
					plusdiv1.append(plusButton);
					partNumDiv.appendTo(partinfoDiv1);
					partDescDiv.appendTo(partinfoDiv1);
					partSubInvDiv.appendTo(partinfoDiv1);
					onHandQuantityDiv.appendTo(partinfoDiv1);
					partQuaDiv.appendTo(partinfoDiv1);
					SelectDiv1.append(Selectlbl1);
					SelectDiv1.append(minusdiv1);
					SelectDiv1.append(inputdiv1);
					SelectDiv1.append(plusdiv1);
					QtyFieldDiv1.append(QtyFieldlbl1);
					Qtydiv1.append(invItem.I_DEBRIEF_FINAL_DEBRIEF);
					QtyFieldDiv1.append(Qtydiv1);

					if (search == 0 && search != 1) {
						SelectDiv1.appendTo(partinfoDiv1);
						QtyFieldDiv1.appendTo(partinfoDiv1);
					}
					if (search == 1) {
						partinfoDiv1.append(AddButtonDiv);
					}
					NewpartinfoDiv.append(partinfoDiv1);
					Addcontainer1.append(NewpartinfoDiv);
					Addcontainer1.append();
					if (search == 0 && search != 1 && i != 1) {
						var hr1 = $('<hr>').addClass('hr-line');
					}
					var hr1 = $('<hr>').addClass('hr-line');
					partinfoDiv1.append(hr1);
				});
				partinfoDiv1.append(AddSubmitButtonDiv);
				Addcontainer1.append(partinfoDiv1);
				Addcontainer1.append();
				$("#visitList2").append(Addcontainer1);
			}

			function ddOnchangedFunction(partno, idd, isAddedPart, indexKey, adjQtyIpKey) {

				var subInventory = $('#' + idd + ' :selected').val();
				var inventoryListDebValidation4 = receivedData.inventoryList;
				var subInventoryList = [];
				var subInventoryOwner = [];
				if (receivedData.resource.R_SUBINVENTORY_LIST != null)
					subInventoryList = receivedData.resource.R_SUBINVENTORY_LIST.split(",");
				if (receivedData.resource.R_SUBINVENTORY_OWNER != null)
					subInventoryOwner = receivedData.resource.R_SUBINVENTORY_OWNER.split(",");
				var resourceId = receivedData.resource.external_id;
				var primaryOwnedSubInventories = {};
				var sharedSubInventories = {};
				primaryOwnedSubInventories["Primary Sub-Inventory"] = resourceId;
				for (var i = 0; i < subInventoryOwner.length; i++) {
					if (subInventoryOwner[i] == resourceId) {
						primaryOwnedSubInventories[subInventoryList[i]] = subInventoryOwner[i];
					} else {
						sharedSubInventories[subInventoryList[i]] = subInventoryOwner[i];
					}
				}
				var sharedSubInvTechId;
				$.each(sharedSubInventories, function(key, value) {
					if (subInventory === key) {
						sharedSubInvTechId = value;
					}
				});
				if (sharedSubInvTechId == null) {
					$.each(inventoryListDebValidation4, function(key, invItem) {
						if (invItem.invpool == "provider") {
							debAdjPartDetailListDebValidation4.push(invItem);
						}
					});
					var isAgainExistInAddedPartDD = 0;
					var isAgainExistInAddedPartQuantity = 0;
					$.each(debAdjPartDetailListDebValidation4, function(key, invItem) {
						if (partno == invItem.I_ITEM_NUMBER && (subInventory == invItem.I_SUBINVENTORY || subInventory == invItem.I_SUBINVENTORY_NAME)) {
							if (isAddedPart == 1) {
								$('#onHandQuantityValue1' + indexKey).html(invItem.quantity);
								isAgainExistInAddedPartDD = 1;
								isAgainExistInAddedPartQuantity = invItem.quantity;
							}
						}
					});
					if (isAddedPart == 1) {
						if (isAgainExistInAddedPartDD == 1) {
							$('#onHandQuantityValue1' + indexKey).html(isAgainExistInAddedPartQuantity);
							$('#debAdjQuantity' + adjQtyIpKey).prop("disabled", false);
							$('#plus' + adjQtyIpKey).prop("disabled", false);
							$('#minus' + adjQtyIpKey).prop("disabled", false);
						} else {
							$('#onHandQuantityValue1' + indexKey).html("0");
							$('#debAdjQuantity' + adjQtyIpKey).prop("disabled", true);
							$('#debAdjQuantity' + adjQtyIpKey).val(0);
							$('#Qtydiv' + adjQtyIpKey).val(0);
							$('#Qtydiv' + adjQtyIpKey).text(0);
							$('#plus' + adjQtyIpKey).prop("disabled", true);
							$('#minus' + adjQtyIpKey).prop("disabled", true);

							const found = debAdjPartDetailAddList.some(el => el.I_ITEM_NUMBER === partno);

							if (found) {
								$.each(debAdjPartDetailAddList, function(key, invItem) {
									if (debAdjPartDetailAddList[key].I_ITEM_NUMBER === partno) {
										debAdjPartDetailAddList[key].I_DEBRIEF_ADJ_QUANTITY = 0 + "";
										debAdjPartDetailAddList[key].I_DEBRIEF_FINAL_DEBRIEF = 0 + "";
									}
								});
								$.each(debAdjPartDetailAddList, function(key, invItem) {
									if (debAdjPartDetailAddList[key].I_DEBRIEF_ADJ_QUANTITY != null &&
										debAdjPartDetailAddList[key].I_DEBRIEF_ADJ_QUANTITY === "0") {
										debAdjPartDetailAddList.splice(key, 1);
									}
								});
							}
							alert("No on hand quantity found for the part " + partno + " in the sub inventory " + subInventory);
						}
					}
				}
				if (sharedSubInvTechId != null) {
					var isAgainExistInAddedPartDD1 = 0;
					var isAgainExistInAddedPartQuantity1 = 0;
					$.each(debAdjPartDetailListDebValidation4, function(key, invItem6) {
						if (partno == invItem6.I_ITEM_NUMBER && (subInventory == invItem6.I_SUBINVENTORY || subInventory == invItem6.I_SUBINVENTORY_NAME)) {
							if (isAddedPart == 1) {
								$('#onHandQuantityValue1' + indexKey).html(invItem6.quantity);
								isAgainExistInAddedPartDD1 = 1;
								isAgainExistInAddedPartQuantity1 = invItem6.quantity;
							}
						}
					});
					if (isAddedPart == 1) {
						if (isAgainExistInAddedPartDD1 == 1) {
							$('#onHandQuantityValue1' + indexKey).html(isAgainExistInAddedPartQuantity1);
							$('#debAdjQuantity' + adjQtyIpKey).prop("disabled", false);
							$('#plus' + adjQtyIpKey).prop("disabled", false);
							$('#minus' + adjQtyIpKey).prop("disabled", false);
						} else {
							$('#onHandQuantityValue1' + indexKey).html("0");
							$('#debAdjQuantity' + adjQtyIpKey).prop("disabled", true);
							$('#debAdjQuantity' + adjQtyIpKey).val(0);
							$('#Qtydiv' + adjQtyIpKey).val(0);
							$('#Qtydiv' + adjQtyIpKey).text(0);
							$('#plus' + adjQtyIpKey).prop("disabled", true);
							$('#minus' + adjQtyIpKey).prop("disabled", true);
							const found = debAdjPartDetailAddList.some(el => el.I_ITEM_NUMBER === partno);
							if (found) {
								$.each(debAdjPartDetailAddList, function(key, invItem) {
									if (debAdjPartDetailAddList[key].I_ITEM_NUMBER === partno) {
										debAdjPartDetailAddList[key].I_DEBRIEF_ADJ_QUANTITY = 0 + "";
										debAdjPartDetailAddList[key].I_DEBRIEF_FINAL_DEBRIEF = 0 + "";
									}
								});

								$.each(debAdjPartDetailAddList, function(key, invItem) {
									if (debAdjPartDetailAddList[key].I_DEBRIEF_ADJ_QUANTITY != null &&
										debAdjPartDetailAddList[key].I_DEBRIEF_ADJ_QUANTITY === "0") {
										debAdjPartDetailAddList.splice(key, 1);
									}
								});
							}
							//alert("No on hand quantity found for the part in the sub inventory " + partno);
							alert("No on hand quantity found for the part " + partno + " in the sub inventory " + subInventory);
						}
					}
				}
			}




			function ckeckchangedFunction(id, partno) {
				// Get the checkbox
				var checkBox = document.getElementById(id);
				// Get the output text
				var text = document.getElementById("remove_btn");
				// If the checkbox is checked, display the output text
				if (checkBox.checked == true) {
					$(text).css("background-color", "#337ab7");
					$('#btn_tech_rev').css("background-color", "#808080");  // new
					$('#btn_tech_rev').attr("disabled", true);  // new
					$('#btn_tech_rev').css("color", "#fff");  // new
				} else {
					$(text).css("background-color", "gray");
					$('#btn_tech_rev').css("background-color", "#337ab7");  // new
					$('#btn_tech_rev').removeAttr("disabled");  // new
				}
				$('.remove_chk').each(function(index, obj) {
					if (this.checked === true) {
						$(text).css("background-color", "#337ab7");
						$('#btn_tech_rev').css("background-color", "#808080");  // new
						$('#btn_tech_rev').attr("disabled", true);  // new
						$('#btn_tech_rev').css("color", "#fff");  // new
					}
				});
			}

			function keyup(id, partno, subInventory, isAddedPart, indexKey) {
				var suffix = id.match(/\d+/);
				var data = 0;
				var Qtydiv = document.getElementById('Qtydiv' + suffix);
				var adjqtyval = $('#debAdjQuantity' + suffix).val();
				if (adjqtyval != null && adjqtyval != '' && adjqtyval > 99) {
					alert("Can not adjust more than 99.");
					$('#debAdjQuantity' + suffix).val(99);
					adjqtyval = 99;
				}
				var subInventoryList = [];
				var subInventoryOwner = [];
				if (receivedData.resource.R_SUBINVENTORY_LIST != null)
					subInventoryList = receivedData.resource.R_SUBINVENTORY_LIST.split(",");
				if (receivedData.resource.R_SUBINVENTORY_OWNER != null)
					subInventoryOwner = receivedData.resource.R_SUBINVENTORY_OWNER.split(",");
				var resourceId = receivedData.resource.external_id;
				var primaryOwnedSubInventories = {};
				var sharedSubInventories = {};
				primaryOwnedSubInventories["Primary Sub-Inventory"] = resourceId;
				for (var i = 0; i < subInventoryOwner.length; i++) {
					if (subInventoryOwner[i] == resourceId) {
						primaryOwnedSubInventories[subInventoryList[i]] = subInventoryOwner[i];
					} else {
						sharedSubInventories[subInventoryList[i]] = subInventoryOwner[i];
					}
				}
				var sharedSubInvTechId;
				$.each(sharedSubInventories, function(key, value) {
					if (subInventory === key) {
						sharedSubInvTechId = value;
					}
				});
				if (sharedSubInvTechId == null) {
					var debAdjPartDetailListDebValidation = [];
					var inventoryListDebValidation = receivedData.inventoryList;
					$.each(inventoryListDebValidation, function(key, invItem) {
						if (invItem.invpool == "provider") {
							debAdjPartDetailListDebValidation.push(invItem);
						}
					});
					const isExistInOwnedSubInventoty = debAdjPartDetailListDebValidation.some(el => el.I_ITEM_NUMBER === partno);
					if (isExistInOwnedSubInventoty == false) {
						if (isAddedPart == 0) {
							if ($('#onHandQuantityValue' + indexKey).text() == 0 && adjqtyval > $('#onHandQuantityValue' + indexKey).text()) {
								alert("Adjusted Quantity cannot be greater than OnHand Quantity. Negative Adjusted Total is not allowed.");
								$('#debAdjQuantity' + suffix).val(0);
								adjqtyval = 0;
							}
						}
					}
					if (isExistInOwnedSubInventoty == true) {
						$.each(debAdjPartDetailListDebValidation, function(key, invItem) {
							if (partno == invItem.I_ITEM_NUMBER && (subInventory == invItem.I_SUBINVENTORY || subInventory == invItem.I_SUBINVENTORY_NAME) && adjqtyval > invItem.quantity) {
								alert("Adjusted Quantity cannot be greater than OnHand Quantity. Negative Adjusted Total is not allowed.");
								$('#debAdjQuantity' + suffix).val(invItem.quantity != null ? invItem.quantity : 0);
								///	$('#debAdjQuantity' + suffix).val(invItem.quantity);
								adjqtyval = invItem.quantity != null ? invItem.quantity : 0;
							}
						});
					}
				}

				if (adjqtyval != null || adjqtyval != '') {
					var qtyval = "";
					$.each(debAdjPartDetailList, function(key, invItem) {
						if (invItem.I_ITEM_NUMBER == partno) {
							qtyval = invItem.quantity;
						}
					});
					if (Math.sign(adjqtyval) === -1) {
						var finalval = (parseInt(qtyval)) + (parseInt(adjqtyval));
						var result = isNaN(parseFloat(finalval));
						if (result == true || Math.sign(finalval) === -1) {
							alert("You cannot remove more the original quantity.");
							$('#debAdjQuantity' + suffix).val("-" + qtyval);
							Qtydiv.innerHTML = 0;
						}
						else {
							Qtydiv.innerHTML = finalval;
						}
					}
					else {
						var finalval = (parseInt(qtyval)) + (parseInt(adjqtyval));
						//alert(finalval);
						var result = isNaN(parseFloat(finalval));
						if (result == true || Math.sign(finalval) === -1) {
							Qtydiv.innerHTML = 0;
						}
						else {
							var Qtydiv = document.getElementById('Qtydiv' + suffix);
							Qtydiv.innerHTML = parseInt(qtyval) + parseInt(adjqtyval);
						}
					}
					const found = debAdjPartDetailAddList.some(el => el.I_ITEM_NUMBER === partno);
					if (found) {
						$.each(debAdjPartDetailAddList, function(key, invItem) {
							if (debAdjPartDetailAddList[key].I_ITEM_NUMBER === partno) {
								if (Math.sign(finalval) === -1) {
									adjqtyval = "-" + qtyval
									finalval = 0;
								}
								debAdjPartDetailAddList[key].I_DEBRIEF_ADJ_QUANTITY = adjqtyval;
								debAdjPartDetailAddList[key].I_DEBRIEF_FINAL_DEBRIEF = finalval;
							}
						});
					}
					else {
						$.each(debAdjPartDetailList, function(key, invItem) {
							if (invItem.I_ITEM_NUMBER == partno) {
								if (result == true || Math.sign(finalval) === -1) {
									adjqtyval = "-" + qtyval
									finalval = 0;
								}
								debAdjPartDetailAddList.push({ I_ITEM_NUMBER: invItem.I_ITEM_NUMBER, I_ITEM_DESCRIPTION: invItem.I_ITEM_DESCRIPTION, quantity: qtyval, I_DEBRIEF_ADJ_QUANTITY: adjqtyval, I_DEBRIEF_FINAL_DEBRIEF: finalval, invid: invItem.invid, invtype: invItem.invtype, I_INVENTORY_KEY: invItem.I_INVENTORY_KEY, I_SUBINVENTORY: invItem.I_SUBINVENTORY }); // new ver2.0 added I_SUBINVENTORY: invItem.I_SUBINVENTORY 
							}

						});
					}
				}
				else {
					alert("Adjustment quantity should not be empty");
				}
				var loopCountN = 0;
				var loopIncCountN = 0;

				$('.dev_adj_ip_field').each(function(index, obj) {
					loopCountN++;
					if (this.value === "" || this.value === null || this.value === "0") {
						loopIncCountN++;
						//	$('#btn_tech_rev').attr("disabled", true);  // new
					}
				});
				if (loopCountN === loopIncCountN) {
					$('#btn_rev').attr("disabled", true);  // new
				}
				$('.dev_adj_ip_field').each(function(index, obj) {
					if (this.value !== "" && this.value !== null && this.value !== "0") {
						$('#btn_rev').removeAttr("disabled");  // new
					}
				});

				var loopCount = 0;
				var loopIncCount = 0;
				$('.dev_adj_add_part_ip_field').each(function(index, obj) {
					loopCount++;
					if (this.value === "" || this.value === null || this.value === "0") {
						loopIncCount++;
					}
				});
				if (loopCount === loopCount) {
					loopIncCount++;
					$('#btn_tech_rev').attr("disabled", true);  // new
				}
				$('.dev_adj_add_part_ip_field').each(function(index, obj) {
					if (this.value !== "" && this.value !== null && this.value !== "0") {
						$('#btn_tech_rev').removeAttr("disabled");  // new
					}
				});
				if (sharedSubInvTechId == null) {
					$.each(debAdjPartDetailListDebValidation, function(key, invItem) {
						if (partno == invItem.I_ITEM_NUMBER && (subInventory == invItem.I_SUBINVENTORY || subInventory == invItem.I_SUBINVENTORY_NAME)) {
							if (isAddedPart == 1) {
								$('#onHandQuantityValue1' + indexKey).html(invItem.quantity);
								isAgainExistInAddedPartDD = 1;
								isAgainExistInAddedPartQuantity = invItem.quantity;
							}
						}
					});
					if (isAddedPart == 1) {
						if (isAgainExistInAddedPartDD == 1) {
							$('#onHandQuantityValue1' + indexKey).html(isAgainExistInAddedPartQuantity);
						} else {
							$('#onHandQuantityValue1' + indexKey).html("0");
						//	alert("No on hand quantity found for the part in the sub inventory " + partno);
							alert("No on hand quantity found for the part " + partno + " in the sub inventory " + subInventory);
						}
					}

				} else {
					if ($('#onHandQuantityValue1' + indexKey).text() != null && (($('#onHandQuantityValue1' + indexKey).text() != "" && (adjqtyval - 1) > $('#onHandQuantityValue1' + indexKey).val())
						//	&& $('#onHandQuantityValue1' + indexKey).text() != "0" && (adjqtyval - 1) > $('#onHandQuantityValue1' + indexKey).val()) {
					)) {
						alert("Adjusted Quantity cannot be greater than OnHand Quantity. Negative Adjusted Total is not allowed.");
						$('#debAdjQuantity' + suffix).val($('#onHandQuantityValue1' + indexKey).text());
						adjqtyval = $('#onHandQuantityValue1' + indexKey).text();
					}
					//		if (($('#onHandQuantityValue' + indexKey).text() == null || $('#onHandQuantityValue' + indexKey).text() == "0") && (adjqtyval - 1) > $('#onHandQuantityValue' + indexKey).val()) {
					if (($('#onHandQuantityValue' + indexKey).text() == null || $('#onHandQuantityValue' + indexKey).text() == "") && isAddedPart == 0 && adjqtyval > 0) {
						alert("Adjusted Quantity cannot be greater than OnHand Quantity. Negative Adjusted Total is not allowed.");
						$('#debAdjQuantity' + suffix).val(0);
						adjqtyval = 0;
					}
				}
			}


			function plusbtn(id, partno, subInventory, isAddedPart, indexKey) {
				var suffix = id.match(/\d+/);
				var data = 0;
				var Qtydiv = document.getElementById('Qtydiv' + suffix);
				Qtydiv.innerHTML = data;
				$('#debAdjQuantity' + suffix).keyup(function() {
					var adjqtyval = $('#debAdjQuantity' + suffix).val();
					if (adjqtyval != null || adjqtyval != '') {
						//var qtyval = $('#partQtyval' + suffix).text();
						var qtyval = "";
						$.each(debAdjPartDetailList, function(key, invItem) {
							if (invItem.I_ITEM_NUMBER == partno) {
								//	console.log('qtyadd');
								qtyval = invItem.quantity;
							}
						});
						if (Math.sign(adjqtyval) === -1) {
							var finalval = (parseInt(qtyval)) + (parseInt(adjqtyval));
							var result = isNaN(parseFloat(finalval));
							if (result == true || Math.sign(finalval) === -1) {
								alert("You cannot remove more the original quantity.");
								$('#debAdjQuantity' + suffix).val("-" + qtyval);
								Qtydiv.innerHTML = 0;
							}
							else {
								Qtydiv.innerHTML = finalval;
							}
						}
						else {
							var finalval = (parseInt(qtyval)) + (parseInt(adjqtyval));
							var result = isNaN(parseFloat(finalval));
							if (result == true || Math.sign(finalval) === -1) {
								Qtydiv.innerHTML = 0;
							}
							else {
								Qtydiv.innerHTML = finalval;
							}
						}
						const found = debAdjPartDetailAddList.some(el => el.I_ITEM_NUMBER === partno);
						if (found) {
							$.each(debAdjPartDetailAddList, function(key, invItem) {
								if (debAdjPartDetailAddList[key].I_ITEM_NUMBER === partno) {
									if (Math.sign(finalval) === -1) {
										adjqtyval = "-" + qtyval
										finalval = 0;
									}
									debAdjPartDetailAddList[key].I_DEBRIEF_ADJ_QUANTITY = adjqtyval;
									debAdjPartDetailAddList[key].I_DEBRIEF_FINAL_DEBRIEF = finalval;
								}
							});
						}
						else {
							$.each(debAdjPartDetailList, function(key, invItem) {
								if (invItem.I_ITEM_NUMBER == partno) {
									//delete debAdjPartDetailAddList;
									if (Math.sign(finalval) === -1) {
										adjqtyval = "-" + qtyval
										finalval = 0;
									}
									debAdjPartDetailAddList.push({ I_ITEM_NUMBER: invItem.I_ITEM_NUMBER, I_ITEM_DESCRIPTION: invItem.I_ITEM_DESCRIPTION, quantity: qtyval, I_DEBRIEF_ADJ_QUANTITY: adjqtyval, I_DEBRIEF_FINAL_DEBRIEF: finalval, invid: invItem.invid, invtype: invItem.invtype, I_INVENTORY_KEY: invItem.I_INVENTORY_KEY, I_SUBINVENTORY: invItem.I_SUBINVENTORY });
								}
							});
						}

					}
					else {
						alert("Adjustment quantity should not be empty");
					}

				});

				$(this).addClass("activeplus");
				$("#minus" + suffix).removeClass("active");
				var data1 = $('#debAdjQuantity' + suffix).val();
				data = parseInt(data1) + 1;
				$('#debAdjQuantity' + suffix).val(data);
				var adjqtyval = $('#debAdjQuantity' + suffix).val();
				if (adjqtyval != null && adjqtyval != '' && adjqtyval > 99) {
					alert("Can not adjust more than 99.");
					//	adjqtyval.val = 99;
					$('#debAdjQuantity' + suffix).val(99);
					adjqtyval = 99;
				}
				var subInventoryList = [];
				var subInventoryOwner = [];
				if (receivedData.resource.R_SUBINVENTORY_LIST != null)
					subInventoryList = receivedData.resource.R_SUBINVENTORY_LIST.split(",");
				if (receivedData.resource.R_SUBINVENTORY_OWNER != null)
					subInventoryOwner = receivedData.resource.R_SUBINVENTORY_OWNER.split(",");
				var resourceId = receivedData.resource.external_id;
				var primaryOwnedSubInventories = {};
				var sharedSubInventories = {};
				primaryOwnedSubInventories["Primary Sub-Inventory"] = resourceId;
				for (var i = 0; i < subInventoryOwner.length; i++) {
					if (subInventoryOwner[i] == resourceId) {
						primaryOwnedSubInventories[subInventoryList[i]] = subInventoryOwner[i];
					} else {
						sharedSubInventories[subInventoryList[i]] = subInventoryOwner[i];
					}
				}
				var sharedSubInvTechId;
				$.each(sharedSubInventories, function(key, value) {
					if (subInventory === key) {
						sharedSubInvTechId = value;
					}
				});
				if (sharedSubInvTechId == null) {
					var debAdjPartDetailListDebValidation = [];
					var inventoryListDebValidation = receivedData.inventoryList;
					$.each(inventoryListDebValidation, function(key, invItem) {
						if (invItem.invpool == "provider") {
							debAdjPartDetailListDebValidation.push(invItem);
						}
					});
					const isExistInOwnedSubInventoty = debAdjPartDetailListDebValidation.some(el => el.I_ITEM_NUMBER === partno);
					var isAgainExistInAddedPartDD = 0;
					var isAgainExistInAddedPartQuantity = 0;
					if (isExistInOwnedSubInventoty == false) {
						if (isAddedPart == 0) {

							if ($('#onHandQuantityValue' + indexKey).text() == 0 && adjqtyval > $('#onHandQuantityValue' + indexKey).text()) {
								alert("Adjusted Quantity cannot be greater than OnHand Quantity. Negative Adjusted Total is not allowed.");
								$('#debAdjQuantity' + suffix).val(0);
								adjqtyval = 0;
							}
						}
					}
					if (isExistInOwnedSubInventoty == true) {
						$.each(debAdjPartDetailListDebValidation, function(key, invItem) {
							if (partno == invItem.I_ITEM_NUMBER && (subInventory == invItem.I_SUBINVENTORY || subInventory == invItem.I_SUBINVENTORY_NAME) && adjqtyval > invItem.quantity) {
								alert("Adjusted Quantity cannot be greater than OnHand Quantity. Negative Adjusted Total is not allowed.");
								$('#debAdjQuantity' + suffix).val(invItem.quantity != null ? invItem.quantity : 0);
								//	$('#debAdjQuantity' + indexKey).val(invItem.quantity!= null ? invItem.quantity : 0); // new changes on defect start
								adjqtyval = invItem.quantity != null ? invItem.quantity : 0; // new changes on defect start					
							}
						});
					}
					$.each(debAdjPartDetailListDebValidation, function(key, invItem) {
						if (partno == invItem.I_ITEM_NUMBER && (subInventory == invItem.I_SUBINVENTORY || subInventory == invItem.I_SUBINVENTORY_NAME)) {
							if (isAddedPart == 1) {
								$('#onHandQuantityValue1' + indexKey).html(invItem.quantity);
								isAgainExistInAddedPartDD = 1;
								isAgainExistInAddedPartQuantity = invItem.quantity;
							}
						}
					});

					if (isAddedPart == 1) {
						if (isAgainExistInAddedPartDD == 1) {
							$('#onHandQuantityValue1' + indexKey).html(isAgainExistInAddedPartQuantity);
							$('#debAdjQuantity' + indexKey).prop("disabled", false);
							$('#plus' + indexKey).prop("disabled", false);
							$('#minus' + indexKey).prop("disabled", false);
						} else {
							$('#onHandQuantityValue1' + indexKey).html("0");
							$('#debAdjQuantity' + indexKey).prop("disabled", true);
							$('#debAdjQuantity' + indexKey).val(0);
							$('#Qtydiv' + indexKey).val(0);
							$('#Qtydiv' + indexKey).text(0);
							$('#plus' + indexKey).prop("disabled", true);
							$('#minus' + indexKey).prop("disabled", true);
							$('#debAdjQuantity' + suffix).val(0);
							adjqtyval = 0;
						//	alert("No on hand quantity found for the part in the sub inventory " + partno);
							alert("No on hand quantity found for the part " + partno + " in the sub inventory " + subInventory);
						}
					}
				} else {
					if ($('#onHandQuantityValue1' + indexKey).text() != null && (($('#onHandQuantityValue1' + indexKey).text() != "" && (adjqtyval - 1) > $('#onHandQuantityValue1' + indexKey).val())
						//	&& $('#onHandQuantityValue1' + indexKey).text() != "0" && (adjqtyval - 1) > $('#onHandQuantityValue1' + indexKey).val()) {
					)) {
						alert("Adjusted Quantity cannot be greater than OnHand Quantity. Negative Adjusted Total is not allowed.");
						$('#debAdjQuantity' + suffix).val($('#onHandQuantityValue1' + indexKey).text());
						adjqtyval = $('#onHandQuantityValue1' + indexKey).text();
					}
					//		if (($('#onHandQuantityValue' + indexKey).text() == null || $('#onHandQuantityValue' + indexKey).text() == "0") && (adjqtyval - 1) > $('#onHandQuantityValue' + indexKey).val()) {
					if (($('#onHandQuantityValue' + indexKey).text() == null || $('#onHandQuantityValue' + indexKey).text() == "") && isAddedPart == 0 && adjqtyval > 0) {
						alert("Adjusted Quantity cannot be greater than OnHand Quantity. Negative Adjusted Total is not allowed.");
						$('#debAdjQuantity' + suffix).val(0);
						adjqtyval = 0;
					}
				}

				if (adjqtyval != null || adjqtyval != '') {
					var qtyval = "";

					$.each(debAdjPartDetailList, function(key, invItem) {
						if (invItem.I_ITEM_NUMBER == partno) {
							//console.log('qtyadd');
							qtyval = invItem.quantity;
						}

					});
					var finalval = parseInt(qtyval) + parseInt(adjqtyval);
					var Qtydiv = document.getElementById('Qtydiv' + suffix);
					Qtydiv.innerHTML = parseInt(qtyval) + parseInt(adjqtyval);
					const found = debAdjPartDetailAddList.some(el => el.I_ITEM_NUMBER === partno);
					if (found) {
						$.each(debAdjPartDetailAddList, function(key, invItem) {
							if (debAdjPartDetailAddList[key].I_ITEM_NUMBER === partno) {
								if (Math.sign(finalval) === -1) {
									adjqtyval = "-" + qtyval
									finalval = 0;
								}
								debAdjPartDetailAddList[key].I_DEBRIEF_ADJ_QUANTITY = adjqtyval;
								debAdjPartDetailAddList[key].I_DEBRIEF_FINAL_DEBRIEF = finalval;
							}
						});
					}
					else {
						$.each(debAdjPartDetailList, function(key, invItem) {
							if (invItem.I_ITEM_NUMBER == partno) {
								if (Math.sign(finalval) === -1) {
									adjqtyval = "-" + qtyval
									finalval = 0;
								}
								debAdjPartDetailAddList.push({ I_ITEM_NUMBER: invItem.I_ITEM_NUMBER, I_ITEM_DESCRIPTION: invItem.I_ITEM_DESCRIPTION, quantity: qtyval, I_DEBRIEF_ADJ_QUANTITY: adjqtyval, I_DEBRIEF_FINAL_DEBRIEF: finalval, invid: invItem.invid, invtype: invItem.invtype, I_INVENTORY_KEY: invItem.I_INVENTORY_KEY, I_SUBINVENTORY: invItem.I_SUBINVENTORY });
							}
						});
					}
				}
				else {
					alert("Adjustment quantity should not be empty");
				}
				var loopCountN = 0;
				var loopIncCountN = 0;
				$('.dev_adj_ip_field').each(function(index, obj) {
					loopCountN++;
					if (this.value === "" || this.value === null || this.value === "0") {
						loopIncCountN++;
					}
				});
				if (loopCountN === loopIncCountN) {
					$('#btn_rev').attr("disabled", true);  // new
				}
				$('.dev_adj_ip_field').each(function(index, obj) {
					if (this.value !== "" && this.value !== null && this.value !== "0") {
						$('#btn_rev').removeAttr("disabled");  // new
					}
				});
				var loopCount = 0;
				var loopIncCount = 0;
				$('.dev_adj_add_part_ip_field').each(function(index, obj) {
					loopCount++;
					if (this.value === "" || this.value === null || this.value === "0") {
						loopIncCount++;
					}
				});

				if (loopCount === loopCount) {
					$('#btn_tech_rev').attr("disabled", true);  // new
				}

				$('.dev_adj_add_part_ip_field').each(function(index, obj) {
					if (this.value !== "" && this.value !== null && this.value !== "0") {
						$('#btn_tech_rev').removeAttr("disabled");  // new
					}
				});
			}

			function minusbtn(id, partno) {
				var data = 0;
				var suffix = id.match(/\d+/);
				$(this).addClass("active");
				$("#plus" + suffix).removeClass("activeplus");

				$('#debAdjQuantity' + suffix).keyup(function() {
					var adjqtyval = $('#debAdjQuantity' + suffix).val();
					if (adjqtyval != null || adjqtyval != '') {
						var qtyval = "";
						$.each(debAdjPartDetailList, function(key, invItem) {
							if (invItem.I_ITEM_NUMBER == partno) {
								qtyval = invItem.quantity;
							}
						});
						if (Math.sign(adjqtyval) === -1) {
							var finalval = (parseInt(qtyval)) + (parseInt(adjqtyval));
							var result = isNaN(parseFloat(finalval));
							if (result == true || Math.sign(finalval) === -1) {
								alert("You cannot remove more the original quantity.");
								$('#debAdjQuantity' + suffix).val("-" + qtyval);
								Qtydiv.innerHTML = 0;
							}
							else {
								Qtydiv.innerHTML = finalval;
							}
						}
						else {
							var finalval = (parseInt(qtyval)) + (parseInt(adjqtyval));
							var result = isNaN(parseFloat(finalval));
							if (result == true || Math.sign(finalval) === -1) {
								Qtydiv.innerHTML = 0;
							}
							else {
								Qtydiv.innerHTML = parseInt(qtyval) + parseInt(adjqtyval);
							}
						}
						const found = debAdjPartDetailAddList.some(el => el.I_ITEM_NUMBER === partno);
						if (found) {
							$.each(debAdjPartDetailAddList, function(key, invItem) {
								if (debAdjPartDetailAddList[key].I_ITEM_NUMBER === partno) {
									if (Math.sign(finalval) === -1) {
										adjqtyval = "-" + qtyval
										finalval = 0;
									}
									debAdjPartDetailAddList[key].I_DEBRIEF_ADJ_QUANTITY = adjqtyval;
									debAdjPartDetailAddList[key].I_DEBRIEF_FINAL_DEBRIEF = finalval;
								}
							});
						}
						else {
							$.each(debAdjPartDetailList, function(key, invItem) {
								if (invItem.I_ITEM_NUMBER == partno) {
									//delete debAdjPartDetailAddList;
									if (Math.sign(finalval) === -1) {
										adjqtyval = "-" + qtyval
										finalval = 0;
									}
									debAdjPartDetailAddList.push({ I_ITEM_NUMBER: invItem.I_ITEM_NUMBER, I_ITEM_DESCRIPTION: invItem.I_ITEM_DESCRIPTION, quantity: qtyval, I_DEBRIEF_ADJ_QUANTITY: adjqtyval, I_DEBRIEF_FINAL_DEBRIEF: finalval, invid: invItem.invid, invtype: invItem.invtype, I_INVENTORY_KEY: invItem.I_INVENTORY_KEY, I_SUBINVENTORY: invItem.I_SUBINVENTORY });
								}
							});
						}

					}
					else {
						alert("Adjustment quantity should not be empty");
					}
				});

				var data1 = $('#debAdjQuantity' + suffix).val();
				data = parseInt(data1) - 1;
				$('#debAdjQuantity' + suffix).val(data);
				var adjqtyval = $('#debAdjQuantity' + suffix).val();
				if (adjqtyval != null || adjqtyval != '') {
					var qtyval = "";
					$.each(debAdjPartDetailList, function(key, invItem) {
						if (invItem.I_ITEM_NUMBER == partno) {
							console.log('qtyadd');
							qtyval = invItem.quantity;
						}
					});
					var Qtydiv = document.getElementById('Qtydiv' + suffix);
					if (Math.sign(adjqtyval) === -1) {
						var finalval = (parseInt(qtyval)) + (parseInt(adjqtyval));
						var result = isNaN(parseFloat(finalval));
						if (result == true || Math.sign(finalval) === -1) {
							alert("You cannot remove more the original quantity.");
							$('#debAdjQuantity' + suffix).val("-" + qtyval);
							Qtydiv.innerHTML = 0;
						}
						else {
							var finalval = (parseInt(qtyval)) + (parseInt(adjqtyval));
							Qtydiv.innerHTML = finalval;
						}
					}
					else {
						var finalval = (parseInt(qtyval)) + (parseInt(adjqtyval));
						Qtydiv.innerHTML = parseInt(qtyval) + parseInt(adjqtyval);
					}
					const found = debAdjPartDetailAddList.some(el => el.I_ITEM_NUMBER === partno);
					if (found) {
						$.each(debAdjPartDetailAddList, function(key, invItem) {
							if (debAdjPartDetailAddList[key].I_ITEM_NUMBER === partno) {
								if (Math.sign(finalval) === -1) {
									adjqtyval = "-" + qtyval
									finalval = 0;
								}
								debAdjPartDetailAddList[key].I_DEBRIEF_ADJ_QUANTITY = adjqtyval;
								debAdjPartDetailAddList[key].I_DEBRIEF_FINAL_DEBRIEF = finalval;
							}
						});

					}
					else {
						$.each(debAdjPartDetailList, function(key, invItem) {
							if (invItem.I_ITEM_NUMBER == partno) {
								if (Math.sign(finalval) === -1) {
									adjqtyval = "-" + qtyval
									finalval = 0;
								}
								debAdjPartDetailAddList.push({ I_ITEM_NUMBER: invItem.I_ITEM_NUMBER, I_ITEM_DESCRIPTION: invItem.I_ITEM_DESCRIPTION, quantity: qtyval, I_DEBRIEF_ADJ_QUANTITY: adjqtyval, I_DEBRIEF_FINAL_DEBRIEF: finalval, invid: invItem.invid, invtype: invItem.invtype, I_INVENTORY_KEY: invItem.invkey, I_SUBINVENTORY: invItem.I_SUBINVENTORY });
							}

						});
					}

				}
				else {
					alert("Adjustment quantity should not be empty");
				}

				var loopCountN = 0;
				var loopIncCountN = 0;

				$('.dev_adj_ip_field').each(function(index, obj) {
					loopCountN++;
					if (this.value === "" || this.value === null || this.value === "0") {
						loopIncCountN++;
					}
				});
				if (loopCountN === loopIncCountN) {
					$('#btn_rev').attr("disabled", true);  // new
				}
				$('.dev_adj_ip_field').each(function(index, obj) {
					if (this.value !== "" && this.value !== null && this.value !== "0") {
						$('#btn_rev').removeAttr("disabled");  // new
					}
				});
				var loopCount = 0;
				var loopIncCount = 0;
				$('.dev_adj_add_part_ip_field').each(function(index, obj) {
					loopCount++;
					if (this.value === "" || this.value === null || this.value === "0") {
						loopIncCount++;
					}
				});
				if (loopCount === loopCount) {
					$('#btn_tech_rev').attr("disabled", true);  // new
				}
				$('.dev_adj_add_part_ip_field').each(function(index, obj) {
					if (this.value !== "" && this.value !== null && this.value !== "0") {
						$('#btn_tech_rev').removeAttr("disabled");  // new
					}
				});
			}

			function ReviewFunctionality2(debAdjPartDetailAddList, filteredData) {
				$.each(debAdjPartDetailList, function(key1, invItem) {
					$.each(debAdjPartDetailAddList, function(key2, partData) {
						if (invItem.search == 1 && invItem.I_ITEM_NUMBER === partData.I_ITEM_NUMBER) {
							if ($('#subInventoryListSelectDropDown' + key1).val() == "") {
								redirectionToPartFunctionality();
								alert("Please select Subinventory for Part No. - " + partData.I_ITEM_NUMBER);
								// reload();
								//location.reload();
								throw new Error("exiting the function");
							}
							$.extend(debAdjPartDetailAddList[key2], { I_SUBINVENTORY: $('#subInventoryListSelectDropDown' + key1).val(), search: 1 });
						}
					});
				});
				$('#partInfoReview').empty();

				$('#stageDiv4').show();
				$('#stageDiv3').hide();
				$('#stageDiv2').hide();
				$('#stageDiv1').hide();

				var container1 = $('<div />').attr("id", "manual-part-addition").addClass("cp_section manual-part-addition");

				var partinfoDiv = $('<div/>').attr("id", "PartInfo");
				var partinfoDiv1 = $('<div/>').addClass('cp_text_block invitation-text pedDiv').attr("id", "partInfoReview");
				var adjButtonDiv = $('<div/>').addClass('adjBtnDiv4');

				var partinfoLbl = $("<label>").text('Part Information ').addClass('refno');
				partinfoDiv.append(partinfoLbl);

				var backButton = $('<button/>', {
					text: "Dismiss", //set text 1 to 10
					id: 'bk_btn',
					click: function() { redirectionToPartFunctionality(); }
				}).addClass("back-button custom-btn custom-btn-primary");

				var adjButton = $('<button/>', {
					text: "Submit", //set text 1 to 10
					id: 'btn_6_submit',
					click: function() { submitPart2(debAdjPartDetailAddList); }
				}).addClass("custom-btn custom-btn-primary");

				var hr = $('<hr>');

				if (debAdjPartDetailAddList.length > 0) {
					var iterations = debAdjPartDetailAddList.length;
					var ii = 0;
					$.each(debAdjPartDetailAddList, function(key1, partData) {
						ii++;
						var partNumDiv = $('<div/>').addClass('flex-container');
						var partDescDiv = $('<div/>').addClass('flex-container');
						var partQuaDiv = $('<div/>').addClass('flex-container');
						var partAdjustmentQtyDiv = $('<div/>').addClass('flex-container');
						var partFinaldebriefQtyDiv = $('<div/>').addClass('flex-container');
						var hr1 = $('<hr>').addClass('hr-line');

						var partnodiv1 = $('<div/>').addClass('ContainerDiv');
						var partnovaldiv1 = $('<div/>').addClass('ContainerVal');
						partnodiv1.append('Part No: ');
						partnovaldiv1.append(partData.I_ITEM_NUMBER);
						var partdescdiv = $('<div/>').addClass('ContainerDiv');
						var partdescval = $('<div/>').addClass('ContainerVal');
						partdescdiv.append('Part Description: ');
						partdescval.append(partData.I_ITEM_DESCRIPTION);
						var additionalParSubInvDiv = $('<div/>').addClass('flex-container');
						var additionalParSubInvLbl = $('<div/>').addClass('ContainerDiv');
						var additionalParSubInvVal = $('<div/>').addClass('ContainerVal');
						additionalParSubInvLbl.append('Sub Inventory');
						additionalParSubInvVal.append(partData.I_SUBINVENTORY);
						var PartQtylblDiv = $('<div/>').addClass('ContainerDiv');
						var PartQtyvalueDiv = $('<div/>').addClass('ContainerVal');
						var partAdjustmentQtydiv = $('<div/>').addClass('ContainerDiv');
						var partAdjustmentQtyval = $('<div/>').addClass('ContainerVal').attr("id", "partAdjQtyReviewVal" + key1);
						var partFinaldebriefQtyQtydiv = $('<div/>').addClass('ContainerDiv');
						var partfinalDebriefQtyval = $('<div/>').addClass('ContainerVal');
						PartQtylblDiv.append('Original Quantity: ');
						PartQtyvalueDiv.append(partData.quantity);
						partAdjustmentQtydiv.append('Adjustment Quantity: ');
						if (partData.I_DEBRIEF_ADJ_QUANTITY > 0) {
							partAdjustmentQtyval.append("+" + partData.I_DEBRIEF_ADJ_QUANTITY);
						} else {
							partAdjustmentQtyval.append(partData.I_DEBRIEF_ADJ_QUANTITY);
						}
						partFinaldebriefQtyQtydiv.append('Final Debrief Quantity: ');
						partfinalDebriefQtyval.append(partData.I_DEBRIEF_FINAL_DEBRIEF);
						partNumDiv.append(partnodiv1);
						partNumDiv.append(partnovaldiv1);
						partDescDiv.append(partdescdiv);
						partDescDiv.append(partdescval);
						additionalParSubInvDiv.append(additionalParSubInvLbl);
						additionalParSubInvDiv.append(additionalParSubInvVal);
						partQuaDiv.append(PartQtylblDiv);
						partQuaDiv.append(PartQtyvalueDiv);
						partAdjustmentQtyDiv.append(partAdjustmentQtydiv);
						partAdjustmentQtyDiv.append(partAdjustmentQtyval);
						partFinaldebriefQtyDiv.append(partFinaldebriefQtyQtydiv);
						partFinaldebriefQtyDiv.append(partfinalDebriefQtyval);
						partNumDiv.appendTo(partinfoDiv1);
						partDescDiv.appendTo(partinfoDiv1);
						additionalParSubInvDiv.appendTo(partinfoDiv1);
						partQuaDiv.appendTo(partinfoDiv1);
						partAdjustmentQtyDiv.appendTo(partinfoDiv1);
						partFinaldebriefQtyDiv.appendTo(partinfoDiv1);
						partinfoDiv1.append(hr1);
						partinfoDiv1.append(adjButtonDiv);
						partinfoDiv.append(partinfoDiv1);
					});
				}
				else {
					partinfoDiv.append("<br>");
					partinfoDiv.append("   No Record Found. Adjustment quantity is not found").css("color", "red");
				}
				adjButtonDiv.append(backButton);
				adjButtonDiv.append(adjButton);
				partinfoDiv1.append(adjButtonDiv);
				container1.append(partinfoDiv);
				$("#visitList4").append(container1);
			}

			function RemoveData(filteredData, debAdjPartDetailAddList) {
				if (filteredData) {
					var count = 0;
					$('input[type=checkbox]').each(function() {
						if (this.checked) {
							var partno = $(this).val();
							for (var i = 0; i < filteredData.length; i++) {
								if (filteredData[i].I_ITEM_NUMBER == partno) {
									filteredData.splice(i, 1);
									break;
								}
							}
							for (var i = 0; i < debAdjPartDetailAddList.length; i++) {
								if (debAdjPartDetailAddList[i].I_ITEM_NUMBER == partno) {
									debAdjPartDetailAddList.splice(i, 1);
									break;
								}
							}
							count++;
						}
					});

					if (count == 0) {
						alert("Please check at least one of the checkboxes to remove an item from the list");
					}
				}
				var search = 0;
				$("#searchPart").empty();
				addPartInfo(debAdjPartDetailList, search);
			}

			function submitPart2(partsData) {
				var susActflag = false;
				var suspendActivityflagArr = [];
				var daas = "2";
				var inventoryUrlAddPart = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/activities/" + receivedData.activity.aid + "/customerInventories";
				$.each(partsData, function(key1, partData) {
					if (!partData.invid) {
						var invdata = {
							"inventoryType": "DEBRIEF_INV_ADJUSTMENT",
							"invpool": "customer",
							"inv_aid": receivedData.activity.aid,
							"quantity": 0,
							"I_ITEM_NUMBER": partData.I_ITEM_NUMBER,
							"I_ITEM_DESCRIPTION": partData.I_ITEM_DESCRIPTION,
							"I_DEBRIEF_ADJ_QUANTITY": partData.I_DEBRIEF_ADJ_QUANTITY + '',
							"I_SUBINVENTORY": partData.I_SUBINVENTORY
						}
						$.ajax({
							url: inventoryUrlAddPart,
							timeout: 20000,
							cache: false,
							method: 'POST',
							dataType: 'json',
							contentType: 'application/json; charset=utf-8',
							data: JSON.stringify(invdata),
							headers: {
								'accept': 'application/json',
								'Authorization':
									'Basic ' + window.btoa(receivedData.securedData.clientId + "@" + domainName + ":" + receivedData.securedData.clientSecret)
							},
							success: function(successData) {
								console.log("Inventory created for added part- Success messagae: " + JSON.stringify(successData));
							},
							error: function(errorData) {
								alert("There is some issue while creating Inventory for added part!!");
								console.log("Update Resource properties for added part - Error messagae:" + JSON.stringify(errorData));
								throw new Error("There is some issue while creating Inventory for added part");
							}
						});
					}
				});

				$.each(partsData, function(key1, partData) {
					var debAdjQuantity = partData.I_DEBRIEF_ADJ_QUANTITY;
					if (debAdjQuantity != null) {
						var sc = {
							"suspendActivityflag": true
						};
						suspendActivityflagArr.push(sc);
					} else {
						var sc = {
							"suspendActivityflag": false
						};
						suspendActivityflagArr.push(sc);
					}
				});
				$.each(suspendActivityflagArr, function(key1, partData) {
					if (partData.suspendActivityflag) {
						susActflag = true;
					}
				});
				var debAdjQuantity;
				var InventoryListJSON = {};
				if (partsData.length > 0) {
					try {
						$.each(partsData, function(key1, partData) {
							if (partData.invid) {
								debAdjQuantity = partData.I_DEBRIEF_ADJ_QUANTITY;
								//		debAdjQuantity = $("#partAdjQtyReviewVal" + key1).val();
								$.extend(InventoryListJSON, {
									[partData.invid]: {
										"invid": partData.invid,
										"inv_aid": receivedData.activity.aid,
										"I_ITEM_NUMBER": partData.I_ITEM_NUMBER,
										"I_ITEM_DESCRIPTION": partData.I_ITEM_DESCRIPTION,
										"invtype": partData.invtype,
										"I_INVENTORY_KEY": partData.I_INVENTORY_KEY,
										"I_DEBRIEF_ADJ_QUANTITY": debAdjQuantity
									}
								});
							}
						});
						if (susActflag) {
							var activitySuspendUrl = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/activities/" + receivedData.activity.aid + "/custom-actions/suspend";
							var activityMoveUrl = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/activities/" + receivedData.activity.aid + "/custom-actions/move";
							var activitySuspendPayload = {
								"A_DA_ACTIVITY_STATUS": daas
							};
							ultimateBind._sendPostMessageData({
								"apiVersion": 1,
								"method": "update",
								"backScreen": "default",
								"inventoryList": InventoryListJSON,
								"activity": {
									"aid": receivedData.activity.aid,
									"A_DA_ACTIVITY_STATUS": daas,
								}
							});
							$.ajax({
								url: activitySuspendUrl,
								timeout: 20000,
								cache: false,
								method: 'POST',
								dataType: 'json',
								contentType: 'application/json; charset=utf-8',
								headers: {
									'accept': 'application/json',
									'Authorization':
										'Basic ' + window.btoa(receivedData.securedData.clientId + "@" + domainName + ":" + receivedData.securedData.clientSecret)
								},
								success: function(successData) {
									console.log("Activity Suspended - Success messagae: " + JSON.stringify(successData));
									$.ajax({
										url: activityMoveUrl,
										timeout: 20000,
										//	cache: false,
										method: 'POST',
										dataType: 'json',
										contentType: 'application/json; charset=utf-8',
										data: JSON.stringify({
											'setDate': {
												'date': null
											}
										}),
										headers: {
											'accept': 'application/json',
											'Authorization':
												'Basic ' + window.btoa(receivedData.securedData.clientId + "@" + domainName + ":" + receivedData.securedData.clientSecret)
										},
										success: function(successData) {
											console.log("Activity Move - Success messagae: ");
											ultimateBind._sendPostMessageData({
												"apiVersion": 1,
												"method": "close",
												"backScreen": "default"
											});
										},
										error: function(errorData) {
											alert("There is some issue!!");
											console.log("Activity Move Update Resource properties - Error messagae:" + JSON.stringify(errorData));
										}
									});
								},
								error: function(errorData) {
									alert("There is some issue!!");
									console.log("Activity Suspend Update Resource properties - Error messagae:" + JSON.stringify(errorData));
								}
							});
						} else {
							alert("Please enter quantity.");
						}
					} catch (err) {
						var now = new Date(Date.now());
						if (errorLogs == null) {
							errorLogs = "";
						}
						errorLogs = errorLogs + "||" + now.toString() + "|Plugin :Debrief Adjustment :Exception " + err.message;
						$.ErrorUpdate(receivedData.activity.aid, errorLogs);
					}
				} else {
					alert("Don't get any part details!!!!");
				}

			}

			function redirectionToPartFunctionality() {
				stage = 2;
				$('#stageDiv2').show();
				$('#stageDiv3').hide();
				$('#stageDiv1').hide();
				$('#stageDiv4').hide();
				$('#visitList4').empty();
			}

			$.ErrorUpdate = function(activityId, sErrorLogs) {

				this._sendPostMessageData({
					"apiVersion": 1,
					"method": "update",
					"activity": {
						"A_PLUGIN_ERROR_LOG": sErrorLogs,
						"aid": activityId
					}

				});
			}.bind(this);

			var resourceNumber = receivedData.resource.R_EMPLOYEE_NUMBER;
			var rid = receivedData.resource.external_id;
			var domainName = this._getDomainURL();
			var clientId = receivedData.securedData.clientId;
			var clientSecret = receivedData.securedData.clientSecret;
			var company = receivedData.securedData.company;
			var uName = clientId + "@" + domainName;
			var passwrd = clientSecret;

			var headers = {
				'accept': 'application/json',
				'Authorization':
					'Basic ' + window.btoa(receivedData.securedData.clientId + "@" + domainName + ":" + receivedData.securedData.clientSecret)
			};
			var activityCreationUrl = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/activities";
			var stage;
			var firstStage = 1;
			var secondStage = receivedData.openParams.stage;
			var thirdStage = receivedData.openParams.managerStage;
			var forthStage = receivedData.openParams.reviewStage;

			if (thirdStage != null && thirdStage == 3) {
				stage = 3;
				$('#stageDiv3').show();
				$('#stageDiv2').hide();
				$('#stageDiv1').hide();
				$('#stageDiv4').hide();
				$('#stageDiv5').hide();
			} else if (secondStage != null && secondStage == 2) {
				stage = 2;
				$('#stageDiv2').show();
				$('#stageDiv3').hide();
				$('#stageDiv1').hide();
				$('#stageDiv4').hide();
				$('#stageDiv5').hide();
			} else if (firstStage != null && firstStage == 1) {
				stage = 1;
				$('#stageDiv1').show();
				$('#stageDiv2').hide();
				$('#stageDiv3').hide();
				$('#stageDiv4').hide();
				$('#stageDiv5').hide();
			}

			if (stage != null && stage == 3) {
				$('#stageDiv3').show();
				$('#stageDiv2').hide();
				$('#stageDiv1').hide();
				$('#stageDiv4').hide();
				$('#stageDiv5').hide();
				managerFunctionality();
			} else if (stage != null && stage == 2) {
				$('#stageDiv2').show();
				$('#stageDiv3').hide();
				$('#stageDiv1').hide();
				$('#stageDiv4').hide();
				$('#stageDiv5').hide();
				partFunctionality();
			} else if (stage != null && stage == 1) {
				$('#stageDiv1').show();
				$('#stageDiv2').hide();
				$('#stageDiv3').hide();
				$('#stageDiv4').hide();
				$('#stageDiv5').hide();
				visitFunctionality();
			}
			$.dateFormatter = function(visitDate) {
				var visDate = new Date(visitDate);
				var day = ("0" + visDate.getDate()).slice(-2);
				var month = ("0" + (visDate.getMonth() + 1)).slice(-2);
				var vist_date_DD_MM_YYYY = day + "-" + month + "-" + visDate.getFullYear().toString();
				return vist_date_DD_MM_YYYY;
			};

			function visitFunctionality() {

				var searchFieldCount = 5;
				if (!$.trim($('#cpf_SerachRequestField').html()).length) {
					for (var i = 1; i <= searchFieldCount; i++) {
						//Create the label element
						var Bannerlabel = $("<label>").text('Must be Online').addClass('bannerLabel');
						var lebelDiv = $('<div/>').addClass('cp_field_value');
						lebelDiv.append(Bannerlabel);
						lebelDiv.append('<br\>');
						var container = $('<div />').attr("id", "searchFieldRow" + i);
						container.append(lebelDiv);
						container.addClass('cp_field_row');
						if (i != 1) {
							container.addClass('cp_hidden');
						}
						var searchField = $('<div/>').addClass('cp_field_value');

						searchField.append($('<input/>').attr({
							"id": "searchKeyword",
							"type": "search",
							"placeholder": "Search by keyword"
						}).addClass("cp_field_text_component form-item text-uppercase"));
						container.append(searchField);
						$('#cpf_SerachRequestField').append(container);
					}
				}
				$('#searchButton').click(function(event) {
					$("#searchButton").attr("disabled", true);
					if ($.trim($("#searchKeyword").val())) {
						$("#visitList").show();
						var taskNumber = $("#searchKeyword").val();
						var activitydata = {
							"taskNumber": taskNumber,
							"resourceNumber": resourceNumber,
							"activityType": "Debrief_Adjustment",
							"title": "New Debrief Adjustment Activity",
							"duration": 60,
							"language": "en",
							"languageISO": "en-US",
							"headers": headers,
							"activityCreationUrl": activityCreationUrl,
							"rid": rid,
							"inventoryType": "DEBRIEF_INV_ADJUSTMENT"
						};

						$("#visitList").empty();
						$("#waitingBox").empty();
						$("#waitingBox").removeClass("cp_hidden");
						$("#waitingBox").append("<span style='padding:10px;font-style: italic;'>Loading....</span>");
						$("#manualPartsAdditionSection").empty();
						$("#visitList").removeClass("cp_hidden");

						var oicApiUrl = receivedData.securedData.oicApiUrl;
						var oicAccessTokenUrl = receivedData.securedData.oicAccessTokenUrl;
						var oicClientId = receivedData.securedData.oicClientId;
						var oicClientSecret = receivedData.securedData.oicClientSecret;
						var oicScope = receivedData.securedData.oicScope;
						try {
							var clientID1 = '9c8d2cbea61c4585bd1a667120c9ff85';
							var clientSecret1 = '73d0bddb-0fb6-4127-a621-525c602b5bc7';
							$.ajax({
								type: 'POST',
								url: oicAccessTokenUrl,
								contentType: 'application/x-www-form-urlencoded; charset=utf-8',
								crossDomain: true,
								cache: true,
								dataType: 'json',
								data: {
									client_id: oicClientId,
									client_secret: oicClientSecret,
									grant_type: "client_credentials",
									scope: oicScope
								},
								success: function(data) {
									if (data.access_token != null) {
										var headers2 = {
											'accept': 'application/json',
											'Content-Type': "application/json",
											'Authorization': 'Bearer ' + data.access_token,
											'Access-Control-Allow-Origin': '*'
										};
										var taskData = {
											"task": taskNumber,
											"external_id": rid
										}
										$.ajax({
											url: oicApiUrl,
											method: 'POST',
											crossDomain: true,
											mode: 'cors',
											headers: headers2,
											data: JSON.stringify(taskData),
											success: function(successData) {
												$("#waitingBox").hide();
												$("#visitList").empty();
												$("#waitingBox").empty();
												console.log("successData on call to part catalog : " + JSON.stringify(successData));
												if (successData.status == 'S') {
													$("#searchButton").removeAttr("disabled");
													var sampleJsonPayload = successData.Visits;
													var container1 = $('<div />').attr("id", "manual-part-addition").addClass("cp_section manual-part-addition");
													if (Array.isArray(sampleJsonPayload) && sampleJsonPayload.length) {
														let succLength = sampleJsonPayload.length;
														var iii = 0;
														$.each(sampleJsonPayload, function(key, visitData) {
															var activityExits = false;
															var ts = visitData.task_number;
															var vd = visitData.visit_date;
															$.each(acttivityList, function(key1, al) {
																if (ts == al.appt_number && vd == al.A_FV_DATE) {
																	activityExits = true;
																}
															});

															var container2 = $('<div />').attr("id", "sub_con-" + key).addClass("adj_btn-" + key);
															iii++;
															var visitDateDiv = $('<div/>').addClass('Layoutflex-container');
															var custNameDiv = $('<div/>').addClass('Layoutflex-container');
															var partinfoDiv = $('<div/>');
															var partinfoDiv1 = $('<div/>').addClass('cp_text_block invitation-text pedDiv');
															var adjButtonDiv = $('<div/>').addClass('adjBtnDiv');

															var partinfoLbl = $("<label>").text('Part Information ').addClass('partnoInfo');
															if (Array.isArray(visitData.Parts) && visitData.Parts.length) {
																partinfoDiv.append(partinfoLbl);
															}

															var visitdatediv1 = $('<div/>').addClass('visitdatediv');
															var visitdateval = $('<div/>').addClass('visitDateValdiv');
															var visitdateval1 = $('<div/>').addClass('visitDateValdiv');

															var CustomerNamediv1 = $('<div/>').addClass('CustomerNamediv');
															var CustomerValvaldiv1 = $('<div/>').addClass('CustomerValvaldiv');

															var TaskNodiv1 = $('<div/>').addClass('visitdatediv');
															var TaskNovaldiv1 = $('<div/>').addClass('visitDateValdiv');

															var visDate = new Date(visitData.visit_date);
															var day = ("0" + visDate.getDate()).slice(-2);
															var month = ("0" + (visDate.getMonth() + 1)).slice(-2);
															var vist_date_DD_MM_YYYY = month + "/" + day + "/" + visDate.getFullYear().toString();

															visitdatediv1.append('Visit Date : ');
															if (visitData.visit_date != null && visitData.visit_date != "") {
																visitdateval.append(vist_date_DD_MM_YYYY);
															} else {
																visitdateval.append("N/A");
															}
															visitdateval1.append(visitData.visit_date);
															CustomerNamediv1.append('Customer Name : ');
															CustomerValvaldiv1.append(visitData.customer_name);

															var adjButton = $('<button/>', {
																text: "Create Adjustment Activity", //set text 1 to 10
																id: 'saveAjd-' + key,
																click: function() { saveAdjustment(visitData, activitydata); }

															}).addClass("cp_plugin_button custom-btn custom-btn-primary adj_btn");

															var hr = $('<hr>');
															let iterations = 1111;
															if (Array.isArray(visitData.Parts) && visitData.Parts.length) {
																iterations = visitData.Parts.length;
															}

															var ii = 0;

															$.each(visitData.Parts, function(key1, partsData) {
																ii++;
																var partNumDiv = $('<div/>').addClass('flex-container');
																var partDescDiv = $('<div/>').addClass('flex-container');
																var partQuaDiv = $('<div/>').addClass('flex-container');
																var hr1 = $('<hr>').addClass('hr-line');

																var partnodiv1 = $('<div/>').addClass('partnodiv');
																var partnovaldiv1 = $('<div/>').addClass('partnoValdiv');

																partnodiv1.append('Part No: ');
																partnovaldiv1.append(partsData.part_number);

																var partdescdiv = $('<div/>').addClass('partnodiv');
																var partdescval = $('<div/>').addClass('partnoValdiv');

																partdescdiv.append('Part Description: ');
																partdescval.append(partsData.part_description);
																var PartQtylblDiv = $('<div/>').addClass('partnodiv');
																var PartQtyvalueDiv = $('<div/>').addClass('partnoValdiv');
																PartQtylblDiv.append('Quantity: ');

																PartQtyvalueDiv.append(partsData.part_quantity);
																partNumDiv.append(partnodiv1);
																partNumDiv.append(partnovaldiv1);
																partDescDiv.append(partdescdiv);
																partDescDiv.append(partdescval);
																partQuaDiv.append(PartQtylblDiv);
																partQuaDiv.append(PartQtyvalueDiv);

																partNumDiv.appendTo(partinfoDiv1);
																partDescDiv.appendTo(partinfoDiv1);
																partQuaDiv.appendTo(partinfoDiv1);
																if (iterations != ii) {
																	partinfoDiv1.append(hr1);
																}
															});

															partinfoDiv1.append(adjButtonDiv);
															partinfoDiv.append(partinfoDiv1);

															if (!activityExits) {
																adjButtonDiv.append(adjButton);
															}

															if (!activityExits) {
																partinfoDiv1.append(adjButtonDiv);
															} else {
																partinfoDiv1.append("Activity already got created for this visit.");
															}

															visitDateDiv.append(visitdatediv1);
															visitDateDiv.append(visitdateval);

															custNameDiv.append(CustomerNamediv1);
															custNameDiv.append(CustomerValvaldiv1);

															container2.append(visitDateDiv);
															container2.append(custNameDiv);
															container2.append(partinfoDiv);

															container1.append(container2);
															if (succLength != iii) {
																container2.append(hr);
															}
														});
													} else {
														container1.append("No Record Found").css("color", "red");
													}
													$("#visitList").append(container1);
												} else if (successData.status == 'E') {
													alert(successData.status_msg);
													$("#waitingBox").hide();
													$("#searchButton").removeAttr("disabled");
												} else if (successData.status == 'INVAID-RES') {
													$("#waitingBox").hide();
													$("#searchButton").removeAttr("disabled");
												} else if (successData.status == 'INVAID-TASK') {
													alert(successData.status_msg);
													$("#waitingBox").hide();
													$("#searchButton").removeAttr("disabled");
												} else {
													alert(successData.status_msg);
													$("#waitingBox").hide();
													$("#searchButton").removeAttr("disabled");
												}

											},
											error: function(xhr, textStatus, errorThrown) {
												alert("Some Server Issue.");
												$("#waitingBox").hide();
												$("#searchButton").removeAttr("disabled");
												console.log("Error on call to part catalog : " + JSON.stringify(xhr));
												var now = new Date(Date.now());
												if (errorLogs == null) {
													errorLogs = "";
												}
												errorLogs = errorLogs + "||" + now.toString() + "|Plugin :Error on call to part catalog :Exception " + JSON.stringify(xhr);
												$.ErrorUpdate(activityId, errorLogs);
											}
										});
									} else {
										alert("not able to get access token.");
										console.log(" Access Token not found. ");
									}

								},
								error: function(xhr, textStatus, errorThrown) {
									alert("Some Server Issue to get Access Token.");
									$("#waitingBox").hide();
									console.log("Error on getting Access Token : " + JSON.stringify(xhr));
									var now = new Date(Date.now());
									if (errorLogs == null) {
										errorLogs = "";
									}
									errorLogs = errorLogs + "||" + now.toString() + "|Plugin :Error on getting Access Token :Exception " + JSON.stringify(xhr);
									$.ErrorUpdate(activityId, errorLogs);
								}
							});
						} catch (err) {
							var now = new Date(Date.now());
							if (errorLogs == null) {
								errorLogs = "";
							}
							errorLogs = errorLogs + "||" + now.toString() + "|Plugin :Debrief Adjustment OIC Call New API:Exception " + err.message;
							$.ErrorUpdate(activityId, errorLogs);
						}
					} else {
						alert("please enter some value");
					}
				}.bind(this));

			}

			function partFunctionality() {

				var debAdjPartDetailListDebValidation1 = [];
				var inventoryListDebValidation1 = [];
				inventoryListDebValidation1 = receivedData.inventoryList;
				var isPartExistsInProvidePool = 0;
				$.each(inventoryListDebValidation1, function(key, invItem) {
					if (invItem.invpool == "provider") {
						debAdjPartDetailListDebValidation1.push(invItem);
						isPartExistsInProvidePool = 1;
					}
				});
				$.each(debAdjPartDetailList, function(key4, invItem4) {
					if (isPartExistsInProvidePool) {

						if (debAdjPartDetailListDebValidation1.length > 0) {
							$.each(debAdjPartDetailListDebValidation1, function(key5, invItem5) {

								if (invItem4.I_ITEM_NUMBER == invItem5.I_ITEM_NUMBER && (invItem4.I_SUBINVENTORY == invItem5.I_SUBINVENTORY || invItem4.I_SUBINVENTORY == invItem5.I_SUBINVENTORY_NAME)) {
									$.extend(debAdjPartDetailList[key4], { I_ONHAND_QUANTITY: invItem5.quantity });
								}

							});

						}
					} else {
						// need to search in shared sub inv
					}

				});

				$('#searchPart').hide();
				localStorage.removeItem('NewAddedPartArray1');
				localStorage.clear();

				if (localStorage.getItem("NewAddedPartArray1") !== null) {
					var storedData = JSON.parse(localStorage.NewAddedPartArray1);
					//	console.log(storedData);
				}
				if (storedData) {
					debAdjPartDetailList = storedData;
				}
				else {
					debAdjPartDetailList = debAdjPartDetailList;
				}
				var searchFieldCount = 5;
				if (!$.trim($('#cpf_SerachRequestField2').html()).length) {
					for (var i = 1; i <= searchFieldCount; i++) {
						var lebelDiv = $('<div/>').addClass('cp_field_value');
						var container = $('<div />').attr("id", "searchFieldRow" + i);
						container.append(lebelDiv);
						container.addClass('cp_field_row');
						if (i != 1) {
							container.addClass('cp_hidden');
						}
						var searchField = $('<div/>').addClass('cp_field_value');
						searchField.append($('<input/>').attr({
							"id": "searchKeyword",
							"type": "search",
							"placeholder": "Search by Part number"
						}).addClass("cp_field_text_component form-item text-uppercase"));
						container.append(searchField);
						$('#cpf_SerachRequestField2').append(container);
					}
				}
				var container1 = $('<div />').attr("id", "manual-part-addition2").addClass("cp_section manual-part-addition");
				let succLength = debAdjPartDetailList.length;
				var iii = 0;
				iii++;
				var partinfoDiv = $('<div/>');
				var partinfoDiv1 = $('<div/>').addClass('cp_text_block invitation-text pedDiv').attr("id", "partdetailsBeforeAdd");
				var adjButtonDiv = $('<div/>').addClass('adjBtnDiv1');

				var partinfoLbl = $("<label>").text('Part Information : ').addClass('refno').attr("id", "partdetailsAdd");
				partinfoDiv.append(partinfoLbl);
				var adjButton = $('<button/>', {
					text: "Review", //set text 1 to 10
					id: 'btn_rev',
					click: function() { ReviewFunctionality2(debAdjPartDetailAddList); }
				}).addClass("cp_plugin_button custom-btn custom-btn-primary").attr('disabled', true);
				adjButtonDiv.append(adjButton);
				var hr = $('<hr>');
				let iterations = debAdjPartDetailList.length;
				var ii = 0;
				if (debAdjPartDetailList.length > 0) {
					$.each(debAdjPartDetailList, function(key1, invItem1) {
						ii++;
						var partNumDiv = $('<div/>').addClass('flex-container');
						var partDescDiv = $('<div/>').addClass('flex-container');
						var partQuaDiv = $('<div/>').addClass('flex-container');
						var partnodiv1 = $('<div/>').addClass('ContainerDiv');
						var partnoval = $('<div/>').addClass('ContainerVal');
						var partDescdiv1 = $('<div/>').addClass('ContainerDiv');
						var partDescval = $('<div/>').addClass('ContainerVal');

						var additionalParSubInvDiv = $('<div/>').addClass('flex-container');
						var additionalParSubInvLbl = $('<div/>').addClass('ContainerDiv');
						var additionalParSubInvVal = $('<div/>').addClass('ContainerVal');

						var onHandQuantityDiv = $('<div/>').addClass('flex-container').attr("id", "onHandQuantityDiv");;
						var onHandQuantityLbl = $('<div/>').addClass('ContainerDiv');
						var onHandQuantityVal = $('<div/>').addClass('ContainerVal').attr("id", "onHandQuantityVal" + key1);

						var partQtydiv1 = $('<div/>').addClass('ContainerDiv');
						var partQtyval = $('<div/>').attr("id", "partQtyval" + key1).addClass('ContainerVal');

						partNumDiv.append(partnodiv1);
						partNumDiv.append(partnoval);
						partDescDiv.append(partDescdiv1);
						partDescDiv.append(partDescval);
						partQuaDiv.append(partQtydiv1);
						partQuaDiv.append(partQtyval);

						var SelectDiv1 = $('<div/>').addClass('flex-container');
						var QtyFieldDiv1 = $('<div/>').addClass('flex-container');
						var Selectlbl1 = $('<div/>').addClass('Selectlbl1');
						var QtyFieldlbl1 = $('<div/>').addClass('Selectlbl1');
						var selectboxdiv1 = $('<div/>').addClass('Selectdiv1');
						var plusdiv1 = $('<div/>').addClass('plusdiv1');
						var inputdiv1 = $('<div/>').addClass('inputdiv1');
						var minusdiv1 = $('<div/>').addClass('minusdiv1');
						var Qtydiv1 = $('<div/>').attr("id", "Qtydiv" + key1).addClass('Qtydiv1');


						SelectDiv1.append(Selectlbl1);
						SelectDiv1.append(minusdiv1);
						SelectDiv1.append(inputdiv1);
						SelectDiv1.append(plusdiv1);
						QtyFieldDiv1.append(QtyFieldlbl1);
						QtyFieldDiv1.append(Qtydiv1);

						var hr1 = $('<hr>').addClass('hr-line');

						partnodiv1.append('Part No: ');
						partnoval.append(invItem1.I_ITEM_NUMBER);

						partDescdiv1.append('Part Description: ');
						partDescval.append(invItem1.I_ITEM_DESCRIPTION);

						additionalParSubInvLbl.append('Sub Inventory');
						additionalParSubInvVal.append(invItem1.I_SUBINVENTORY);
						additionalParSubInvDiv.append(additionalParSubInvLbl);
						additionalParSubInvDiv.append(additionalParSubInvVal);
						onHandQuantityLbl.append('On Hand Quantity');
						onHandQuantityVal.append(invItem1.I_ONHAND_QUANTITY != null ? invItem1.I_ONHAND_QUANTITY : "0");
						onHandQuantityDiv.append(onHandQuantityLbl);
						onHandQuantityDiv.append(onHandQuantityVal);
						partQtydiv1.append('Original Quantity: ');
						partQtyval.append(invItem1.quantity);

						Selectlbl1.append('Adjust by: ');
						QtyFieldlbl1.append('Final Debrief Quantity: ');

						var plusButton = $('<button/>', {
							text: "+", //set text 1 to 10
							id: 'plus' + key1,
							click: function() { plusbtn(this.id, invItem1.I_ITEM_NUMBER, invItem1.I_SUBINVENTORY, 0, key1); }
						}).addClass("cp_plugin_button custom-btn custom-btn-plus");

						var minusButton = $('<button/>', {
							text: "-", //set text 1 to 10
							id: 'minus' + key1,
							click: function() { minusbtn(this.id, invItem1.I_ITEM_NUMBER); }
						}).addClass("cp_plugin_button custom-btn custom-btn-minus");

						var FinaldebriefQty = $('<input/>', {
							value: "0",
							type: "text",
							id: 'debAdjQuantity' + key1,
							keyup: function() { keyup(this.id, invItem1.I_ITEM_NUMBER, invItem1.I_SUBINVENTORY, 0); }
						}).addClass("bin-qty form-item dev_adj_ip_field");

						minusdiv1.append(minusButton);
						inputdiv1.append(FinaldebriefQty);
						plusdiv1.append(plusButton);

						partNumDiv.appendTo(partinfoDiv1);
						partDescDiv.appendTo(partinfoDiv1);
						additionalParSubInvDiv.appendTo(partinfoDiv1);
						onHandQuantityDiv.appendTo(partinfoDiv1);
						partQuaDiv.appendTo(partinfoDiv1);
						SelectDiv1.appendTo(partinfoDiv1);
						QtyFieldDiv1.appendTo(partinfoDiv1);
						partinfoDiv1.append(hr1);
						partinfoDiv1.append(adjButtonDiv); // demo changes location of button
						partinfoDiv.append(partinfoDiv1);
					});
				} else {
					partinfoDiv.append("No Record Found").css("color", "red");
				}
				container1.append(partinfoDiv);
				container1.append();
				$("#visitList2").append(container1);
				if (
					typeof inventoryList === 'object' &&
					!Array.isArray(inventoryList) &&
					inventoryList !== null
				) {
					$('#searchButton2').click(function(event) {
						$("#searchPart").show();
						var PartNumber = $("#searchKeyword").val();
						$("#waitingBox1").removeClass("cp_hidden");
						$("#waitingBox1").append("<span style='padding:10px;font-style: italic;'>Loading....</span>");
						$("#manualPartsAdditionSection").empty();
						$("#visitList").removeClass("cp_hidden");
						var searchKeywordOrig = "";
						if ($.trim($('#searchKeyword').val())) {
							if (searchKeywordOrig != null && searchKeywordOrig != "") {
								searchKeywordOrig = searchKeywordOrig + "," + $.trim($('#searchKeyword').val());
								//alert(searchKeywordOrig);
							} else {
								searchKeywordOrig = $.trim($('#searchKeyword').val());
							}
						}
						if (searchKeywordOrig == "" || typeof searchKeywordOrig === undefined || searchKeywordOrig == null) {
							alert("Please enter a search term.");
							return false;
						} else if (searchKeywordOrig.length < 3) {
							alert("Please enter a search term more than 3 characters");
							return false;
						}
						var searchedParts = searchKeywordOrig.toUpperCase();	// CHG0078235 - Change

						var searchArray = [];
						if (searchKeywordOrig.indexOf(',') != -1) {
							searchArray = searchKeywordOrig.split(',');
						}
						searchKeywordOrig = searchKeywordOrig.toUpperCase();
						$("#waitingBox1").hide();
						$.generateCallId = function() {
							return btoa(String.fromCharCode.apply(null, window.crypto.getRandomValues(new Uint8Array(16))));
						},
							console.log("Parts Catalog call started");
						var partssearchcallID = "";
						var uniquecallid = $.generateCallId();
						partssearchcallID = uniquecallid;
						var jsonSearchToSend = {
							"apiVersion": 1,
							"method": "callProcedure",
							"callId": uniquecallid,
							"procedure": "searchParts",
							"params": {
								"limit": 100,
								"query": searchKeywordOrig,
								"cacheOnly": false
							}
						}
						console.log("Parts Catalog search call:" + jsonSearchToSend);
						ultimateBind._sendPostMessageData(jsonSearchToSend);
					});
				}

				var subInventoryList = [];
				var subInventoryOwner = [];
				if (receivedData.resource.R_SUBINVENTORY_LIST != null)
					subInventoryList = receivedData.resource.R_SUBINVENTORY_LIST.split(",");
				if (receivedData.resource.R_SUBINVENTORY_OWNER != null)
					subInventoryOwner = receivedData.resource.R_SUBINVENTORY_OWNER.split(",");
				var resourceId = receivedData.resource.external_id;

				var primaryOwnedSubInventories = {};
				var sharedSubInventories = {};
				primaryOwnedSubInventories["Primary Sub-Inventory"] = resourceId;
				for (var i = 0; i < subInventoryOwner.length; i++) {
					if (subInventoryOwner[i] == resourceId) {
						primaryOwnedSubInventories[subInventoryList[i]] = subInventoryOwner[i];
					} else {
						sharedSubInventories[subInventoryList[i]] = subInventoryOwner[i];
					}
				}
				$.each(sharedSubInventories, function(key, value) {
					resourceInventory1(value, 0);
				});
			}

			function resourceInventory1(subInventoryOwner, offSet) {
				var totalResults = 0;
				var rInventoryURL = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/resources/" + subInventoryOwner + "/inventories?offset=" + offSet + "&limit=100";
				$.ajax({
					url: rInventoryURL,
					method: 'GET',
					dataType: 'json',
					processData: false,
					contentType: 'application/json; charset=utf-8',
					headers: headers,
					//async: false,
					crossDomain: true,
					timeout: 8000,
					success: function(successData) {
						totalResults = successData.totalResults;
						if (successData.items.length > 0) {
							$.each(successData.items, function(key1, partData) {
								sharedSuvInvInventoryListJSON.push({
									"invpool": partData.invpool,
									"invtype": partData.inventoryType,
									"I_ITEM_NUMBER": partData.I_ITEM_NUMBER,
									"I_INVENTORY_KEY": partData.I_INVENTORY_KEY,
									"I_SUBINVENTORY_NAME": partData.I_SUBINVENTORY_NAME,
									"I_DEBRIEF_ADJ_QUANTITY": null,
									"I_TASK_NUMBER": null,
									"I_DEBRIEF_ADJ_APPROVE": null,
									"I_DEBRIEF_ADJ_REJECT": null,
									"I_ITEM_COST": null,
									"I_ITEM_CHARGE_AMOUNT": null,
									"invid": partData.inventoryId,
									"inv_aid": null,
									"I_ITEM_DESCRIPTION": partData.I_ITEM_DESCRIPTION,
									"quantity": partData.quantity,
									"I_SUBINVENTORY": partData.I_SUBINVENTORY
								});
							});
							$.each(sharedSuvInvInventoryListJSON, function(key1, partData) {
								debAdjPartDetailListDebValidation4.push(partData);
							});
						}
						offSet = offSet + 100;
						if (totalResults > offSet) {
							resourceInventory1(subInventoryOwner, offSet);
						}
					},
					error: function(errorData) {
						console.log(errorData);
					}
				});
			}

			function managerFunctionality() {

				var activityId = receivedData.activity != null ? receivedData.activity.aid : 'null';
				var customerName = receivedData.activity != null ? receivedData.activity.Customer_Name : 'null';
				var visitDate = receivedData.activity != null ? receivedData.activity.A_FV_DATE : 'null';
				var taskNumber = receivedData.activity != null ? receivedData.activity.appt_number : 'null';
				var debAdjVistPartDetailManagerList = [];
				var inventoryList = receivedData.inventoryList;
				var invActivityId;
				$.each(inventoryList, function(key, invItem) {
					invActivityId = invItem.inv_aid;
					if (invItem.inv_aid == activityId) {
						if (invItem.invpool == "customer") {
							if (invItem.invtype == "DEBRIEF_INV_ADJUSTMENT") {
								debAdjVistPartDetailManagerList.push(invItem);
							}
						}
					}
				});
				if (debAdjVistPartDetailManagerList.length > 0) {
					var managerActflag = false;
					var managerActivityflagArr = [];
					$.each(debAdjVistPartDetailManagerList, function(key1, partData) {
						var debAdjQuantity = partData.I_DEBRIEF_ADJ_QUANTITY;
						if (debAdjQuantity != null) {
							var sc = {
								"managerActivityflag": true
							};
							managerActivityflagArr.push(sc);
						} else {
							var sc = {
								"managerActivityflag": false
							};
							managerActivityflagArr.push(sc);
						}

					});

					$.each(managerActivityflagArr, function(key1, partData) {
						if (partData.managerActivityflag) {
							managerActflag = true;
						}
					});
					var container1 = $('<div />').attr("id", "manual-part-addition3").addClass("cp_section manual-part-addition");
					if (managerActflag) {
						var container2 = $('<div />').attr("id", "manual-part-addition3").addClass("");
						var adjButtonDiv1 = $('<div/>').addClass('');
						var adjButton = $('<button/>', {
							text: "Approve All", //set text 1 to 10
							id: 'SuccessfulSubmitbtn',
							click: function() { managerReviewFunctionaltySubmit(debAdjVistPartDetailManagerList, 2); }
						}).addClass(" custom-btn custom-btn-primary4 btn-apprej");
						adjButtonDiv1.append(adjButton);

						var adjButton = $('<button/>', {
							text: "Reject All", //set text 1 to 10
							id: 'SuccessfulSubmitbtn',
							click: function() { managerReviewFunctionaltySubmit(debAdjVistPartDetailManagerList, 3); }
						}).addClass("custom-btn custom-btn-primary4");
						adjButtonDiv1.append(adjButton);
						container2.append(adjButtonDiv1);
						$("#cpf__unnamed_23").append(container2);
						let succLength = debAdjVistPartDetailManagerList.length;
						var visitdateDiv = $('<div/>').addClass('flex-container');
						var visitDateDiv = $('<div/>').addClass('Layoutflex-container');
						var custNameDiv = $('<div/>').addClass('Layoutflex-container');
						var TasknoDiv = $('<div/>').addClass('Layoutflex-container');
						var partinfoDiv = $('<div/>');
						var partinfoDiv1 = $('<div/>').addClass('cp_text_block invitation-text pedDiv');
						var adjButtonDiv = $('<div/>').addClass('adjBtnDiv');
						if (visitDate != null && visitDate != "") {
							var visManScDate = new Date(visitDate);
							var day = ("0" + visManScDate.getDate()).slice(-2);
							var month = ("0" + (visManScDate.getMonth() + 1)).slice(-2);
							var vist_date_DD_MM_YYYY = month + "/" + day + "/" + visManScDate.getFullYear().toString();
						} else {
							var vist_date_DD_MM_YYYY = "N/A";
						}
						var visitdatediv1 = $('<div/>').addClass('visitdatediv1');
						var visitdateval = $('<div/>').addClass('visitDateValdiv1');

						var CustomerNamediv1 = $('<div/>').addClass('CustomerNamediv1');
						var CustomerValvaldiv1 = $('<div/>').addClass('CustomerValvaldiv1');

						var TaskNodiv1 = $('<div/>').addClass('visitdatediv1');
						var TaskNovaldiv1 = $('<div/>').addClass('visitDateValdiv1');

						visitdatediv1.append('Visit Date : ');
						visitdateval.append(vist_date_DD_MM_YYYY);

						CustomerNamediv1.append('Customer Name : ');
						CustomerValvaldiv1.append(customerName);

						TaskNodiv1.append('Task No : ');
						TaskNovaldiv1.append(taskNumber);

						var partinfoLbl = $("<label>").text('Part Information : ').addClass('refno');
						partinfoDiv.append(partinfoLbl);

						var hr = $('<hr>');

						let iterations = debAdjVistPartDetailManagerList.length;
						var ii = 0;
						$.each(debAdjVistPartDetailManagerList, function(key1, invItem1) {
							ii++;
							var partNumDiv = $('<div/>').addClass('flex-container');
							var partQtyDiv = $('<div/>').addClass('flex-container');
							var partAmountDiv = $('<div/>').addClass('flex-container');
							var partBriefQtyDiv = $('<div/>').addClass('flex-container');

							var partnodiv1 = $('<div/>').addClass('partnodiv1');
							var partnovaldiv1 = $('<div/>').addClass('partnoValdiv1');

							var SubInventorydiv1 = $('<div/>').addClass('SubInventorydiv1');
							var SubInventoryvaldiv1 = $('<div/>').addClass('SubInventoryValdiv1');

							var QtyDiv = $('<div/>').addClass('partnodiv1');
							var QtyValDiv = $('<div/>').addClass('partnoValdiv1');

							var AdjustmentDiv = $('<div/>').addClass('SubInventorydiv1');
							var AdjustmentValDiv = $('<div/>').addClass('SubInventoryValdiv1');

							var ChargeAmountDiv = $('<div/>').addClass('partnodiv1');
							var ChargeAmountValDiv = $('<div/>').addClass('partnoValdiv1');

							var FinalBriefQtyDiv = $('<div/>').addClass('SubInventorydiv1');
							var FinalBriefQtyValDiv = $('<div/>').addClass('SubInventoryValdiv1');

							var partQtydiv1 = $('<div/>').addClass('ContainerDiv');
							var partQtyval = $('<div/>').addClass('ContainerVal');

							var SelectDiv1 = $('<div/>').addClass('flex-container');
							var Selectlbl1 = $('<div/>').addClass('Selectlbl3');
							var selectboxdiv1 = $('<div/>').addClass('Selectdiv3');

							SelectDiv1.append(Selectlbl1);
							SelectDiv1.append(selectboxdiv1);

							var hr1 = $('<hr>').addClass('hr-line');

							partnodiv1.append('Part No: ');
							partnovaldiv1.append(invItem1.I_ITEM_NUMBER);

							SubInventorydiv1.append('Sub Inventory: ');
							SubInventoryvaldiv1.append(invItem1.I_SUBINVENTORY);
							if (invItem1.quantity == null) {
								var qty = 0;
							}
							else {
								var qty = invItem1.quantity;

							}
							QtyDiv.append('Original Quantity: ');
							QtyValDiv.append(qty);

							AdjustmentDiv.append('Adjustment Quantity: ');
							AdjustmentValDiv.append(invItem1.I_DEBRIEF_ADJ_QUANTITY);

							ChargeAmountDiv.append('Charge Amount: ');
							ChargeAmountValDiv.append(invItem1.I_ITEM_CHARGE_AMOUNT);

							FinalBriefQtyDiv.append('Final Debrief Quantity: ');
							FinalBriefQtyValDiv.append(parseInt(qty) + parseInt(invItem1.I_DEBRIEF_ADJ_QUANTITY));

							Selectlbl1.append('Status : ');

							var myOptions = {
								approved: 'Approve',
								rejected: 'Reject'
							};
							var selectval = $('<select>');
							selectval.attr("id", "managerApproval" + key1);
							selectval.addClass("form-item");
							$.each(myOptions, function(val, text) {
								selectval.append(
									$('<option></option>').val(val).html(text)
								);
							});
							selectboxdiv1.append(selectval);

							visitDateDiv.append(visitdatediv1);
							visitDateDiv.append(visitdateval);
							custNameDiv.append(CustomerNamediv1);
							custNameDiv.append(CustomerValvaldiv1);
							TasknoDiv.append(TaskNodiv1);
							TasknoDiv.append(TaskNovaldiv1);
							partNumDiv.append(partnodiv1);
							partNumDiv.append(partnovaldiv1);
							partNumDiv.append(SubInventorydiv1);
							partNumDiv.append(SubInventoryvaldiv1);
							partQtyDiv.append(QtyDiv);
							partQtyDiv.append(QtyValDiv);
							partQtyDiv.append(AdjustmentDiv);
							partQtyDiv.append(AdjustmentValDiv);
							partAmountDiv.append(ChargeAmountDiv);
							partAmountDiv.append(ChargeAmountValDiv);
							partAmountDiv.append(FinalBriefQtyDiv);
							partAmountDiv.append(FinalBriefQtyValDiv);
							partNumDiv.appendTo(partinfoDiv1);
							partQtyDiv.appendTo(partinfoDiv1);
							partAmountDiv.appendTo(partinfoDiv1);
							partBriefQtyDiv.appendTo(partinfoDiv1);
							SelectDiv1.appendTo(partinfoDiv1);
							if (iterations != ii) {
								partinfoDiv1.append(hr1);
							}
							partinfoDiv.append(partinfoDiv1);
						});
						container1.append(visitDateDiv);
						container1.append(custNameDiv);
						container1.append(TasknoDiv);
						container1.append(partinfoDiv);
						container1.append();
						$("#visitList3").append(container1);
						var adjButtonDiv = $('<div/>').addClass('adjBtnDiv3');
						var NoteDiv = $('<div/>').addClass('flex-container');
						var Notelbl1 = $('<div/>').addClass('Notelbl1');
						var NoteValdiv = $('<div/>').addClass('NoteValdiv');
						NoteDiv.append(Notelbl1);
						NoteDiv.append(NoteValdiv);
						Notelbl1.append('Note : ').addClass('Notelbl');
						NoteValdiv.append('Manager responsible to determine if manual billing required');
						var adjButton = $('<button/>', {
							text: "Review", //set text 1 to 10
							id: 'btn_submit',
							click: function() { managerReviewFunctionaltySubmit(debAdjVistPartDetailManagerList, 1); }
						}).addClass("cp_plugin_button custom-btn custom-btn-primary3");
						adjButtonDiv.append(adjButton);
						$("#PartInfoFooter").append(NoteDiv);
						$("#PartInfoFooter").append(adjButtonDiv);
						$('#SuccessfulSubmitbtn').click(function(event) {
							$("#SuccessfulSubmit").empty();
							$("#SuccessfulSubmit").append('Submit Successful. Please click "Close X" button to close this window');
						});
					} else {
						$("#visitList3").append("Invalid Request").css("color", "red");
					}
				} else {
					alert("No Record Found");
				}
			}

			function managerReviewFunctionaltySubmit(debAdjVistPartDetailManagerList, submitCondition) {
				var customerName = receivedData.activity != null ? receivedData.activity.Customer_Name : 'null';
				var visitDate = receivedData.activity != null ? receivedData.activity.A_FV_DATE : 'null';
				var taskNumber = receivedData.activity != null ? receivedData.activity.appt_number : 'null';
				$('#stageDiv5').show();
				$('#stageDiv4').hide();
				$('#stageDiv3').hide();
				$('#stageDiv2').hide();
				$('#stageDiv1').hide();
				var managerReviewedValue = "";
				if (debAdjVistPartDetailManagerList.length > 0) {
					var managerActflag = false;
					var managerActivityflagArr = [];
					$.each(debAdjVistPartDetailManagerList, function(key1, partData) {
						var debAdjQuantity = partData.I_DEBRIEF_ADJ_QUANTITY;
						if (debAdjQuantity != null) {
							var sc = {
								"managerActivityflag": true
							};
							managerActivityflagArr.push(sc);
						} else {
							var sc = {
								"managerActivityflag": false
							};
							managerActivityflagArr.push(sc);
						}
					});
					$.each(managerActivityflagArr, function(key1, partData) {
						if (partData.managerActivityflag) {
							managerActflag = true;
						}
					});
					var container1 = $('<div />').attr("id", "manual-part-addition5").addClass("cp_section manual-part-addition");
					if (managerActflag) {
						let succLength = debAdjVistPartDetailManagerList.length;
						var visitdateDiv = $('<div/>').addClass('flex-container');
						var visitDateDiv = $('<div/>').addClass('Layoutflex-container');
						var custNameDiv = $('<div/>').addClass('Layoutflex-container');
						var TasknoDiv = $('<div/>').addClass('Layoutflex-container');
						var partinfoDiv = $('<div/>');
						var partinfoDiv1 = $('<div/>').addClass('cp_text_block invitation-text pedDiv');
						var adjButtonDiv = $('<div/>').addClass('adjBtnDiv');
						if (visitDate != null && visitDate != "") {
							var visManScDate = new Date(visitDate);
							var day = ("0" + visManScDate.getDate()).slice(-2);
							var month = ("0" + (visManScDate.getMonth() + 1)).slice(-2);
							var vist_date_DD_MM_YYYY = month + "/" + day + "/" + visManScDate.getFullYear().toString();
						} else {
							var vist_date_DD_MM_YYYY = "N/A";
						}

						var visitdatediv1 = $('<div/>').addClass('visitdatediv1');
						var visitdateval = $('<div/>').addClass('visitDateValdiv1');

						var CustomerNamediv1 = $('<div/>').addClass('CustomerNamediv1');
						var CustomerValvaldiv1 = $('<div/>').addClass('CustomerValvaldiv1');

						var TaskNodiv1 = $('<div/>').addClass('visitdatediv1');
						var TaskNovaldiv1 = $('<div/>').addClass('visitDateValdiv1');

						visitdatediv1.append('Visit Date : ');
						visitdateval.append(vist_date_DD_MM_YYYY);

						CustomerNamediv1.append('Customer Name : ');
						CustomerValvaldiv1.append(customerName);

						TaskNodiv1.append('Task No : ');
						TaskNovaldiv1.append(taskNumber);

						var partinfoLbl = $("<label>").text('Part Information : ').addClass('refno');
						partinfoDiv.append(partinfoLbl);

						var hr = $('<hr>');

						let iterations = debAdjVistPartDetailManagerList.length;
						var ii = 0;
						$.each(debAdjVistPartDetailManagerList, function(key1, invItem1) {
							if (submitCondition == 1) {
								managerReviewedValue = $("#managerApproval" + key1).val();
							} else if (submitCondition == 2) {
								managerReviewedValue = "approved";
							} else if (submitCondition == 3) {
								managerReviewedValue = "rejected";
							}
							ii++;
							var partNumDiv = $('<div/>').addClass('flex-container');
							var partQtyDiv = $('<div/>').addClass('flex-container');
							var partAmountDiv = $('<div/>').addClass('flex-container');
							var partBriefQtyDiv = $('<div/>').addClass('flex-container');
							var partnodiv1 = $('<div/>').addClass('partnodiv1');

							var partnovaldiv1 = $('<div/>').addClass('partnoValdiv1');

							var SubInventorydiv1 = $('<div/>').addClass('SubInventorydiv1');
							var SubInventoryvaldiv1 = $('<div/>').addClass('SubInventoryValdiv1');

							var QtyDiv = $('<div/>').addClass('partnodiv1');
							var QtyValDiv = $('<div/>').addClass('partnoValdiv1');

							var AdjustmentDiv = $('<div/>').addClass('SubInventorydiv1');
							var AdjustmentValDiv = $('<div/>').addClass('SubInventoryValdiv1');

							var ChargeAmountDiv = $('<div/>').addClass('partnodiv1');
							var ChargeAmountValDiv = $('<div/>').addClass('partnoValdiv1');

							var FinalBriefQtyDiv = $('<div/>').addClass('SubInventorydiv1');
							var FinalBriefQtyValDiv = $('<div/>').addClass('SubInventoryValdiv1');

							var partQtydiv1 = $('<div/>').addClass('ContainerDiv');
							var partQtyval = $('<div/>').addClass('ContainerVal');

							var SelectDiv1 = $('<div/>').addClass('flex-container');
							var Selectlbl1 = $('<div/>').addClass('Selectlbl3');
							var selectboxdiv1 = $('<div/>').addClass('Selectdiv3');

							SelectDiv1.append(Selectlbl1);
							SelectDiv1.append(selectboxdiv1);

							var hr1 = $('<hr>').addClass('hr-line');

							partnodiv1.append('Part No: ');
							partnovaldiv1.append(invItem1.I_ITEM_NUMBER);

							SubInventorydiv1.append('Sub Inventory: ');
							SubInventoryvaldiv1.append(invItem1.I_SUBINVENTORY);

							if (invItem1.quantity == null) {
								var qty = 0;
							}
							else {
								var qty = invItem1.quantity;
							}
							QtyDiv.append('Original Quantity: ');
							QtyValDiv.append(qty);

							AdjustmentDiv.append('Adjustment Quantity: ');
							AdjustmentValDiv.append(invItem1.I_DEBRIEF_ADJ_QUANTITY);

							ChargeAmountDiv.append('Charge Amount: ');
							ChargeAmountValDiv.append(invItem1.I_ITEM_CHARGE_AMOUNT);

							FinalBriefQtyDiv.append('Final Debrief Quantity: ');
							FinalBriefQtyValDiv.append(parseInt(qty) + parseInt(invItem1.I_DEBRIEF_ADJ_QUANTITY));

							Selectlbl1.append('Status : ');
							var selectvalRev = managerReviewedValue;
							selectboxdiv1.append(selectvalRev);

							visitDateDiv.append(visitdatediv1);
							visitDateDiv.append(visitdateval);

							custNameDiv.append(CustomerNamediv1);
							custNameDiv.append(CustomerValvaldiv1);

							TasknoDiv.append(TaskNodiv1);
							TasknoDiv.append(TaskNovaldiv1);

							partNumDiv.append(partnodiv1);
							partNumDiv.append(partnovaldiv1);
							partNumDiv.append(SubInventorydiv1);
							partNumDiv.append(SubInventoryvaldiv1);
							partQtyDiv.append(QtyDiv);
							partQtyDiv.append(QtyValDiv);
							partQtyDiv.append(AdjustmentDiv);
							partQtyDiv.append(AdjustmentValDiv);
							partAmountDiv.append(ChargeAmountDiv);
							partAmountDiv.append(ChargeAmountValDiv);
							partAmountDiv.append(FinalBriefQtyDiv);
							partAmountDiv.append(FinalBriefQtyValDiv);
							partNumDiv.appendTo(partinfoDiv1);
							partQtyDiv.appendTo(partinfoDiv1);
							partAmountDiv.appendTo(partinfoDiv1);
							partBriefQtyDiv.appendTo(partinfoDiv1);
							SelectDiv1.appendTo(partinfoDiv1);
							if (iterations != ii) {
								partinfoDiv1.append(hr1);
							}
							partinfoDiv.append(partinfoDiv1);
						});
						container1.append(visitDateDiv);
						container1.append(custNameDiv);
						container1.append(TasknoDiv);
						container1.append(partinfoDiv);
						container1.append();
						$("#visitList5").append(container1);
						var adjButtonDiv = $('<div/>').addClass('adjBtnDiv3');
						var NoteDiv = $('<div/>').addClass('flex-container');
						var Notelbl1 = $('<div/>').addClass('Notelbl1');
						var NoteValdiv = $('<div/>').addClass('NoteValdiv');
						NoteDiv.append(Notelbl1);
						NoteDiv.append(NoteValdiv);
						Notelbl1.append('Note : ').addClass('Notelbl');
						NoteValdiv.append('Manager responsible to determine if manual billing required');

						var backButton = $('<button/>', {
							text: "Dismiss", //set text 1 to 10
							id: 'bk_btn_m',
							click: function() { redirectionToManagerFunctionality(); }
						}).addClass("back-button custom-btn custom-btn-primary");

						if (submitCondition == 1) {
							var adjButton = $('<button/>', {
								text: "Submit", //set text 1 to 10
								id: 'btn_submit',
								click: function() { managerSubmit(debAdjVistPartDetailManagerList); }
							}).addClass("cp_plugin_button custom-btn custom-btn-primary3");
						} else if (submitCondition == 2) {
							var adjButton = $('<button/>', {
								text: "Submit", //set text 1 to 10
								id: 'btn_submit',
								click: function() { managerApproveAllSubmit(debAdjVistPartDetailManagerList); }
							}).addClass("cp_plugin_button custom-btn custom-btn-primary3");
						} else if (submitCondition == 3) {
							var adjButton = $('<button/>', {
								text: "Submit", //set text 1 to 10
								id: 'btn_submit',
								click: function() { managerRejectAllSubmit(debAdjVistPartDetailManagerList); }
							}).addClass("cp_plugin_button custom-btn custom-btn-primary3");
						}

						adjButtonDiv.append(backButton);
						adjButtonDiv.append(adjButton);

						$("#PartInfoFooter1").append(NoteDiv);
						$("#PartInfoFooter1").append(adjButtonDiv);
					} else {
						$("#visitList5").append("Invalid Request").css("color", "red");
					}
				} else {
					alert("No Record Found");
				}
			}

			function redirectionToManagerFunctionality() {
				stage = 3;
				$('#stageDiv3').show();
				$('#stageDiv1').hide();
				$('#stageDiv2').hide();
				$('#stageDiv4').hide();
				$('#stageDiv5').hide();
				$('#visitList5').empty();
				$('#PartInfoFooter1').empty();
				$('#SuccessfulSubmit1').empty();
			}

			function managerSubmit(debAdjVistPartDetailManagerList) {

				var InventoryListJSON1 = {};
				var debreifAdjApprove;
				var debreifAdjReject;
				var daas = "6";
				var findManagerAprrove = 0;
				var findManagerReject = 0;
				try {
					if (debAdjVistPartDetailManagerList.length > 0) {
						$.each(debAdjVistPartDetailManagerList, function(key1, partData) {
							var approvalValue = $("#managerApproval" + key1).val();
							if ('approved' == approvalValue) {
								findManagerAprrove++;
								debreifAdjApprove = "1";
								debreifAdjReject = "";
							} else if ('rejected' == approvalValue) {
								findManagerReject++;
								debreifAdjReject = "1";
								debreifAdjApprove = "";
							}
							$.extend(InventoryListJSON1, {
								[partData.invid]: {
									"invid": partData.invid,
									"inv_aid": receivedData.activity.aid,
									"I_ITEM_NUMBER": partData.I_ITEM_NUMBER,
									"quantity": partData.quantity,
									"I_SUBINVENTORY": partData.I_SUBINVENTORY,
									"invpool": partData.invpool,
									"I_ITEM_DESCRIPTION": partData.I_ITEM_DESCRIPTION,
									"I_SUBINVENTORY_NAME": partData.I_SUBINVENTORY_NAME,
									"invtype": partData.invtype,
									"I_INVENTORY_KEY": partData.I_INVENTORY_KEY,
									"I_DEBRIEF_ADJ_QUANTITY": partData.I_DEBRIEF_ADJ_QUANTITY,
									"I_DEBRIEF_ADJ_APPROVE": debreifAdjApprove,
									"I_DEBRIEF_ADJ_REJECT": debreifAdjReject
								}
							});
						});
						if (findManagerAprrove == debAdjVistPartDetailManagerList.length) {
							daas = 3;
						} else if (findManagerReject == debAdjVistPartDetailManagerList.length) {
							daas = 5;
						} else {
							daas = 4;
						}
						cancelActivityByManager(InventoryListJSON1, daas);
					} else {
						alert("No Record Found");
					}
				} catch (err) {
					var now = new Date(Date.now());

					if (errorLogs == null) {
						errorLogs = "";
					}
					errorLogs = errorLogs + "||" + now.toString() + "|Plugin :Debrief Adjustment Manager :Exception " + err.message;
					$.ErrorUpdate(receivedData.activity.aid, errorLogs);
				}
			}

			function managerApproveAllSubmit(debAdjVistPartDetailManagerList) {

				var InventoryListJSON1 = {};
				var debreifAdjApprove = "1";
				var debreifAdjReject = "";
				var daas = "3";
				try {
					if (debAdjVistPartDetailManagerList.length > 0) {
						$.each(debAdjVistPartDetailManagerList, function(key1, partData) {
							$.extend(InventoryListJSON1, {
								[partData.invid]: {
									"invid": partData.invid,
									"inv_aid": receivedData.activity.aid,
									"I_ITEM_NUMBER": partData.I_ITEM_NUMBER,
									"quantity": partData.quantity,
									"I_SUBINVENTORY": partData.I_SUBINVENTORY,
									"invpool": partData.invpool,
									"I_ITEM_DESCRIPTION": partData.I_ITEM_DESCRIPTION,
									"I_SUBINVENTORY_NAME": partData.I_SUBINVENTORY_NAME,
									"invtype": partData.invtype,
									"I_INVENTORY_KEY": partData.I_INVENTORY_KEY,
									"I_DEBRIEF_ADJ_QUANTITY": partData.I_DEBRIEF_ADJ_QUANTITY,
									"I_DEBRIEF_ADJ_APPROVE": debreifAdjApprove,
									"I_DEBRIEF_ADJ_REJECT": debreifAdjReject
								}
							});
						});
						cancelActivityByManager(InventoryListJSON1, daas);
					} else {
						alert("No Record Found");
					}
				} catch (err) {
					var now = new Date(Date.now());
					if (errorLogs == null) {
						errorLogs = "";
					}
					errorLogs = errorLogs + "||" + now.toString() + "|Plugin :Debrief Adjustment Manager :Exception " + err.message;
					$.ErrorUpdate(receivedData.activity.aid, errorLogs);
				}
			}
			function managerRejectAllSubmit(debAdjVistPartDetailManagerList) {

				var InventoryListJSON1 = {};
				var debreifAdjApprove = "";
				var debreifAdjReject = "1";
				var daas = "5";
				try {
					if (debAdjVistPartDetailManagerList.length > 0) {
						$.each(debAdjVistPartDetailManagerList, function(key1, partData) {
							$.extend(InventoryListJSON1, {
								[partData.invid]: {
									"invid": partData.invid,
									"inv_aid": receivedData.activity.aid,
									"I_ITEM_NUMBER": partData.I_ITEM_NUMBER,
									"quantity": partData.quantity,
									"I_SUBINVENTORY": partData.I_SUBINVENTORY,
									"invpool": partData.invpool,
									"I_ITEM_DESCRIPTION": partData.I_ITEM_DESCRIPTION,
									"I_SUBINVENTORY_NAME": partData.I_SUBINVENTORY_NAME,
									"invtype": partData.invtype,
									"I_INVENTORY_KEY": partData.I_INVENTORY_KEY,
									"I_DEBRIEF_ADJ_QUANTITY": partData.I_DEBRIEF_ADJ_QUANTITY,
									"I_DEBRIEF_ADJ_APPROVE": debreifAdjApprove,
									"I_DEBRIEF_ADJ_REJECT": debreifAdjReject
								}
							});
						});
						cancelActivityByManager(InventoryListJSON1, daas);
					} else {
						alert("No Record Found");
					}
				} catch (err) {
					var now = new Date(Date.now());
					if (errorLogs == null) {
						errorLogs = "";
					}
					errorLogs = errorLogs + "||" + now.toString() + "|Plugin :Debrief Adjustment Manager :Exception " + err.message;
					$.ErrorUpdate(receivedData.activity.aid, errorLogs);
				}
			}

			function cancelActivityByManager(InventoryListJSON1, daas) {
				ultimateBind._sendPostMessageData({
					"apiVersion": 1,
					"method": "close",
					"backScreen": "default",
					"wakeupNeeded": false,
					//"backActivityId": receivedData.activity.aid,
					"inventoryList": InventoryListJSON1,
					"activity": {
						"aid": receivedData.activity.aid,
						"A_DA_ACTIVITY_STATUS": daas,
						"astatus": "cancelled"
					}
				});
			}

			function saveAdjustment(visitData, activitydata) {

				let arr = [];
				$.each(visitData.Parts, function(key1, partsData) {
					var itemsclass = {
						"I_ITEM_NUMBER": partsData.part_number,
						"I_ITEM_DESCRIPTION": partsData.part_description,
						"quantity": Number(partsData.part_quantity),
						"inventoryType": activitydata.inventoryType,
						"I_SUBINVENTORY": partsData.sub_inventory,
						"I_SUBINVENTORY_NAME": partsData.sub_inventory_name,
						"I_INVENTORY_KEY": partsData.inventoryKey,
						"I_ITEM_COST": partsData.part_cost,
						"I_ITEM_CHARGE_AMOUNT": partsData.charge_amount
					};
					arr.push(itemsclass);
				});

				var invItemjson = JSON.stringify(visitData);
				var activityPayload1 = {
					"updateParameters": {
						"identifyActivityBy": "apptNumber",
						"ifInFinalStatusThen": "doNothing"
					},
					"activities": [
						{
							"title": activitydata.title,
							"activityType": activitydata.activityType,
							"apptNumber": activitydata.taskNumber,
							"resourceId": activitydata.rid,
							"customerName": visitData.customer_name,
							"duration": 60,
							"SRNumber": visitData.SRNumber,
							"language": activitydata.language,
							"languageISO": activitydata.languageISO,
							"inventories": {
								"items": arr
							}
						}
					]
				}
				var daas = "1";
				var activityPayload = {
					"title": activitydata.title,
					"activityType": activitydata.activityType,
					"apptNumber": activitydata.taskNumber,
					"resourceId": activitydata.rid,
					"customerName": visitData.customer_name,
					"duration": 60,
					"SRNumber": visitData.SRNumber,
					"language": activitydata.language,
					"languageISO": activitydata.languageISO,
					"Customer_Name": visitData.customer_name,
					"A_FV_DATE": visitData.visit_date,
					"A_DA_ACTIVITY_STATUS": daas
				}
				var closeParams = {
					apiVersion: 1,
					method: 'close',
					wakeupNeeded: false,
					backScreen: 'default',
					"activity": {
						"aid": receivedData.activity != null ? receivedData.activity.aid : 'null',
						"astatus": "pending"
					}
				};
				$.ajax({
					url: activitydata.activityCreationUrl,
					timeout: 20000,
					cache: false,
					method: 'POST',
					dataType: 'json',
					contentType: 'application/json; charset=utf-8',
					data: JSON.stringify(activityPayload),
					headers: activitydata.headers,
					success: function(successData) {
						alert("Activity has been created for this adjustment!!");
						console.log("Activity created - Success messagae: " + JSON.stringify(successData));
						inventoryDetailsSaveCall(closeParams, successData.activityId, arr, activitydata.headers)
					},
					error: function(errorData) {
						alert("There is some issue!!");
						console.log("Update Resource properties - Error messagae:" + JSON.stringify(errorData));
					}
				});
			}

			function inventoryDetailsSaveCall(closeParams, activityId, arr, headers) {
				// need to write a code for second api call here we need ectivity id
				var inventoryUrl = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/activities/" + activityId + "/customerInventories";
				var xx = 0;
				var inLengh = arr.length;
				$.each(arr, function(key1, inventoryData) {
					xx++;
					$.ajax({
						url: inventoryUrl,
						timeout: 20000,
						cache: false,
						method: 'POST',
						dataType: 'json',
						contentType: 'application/json; charset=utf-8',
						data: JSON.stringify(inventoryData),
						headers: headers,
						success: function(successData) {
							console.log("Inventory created - Success messagae: " + JSON.stringify(successData));
							alert("Inventory has been created for this adjustment!!");
						},
						error: function(errorData) {
							alert("There is some issue while creating Inventory!!");
							console.log("Update Resource properties - Error messagae:" + JSON.stringify(errorData));
						}
					});
				});
				postMessageData(closeParams);
			}
			function postMessageData(closeParams) {
				ultimateBind._sendPostMessageData(closeParams);
			}
		},

		/**
		 * Business login on plugin wakeup (background open for sync)
		 *
		 * @param {Object} receivedData - JSON object that contain data from OFSC
		 */
		pluginWakeup: function(receivedData) {
			this._log(window.location.host + ' WAKEUP', JSON.stringify(receivedData, null, 4));

			var wakeupData = {
				pluginWakeupCount: +localStorage.getItem('pluginWakeupCount'),
				pluginWakeupMaxCount: +localStorage.getItem('pluginWakeupMaxCount'),
				pluginWakeupDontRespondOn: +localStorage.getItem('pluginWakeupDontRespondOn')
			};

			wakeupData.pluginWakeupCount = wakeupData.pluginWakeupCount + 1;

			localStorage.setItem('pluginWakeupCount', wakeupData.pluginWakeupCount);
			localStorage.setItem('pluginWakeupMaxCount', wakeupData.pluginWakeupMaxCount);
			localStorage.setItem('pluginWakeupDontRespondOn', wakeupData.pluginWakeupDontRespondOn);

			this._log(window.location.host + ' SAVE WAKEUP DATA TO LOCAL STORAGE', JSON.stringify(wakeupData, null, 4));

			if (wakeupData.pluginWakeupDontRespondOn == wakeupData.pluginWakeupCount) {
				this._log(window.location.host + ' EMULATE NOT RESPONDING PLUGIN');

				return;
			}

			if (wakeupData.pluginWakeupCount < wakeupData.pluginWakeupMaxCount) {
				setTimeout(function() {
					this._log(window.location.host + ' SLEEP. RETRY NEEDED');

					this._sendPostMessageData({
						apiVersion: 1,
						method: 'sleep',
						wakeupNeeded: true
					});
				}.bind(this), 2000);
			} else {
				setTimeout(function() {
					this._log(window.location.host + ' SLEEP. NO RETRY');

					this._sendPostMessageData({
						apiVersion: 1,
						method: 'sleep',
						wakeupNeeded: false
					});
				}.bind(this), 12000);
			}
		},

		/**
			* Update JSON
			* 
			* @private
			*/
		_updateResponseJSON: function() {
			var jsonToSend = this.generateJson();
			$('.json__response').text(JSON.stringify(jsonToSend, null, 4));
		},


		// CHG0075659 - MPF Phase 5 - Function to handle Call Procedure api result
		finishCallIdCallbacks: function(receivedJson) {
			let jsonObject = null;
			console.log("Call procedure:" + receivedJson);
			jsonObject = JSON.parse(receivedJson);
			console.log("Call Procedure JSONobject" + JSON.stringify(jsonObject));
			var jsonObjectItemLength = jsonObject.resultData.items.length;
			var partssearchcallID = "";
			if (jsonObjectItemLength != 0) {
				$.each(jsonObject.resultData.items, function(i, a) {
					multipleFieldsArray.push(a.fields);
					a.fields.LINKED_COUNT = a.linkedItems.length;
				});
				$.processSearchResultsFnCallBck(multipleFieldsArray);
			}
		},

		/**
		 * Initialization function
		 */
		init: function() {
			if (navigator.serviceWorker) {
				this._log(window.location.host + ' Service Worker is supported');
				navigator.serviceWorker.register('debriefAdjustment-service-worker.js').then(function(registration) {
					this._log(window.location.host + ' Service Worker is registered with scope: ' + registration.scope);
					registration.addEventListener('updatefound', function() {
						this._log(window.location.host + ' Service Worker update is found');
						var newServiceWorker = registration.installing;
						newServiceWorker.addEventListener('statechange', function() {
							switch (newServiceWorker.state) {
								case "installed":
									this._log(window.location.host + ' New Service Worker is installed');
									break;
							}
						}.bind(this));
					}.bind(this));
					navigator.serviceWorker.addEventListener('controllerchange', function() {
						this.notifyAboutNewVersion();
					}.bind(this));
					this.startApplication();
				}.bind(this), function(err) {
					this._log(window.location.host + ' Service Worker registration failed: ' + err);
					this.startApplication();
				}.bind(this));
				return;
			} else {
				this._log(window.location.host + ' Service Worker is not supported');
			}
			this.startApplication();
		},
		startApplication: function() {
			//$.getConfigDataFromJson(); // Added to get the config.json values for 19C upgrade

			//default ofsc function
			window.addEventListener("message", this._getPostMessageData.bind(this), false);
			this._log(window.location.host + ' PLUGIN HAS BEEN STARTED');

			//default data variables
			var thisVar = this;

			var jsonToSend = {
				apiVersion: 1,
				method: 'ready',
				sendInitData: true
			};

			//parse data items
			var dataItems = JSON.parse(localStorage.getItem('dataItems'));
			if (dataItems) {
				$.extend(jsonToSend, { dataItems: dataItems });
			}

			thisVar._sendPostMessageData(jsonToSend);
		},
		notifyAboutNewVersion: function() {
			this._log(window.location.host + ' New Service Worker is activated. Page refresh is needed');
			var footer = document.querySelector('.footer');
			var versionNotificationElement = document.createElement('div');
			versionNotificationElement.className = 'new-version-notification';
			versionNotificationElement.innerHTML = 'New version is detected. Please reopen the page';
			footer.appendChild(versionNotificationElement);
		}
	});
	window.OfscPlugin.getVersion = function() {
		return resourcesVersion;
	};

})(jQuery);