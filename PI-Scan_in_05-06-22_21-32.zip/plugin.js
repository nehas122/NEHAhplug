"use strict";

(function($) {
    window.OfscPlugin = function(debugMode) {
        this.debugMode = debugMode || false;
    };

    $.extend(window.OfscPlugin.prototype, {
        /**
         * Dictionary of enums
         */
        dictionary: {
            astatus: {
                pending: {
                    label: 'pending',
                    translation: 'Pending',
                    outs: ['started', 'cancelled', 'suspended'],
                    color: '#FFDE00'
                },
                started: {
                    label: 'started',
                    translation: 'Started',
                    outs: ['complete', 'suspended', 'notdone', 'cancelled'],
                    color: '#A2DE61'
                },
                complete: {
                    label: 'complete',
                    translation: 'Completed',
                    outs: [],
                    color: '#79B6EB'
                },
                suspended: {
                    label: 'suspended',
                    translation: 'Suspended',
                    outs: [],
                    color: '#9FF'
                },
                notdone: {
                    label: 'notdone',
                    translation: 'Not done',
                    outs: [],
                    color: '#60CECE'
                },
                cancelled: {
                    label: 'cancelled',
                    translation: 'Cancelled',
                    outs: [],
                    color: '#80FF80'
                }
            },
            invpool: {
                customer: {
                    label: 'customer',
                    translation: 'Customer',
                    outs: ['deinstall'],
                    color: '#04D330'
                },
                install: {
                    label: 'install',
                    translation: 'Installed',
                    outs: ['provider'],
                    color: '#00A6F0'
                },
                deinstall: {
                    label: 'deinstall',
                    translation: 'Deinstalled',
                    outs: ['customer'],
                    color: '#00F8E8'
                },
                provider: {
                    label: 'provider',
                    translation: 'Resource',
                    outs: ['install'],
                    color: '#FFE43B'
                }
            }
        },

        mandatoryActionProperties: {},

        /**
         * Which field shouldn't be editable
         *
         * format:
         *
         * parent: {
         *     key: true|false
         * }
         *
         */
        renderReadOnlyFieldsByParent: {
            data: {
                apiVersion: true,
                method: true,
                entity: true
            },
            resource: {
                pid: true,
                pname: true,
                gender: true
            }
        },

        /**
         * Check for string is valid JSON
         *
         * @param {*} str - String that should be validated
         *
         * @returns {boolean}
         *
         * @private
         */
        _isJson: function(str) {
            try {
                JSON.parse(str);
            } catch (e) {
                return false;
            }
            return true;
        },

        /**
         * Return origin of URL (protocol + domain)
         *
         * @param {String} url
         *
         * @returns {String}
         *
         * @private
         */
        _getOrigin: function(url) {
            if (url != '') {
                if (url.indexOf("://") > -1) {
                    return 'https://' + url.split('/')[2];
                } else {
                    return 'https://' + url.split('/')[0];
                }
            }

            return '';
        },

        /**
         * Return domain of URL
         *
         * @param {String} url
         *
         * @returns {String}
         *
         * @private
         */
        _getDomain: function(url) {
            if (url != '') {
                if (url.indexOf("://") > -1) {
                    return url.split('/')[2];
                } else {
                    return url.split('/')[0];
                }
            }

            return '';
        },

        /**
         * Sends postMessage to document.referrer
         *
         * @param {Object} data - Data that will be sent
         *
         * @private
         */
        _sendPostMessageData: function(data) {
            var originUrl = document.referrer || (document.location.ancestorOrigins && document.location.ancestorOrigins[0]) || '';

            if (originUrl) {
                this._log(window.location.host + ' -> ' + data.method + ' ' + this._getDomain(originUrl), JSON.stringify(data, null, 4));

                parent.postMessage(data, this._getOrigin(originUrl));
            } else {
                this._log(window.location.host + ' -> ' + data.method + ' ERROR. UNABLE TO GET REFERRER');
            }
        },

        /**
         * Handles during receiving postMessage
         *
         * @param {MessageEvent} event - Javascript event
         *
         * @private
         */
        _getPostMessageData: function(event) {

            if (typeof event.data === 'undefined') {
                this._log(window.location.host + ' <- NO DATA ' + this._getDomain(event.origin), null, null, true);

                return false;
            }

            if (!this._isJson(event.data)) {
                this._log(window.location.host + ' <- NOT JSON ' + this._getDomain(event.origin), null, null, true);

                return false;
            }

            var data = JSON.parse(event.data);

            if (!data.method) {
                this._log(window.location.host + ' <- NO METHOD ' + this._getDomain(event.origin), null, null, true);

                return false;
            }

            this._log(window.location.host + ' <- ' + data.method + ' ' + this._getDomain(event.origin), JSON.stringify(data, null, 4));

            switch (data.method) {
                case 'init':
                    this.pluginInitEnd(data);
                    break;

                case 'open':
                    this.pluginOpen(data);
                    break;

                case 'wakeup':
                    this.pluginWakeup(data);
                    break;

                case 'error':
                    data.errors = data.errors || {
                        error: 'Unknown error'
                    };
                    this._showError(data.errors);
                    break;

                default:
                    this._log(window.location.host + ' <- UNKNOWN METHOD: ' + data.method + ' ' + this._getDomain(event.origin), null, null, true);
                    break;
            }
        },

        /**
         * Show alert with error
         *
         * @param {Object} errorData - Object with errors
         *
         * @private
         */
        _showError: function(errorData) {
            alert(JSON.stringify(errorData, null, 4));
        },

        /**
         * Logs to console
         *
         * @param {String} title - Message that will be log
         * @param {String} [data] - Formatted data that will be collapsed
         * @param {String} [color] - Color in Hex format
         * @param {Boolean} [warning] - Is it warning message?
         *
         * @private
         */
        _log: function(title, data, color, warning) {
            if (!this.debugMode) {
                return;
            }
            if (!color) {
                color = '#0066FF';
            }
            if (!!data) {
                console.groupCollapsed('%c[Plugin API] ' + title, 'color: ' + color + '; ' + (!!warning ? 'font-weight: bold;' : 'font-weight: normal;'));
                console.log('[Plugin API] ' + data);
                console.groupEnd();
            } else {
                console.log('%c[Plugin API] ' + title, 'color: ' + color + '; ' + (!!warning ? 'font-weight: bold;' : ''));
            }
        },

        /**
         * Business login on plugin init
         */
        saveToLocalStorage: function(data) {
            this._log(window.location.host + ' INIT. SET DATA TO LOCAL STORAGE', JSON.stringify(data, null, 4));

            if (data.attributeDescription) {
                localStorage.setItem('pluginInitData', JSON.stringify(data.attributeDescription));
            }
        },

        /**
         * Business login on plugin init end
         *
         * @param {Object} data - JSON object that contain data from OFSC
         */
        pluginInitEnd: function(data) {
            this.saveToLocalStorage(data);

            var messageData = {
                apiVersion: 1,
                method: 'initEnd'
            };

            if (localStorage.getItem('pluginWakeupCount') < localStorage.getItem('pluginWakeupMaxCount')) {
                this._log(window.location.host + ' UNFINISHED WAKEUP DATA FOUND IN LOCAL STORAGE');

                messageData.wakeupNeeded = true;
            }

            this._sendPostMessageData(messageData);
        },

        /**
         * Business login on plugin open
         *
         * @param {Object} receivedData - JSON object that contain data from OFSC
         */
        pluginOpen: function(receivedData) {
            //Fields Data from OFSC:
			//console.log('receivedData in scan in:' + JSON.stringify(receivedData));
            var email = receivedData.resource.email;
            var aEquipmentNumber = receivedData.activity.A_EQUIPMENT_NUMBER;
            var aSerial = receivedData.activity.A_SERIAL;
            var aVendorSerial = receivedData.activity.A_MFG_SERIAL;
            var activityId = receivedData.activity.aid;
			var actionsArr = [];
			var inventoryList = receivedData.inventoryList;
			
         	/////*****Build the deinstall list*****//////
			$.each(inventoryList, function(key, invItem){
				 if(invItem.inv_aid == receivedData.activity.aid){
					  var invID = invItem.invid; var qty = invItem.quantity;
					  
					 if(invItem.invpool == "deinstall" && invItem.I_IGNORE_FLAG == 'Ignore'){ //added Ignore condition on 05/03 to isolate current visit parts
										
							actionsArr.push({
									//Begin Modification for INC1481282
												//"action": "undo_deinstall",
												//"quantity": qty+'',
												"action": "delete",
									//End Modification for INC1481282			
												"invid": invID,
												"entity": "inventory",
												"properties": {}
										});
											
						}
				 }
			});				 

            // set the innerText of cpf_vendorSerial_inner
            $('#cpf_vendorSerial_inner').text(aVendorSerial);
            
            
			var nowDate = new Date();
             var nowCurrTime = nowDate.toISOString(); 
			console.log('Now '+nowCurrTime);
			//
			//$.urlParam = function(name) {
           //     var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
           //     return results[1] || 0;
           // }
			var timeZoneName = receivedData.resource.time_zone;
                //console.log('timeZoneName:', timeZoneName);

				var TimeZoneMapping = {
					"19": "Alaska",
					"6": "Arizona",
					"4": "Central",
					"2": "Eastern",
					"15": "GMT",
					"17": "Hawaii (Adak)",
					"18": "Hawaii (Honolulu)",
					"5": "Mountain",
					"7": "Pacific"
				};
													
				var timeOffset = {
					'Alaska':9,
					'dAlaska':8,
					'Arizona':7,
					'dArizona':7,
					'Central':6,
					'dCentral':5,
					'Eastern':5,
					'dEastern':4,
					'GMT':0,
					'dGMT':0,
					'Hawaii(Adak)':10,
					'dHawaii(Adak)':10,
					'Hawaii(Honolulu)':10,
					'dHawaii(Honolulu)':10,
					'Mountain':7,
					'dMountain':6,
					'Pacific':8,
					'dPacific':7
				}
				

				var timeZone = TimeZoneMapping[timeZoneName];
				
				Date.prototype.stdTimezoneOffset = function() {
					var jan = new Date(this.getFullYear(), 0, 1);
					var jul = new Date(this.getFullYear(), 6, 1);
					return Math.max(jan.getTimezoneOffset(), jul.getTimezoneOffset());
				}
				
				Date.prototype.dst = function() {
					return this.getTimezoneOffset() < this.stdTimezoneOffset();
				}
				
				var today = new Date();
				if(today.dst()){
					var timeZoneId = timeOffset['d'+timeZone.replace(' ','')];
				}else{
					var timeZoneId = timeOffset[timeZone.replace(' ','')];
				}

				var indainDateObj = new Date();
				indainDateObj.setHours(indainDateObj.getHours() - timeZoneId);
				var aScanInTime = indainDateObj.toISOString();
			//
            var activityJSONData = {
                aid: activityId,
				//Added 19 characters to A_SCAN_IN_TIME field on: 10-08-2018
				A_SCAN_IN_TIME: aScanInTime.substring(0,19),
				//A_SCAN_IN_TIME_OVERRIDE: aScanInTime,
				A_STATE: "SI"
            };


            $('#scanSubmitBtn').click(function() {
				
				// on click of submit button in ScanIn screen..
				var updateEquipmentID = false;
				var updateSerialNumber = true;
                //Fields Data from Plugin:
                var equipmentIdScan = $('#cpf_equipment_id_inner').val();
				equipmentIdScan = equipmentIdScan.toUpperCase();
                var serialNumberScan = $('#cpf_SerialNumberScan_inner').val();
				serialNumberScan = serialNumberScan.toUpperCase();
                if (equipmentIdScan == aEquipmentNumber && equipmentIdScan != "") {
                    updateEquipmentID = true;
                        $.extend(activityJSONData, {
                            Equipment_ID_SCAN: equipmentIdScan
                        });
                } else {
					if( (serialNumberScan == "" && equipmentIdScan == "") ||  (serialNumberScan == "" && equipmentIdScan !=aEquipmentNumber))
					{
                        $("#cpf_error_message").removeClass("cp_hidden");
                        $("#cp_error_equipment_block").removeClass("cp_hidden");
                        $("#cp_error_serialN_block").addClass("cp_hidden");

                        //Show or Hide the buttons
                        $("#reScanBtn").removeClass("cp_hidden");
                        $('#notDoneBtn').removeClass("cp_hidden");
                        $('#scanSubmitBtn').addClass("cp_hidden");
                        $('#cancelBtn').addClass("cp_hidden");

                        //Hide the Scan In main section fields.
                        $(".scanInSection").addClass("cp_hidden");
					}
                    
                }
                if (serialNumberScan != "") {
                    if (aSerial != null || aSerial != "" || aSerial != undefined) {
                        if (serialNumberScan == aSerial && updateEquipmentID ) {
							  updateSerialNumber = true;
                            $.extend(activityJSONData, {
                                A_Serial_Number: serialNumberScan
                            });
						} else if(serialNumberScan == aSerial && equipmentIdScan == "") {
							 // a correct serial number is entered and no Equipment ID then go to ReTag screen
								//alert("serial match no eqp ID");
                                //Hide Equipment number
                                $("#cpf_equipment_id").addClass("cp_hidden");
                                //Show New Equipment ID
                                $("#cpf_new_equipment_id").removeClass("cp_hidden");
                                $("#ReTagSectionLabel").removeClass("cp_hidden");
                                //Prepoulate the Serial Number if any.
                                $('#cpf_SerialNumberScan_inner').val(aSerial);
                                //Show or Hide the buttons
                                $("#reScanBtn").addClass("cp_hidden");
                                $("#reTagBtn").addClass("cp_hidden");
                                $('#scanSubmitBtn').addClass("cp_hidden");
								//show the ReTag Submit buttons
                                $('#reTagSubmitBtn').removeClass("cp_hidden"); 
                                $('#cancelBtn').removeClass("cp_hidden");
                                $('#notDoneBtn').removeClass("cp_hidden");
                            }
						else{
							updateSerialNumber = false;
							//Show Error Message
							 $("#cpf_error_message").removeClass("cp_hidden");
                            $("#cp_error_serialN_block").removeClass("cp_hidden");
							$("#cp_error_equipment_block").addClass("cp_hidden");
                            //Hide the Scan-In main fields section 
							$(".scanInSection").addClass("cp_hidden");
                            //Show or Hide the buttons
                            $("#reScanBtn").removeClass("cp_hidden");
                            $('#notDoneBtn').removeClass("cp_hidden");
                            $('#scanSubmitBtn').addClass("cp_hidden");
                            $('#cancelBtn').addClass("cp_hidden");
                        }
                    }
                }

                if (updateEquipmentID && updateSerialNumber) {
                    this._sendPostMessageData({
                        "apiVersion": 1,
                        "method": "close",
                        "backScreen": "default",
                        "wakeupNeeded": false,
						"actions": actionsArr,
                        "activity": activityJSONData
                    });
                }
            }.bind(this));
            
            $('#reScanBtn').click(function() {	
				//Show below sections
                $("#cpf_error_message").addClass("cp_hidden");
                $("#cp_error_equipment_block").addClass("cp_hidden");
                $(".scanInSection").removeClass("cp_hidden");
                // $("#cpf_general_submit").removeClass("cp_hidden");
                //Hide all the reTag options:
                $("cpf_new_equipment_id").addClass("cp_hidden");
                $("#ReTagSectionLabel").addClass("cp_hidden");
                //Show or Hide the buttons
                $("#reScanBtn").addClass("cp_hidden");
                $('#notDoneBtn').addClass("cp_hidden");
                $('#scanSubmitBtn').removeClass("cp_hidden");
                $('#cancelBtn').removeClass("cp_hidden");
				$("#reTagSubmitBtn").addClass("cp_hidden");
                //Show Equipment number
                $("#cpf_equipment_id").removeClass("cp_hidden");
                //Hide New Equipment ID
                $("#cpf_new_equipment_id").addClass("cp_hidden");
                $("#ReTagSectionLabel").addClass("cp_hidden");
                //reset the Serial Number
                $('#cpf_SerialNumberScan_inner').val("");
            }.bind(this));

            $('#cancelBtn').click(function() {
                this._sendPostMessageData({
                    "apiVersion": 1,
                    "method": "close",
                    "backScreen": "default",
                    "wakeupNeeded": false
                });
            }.bind(this));
            
            $('#reTagBtn').click(function() {
                // Hide Error Messages.
                $("#cpf_error_message").addClass("cp_hidden");
                $("#cp_error_equipment_block").addClass("cp_hidden");

                //Show the main fields section					
                $(".scanInSection").removeClass("cp_hidden");

                //Hide Equipment number
                $("#cpf_equipment_id").addClass("cp_hidden");

                //Show New Equipment ID
                $("#cpf_new_equipment_id").removeClass("cp_hidden");
                $("#ReTagSectionLabel").removeClass("cp_hidden");

                //Prepoulate the Serial Number               
                $('#cpf_SerialNumberScan_inner').val(aSerial);

				//Reset the Equipment Number
				 $('#cpf_equipment_id_inner').val("");
				 
                //Show or Hide the buttons
                $("#reScanBtn").addClass("cp_hidden");
                $("#reTagBtn").addClass("cp_hidden");
                $('#scanSubmitBtn').addClass("cp_hidden");				
				$("#reTagSubmitBtn").removeClass("cp_hidden");
                $('#cancelBtn').removeClass("cp_hidden");
                $('#notDoneBtn').removeClass("cp_hidden");
            }.bind(this));
			
			$('#reTagSubmitBtn').click(function() {
				var newEquipmentId = $('#cpf_new_equipment_id_inner').val();   
                newEquipmentId = newEquipmentId.toUpperCase();				
                var serialNumberScan = $('#cpf_SerialNumberScan_inner').val();
				serialNumberScan = serialNumberScan.toUpperCase();
				//if(newEquipmentId != "")
				//{
					var nowDateReTag = new Date();
					var nowCurrTimeReTag = nowDateReTag.toISOString(); 
					console.log('Now '+nowCurrTimeReTag);
				    this._sendPostMessageData({
					  "apiVersion": 1,
					  "method": "close",
					  "backScreen": "default",
					  "wakeupNeeded": false,
					   "actions": actionsArr,
					  "activity": {
						     "aid": activityId,
							 "A_NEW_EQUIPMENT_ID": newEquipmentId,
							// "A_EQUIPMENT_NUMBER": newEquipmentId,
							 "A_Serial_Number":serialNumberScan, 
							 "A_SERIAL":serialNumberScan,	
							//Added 19 characters to A_SCAN_IN_TIME field on: 10-08-2018							 
							 "A_SCAN_IN_TIME": aScanInTime.substring(0,19),
							 //"A_SCAN_IN_TIME_OVERRIDE": aScanInTime,
							 "A_STATE": "SI"
					  }
			   }); 
				/*}else{
					alert("New Equipment ID is required. Please enter the New Equipment Id to submit.");
				}	*/		   
				
			}.bind(this));
			
          // Not Done Activity section...
		   $('#notDoneBtn').click(function() {
			   
			   // clear the local storage fields:			
				
			     this._sendPostMessageData({                        		
						"apiVersion": 1,
						"method": "close",
						"backScreen": "notdone_activity",
						"backActivityId": activityId,
						 "activity": {
						     "aid": activityId,
							 "A_STATUS": null,
							  "A_ORACLE_STATUS": "Cancelled",
							 "A_STATE":null							 
					  }
                    });
					
					
			
		   }.bind(this));
            this._clearWakeupData();
            if (localStorage.getItem('pluginInitData')) {
                this._log(window.location.host + ' OPEN. GET DATA FROM LOCAL STORAGE', JSON.stringify(JSON.parse(localStorage.getItem('pluginInitData')), null, 4));

                $('.json__local-storage').text(JSON.stringify(JSON.parse(localStorage.getItem('pluginInitData')), null, 4));
            }
            this.initChangeOfWakeup(document);
            this.initChangeOfDataItems();
        },

        /**
         * Business login on plugin wakeup (background open for sync)
         *
         * @param {Object} receivedData - JSON object that contain data from OFSC
         */
        pluginWakeup: function(receivedData) {
            this._log(window.location.host + ' WAKEUP', JSON.stringify(receivedData, null, 4));

            var wakeupData = {
                pluginWakeupCount: +localStorage.getItem('pluginWakeupCount'),
                pluginWakeupMaxCount: +localStorage.getItem('pluginWakeupMaxCount'),
                pluginWakeupDontRespondOn: +localStorage.getItem('pluginWakeupDontRespondOn')
            };

            wakeupData.pluginWakeupCount = wakeupData.pluginWakeupCount + 1;

            localStorage.setItem('pluginWakeupCount', wakeupData.pluginWakeupCount);
            localStorage.setItem('pluginWakeupMaxCount', wakeupData.pluginWakeupMaxCount);
            localStorage.setItem('pluginWakeupDontRespondOn', wakeupData.pluginWakeupDontRespondOn);

            this._log(window.location.host + ' SAVE WAKEUP DATA TO LOCAL STORAGE', JSON.stringify(wakeupData, null, 4));

            if (wakeupData.pluginWakeupDontRespondOn == wakeupData.pluginWakeupCount) {
                this._log(window.location.host + ' EMULATE NOT RESPONDING PLUGIN');

                return;
            }

            if (wakeupData.pluginWakeupCount < wakeupData.pluginWakeupMaxCount) {
                setTimeout(function() {
                    this._log(window.location.host + ' SLEEP. RETRY NEEDED');

                    this._sendPostMessageData({
                        apiVersion: 1,
                        method: 'sleep',
                        wakeupNeeded: true
                    });
                }.bind(this), 2000);
            } else {
                setTimeout(function() {
                    this._log(window.location.host + ' SLEEP. NO RETRY');

                    this._sendPostMessageData({
                        apiVersion: 1,
                        method: 'sleep',
                        wakeupNeeded: false
                    });
                }.bind(this), 12000);
            }
        },

        /**
         * Save configuration of wakeup (background open for sync) behavior for Plugin
         * to Local Storage
         *
         * @private
         */
        _saveWakeupData: function() {
            var wakeupData = {
                pluginWakeupCount: 0,
                pluginWakeupMaxCount: 0,
                pluginWakeupDontRespondOn: 0
            };

            if ($('#wakeup').is(':checked')) {
                wakeupData.pluginWakeupMaxCount = parseInt($('#repeat_count').val());

                if ($('#dont_respond').is(':checked')) {
                    wakeupData.pluginWakeupDontRespondOn = parseInt($('#dont_respond_on').val());
                }
            }

            localStorage.setItem('pluginWakeupCount', wakeupData.pluginWakeupCount);
            localStorage.setItem('pluginWakeupMaxCount', wakeupData.pluginWakeupMaxCount);
            localStorage.setItem('pluginWakeupDontRespondOn', wakeupData.pluginWakeupDontRespondOn);

            this._log(window.location.host + ' SAVE WAKEUP DATA TO LOCAL STORAGE', JSON.stringify(wakeupData, null, 4));
        },

        /**
         * Clear previous configuration of wakeup (background open for sync) behavior for Plugin
         * from the Local Storage
         *
         * @private
         */
        _clearWakeupData: function() {
            localStorage.removeItem('pluginWakeupCount');
            localStorage.removeItem('pluginWakeupMaxCount');
            localStorage.removeItem('pluginWakeupDontRespondOn');

            this._log(window.location.host + ' CLEAR WAKEUP DATA FROM LOCAL STORAGE');
        },

        initChangeOfWakeup: function(element) {

            function onWakeupChange(elem) {
                var isChecked = $(elem).is(':checked');

                if (isChecked) {
                    $(element).find('#repeat_count').prop('disabled', false);
                    $(element).find('#dont_respond').prop('disabled', false);

                    $(element).find('#wakeup_row').removeClass('wakeup-form-row--disabled');

                    onDontRespondChange($(element).find('#dont_respond'));
                } else {
                    $(element).find('#repeat_count').prop('disabled', true);
                    $(element).find('#dont_respond').prop('disabled', true);
                    $(element).find('#dont_respond_on').prop('disabled', true);

                    $(element).find('#wakeup_row').addClass('wakeup-form-row--disabled');
                    $(element).find('#dont_respond_row').addClass('wakeup-form-row--disabled');
                }
            }

            function onDontRespondChange(elem) {
                var isChecked = $(elem).is(':checked');

                if (isChecked) {
                    $(element).find('#dont_respond_on').prop('disabled', false);
                    $(element).find('#dont_respond_row').removeClass('wakeup-form-row--disabled');
                } else {
                    $(element).find('#dont_respond_on').prop('disabled', true);
                    $(element).find('#dont_respond_row').addClass('wakeup-form-row--disabled');
                }
            }

            $(element).find('#wakeup').change(function(e) {
                onWakeupChange(e.target);
            });

            $(element).find('#dont_respond').change(function(e) {
                onDontRespondChange(e.target);
            });

            onWakeupChange($(element).find('#wakeup'));
        },

        initChangeOfDataItems: function() {
            //set checkboxes from local storage
            if (localStorage.getItem('dataItems')) {
                $('.data-items').attr('checked', true);
                $('.data-items-holder').show();

                var dataItems = JSON.parse(localStorage.getItem('dataItems'));
				

                $('.data-items-holder input').each(function() {
                    if (dataItems.indexOf(this.value) != -1) {
                        $(this).attr('checked', true);
                    }
                });
            }

            //init handlers
            $('.data-items').on('change', function(e) {
                $('.data-items-holder').toggle();
            });
        },

        initLocalStorageOption: function(localStorageKey) {
            if (localStorage.getItem(localStorageKey) === null) {
                localStorage.setItem(localStorageKey, 'true');
            }
        },


        /**
         * Initialization function
         */
		init: function() {
			if (navigator.serviceWorker) {
				this._log(window.location.host + ' Service Worker is supported');
				navigator.serviceWorker.register('scanin-service-worker.js').then(function(registration) {
					this._log(window.location.host + ' Service Worker is registered with scope: ' + registration.scope);
					registration.addEventListener('updatefound', function() {
						this._log(window.location.host + ' Service Worker update is found');
						var newServiceWorker = registration.installing;
						newServiceWorker.addEventListener('statechange', function() {
							switch (newServiceWorker.state) {
								case "installed":
									this._log(window.location.host + ' New Service Worker is installed');
									break;
							}
						}.bind(this));
					}.bind(this));
					navigator.serviceWorker.addEventListener('controllerchange', function() {
						this.notifyAboutNewVersion();
					}.bind(this));
					this.startApplication();
				}.bind(this), function(err) {
					this._log(window.location.host + ' Service Worker registration failed: ' + err);
					this.startApplication();
				}.bind(this));
				return;
			} else {
				this._log(window.location.host + ' Service Worker is not supported');
			}
			this.startApplication();
		},
		startApplication: function() {
    	   //$.getConfigDataFromJson();  Get the config.json values for 19C upgrade
            this._log(window.location.host + ' PLUGIN HAS BEEN STARTED');
            $('.back_method_select').on('change', function() {
                var selectValue = $('.back_method_select').val();
                if (selectValue == 'activity_by_id' ||
                    selectValue == 'end_activity' ||
                    selectValue == 'cancel_activity' ||
                    selectValue == 'notdone_activity' ||
                    selectValue == 'start_activity' ||
                    selectValue == 'suspend_activity' ||
                    selectValue == 'delay_activity') {
                    $('.back_activity_id').show();
                } else {
                    $('.back_activity_id').val('').hide();
                }
            });

            $('.json_local_storage_toggle').on('click', function() {
                $('.json__local-storage').toggle();
            });

            $('.json_request_toggle').on('click', function() {
                $('.column-item--request').toggle();
            });

            $('.json_response_toggle').on('click', function() {
                $('.column-item--response').toggle();
            }.bind(this));


            window.addEventListener("message", this._getPostMessageData.bind(this), false);

            this.initLocalStorageOption('showHeader');
            this.initLocalStorageOption('backNavigationFlag');

            var jsonToSend = {
                apiVersion: 1,
                method: 'ready',
                sendInitData: true,
                showHeader: !!localStorage.getItem('showHeader'),
                enableBackButton: !!localStorage.getItem('backNavigationFlag')
            };

            //parse data items
            //var dataItems = JSON.parse(localStorage.getItem('dataItems'));
			 var dataItems = ['resource','deinstalledInventories'];
			
            if (dataItems) {
                $.extend(jsonToSend, {
                    dataItems: dataItems
                });
            }
            this._sendPostMessageData(jsonToSend);
		},
		notifyAboutNewVersion: function() {
			this._log(window.location.host + ' New Service Worker is activated. Page refresh is needed');
			var footer = document.querySelector('.footer');
			var versionNotificationElement = document.createElement('div');
			versionNotificationElement.className = 'new-version-notification';
			versionNotificationElement.innerHTML = 'New version is detected. Please reopen the page';
			footer.appendChild(versionNotificationElement);
		}		
    });
	window.OfscPlugin.getVersion = function() {
		return resourcesVersion;
	};

})(jQuery);