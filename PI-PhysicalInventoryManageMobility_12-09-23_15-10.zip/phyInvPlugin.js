"use strict";
(function ($) {
	window.OfscPlugin = function (debugMode) {
		this.debugMode = debugMode || false;
	};

	$.extend(window.OfscPlugin.prototype, {
		/**
		 * Dictionary of enums
		 */
		dictionary: {
			astatus: {
				pending: {
					label: 'pending',
					translation: 'Pending',
					outs: ['started', 'cancelled', 'suspended', 'enroute'],
					color: '#ffde00'
				},
				enroute: {
					label: 'enroute',
					translation: 'En Route',
					outs: ['started', 'cancelled', 'pending'],
					color: '#ff920c'
				},
				started: {
					label: 'started',
					translation: 'Started',
					outs: ['complete', 'suspended', 'notdone', 'cancelled'],
					color: '#a2de61'
				},
				complete: {
					label: 'complete',
					translation: 'Completed',
					outs: [],
					color: '#79B6EB'
				},
				suspended: {
					label: 'suspended',
					translation: 'Suspended',
					outs: [],
					color: '#9FF'
				},
				notdone: {
					label: 'notdone',
					translation: 'Not done',
					outs: [],
					color: '#60CECE'
				},
				cancelled: {
					label: 'cancelled',
					translation: 'Cancelled',
					outs: [],
					color: '#80FF80'
				}
			},
			invpool: {
				customer: {
					label: 'customer',
					translation: 'Customer',
					outs: ['deinstall'],
					color: '#04D330'
				},
				install: {
					label: 'install',
					translation: 'Installed',
					outs: ['provider'],
					color: '#00A6F0'
				},
				deinstall: {
					label: 'deinstall',
					translation: 'Deinstalled',
					outs: ['customer'],
					color: '#00F8E8'
				},
				provider: {
					label: 'provider',
					translation: 'Resource',
					outs: ['install'],
					color: '#FFE43B'
				}
			}
		},
		mandatoryActionProperties: {},
		/**
		 * Which field shouldn't be editable
		 * 
		 * format: parent: { key: true|false }
		 */
		renderReadOnlyFieldsByParent: {
			data: {
				apiVersion: true,
				method: true,
				entity: true
			},
			resource: {
				pid: true,
				pname: true,
				gender: true
			}
		},
		/**
		 * Check for string is valid JSON
		 * 
		 * @param {*}
		 *            str - String that should be validated
		 * @returns {boolean}
		 * @private
		 */
		_isJson: function (str) {
			try {
				JSON.parse(str);
			} catch (e) {
				return false;
			}
			return true;
		},
		/**
		 * Return origin of URL (protocol + domain)
		 * 
		 * @param {String}
		 *            url
		 * @returns {String}
		 * @private
		 */
		_getOrigin: function (url) {
			if (url != '') {
				if (url.indexOf("://") > -1) {
					return 'https://' + url.split('/')[2];
				} else {
					return 'https://' + url.split('/')[0];
				}
			}
			return '';
		},
		/**
		 * Return domain of URL
		 * 
		 * @param {String}
		 *            url
		 * @returns {String}
		 * @private
		 */
		_getDomain: function (url) {
			if (url != '') {
				if (url.indexOf("://") > -1) {
					return url.split('/')[2];
				} else {
					return url.split('/')[0];
				}
			}
			return '';
		},
		//added for MPF Phase 4 - CHG0069304
		_getDomainURL: function () {
			//return document.referrer.match(/\:\/\/([^\/]+)\.etadirect\.com\//)[1];
			//Reg Ex modified to handle both etadirect.com and fs.ocs.oraclecloud.com URLs
			return document.referrer.match(/\:\/\/([^\/]+)\.(?:etadirect.com|fs.ocs.oraclecloud.com)/)[1];
		},
		/**
		 * Sends postMessage to document.referrer
		 * 
		 * @param {Object}
		 *            data - Data that will be sent
		 * @private
		 */
		_sendPostMessageData: function (data) {
			var originUrl = document.referrer || (document.location.ancestorOrigins &&
				document.location.ancestorOrigins[0]) || '';
			var isString = 'string' === typeof data;
			if (originUrl) {
				this._log(window.location.host + ' -> ' + (isString ? '' : data.method) + ' ' + this._getDomain(originUrl),
					isString ? data : JSON.stringify(data, null, 4));
				parent.postMessage(data, this._getOrigin(originUrl));
			} else {
				this._log(window.location.host + ' -> ' + (isString ? '' : data.method) + ' ERROR. UNABLE TO GET REFERRER');
			}
		},
		/**
		 * Handles during receiving postMessage
		 * 
		 * @param {MessageEvent}
		 *            event - Javascript event
		 * @private
		 */
		_getPostMessageData: function (event) {
			if (typeof event.data === 'undefined') {
				this._log(window.location.host + ' <- NO DATA ' + this._getDomain(event.origin), null, null, true);
				return false;
			}
			if (!this._isJson(event.data)) {
				this._log(window.location.host + ' <- NOT JSON ' + this._getDomain(event.origin), null, null, true);
				return false;
			}
			var data = JSON.parse(event.data);
			if (!data.method) {
				this._log(window.location.host + ' <- NO METHOD ' + this._getDomain(event.origin), null, null, true);
				return false;
			}
			this._log(window.location.host + ' <- ' + data.method + ' ' + this._getDomain(event.origin),
				JSON.stringify(data, null, 4));
			switch (data.method) {
				case 'init':
					this.pluginInitEnd(data);
					break;
				case 'open':
					this.pluginOpen(data);
					break;
				case 'wakeup':
					this.pluginWakeup(data);
					break;
				case 'error':
					data.errors = data.errors || {
						error: 'Unknown error'
					};
					//  this.processProcedureResult(document, event.data);
					this._showError(data.errors);
					break;
				case 'callProcedureResult':
					this.processProcedureResult(document, event.data);
					break;
				default:
					this.processProcedureResult(document, event.data);
					this._log(window.location.host + ' <- UNKNOWN METHOD: ' + data.method + ' ' +
						this._getDomain(event.origin), null, null, true);
					break;
			}
		},
		/**
		 * Show alert with error
		 * 
		 * @param {Object}
		 *            errorData - Object with errors
		 * @private
		 */
		_showError: function (errorData) {
			alert(JSON.stringify(errorData, null, 4));
		},
		/**
		 * Logs to console
		 * 
		 * @param {String}
		 *            title - Message that will be log
		 * @param {String}
		 *            [data] - Formatted data that will be collapsed
		 * @param {String}
		 *            [color] - Color in Hex format
		 * @param {Boolean}
		 *            [warning] - Is it warning message?
		 * 
		 * @private
		 */
		_log: function (title, data, color, warning) {
			if (!this.debugMode) {
				return;
			}
			if (!color) {
				color = '#0066FF';
			}
			if (!!data) {
				console.groupCollapsed('%c[Plugin API] ' + title, 'color: ' + color + '; ' + (!!warning ? 'font-weight: bold;' : 'font-weight: normal;'));
				console.log('[Plugin API] ' + data);
				console.groupEnd();
			} else {
				console.log('%c[Plugin API] ' + title, 'color: ' + color + '; ' + (!!warning ? 'font-weight: bold;' : ''));
			}
		},
		_getBlob: function (url) {
			return new Promise(function (resolve, reject) {
				var xhr = new XMLHttpRequest();
				xhr.responseType = 'blob';
				xhr.open('GET', url, true);
				xhr.onreadystatechange = function () {
					if (xhr.readyState === xhr.DONE) {
						if (200 == xhr.status || 201 == xhr.status) {
							try {
								return resolve(xhr.response);
							} catch (e) {
								return reject(e);
							}
						}
						return reject(new Error(
							'Server returned an error. HTTP Status: ' + xhr.status
						));
					}
				};
				xhr.send();
			});
		},
		/**
		 * Business login on plugin init
		 */
		saveToLocalStorage: function (data) {
			this._log(window.location.host + ' INIT. SET DATA TO LOCAL STORAGE', JSON.stringify(data, null, 4));
			var initData = {};
			$.each(data, function (key, value) {
				if (-1 !== $.inArray(key, ['apiVersion', 'method'])) {
					return true;
				}
				initData[key] = value;
			});
			localStorage.setItem('pluginInitData', JSON.stringify(initData));
		},
		/**
		 * Business login on plugin init end
		 * 
		 * @param {Object}
		 *            data - JSON object that contain data from OFSC
		 */
		pluginInitEnd: function (data) {
			this.saveToLocalStorage(data);
			var messageData = {
				apiVersion: 1,
				method: 'initEnd'
			};
			if (localStorage.getItem('pluginWakeupCount') < localStorage.getItem('pluginWakeupMaxCount')) {
				this._log(window.location.host + ' UNFINISHED WAKEUP DATA FOUND IN LOCAL STORAGE');
				messageData.wakeupNeeded = true;
			}
			this._sendPostMessageData(messageData);
		},
		/**
		 * Business login on plugin open
		 * 
		 * @param {Object}
		 *            receivedData - JSON object that contain data from OFSC
		 */
		pluginOpen: function (receivedData) {

			// Changes start for CHG0069304
			var domainName = this._getDomainURL();
			console.log("Domain Name - " + domainName);
			var errorLogs = receivedData.activity.A_PLUGIN_ERROR_LOG;
			var headers = {
				'Authorization':
					'Basic ' + btoa(receivedData.securedData.clientId + "@" + domainName + ":" + receivedData.securedData.clientSecret)
			};
			var actID = receivedData.activity.aid;
			$.ErrorUpdate = function (activityId, sErrorLogs) {
				this._sendPostMessageData({
					"apiVersion": 1,
					"method": "update",
					"activity": {
						"A_PLUGIN_ERROR_LOG": sErrorLogs,
						"aid": activityId
					}
				});
			}.bind(this);
			// Changes end for CHG0069304

			var g_showUsedItemsGird = false;
			var g_showdefectiveItemsGrid = false;

			if ("Recount" == receivedData.activity.A_PHYSICAL_INVENTORY_STAGE) {
				$("#phyinvUnderReviewSection").removeClass("cp_hidden");
				$("#cpf_PhysicalInventoryForm").addClass("cp_hidden");
			}

			$.buildUILayoutForSubInventories = function (customerInventory) {
				try {
					$.recalculateItemCostVariance = function (tableName) {
						var billingAmt = 0;
						var totTechCnt = 0,
							totSysQty = 0,
							totItemVariance = 0,
							totCostVariance = 0;
						$('table#' + tableName + ' tr.test-grid-row').each(function () {
							var itemVariance = $(this).find('#finalItemVariance').text();
							totItemVariance = totItemVariance + (isNaN(parseInt(itemVariance)) ? 0 : parseInt(itemVariance));
							var costVariance = $(this).find('#finalCostVariance').text();
							costVariance = costVariance.replace("$", "");
							costVariance = $.trim(costVariance);
							costVariance = parseFloat(costVariance);
							totCostVariance = totCostVariance + (isNaN(parseFloat(costVariance)) ? 0 : parseFloat(costVariance));

						});
						// Update the total.
						$('table#' + tableName).find(".totalFinalVariance").text(totItemVariance);
						// Update the total excluding the taxes.
						$('table#' + tableName).find(".totalFinalCostVariance").text("$" + totCostVariance.toFixed(2));
					};

					$.calculateItemLeft = function () {
						var sampleEnteredCount = 0;
						// get total count of Rows from both the tables-defective and used
						var totalRowsCount = Object.keys(customerInventory).length;
						$('table#cpf_ManagerGrid tr.test-grid-row').each(function () {
							var sampleExpectQty = $(this).find('#cpf_entered_qty').val();
							if (isNaN(parseInt(sampleExpectQty))) {
								// sample qty not entered.
							} else {
								// sample qty entered for that row.
								sampleEnteredCount++;
							}
						});
						$('table#cpf_ManagerGridDefective tr.test-grid-row').each(function () {
							var sampleExpectQty = $(this).find('#cpf_entered_qty').val();
							if (isNaN(parseInt(sampleExpectQty))) {
								// sample qty not entered.
							} else {
								// sample qty entered for that row.
								sampleEnteredCount++;
							}
						});
						var leftCount = Math.round(Math.max(totalRowsCount / 10 - sampleEnteredCount, 0));
						// Update the sampleCountLeft column.
						$('table#cpf_ManagerGrid').find(".sampleCountLeft").text(leftCount + " left");
						$('table#cpf_ManagerGridDefective').find(".sampleCountLeft").text(leftCount + " left");
					};

					$.each(customerInventory, function (key, invItem) {
						if (invItem.inv_aid == receivedData.activity.aid) {
							var bindVar = this;
							var highlightRow = "";
							var subtractVariance = 0;
							var sysQty = 0;
							if ("true" != invItem.I_CREATED_FLAG) {
								sysQty = invItem.quantity;
							}
							if (invItem.I_EXPECT_QUANTITY && invItem.I_EXPECT_QUANTITY != "") {
								subtractVariance = invItem.I_EXPECT_QUANTITY;
							} else {
								subtractVariance = invItem.I_USED_QUANTITY;
							}
							var itemVariance = parseInt(subtractVariance) - parseInt(sysQty);
							var costVariance = itemVariance * parseFloat(invItem.I_ITEM_COST);
							costVariance = parseFloat(costVariance).toFixed(2);

							if (isNaN(costVariance)) {
								costVariance = 0.00;
							}
							if (isNaN(itemVariance)) {
								itemVariance = 0.00;
							}

							if (invItem.I_RECOUNT == "Y" || invItem.I_RECOUNT == "M") {
								highlightRow = "grid-row-highlight-tech";
							}
							if (invItem.I_RECOUNT == "N") {
								highlightRow = "";
							}
							var itemDescription = "";
							if (invItem.I_ITEM_DESCRIPTION) {
								itemDescription = invItem.I_ITEM_DESCRIPTION;
							}

							var itemExpectedQty = "";
							if (invItem.I_EXPECT_QUANTITY) {
								itemExpectedQty = invItem.I_EXPECT_QUANTITY;
							}
							var itemUsedQty = "";
							if (invItem.I_USED_QUANTITY) {
								itemUsedQty = invItem.I_USED_QUANTITY;
							}

							/*
							 * Changed to add item_cost. CHG0062367 OFSC
							 * Mobility
							 */
							var row = '<tr id="' + invItem.I_INVENTORY_KEY.replace(/[/]/g, "") + '" class="test-grid-row grid-row-highlight ' + highlightRow + '">\
	            			<td class="cp_hidden cpf_1-0"> <div class="grid-row-highlight"></div></td>\
	            			<td class=" cpf_1-1"><strong class="part-number">' + invItem.I_ITEM_NUMBER + '</strong>\
	            			<span class="part-description">' + itemDescription + '</span>\
	            			<span id="inventoryId" class="cp_hidden">' + invItem.invid + '</span>\
	            			</td>\
	            			<td id="techCount" class="al-right cpf_1-2">' + invItem.I_USED_QUANTITY + '</td>\
	            			<td id="itemCost" class="al-right cpf_1-3">$' + invItem.I_ITEM_COST + '</td>\
	            			<td id="sysQty" class="al-right cpf_1-4">' + sysQty + '</td>\
	            			<td id="itemVariance" class="al-right cpf_1-5">' + itemVariance + '</td>\
	            			<td id="costVariance" class="al-right cpf_1-6">$' + costVariance + '</td>\
	            			<td class="recount-select-item cpf_1-7">\
	            			<div id="cpf__unnamed_6" class="cp_field">\
	            			<div class="cp_field_row">\
	            			<div class="cp_field_label"><span class="cp_field_label_text"></span></div>\
	            			<div class="cp_field_ismandatory"></div>\
	            			<div class="cp_field_value"><input id="cpf_used_qty_cb" type="checkbox" class="cp_field_checkbox_component form-item"></div>\
	            			</div>\
	            			</div>\
	            			</td>\
	            			<td class="sample-count cpf_1-8">\
	            			<div id="cpf__unnamed_7" class="cp_field order-parts-order-quantity">\
	            			<div class="cp_field_row">\
	            			<div class="cp_field_value cp_fullsize">\
	            			<div class="cp_field_value_inner_wrapper">\
	            			<input id="cpf_button_decrease" type="button" class="cpf-spinner-button-decrease button" value="-">\
	            			<input id="cpf_entered_qty" type="text" class="cp_field_text_component cp_field_spinner_component form-item" value="'+ itemExpectedQty + '">\
	            			<input id="cpf_button_increase" type="button" class="cpf-spinner-button-increase button" value="+">\
	            			<div class="cp_error_label" id="cpf__unnamed_7_error"></div>\
	            			</div>\
	            			</div>\
	            			</div>\
	            			</div>\
	            			</td>\
	            			<td id="finalItemVariance" class="al-right cpf_1-9">' + itemVariance + '</td>\
	            			<td id="finalCostVariance" class="al-right cpf_1-10">$' + costVariance + '</td>\
	            			</tr>';
							if (invItem.I_DEFECTIVE == "N") {
								// Used
								$('#cpf_ManagerGrid').append(row);
								$("#managerGridSubInventoryName").text(invItem.I_SUBINVENTORY_NAME);
								g_showUsedItemsGird = true;
							} else {
								// Defective.
								$('#cpf_ManagerGridDefective').append(row);
								$("#managerGridDefSubInventoryName").text(invItem.I_SUBINVENTORY_NAME);
								g_showdefectiveItemsGrid = true;
							}

							// Increase and decrease qty.
							$("#" + invItem.I_INVENTORY_KEY.replace(/[/]/g, "")).on('click', '#cpf_button_decrease', function () {   // change
								var itemNumber = bindVar.I_ITEM_NUMBER;
								var itemKey = bindVar.I_INVENTORY_KEY;
								var itemQty = bindVar.quantity;
								var techCountUsedQty = bindVar.I_USED_QUANTITY;
								var cpfEnteredQty = $(this).next();
								var prevValue = cpfEnteredQty.val();
								if (isNaN(prevValue) || prevValue.indexOf(' ') >= 0 || prevValue === "") {
									cpfEnteredQty.val(0);
								} else {
									cpfEnteredQty.val(parseInt(prevValue));
								}
								prevValue = cpfEnteredQty.val();
								var incCount = parseInt(prevValue);

								if (incCount <= 0) {
									cpfEnteredQty.val(0);
								} else {
									incCount -= 1;
									cpfEnteredQty.val(incCount);
								}
								var tableGrid;
								if (bindVar.I_DEFECTIVE == "N") {
									tableGrid = "cpf_ManagerGrid";
								} else {
									tableGrid = "cpf_ManagerGridDefective";
								}
								var subtractVariance = 0;
								if (cpfEnteredQty.val() && cpfEnteredQty.val() != "") {
									subtractVariance = cpfEnteredQty.val();
								} else {
									subtractVariance = techCountUsedQty;
								}
								var itemVariance;// = parseInt(subtractVariance) - parseInt(itemQty);

								if ("true" != invItem.I_CREATED_FLAG) {
									itemVariance = parseInt(subtractVariance) - parseInt(itemQty);
								} else {
									itemVariance = parseInt(subtractVariance); //+ parseInt(itemQty);
								}

								if (isNaN(itemVariance)) {
									itemVariance = 0;
								}
								$("#" + itemKey.replace(/[/]/g, "")).find("#finalItemVariance").text(itemVariance);
								var newcostVariance = itemVariance * parseFloat(bindVar.I_ITEM_COST);
								if (isNaN(newcostVariance)) {
									newcostVariance = 0.00;
								}
								$("#" + itemKey.replace(/[/]/g, "")).find("#finalCostVariance").text("$" + newcostVariance.toFixed(2)); // .replace(/[/]/g,"")
								$.recalculateItemCostVariance(tableGrid);
								$.calculateItemLeft();
							});
							$("#" + invItem.I_INVENTORY_KEY.replace(/[/]/g, "")).on('click', '#cpf_button_increase', function (e) {  // change
								var totalQty = bindVar.quantity;
								var itemNumber = bindVar.I_ITEM_NUMBER;
								var itemKey = bindVar.I_INVENTORY_KEY;
								var itemQty = bindVar.quantity;
								var techCountUsedQty = bindVar.I_USED_QUANTITY;
								var cpfEnteredQty = $(this).prev();
								var prevValue = cpfEnteredQty.val();
								var totalEnteredQuantity = 0;
								var tableGrid;
								if (isNaN(prevValue) || prevValue.indexOf(' ') >= 0 || prevValue === "") {
									cpfEnteredQty.val(0);
								} else {
									cpfEnteredQty.val(parseInt(prevValue));
								}
								prevValue = cpfEnteredQty.val();
								var incCount = parseInt(prevValue);
								if (isNaN(incCount)) {
									cpfEnteredQty.val(1);
								} else if (incCount < 0) {
									cpfEnteredQty.val(0);
								} else {
									incCount += 1;
									cpfEnteredQty.val(incCount);
								}
								if (bindVar.I_DEFECTIVE == "N") {
									tableGrid = "cpf_ManagerGrid";
								} else {
									tableGrid = "cpf_ManagerGridDefective";
								}
								var subtractVariance = 0;
								if (cpfEnteredQty.val() && cpfEnteredQty.val() != "") {
									subtractVariance = cpfEnteredQty.val();
								} else {
									subtractVariance = techCountUsedQty;
								}
								var itemVariance;
								if ("true" != invItem.I_CREATED_FLAG) {
									itemVariance = parseInt(subtractVariance) - parseInt(itemQty);
								} else {
									itemVariance = parseInt(subtractVariance); //+ parseInt(itemQty);
								}
								if (isNaN(itemVariance)) {
									itemVariance = 0;
								}
								$("#" + itemKey.replace(/[/]/g, "")).find("#finalItemVariance").text(itemVariance);
								var newcostVariance = itemVariance * parseFloat(bindVar.I_ITEM_COST);
								if (isNaN(newcostVariance)) {
									newcostVariance = 0;
								}
								$("#" + itemKey.replace(/[/]/g, "")).find("#finalCostVariance").text("$" + newcostVariance.toFixed(2));  // .replace(/[/]/g,"")
								$.recalculateItemCostVariance(tableGrid);
								$.calculateItemLeft();
							});
							$("#" + invItem.I_INVENTORY_KEY.replace(/[/]/g, "")).on("change paste keyup", "#cpf_entered_qty", function () {  // change
								var enteredVal = $(this).val();
								if (enteredVal.length > 7) {
									$(this).val(9999999);

								}
								if (isNaN(enteredVal) || enteredVal.indexOf(' ') >= 0) {
									$(this).val(0);
								} else {
									if (enteredVal === "") {
									} else {
										$(this).val(parseInt(enteredVal));
									}
								}
								enteredVal = $(this).val();
								var itemNumber = bindVar.I_ITEM_NUMBER;
								var itemKey = bindVar.I_INVENTORY_KEY;
								var itemQty = bindVar.quantity;
								var techCountUsedQty = bindVar.I_USED_QUANTITY;
								var calculateOrigVar = false;
								if (enteredVal == "") {
									if ("true" != invItem.I_CREATED_FLAG) {
										itemVariance = parseInt(bindVar.I_USED_QUANTITY) - parseInt(bindVar.quantity);
									} else {
										itemVariance = parseInt(bindVar.I_USED_QUANTITY);
									}
								} else {
									if ("true" != invItem.I_CREATED_FLAG) {
										itemVariance = parseInt(enteredVal) - parseInt(itemQty);
									} else {
										itemVariance = parseInt(enteredVal);
									}
								}
								var tableGrid;
								if (bindVar.I_DEFECTIVE == "N") {
									tableGrid = "cpf_ManagerGrid";
								} else {
									tableGrid = "cpf_ManagerGridDefective";
								}
								if (isNaN(itemVariance)) {
									itemVariance = 0;
								}
								$("#" + itemKey.replace(/[/]/g, "")).find("#finalItemVariance").text(itemVariance);
								var newcostVariance = itemVariance * parseFloat(bindVar.I_ITEM_COST);
								if (isNaN(newcostVariance)) {
									newcostVariance = 0.00;
								}
								$("#" + itemKey.replace(/[/]/g, "")).find("#finalCostVariance").text("$" + newcostVariance.toFixed(2)); // .replace(/[/]/g,"")
								$.recalculateItemCostVariance(tableGrid);
								$.calculateItemLeft();
							});
							// Recount checkbox
							$("#" + invItem.I_INVENTORY_KEY.replace(/[/]/g, "")).on("change", "#cpf_used_qty_cb", function () {   // change
								var recountUsedArr = [];
								var recountDefectiveArr = [];
								var checkValue = this.checked;
								if (checkValue) {
									$('table#cpf_ManagerGrid tr.test-grid-row').each(function () {
										recountUsedArr.push($(this).find("#cpf_used_qty_cb").prop('checked'));
									});
									$('table#cpf_ManagerGridDefective tr.test-grid-row').each(function () {
										recountDefectiveArr.push($(this).find("#cpf_used_qty_cb").prop('checked'));
									});
								} else {
									$('table#cpf_ManagerGrid tr.test-grid-row').each(function () {
										recountUsedArr.push($(this).find("#cpf_used_qty_cb").prop('checked'));
									});
									$('table#cpf_ManagerGridDefective tr.test-grid-row').each(function () {
										recountDefectiveArr.push($(this).find("#cpf_used_qty_cb").prop('checked'));
									});
								}
								var isPresentUsedRecount = $.inArray(true, recountUsedArr);
								var isPresentDefectiveRecount = $.inArray(true, recountDefectiveArr);
								if (isPresentUsedRecount == -1 && isPresentDefectiveRecount == -1) {
									// Recount items not found.
									$("#cpf_Approve_Submit_Btn").prop("disabled", false);
									$("#cpf_Recount_Btn").prop("disabled", true);
								} else {
									// Recount Items exist.
									$("#cpf_Approve_Submit_Btn").prop("disabled", true);
									$("#cpf_Recount_Btn").prop("disabled", false);
								}
							});
						}
					});

					var total_row_Used = '<tr id="cpf_ManagerGrid_footer" class="test-grid-footer">\
	            			<td class="footer cpf_1-0" style="">Totals</td>\
	            			<td id="totalTechCount" class="footer al-right cpf_1-1" style=""></td>\
	            			<td id="totalItemCost" class="footer al-right cpf_1-2" style=""></td>\
	            			<td id="totalSystemQty" class="footer al-right cpf_1-3" style=""></td>\
	            			<td id="totalItemVariance" class="footer al-right cpf_1-4" style=""></td>\
	            			<td id="totalCostVariance" class="footer al-right cpf_1-5" style=""></td>\
	            			<td colspan="2" class="sampleCountLeft footer al-right cpf_1-6" style=""></td>\
	            			<td class="totalFinalVariance footer al-right cpf_1-7" style=""></td>\
	            			<td class="totalFinalCostVariance footer al-right cpf_1-8" style=""></td>\
	            			</tr>';
					$('#cpf_ManagerGrid').append(total_row_Used);

					var total_row_Defective = '<tr id="cpf_ManagerGridDefective_footer" class="test-grid-footer">\
	            			<td class="footer cpf_3-0" style="">Totals</td>\
	            			<td id="totalTechCount" class="footer al-right cpf_3-1" style=""></td>\
	            			<td id="totalItemCost" class="footer al-right cpf_3-2" style=""></td>\
	            			<td id="totalSystemQty" class="footer al-right cpf_3-3" style=""></td>\
	            			<td id="totalItemVariance" class="footer al-right cpf_3-4" style=""></td>\
	            			<td id="totalCostVariance" class="footer al-right cpf_3-5" style=""></td>\
	            			<td colspan="2" class="sampleCountLeft footer al-right cpf_3-6" style=""></td>\
	            			<td class="totalFinalVariance footer al-right cpf_3-7" style=""></td>\
	            			<td class="totalFinalCostVariance footer al-right cpf_3-8" style=""></td>\
	            			</tr>';
					$('#cpf_ManagerGridDefective').append(total_row_Defective);

					// Used items total calculations..
					var totTechCnt = 0,
						totItemCost = 0,
						totSysQty = 0,
						totItemVariance = 0,
						totCostVariance = 0;
					$('table#cpf_ManagerGrid tr.test-grid-row').each(function () {
						var techCount = $(this).find('#techCount').text();
						totTechCnt = totTechCnt + (isNaN(parseInt(techCount)) ? 0 : parseInt(techCount));
						var sysQty = $(this).find('#sysQty').text();
						totSysQty = totSysQty + (isNaN(parseInt(sysQty)) ? 0 : parseInt(sysQty));
						var itemVariance = $(this).find('#itemVariance').text();
						totItemVariance = totItemVariance + (isNaN(parseInt(itemVariance)) ? 0 : parseInt(itemVariance));
						var costVariance = $(this).find('#costVariance').text();
						costVariance = costVariance.replace("$", "");
						costVariance = $.trim(costVariance);
						costVariance = parseFloat(costVariance);
						totCostVariance = totCostVariance + (isNaN(parseFloat(costVariance)) ? 0 : parseFloat(costVariance));
						var itemCost = $(this).find('#itemCost').text();
						itemCost = itemCost.replace("$", "");
						itemCost = $.trim(itemCost);
						itemCost = parseFloat(itemCost);
						totItemCost = totItemCost + (isNaN(parseFloat(itemCost)) ? 0 : parseFloat(itemCost));
					});

					$("table#cpf_ManagerGrid").find("#totalTechCount").text(totTechCnt);
					$("table#cpf_ManagerGrid").find("#totalItemCost").text("$" + totItemCost.toFixed(2));
					$("table#cpf_ManagerGrid").find("#totalSystemQty").text(totSysQty);
					$("table#cpf_ManagerGrid").find("#totalItemVariance").text(totItemVariance);
					$("table#cpf_ManagerGrid").find("#totalCostVariance").text("$" + totCostVariance.toFixed(2));
					$("table#cpf_ManagerGrid").find(".totalFinalVariance").text(totItemVariance);
					$("table#cpf_ManagerGrid").find(".totalFinalCostVariance").text("$" + totCostVariance.toFixed(2));
					$.calculateItemLeft();

					/* CHG0065955 Alert Text at top of Manage Screen */
					/* CHG0070856 */
					if (totTechCnt == 0 && g_showUsedItemsGird) {
						$("#cpf_ManagerGrid").prepend('<tr class=\"test-grid-footer\">' + $("#cpf_ManagerGrid_footer").clone().html() + '</tr>' + '<tr><td><br></td></tr>');
						$("#cpf_ManagerGridSubInventoryName").append('<span style=\"color:red\">&nbsp;WARNING - Tech has entered zero for all counts.  Send to Tech for recount if appropriate.<br><br>');
					}
					/* CHG0070856 end */
					/* CHG0065955 end */

					var totTechCnt = 0,
						totItemCost = 0,
						totSysQty = 0,
						totItemVariance = 0,
						totCostVariance = 0;
					$('table#cpf_ManagerGridDefective tr.test-grid-row').each(function () {
						var techCount = $(this).find('#techCount').text();
						totTechCnt = totTechCnt + (isNaN(parseInt(techCount)) ? 0 : parseInt(techCount));
						var sysQty = $(this).find('#sysQty').text();
						totSysQty = totSysQty + (isNaN(parseInt(sysQty)) ? 0 : parseInt(sysQty));
						var itemVariance = $(this).find('#itemVariance').text();
						totItemVariance = totItemVariance + (isNaN(parseInt(itemVariance)) ? 0 : parseInt(itemVariance));
						var costVariance = $(this).find('#costVariance').text();
						costVariance = costVariance.replace("$", "");
						costVariance = $.trim(costVariance);
						costVariance = parseFloat(costVariance);
						totCostVariance = totCostVariance + (isNaN(parseFloat(costVariance)) ? 0 : parseFloat(costVariance));
						var itemCost = $(this).find('#itemCost').text();
						itemCost = itemCost.replace("$", "");
						itemCost = $.trim(itemCost);
						itemCost = parseFloat(itemCost);
						totItemCost = totItemCost + (isNaN(parseFloat(itemCost)) ? 0 : parseFloat(itemCost));
					});

					$("table#cpf_ManagerGridDefective").find("#totalTechCount").text(totTechCnt);
					$("table#cpf_ManagerGridDefective").find("#totalItemCost").text("$" + totItemCost.toFixed(2));
					$("table#cpf_ManagerGridDefective").find("#totalSystemQty").text(totSysQty);
					$("table#cpf_ManagerGridDefective").find("#totalItemVariance").text(totItemVariance);
					$("table#cpf_ManagerGridDefective").find("#totalCostVariance").text("$" + totCostVariance.toFixed(2));
					$("table#cpf_ManagerGridDefective").find(".totalFinalVariance").text(totItemVariance);
					$("table#cpf_ManagerGridDefective").find(".totalFinalCostVariance").text("$" + totCostVariance.toFixed(2));
					$.calculateItemLeft();

					// decide whether to display the tables:
					if (!g_showdefectiveItemsGrid) {
						// hide the defective grid
						$("#cpf_ManagerGridDefective").addClass("cp_hidden");
					}

					if (!g_showUsedItemsGird) {
						// hide the usable grid
						$("#cpf_ManagerGrid").addClass("cp_hidden");
					}
				} catch (err) {
					console.log("buildUILayoutForSubInventories- Error messagae: " + err.message)

				}
			};



			// Holds only customer inventories, as per the setup in ready method
			$.buildUILayoutForSubInventories(receivedData.inventoryList);

			$('input[type=checkbox][id=cpf_ManagerGridNormalSelectAll_inner]').change(function () {
				var checkValue = this.checked;
				if (checkValue) {
					$('table#cpf_ManagerGrid tr.test-grid-row').each(function () {
						$(this).find("#cpf_used_qty_cb").prop('checked', checkValue);
					});
					$("#cpf_Approve_Submit_Btn").prop("disabled", true);
					$("#cpf_Recount_Btn").prop("disabled", false);
				} else {
					$('table#cpf_ManagerGrid tr.test-grid-row').each(function () {
						$(this).find("#cpf_used_qty_cb").prop('checked', checkValue);
					});
					$("#cpf_Approve_Submit_Btn").prop("disabled", false);
					$("#cpf_Recount_Btn").prop("disabled", true);
				}
			});

			$('input[type=checkbox][id=cpf_ManagerGridDefectiveSelectAll_inner]').change(function () {
				var checkValue = this.checked;
				if (checkValue) {
					$('table#cpf_ManagerGridDefective tr.test-grid-row').each(function () {
						$(this).find("#cpf_used_qty_cb").prop('checked', checkValue);
					});
					$("#cpf_Approve_Submit_Btn").prop("disabled", true);
					$("#cpf_Recount_Btn").prop("disabled", false);
				} else {
					$('table#cpf_ManagerGridDefective tr.test-grid-row').each(function () {
						$(this).find("#cpf_used_qty_cb").prop('checked', checkValue);
					});
					$("#cpf_Approve_Submit_Btn").prop("disabled", false);
					$("#cpf_Recount_Btn").prop("disabled", true);
				}
			});
			/// Manage Plugin Submit action - Approve and submit

			$("#cpf_Approve_Submit_Btn").click(function () {
				try {
					$("#cpf_Approve_Submit_Btn").prop("disabled", true);
					//validation for 10% entered.
					//Quantity of Lines on the screen/10 <=  Quantity of Lines with not empty Sample Count
					//If validation failed then show message ‘You must review 1 more row(s) in order to proceed’.
					var usedRowCount = $('#cpf_ManagerGrid tr').length - 2;
					var defectiveRowCount = $('#cpf_ManagerGridDefective tr').length - 2;
					var totalRows = usedRowCount + defectiveRowCount;
					var totalEnteredSampleCount = 0;
					var technicianPushInventoriesArr = {};
					///////////inventory loop///
					$('table#cpf_ManagerGrid tr.test-grid-row').each(function () {
						var inventoryId = $(this).find("#inventoryId").text();
						var sysQty = $(this).find("#sysQty").text(); // system qty
						var usedQty = $(this).find("#techCount").text(); //used qty
						var expectedQty = $(this).find("#cpf_entered_qty").val(); // expected qty
						var irecount = "N";
						var iadjustmentFlag = "";
						var cpf_used_qty_cb = $(this).find("#cpf_used_qty_cb").prop('checked'); // if true -- I RECOUNT = Y
						if (cpf_used_qty_cb) {
							irecount = "Y";
						}

						// compute I adjustment flag.
						if (expectedQty == "") {
							expectedQty = usedQty;   // change done for PI variance  issue INC1575366
							if (usedQty == sysQty) {
								iadjustmentFlag = "N";
							} else {
								iadjustmentFlag = "Y";
							}
						} else {
							totalEnteredSampleCount++;
							if (expectedQty == sysQty) {
								iadjustmentFlag = "N";
							} else {
								iadjustmentFlag = "Y";
							}
						}

						$.extend(technicianPushInventoriesArr, {
							[inventoryId]: {
								"invid": inventoryId,
								"invpool": "customer",
								"inv_aid": receivedData.activity.aid,
								"I_RECOUNT": irecount,
								"I_EXPECT_QUANTITY": expectedQty,
								"I_ADJUSTMENT_FLAG": iadjustmentFlag
							}
						});
					});
					$('table#cpf_ManagerGridDefective tr.test-grid-row').each(function () {
						var inventoryId = $(this).find("#inventoryId").text();
						var sysQty = $(this).find("#sysQty").text(); // system qty
						var usedQty = $(this).find("#techCount").text(); //used qty
						var expectedQty = $(this).find("#cpf_entered_qty").val(); // expected qty
						var irecount = "N";
						var iadjustmentFlag = "";
						var cpf_used_qty_cb = $(this).find("#cpf_used_qty_cb").prop('checked'); // if true -- I RECOUNT = Y
						if (cpf_used_qty_cb) {
							irecount = "Y";
						}

						// compute I adjustment flag.
						if (expectedQty == "") {
							expectedQty = usedQty;   // change done for PI variance  issue INC1575366
							if (usedQty == sysQty) {
								iadjustmentFlag = "N";
							} else {
								iadjustmentFlag = "Y";
							}
						} else {
							totalEnteredSampleCount++;
							if (expectedQty == sysQty) {
								iadjustmentFlag = "N";
							} else {
								iadjustmentFlag = "Y";
							}
						}
						$.extend(technicianPushInventoriesArr, {
							[inventoryId]: {
								"invid": inventoryId,
								"invpool": "customer",
								"inv_aid": receivedData.activity.aid,
								"I_RECOUNT": irecount,
								"I_EXPECT_QUANTITY": expectedQty,
								"I_ADJUSTMENT_FLAG": iadjustmentFlag
							}
						});
					});
					console.log("technicianPushInventoriesArr :" + JSON.stringify(technicianPushInventoriesArr));

					if (($('table#cpf_ManagerGrid').is(":visible") && $('table#cpf_ManagerGrid').find("#totalTechCount").text() == 0) ||
						($('table#cpf_ManagerGridDefective').is(":visible") && $('table#cpf_ManagerGridDefective').find("#totalTechCount").text() == 0)) {
						if (confirm('Tech has submitted zero for all counts, are you sure you want to submit Y/N?')) {
						} else {
							$("#cpf_Approve_Submit_Btn").prop("disabled", false);
							return false;
						}
					}

					if (!(totalRows / 10 <= totalEnteredSampleCount)) {
						var leftCount = Math.round(Math.max(totalRows / 10 - totalEnteredSampleCount, 0));
						if (leftCount > 0) {
							alert("You must review " + leftCount + " more row(s) in order to proceed.");
							$("#cpf_Approve_Submit_Btn").prop("disabled", false);
							return false;
						}
					}
					var usedTotalCostVariance = $('table#cpf_ManagerGrid').find(".totalFinalCostVariance").text();
					usedTotalCostVariance = usedTotalCostVariance.replace("$", "");
					usedTotalCostVariance = $.trim(usedTotalCostVariance);
					usedTotalCostVariance = parseFloat(usedTotalCostVariance);

					var defectiveTotalCostVariance = $('table#cpf_ManagerGridDefective').find(".totalFinalCostVariance").text();
					defectiveTotalCostVariance = defectiveTotalCostVariance.replace("$", "");
					defectiveTotalCostVariance = $.trim(defectiveTotalCostVariance);
					defectiveTotalCostVariance = parseFloat(defectiveTotalCostVariance);

					if (defectiveTotalCostVariance != 0 || usedTotalCostVariance != 0) {
						if (confirm('A variance exists, do you wish to proceed with submitting the Physical Inventory? \n Click Ok to continue?')) {
						} else {
							$("#cpf_Approve_Submit_Btn").prop("disabled", false);
							return false;
						}
					}
					var aFinalTotalVariance = parseFloat(usedTotalCostVariance + defectiveTotalCostVariance).toFixed(2);

					var nowDate = new Date();
					var date = nowDate.toISOString().split('T')[0];

					var payload = {
						"pluginName": "PI-PhysicalInventoryManage",
						"instanceName": receivedData.securedData.company,
						"activityId": receivedData.activity.aid + "",
						"resourceId": receivedData.resource.external_id + "",
					};
					var activityId = receivedData.activity.aid;
					this._sendPostMessageData({
						"apiVersion": 1,
						"method": "close",
						"backScreen": "default",
						"backActivityId": receivedData.activity.aid,
						"wakeupNeeded": false,
						"activity": {
							"aid": receivedData.activity.aid,
							"A_PHYSICAL_INVENTORY_STAGE": "Done",
							"A_TOTAL_COST_VARIANCE": aFinalTotalVariance,
							"astatus": "complete",
						},
						"inventoryList": technicianPushInventoriesArr
					});
				} catch (err) {
					console.log("Approve and Sumbit action- Error messagae: " + err.message);
					var now = new Date(Date.now());
					if (errorLogs == null) {
						errorLogs = "";
					}
					errorLogs = errorLogs + "||" + now.toString() + "|Plugin :PhysicalInventoryManage |Error Details:" + err.message;
					console.log(errorLogs);
					$.ErrorUpdate(actID, errorLogs);
				}
			}.bind(this));

			/// Manage Plugin Recount action -
			$("#cpf_Recount_Btn").click(function () {
				try {
					$("#cpf_Recount_Btn").prop("disabled", true);
					var technicianPushInventoriesArr = {};
					$('table#cpf_ManagerGrid tr.test-grid-row').each(function () {
						var inventoryId = $(this).find("#inventoryId").text();
						var sysQty = $(this).find("#sysQty").text(); // system qty
						var usedQty = $(this).find("#techCount").text(); //used qty
						var expectedQty = $(this).find("#cpf_entered_qty").val(); // expected qty
						var irecount = "N";
						var iadjustmentFlag = "";
						var cpf_used_qty_cb = $(this).find("#cpf_used_qty_cb").prop('checked'); // if true -- I RECOUNT = Y
						if (cpf_used_qty_cb) {
							irecount = "Y";
						}

						// compute I adjustment flag.
						if (expectedQty == "") {
							if (usedQty == sysQty) {
								iadjustmentFlag = "N";
							} else {
								iadjustmentFlag = "Y";
							}
						} else {
							if (expectedQty == sysQty) {
								iadjustmentFlag = "N";
							} else {
								iadjustmentFlag = "Y";
							}
						}

						$.extend(technicianPushInventoriesArr, {
							[inventoryId]: {
								"invid": inventoryId,
								"invpool": "customer",
								"inv_aid": receivedData.activity.aid,
								"I_RECOUNT": irecount,
								"I_EXPECT_QUANTITY": expectedQty,
								"I_ADJUSTMENT_FLAG": iadjustmentFlag
							}
						});

					});
					$('table#cpf_ManagerGridDefective tr.test-grid-row').each(function () {
						var inventoryId = $(this).find("#inventoryId").text();
						var sysQty = $(this).find("#sysQty").text(); // system qty
						var usedQty = $(this).find("#techCount").text(); //used qty
						var expectedQty = $(this).find("#cpf_entered_qty").val(); // expected qty
						var irecount = "N";
						var iadjustmentFlag = "";
						var cpf_used_qty_cb = $(this).find("#cpf_used_qty_cb").prop('checked'); // if true -- I RECOUNT = Y
						if (cpf_used_qty_cb) {
							irecount = "Y";
						}

						// compute I adjustment flag.

						if (expectedQty == "") {
							if (usedQty == sysQty) {
								iadjustmentFlag = "N";
							} else {
								iadjustmentFlag = "Y";
							}
						} else {
							if (expectedQty == sysQty) {
								iadjustmentFlag = "N";
							} else {
								iadjustmentFlag = "Y";
							}
						}

						$.extend(technicianPushInventoriesArr, {
							[inventoryId]: {
								"invid": inventoryId,
								"invpool": "customer",
								"inv_aid": receivedData.activity.aid,
								"I_RECOUNT": irecount,
								"I_EXPECT_QUANTITY": expectedQty,
								"I_ADJUSTMENT_FLAG": iadjustmentFlag
							}
						});
					});
					console.log("technicianPushInventoriesArr :" + JSON.stringify(technicianPushInventoriesArr));

					var nowDate = new Date();
					var date = nowDate.toISOString().split('T')[0];
					var activityId = receivedData.activity.aid;
					var payload = {
						"pluginName": "PI-PhysicalInventoryManage",
						//"resourceId":receivedData.resource.external_id+"",
						"activityId": parseInt(activityId),
						"requestType": receivedData.securedData.requestType,
						"requestEntity": "ACTIVITY",
						"date": date,
						"instanceName": receivedData.securedData.company
					};


					var serviceRequestUrl = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/serviceRequests";
					console.log("Main API - Activity Inventory UPDATE and SR creation trigger- input JSON Payload:" + JSON.stringify(payload));
					$.ajax({
						url: serviceRequestUrl,
						type: "POST",
						data: JSON.stringify(payload),
						dataType: 'json',
						processData: false,
						async: false,
						crossDomain: true,
						headers: headers,
						contentType: 'application/json; charset=utf-8',
						success: function (data) {
							console.log('REST CALL FOR - serviceRequests -- SUCCESS:' + JSON.stringify(data));
						}.bind(this),
						error: function (response) {
							console.log('REST CALL FOR - serviceRequests -- FAILURE:' + JSON.stringify(response));
							var now = new Date(Date.now());
							var errorDetails = response.responseJSON;
							var eDetail = errorDetails.detail.replace(/(\r\n|\n|\r)/gm, " ");
							var eStatus = errorDetails.status;
							if (errorLogs == null) {
								errorLogs = "";
							}
							errorLogs = errorLogs + "||" + now.toString() + "|Plugin :PhysicalInventoryManage " + "| URL:" + serviceRequestUrl.toString() + "|Error Status:" + eStatus + "|Error Details:" + eDetail;
							console.log(errorLogs);
							$.ErrorUpdate(activityId, errorLogs);
						}
					});
					this._sendPostMessageData({
						"apiVersion": 1,
						"method": "close",
						"backScreen": "default",
						"wakeupNeeded": false,
						"activity": {
							"aid": receivedData.activity.aid,
							"A_TOTAL": "0",
							"A_SE_TOTAL": "0",
							"A_PHYSICAL_INVENTORY_STAGE": "Recount"
						},
						"inventoryList": technicianPushInventoriesArr
					});
				} catch (err) {
					console.log("Approve and Sumbit action- Error messagae: " + err.message);
					var now = new Date(Date.now());
					var errorDetails = response.responseJSON;
					var eDetail = errorDetails.detail.replace(/(\r\n|\n|\r)/gm, " ");
					var eStatus = errorDetails.status;
					if (errorLogs == null) {
						errorLogs = "";
					}
					errorLogs = errorLogs + "||" + now.toString() + "|Plugin :PhysicalInventoryManage " + "| URL:" + serviceRequestUrl.toString() + "|Error Status:" + eStatus + "|Error Details:" + eDetail;
					console.log(errorLogs);
					$.ErrorUpdate(activityId, errorLogs);
				}
			}.bind(this));

			this.initAddButtons(document);
		},
		/**
		 * Business login on plugin wakeup (background open for sync)
		 * 
		 * @param {Object}
		 *            receivedData - JSON object that contain data from OFSC
		 */
		pluginWakeup: function (receivedData) {
			this._log(window.location.host + ' WAKEUP', JSON.stringify(receivedData, null, 4));
			var wakeupData = {
				pluginWakeupCount: +localStorage.getItem('pluginWakeupCount'),
				pluginWakeupMaxCount: +localStorage.getItem('pluginWakeupMaxCount'),
				pluginWakeupDontRespondOn: +localStorage.getItem('pluginWakeupDontRespondOn'),
				pluginWakeupChangeIcon: JSON.parse(localStorage.getItem('pluginWakeupChangeIcon'))
			};
			wakeupData.pluginWakeupCount = wakeupData.pluginWakeupCount + 1;
			localStorage.setItem('pluginWakeupCount', wakeupData.pluginWakeupCount);
			localStorage.setItem('pluginWakeupMaxCount', wakeupData.pluginWakeupMaxCount);
			localStorage.setItem('pluginWakeupDontRespondOn', wakeupData.pluginWakeupDontRespondOn);
			localStorage.setItem('pluginWakeupChangeIcon', wakeupData.pluginWakeupChangeIcon);
			this._log(window.location.host + ' SAVE WAKEUP DATA TO LOCAL STORAGE', JSON.stringify(wakeupData, null,
				4));
			if (wakeupData.pluginWakeupDontRespondOn == wakeupData.pluginWakeupCount) {
				this._log(window.location.host + ' EMULATE NOT RESPONDING PLUGIN');
				return;
			}
			var iconUrl = './online.svg';
			var iconPromise = wakeupData.pluginWakeupChangeIcon ? this._getBlob(iconUrl) : Promise.resolve(null);
			iconPromise.then(function (iconFile) {
				var iconDataParams = {};
				if (iconFile) {
					iconDataParams.iconData = {
						text: '' + wakeupData.pluginWakeupCount,
						image: iconFile
					};
				}
				if (wakeupData.pluginWakeupCount < wakeupData.pluginWakeupMaxCount) {
					setTimeout(function () {
						this._log(window.location.host + ' SLEEP. RETRY NEEDED');
						this._sendPostMessageData($.extend({
							apiVersion: 1,
							method: 'sleep',
							wakeupNeeded: true
						}, iconDataParams));
					}.bind(this), 2000);
				} else {
					setTimeout(function () {
						this._log(window.location.host + ' SLEEP. NO RETRY');
						this._sendPostMessageData($.extend({
							apiVersion: 1,
							method: 'sleep',
							wakeupNeeded: false
						}, iconDataParams));
					}.bind(this), 12000);
				}
			}.bind(this)).catch(function () {
				this._log('Unable to load icon file "' + iconUrl + '"', null, null, true);
			}.bind(this));
		},
		/**
		 * Save configuration of wakeup (background open for sync) behavior
		 * for Plugin to Local Storage
		 * 
		 * @private
		 */
		_saveWakeupData: function () {
			var wakeupData = {
				pluginWakeupCount: 0,
				pluginWakeupMaxCount: 0,
				pluginWakeupDontRespondOn: 0,
				pluginWakeupChangeIcon: false
			};
			if ($('#wakeup').is(':checked')) {
				wakeupData.pluginWakeupMaxCount = parseInt($('#repeat_count').val());
				if ($('#dont_respond').is(':checked')) {
					wakeupData.pluginWakeupDontRespondOn = parseInt($('#dont_respond_on').val());
				}
				if ($('#wakeup_change_icon').is(':checked')) {
					wakeupData.pluginWakeupChangeIcon = true;
				}
			}
			localStorage.setItem('pluginWakeupCount', wakeupData.pluginWakeupCount);
			localStorage.setItem('pluginWakeupMaxCount', wakeupData.pluginWakeupMaxCount);
			localStorage.setItem('pluginWakeupDontRespondOn', wakeupData.pluginWakeupDontRespondOn);
			localStorage.setItem('pluginWakeupChangeIcon', wakeupData.pluginWakeupChangeIcon);
			this._log(window.location.host + ' SAVE WAKEUP DATA TO LOCAL STORAGE', JSON.stringify(wakeupData, null,
				4));
		},
		/**
		 * Clear previous configuration of wakeup (background open for sync)
		 * behavior for Plugin from the Local Storage
		 * 
		 * @private
		 */
		_clearWakeupData: function () {
			localStorage.removeItem('pluginWakeupCount');
			localStorage.removeItem('pluginWakeupMaxCount');
			localStorage.removeItem('pluginWakeupDontRespondOn');
			localStorage.removeItem('pluginWakeupChangeIcon');
			this._log(window.location.host + ' CLEAR WAKEUP DATA FROM LOCAL STORAGE');
		},
		addMandatoryParam: function (target, key, value) {
			key = key || '';
			value = value || '';
			var clonedElement = $('.example-property').clone().removeClass('example-property').addClass('item--mandatory');
			clonedElement.find('.key').removeClass('writable').removeAttr('contenteditable').text(key);
			clonedElement.find('.value').text(value);
			this.initChangeOfValue(clonedElement);
			this.initItemRemove(clonedElement);
			$(target).parent('.item').after(clonedElement);
		},
		initChangeOfWakeup: function (element) {
			function onWakeupChange(elem) {
				var isChecked = $(elem).is(':checked');
				if (isChecked) {
					$(element).find('#repeat_count').prop('disabled', false);
					$(element).find('#dont_respond').prop('disabled', false);
					$(element).find('#wakeup_change_icon').prop('disabled', false);
					$(element).find('#wakeup_row').removeClass('wakeup-form-row--disabled');
					onDontRespondChange($(element).find('#dont_respond'));
					onWakeupIconChange($(element).find('#wakeup_change_icon'));
				} else {
					$(element).find('#repeat_count').prop('disabled', true);
					$(element).find('#dont_respond').prop('disabled', true);
					$(element).find('#dont_respond_on').prop('disabled', true);
					$(element).find('#wakeup_change_icon').prop('disabled', true);
					$(element).find('#wakeup_row').addClass('wakeup-form-row--disabled');
					$(element).find('#dont_respond_row').addClass('wakeup-form-row--disabled');
					$(element).find('#wakeup_change_icon_row').addClass('wakeup-form-row--disabled');
				}
			}

			function onDontRespondChange(elem) {
				var isChecked = $(elem).is(':checked');
				if (isChecked) {
					$(element).find('#dont_respond_on').prop('disabled', false);
					$(element).find('#dont_respond_row').removeClass('wakeup-form-row--disabled');
				} else {
					$(element).find('#dont_respond_on').prop('disabled', true);
					$(element).find('#dont_respond_row').addClass('wakeup-form-row--disabled');
				}
			}

			function onWakeupIconChange(elem) {
				var isChecked = $(elem).is(':checked');
				if (isChecked) {
					$(element).find('#wakeup_change_icon_row').removeClass('wakeup-form-row--disabled');
				} else {
					$(element).find('#wakeup_change_icon_row').addClass('wakeup-form-row--disabled');
				}
			}
			$(element).find('#wakeup').change(function (e) {
				onWakeupChange(e.target);
			});
			$(element).find('#dont_respond').change(function (e) {
				onDontRespondChange(e.target);
			});
			$(element).find('#wakeup_change_icon').change(function (e) {
				onWakeupIconChange(e.target);
			});
			onWakeupChange($(element).find('#wakeup'));
		},
		initChangeOfInventoryAction: function (element) {
			$(element).find('.select-inventory-action').on('change', function (e) {
				$(e.target).parents('.items').first().find('.item--mandatory').remove();
				switch ($(e.target).val()) {
					case 'create':
						this.addMandatoryParam(e.target, 'invpool');
						this.addMandatoryParam(e.target, 'quantity');
						this.addMandatoryParam(e.target, 'invtype');
						this.addMandatoryParam(e.target, 'inv_aid');
						this.addMandatoryParam(e.target, 'inv_pid');
						break;
					case 'delete':
						this.addMandatoryParam(e.target, 'invid');
						break;
					case 'install':
						this.addMandatoryParam(e.target, 'invid');
						this.addMandatoryParam(e.target, 'inv_aid');
						this.addMandatoryParam(e.target, 'quantity');
						break;
					case 'deinstall':
						this.addMandatoryParam(e.target, 'invid');
						this.addMandatoryParam(e.target, 'inv_pid');
						this.addMandatoryParam(e.target, 'quantity');
						break;
					case 'undo_install':
						this.addMandatoryParam(e.target, 'invid');
						this.addMandatoryParam(e.target, 'quantity');
						break;
					case 'undo_deinstall':
						this.addMandatoryParam(e.target, 'invid');
						this.addMandatoryParam(e.target, 'quantity');
						break;
				}
				this._updateResponseJSON();
			}.bind(this));
		},
		initChangeOfDataItems: function () {
			// set checkboxes from local storage
			if (localStorage.getItem('dataItems')) {
				$('.data-items').attr('checked', true);
				$('.data-items-holder').show();
				var dataItems = JSON.parse(localStorage.getItem('dataItems'));
				$('.data-items-holder input').each(function () {
					if (dataItems.indexOf(this.value) != -1) {
						$(this).attr('checked', true);
					}
				});
			}
			// init handlers
			$('.data-items').on('change', function (e) {
				$('.data-items-holder').toggle();
			});
		},
		initChangeOfOpenOption: function (checkboxId, localStorageKey) {
			var optionCheckbox = $('#' + checkboxId);
			this.initLocalStorageOption(localStorageKey);
			if (localStorage.getItem(localStorageKey)) {
				optionCheckbox.attr('checked', true);
			}
			optionCheckbox.on('change', function (e) {
				if ($(this).is(':checked')) {
					localStorage.setItem(localStorageKey, 'true');
				} else {
					localStorage.setItem(localStorageKey, '');
				}
			});
		},
		initLocalStorageOption: function (localStorageKey) {
			if (localStorage.getItem(localStorageKey) === null) {
				localStorage.setItem(localStorageKey, 'true');
			}
		},
		initFileInputPreview: function (element, mimeTypes) {
			$(element).find('.value__item.value__file').on('change', function (e) {
				var inputElem = e.target;
				var file = inputElem.files[0];
				var container = $(inputElem).closest('.item').find('.value__file_preview_container');
				var thumb = container.find('.value__file_preview');
				var mimeTypes = ['image/png', 'image/jpeg', 'image/gif'];
				if ($(inputElem).hasClass('image_file')) {
					mimeTypes = $(inputElem).attr('accept').split(',');
				}
				if (file && -1 !== $.inArray(file.type, mimeTypes)) {
					thumb.attr('src', URL.createObjectURL(file));
					container.show();
				} else {
					container.hide();
					thumb.attr('src', '');
				}
			}.bind(this));
		},
		initChangeOfValue: function (element) {
			this.initFileInputPreview(element);
			$(element).find('.key.writable').on('input textinput change', function (e) {
				$(e.target).closest('.item').find('.value__item.value__file').attr('data-property-id', $(e.target).text());
			}.bind(this));
			$(element).find('.value__item.writable, .key.writable, #wakeup').on('input textinput change', function (e) {
				$(e.target).parents('.item').addClass('edited');
				this._updateResponseJSON();
			}.bind(this));
		},
		initItemRemove: function (element) {
			$(element).find('.button--remove-item').on('click', function (e) {
				// remove item
				$(e.target).parents('.item').first().remove();
				// reindex actions
				if ($(e.target).parents('.item').first().find('.action-key').length > 0) {
					$('.item:not(.example-action) .action-key').each(function (index) {
						$(this).text(index);
					});
				}
				this._updateResponseJSON();
			}.bind(this));
		},
		initCollapsableKeys: function (element) {
			$(element).find('.key').each(function (index, item) {
				if ($(item).siblings('.value').has('.items').length !== 0) {
					$(item).addClass('clickable');
				}
			});
			$(element).find('.key').on('click', function () {
				if ($(this).siblings('.value').has('.items').length !== 0) {
					$(this).siblings('.value').toggle();
					$(this).toggleClass('collapsed');
				}
			});
			$(element).find('.item-expander').on('click', function (e) {
				var key = $(e.target).parents('.value').first().siblings('.key').first();
				if (key.hasClass('clickable')) {
					key.trigger('click');
				}
			});
		},
		initAddButtons: function (element) {
			$(element).find('.button--add-property, .button--add-file-property').click(function (e) {
				var clonedElement;
				var isFileProperty = $(e.target).hasClass('button--add-file-property');
				if (isFileProperty) {
					var entityId = 'action-' + $(e.target).parents('.item').children('.action-key').text();
					clonedElement = $('.example-file-property').clone().removeClass('example-file-property');
					clonedElement.find('.value__item.value__file').attr('data-entity-id', entityId);
				} else {
					clonedElement = $('.example-property').clone().removeClass('example-property');
				}
				this.initChangeOfValue(clonedElement);
				this.initItemRemove(clonedElement);
				$(e.target).parent('.item').before(clonedElement);
				$(e.target).parents('.item').addClass('edited');
				this._updateResponseJSON();
			}.bind(this));
			$(element).find('.button--add-action').click(function (e) {
				var clonedElement = $('.example-action').clone().removeClass('example-action');
				var actionsCount = +$(e.target).parents('.item:not(.item--excluded)').find('.action-key').length;
				clonedElement.find('.action-key').text(actionsCount);
				this.initAddButtons(clonedElement);
				this.initCollapsableKeys(clonedElement);
				this.initChangeOfValue(clonedElement);
				this.initChangeOfInventoryAction(clonedElement);
				this.initItemRemove(clonedElement);
				$(e.target).parent('.item').before(clonedElement);
				$(e.target).parents('.item').addClass('edited');
				this._updateResponseJSON();
			}.bind(this));
		},
		initProcedureActions: function (element) {
			$(element).find('.button__send-procedure').click(function (e) {
				var jsonToSend = $(element).find('.json__procedure-new').text().replace(/%%uniqueId%%/g,
					this.generateCallId());
				this.showProcedureJson(element, 'request', jsonToSend);
				this._sendPostMessageData(jsonToSend);
			}.bind(this));
		},
		processProcedureResult: function (element, receivedJson) {
			this.showProcedureJson(element, 'response', receivedJson);
		},
		/**
		 * @param {Element}
		 *            element - DOM element whose children will be affected
		 * 
		 * @param {String}
		 *            jsonType - 'request' or 'response'
		 * @param {String}
		 *            json
		 */
		showProcedureJson: function (element, jsonType, json) {
			if ('request' !== jsonType && 'response' !== jsonType) {
				console.error('Unknown jsonType', jsonType);
			}
			var jsonList = $(element).find('.procedures-json-list');
			var eventTime = this.getCurrentTime();
			var callId = '';
			try {
				var jsonObject = JSON.parse(json);
				callId = jsonObject.callId || '';
				json = JSON.stringify(jsonObject, null, 4);
			} catch (e) { }
			var procedureContainer = $(element).find('.section__procedure[data-call-id="' + callId + '"]');
			var isContainerExisted = !!(callId && procedureContainer.length);
			if (!isContainerExisted) {
				procedureContainer = $('.section__procedure-example').clone().removeClass('section__procedure-example');
			}
			var containerDataSet = procedureContainer.get(0).dataset;
			containerDataSet.callId = callId;
			containerDataSet[jsonType + 'Time'] = eventTime;
			procedureContainer.find('.json__procedure-' + jsonType).text(json).removeClass('json__procedure-hidden');
			procedureContainer.find('.procedure-' + jsonType + '-time').text(eventTime);
			if (!isContainerExisted) {
				var procedureNumber = ++jsonList.get(0).dataset.procedureCount;
				containerDataSet.procedureNumber = '' + procedureNumber;
				procedureContainer.find('.procedure-number').text('#' + procedureNumber).click(function () {
					procedureContainer.find('.json__procedure').toggleClass('json__procedure-full');
				});
				jsonList.prepend(procedureContainer);
			}
			json = null;
			jsonObject = null;
		},
		getCurrentTime: function () {
			var d = new Date();
			return '' + ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2) + '.' + ('00' +
				d.getMilliseconds()).slice(-3);
		},
		generateCallId: function () {
			return btoa(String.fromCharCode.apply(null, window.crypto.getRandomValues(new Uint8Array(16))));
		},
		/**
		 * Render JSON object to DOM
		 * 
		 * @param {Object}
		 *            data - JSON object
		 * @returns {jQuery}
		 */
		renderForm: function (data) {
			return this.renderCollection('data', data, true);
		},
		/**
		 * Render JSON object to follow HTML:
		 * 
		 * <div class="item"> <div class="key">{key}</div> <div
		 * class="value">{value}</div> </div> <div class="item"> <div
		 * class="key">{key}</div> <div class="value"> <div class="items">
		 * <div class="item"> <div class="key">{key}</div> <div
		 * class="value">{value}</div> </div> <div class="item"> <div
		 * class="key">{key}</div> <div class="value">{value}</div> </div>
		 * ... </div> </div> </div> ...
		 * 
		 * @param {String}
		 *            key - Collection name
		 * @param {Object}
		 *            items - Child items of collection
		 * @param {Boolean}
		 *            [isWritable] - Will render as writable?
		 * @param {number}
		 *            [level] - Level of recursion
		 * @param {string}
		 *            [parentKey] - parent Key
		 * 
		 * @returns {jQuery}
		 */
		renderCollection: function (key, items, isWritable, level, parentKey) {
			var render_item = $('<div>').addClass('item');
			var render_key = $('<div>').addClass('key').text(key);
			var render_value = $('<div>').addClass('value value__collection');
			var render_items = $('<div>').addClass('items');
			isWritable = isWritable || false;
			level = level || 1;
			parentKey = parentKey || '';
			var newParentKey = key;
			var entityId = '';
			if ('activity' === key || 'activityList' == parentKey) {
				entityId = items.aid;
			} else if ('inventory' === key || 'inventoryList' == parentKey) {
				entityId = items.invid;
			}
			if (items) {
				$.each(items, function (key, value) {
					if (value && typeof value === 'object') {
						render_items.append(this.renderCollection(key, value, isWritable, level + 1, newParentKey));
					} else {
						render_items.append(this.renderItem(key, value, isWritable, level + 1, newParentKey, entityId).get(0));
					}
				}.bind(this));
			}
			render_item.append('<div class="item-expander"></div>');
			render_item.append(render_key);
			render_value.append(render_items);
			render_item.append($('<br>'));
			render_item.append(render_value);
			return render_item;
		},
		/**
		 * Render key and value to follow HTML:
		 * 
		 * <div class="item"> <div class="key">{key}</div> <div
		 * class="value">{value}</div> </div>
		 * 
		 * @param {String}
		 *            key - Key
		 * @param {String}
		 *            value - Value
		 * @param {Boolean}
		 *            [isWritable] - Will render as writable?
		 * @param {Number}
		 *            [level] - Level of recursion
		 * @param {String}
		 *            [parentKey] - parent Key
		 * @param {String}
		 *            [entityId] - id of OFSC entity to associate the file
		 *            input with
		 * 
		 * @returns {jQuery}
		 */
		renderItem: function (key, value, isWritable, level, parentKey, entityId) {
			var render_item = $('<div>').addClass('item');
			var render_value;
			var render_key;
			isWritable = isWritable || false;
			level = level || 1;
			parentKey = parentKey || '';
			render_key = $('<div>').addClass('key').text(key);
			render_item.append('<div class="item-expander"></div>')
				.append(render_key)
				.append('<span class="delimiter">: </span>');
			if (value === null) {
				value = '';
			}
			if (
				typeof this.renderReadOnlyFieldsByParent[parentKey] !== 'undefined' &&
				typeof this.renderReadOnlyFieldsByParent[parentKey][key] !== 'undefined' &&

				this.renderReadOnlyFieldsByParent[parentKey][key] === true
			) {
				isWritable = false;
			}
			switch (key) {
				case "csign":
					if (isWritable) {
						render_value = $('<button>').addClass('button button--item-value button--generate-sign').text('Generate');
					}
					break;
				default:
					var pluginInitData = false;
					var attributeDescription = {};
					if (this._isJson(localStorage.getItem('pluginInitData'))) {
						pluginInitData = JSON.parse(localStorage.getItem('pluginInitData'));
						attributeDescription = pluginInitData.attributeDescription || {};
					}
					if (this.dictionary[key]) {
						render_value = this.renderSelect(this.dictionary, key, value, isWritable).addClass('value value__item');
					} else if (
						attributeDescription[key] &&
						"enum" == attributeDescription[key].type &&
						attributeDescription[key].enum
					) {
						render_value = this.renderEnumSelect(attributeDescription[key].enum, key, value,
							isWritable).addClass('value value__item');
					} else if (
						attributeDescription[key] &&
						"file" == attributeDescription[key].type &&
						"signature" !== attributeDescription[key].gui
					) {
						render_value = this.renderFile(entityId, key);
					} else {
						render_value = $('<div>').addClass('value value__item').text(value);
						if (isWritable) {
							render_value.addClass('writable').attr('contenteditable', true);
						}
					}
					break;
			}
			render_item.append(render_value);
			return render_item;
		},
		/**
		 * Render enums with validate of outs values
		 * 
		 * <select class="value [writable]" [disabled]> <option
		 * value="{value}" [selected]>{dictionary}</option> ... </select>
		 * 
		 * @param {Object}
		 *            dictionary - Dictionary that will be used for Enum
		 *            rendering
		 * @param {String}
		 *            key - Just field name
		 * @param {String}
		 *            value - Selected value
		 * @param {Boolean}
		 *            isWritable - Will render as writable?
		 * 
		 * @returns {HTMLElement}
		 */
		renderSelect: function (dictionary, key, value, isWritable) {
			var render_value;
			var outs = dictionary[key][value].outs;
			var allowedValues = [value].concat(outs);
			var disabled = '';
			render_value = $('<select>').css({
				background: dictionary[key][value].color
			});
			if (!outs.length || !isWritable) {
				render_value.attr('disabled', true);
			} else {
				render_value.addClass('writable');
			}
			$.each(allowedValues, function (index, label) {
				render_value.append('<option' + (label === value ? ' selected' : '') + ' value="' + dictionary[key]
				[label].label + '">' + dictionary[key][label].translation + '</option>');
			});
			return render_value;
		},
		renderFile: function (entityId, key) {
			var render_value = $('<div>')
				.addClass('writable value value__item value__file')
				.attr('data-entity-id', entityId)
				.attr('data-property-id', key);
			var input = $('<input type="file">').addClass('value__file_input');
			var preview =
				$('<div>').addClass('value__file_preview_container')
					.append($('<img>').addClass('value__file_preview'));
			render_value.append(input);
			render_value.append(preview);
			return render_value;
		},
		/**
		 * Render enums
		 * 
		 * <select class="value [writable]" [disabled]> <option
		 * value="{value}" [selected]>{dictionary}</option> ... </select>
		 * 
		 * @param {Object}
		 *            dictionary - Dictionary that will be used for Enum
		 *            rendering
		 * @param {String}
		 *            key - Just field name
		 * @param {String}
		 *            value - Selected value
		 * @param {Boolean}
		 *            isWritable - Will render as writable?
		 * 
		 * @returns {HTMLElement}
		 */
		renderEnumSelect: function (dictionary, key, value, isWritable) {
			var render_value;
			var disabled = '';
			render_value = $('<select>');
			if (isWritable) {
				render_value.addClass('writable');
			} else {
				render_value.attr('disabled', true);
			}
			$.each(dictionary, function (index, label) {
				var option = $('<option' + (index === value ? ' selected' : '') + ' value="' + index + '"></option>').text(label.text);
				render_value.append(option);
			});
			return render_value;
		},
		/**
		 * Generate output JSON
		 * 
		 * @returns {Object}
		 */
		generateJson: function () {
			var outputJson = {
				apiVersion: 1,
				method: 'close',
				backScreen: $('.back_method_select').val(),
				wakeupNeeded: $('#wakeup').is(':checked')
			};
			if (
				outputJson.backScreen === 'activity_by_id' ||
				outputJson.backScreen === 'end_activity' ||
				outputJson.backScreen === 'cancel_activity' ||
				outputJson.backScreen === 'notdone_activity' ||
				outputJson.backScreen === 'start_activity' ||
				outputJson.backScreen === 'suspend_activity' ||
				outputJson.backScreen === 'delay_activity'
			) {
				$.extend(outputJson, {
					backActivityId: $('.back_activity_id').val()
				});
			}
			if (outputJson.backScreen === 'inventory_by_id') {
				$.extend(outputJson, {
					backInventoryId: $('.back_inventory_id').val()
				});
			}
			var backActivityId = $('.back_activity_id').val();
			if (outputJson.backScreen === 'inventory_list' && backActivityId) {
				$.extend(outputJson, {
					backActivityId: backActivityId,
				});
			}
			if (
				outputJson.backScreen === 'install_inventory' ||
				outputJson.backScreen === 'deinstall_inventory'
			) {
				$.extend(outputJson, {
					backActivityId: $('.back_activity_id').val(),
					backInventoryId: $('.back_inventory_id').val()
				});
			}
			if (outputJson.backScreen === 'plugin_by_label') {
				$.extend(outputJson, {
					backPluginLabel: $('.back_plugin_label').val(),
				});
				if ($('.back_plugin_link_id').val()) {
					$.extend(outputJson, {
						backPluginLinkId: $('.back_plugin_link_id').val()
					});
				}
				if ($('.back_plugin_params').val()) {
					$.extend(outputJson, {
						backPluginOpenParams: JSON.parse($('.back_plugin_params').val())
					});
				}
			}
			// icon data
			$.extend(outputJson, this.parseIconData($('.icon-options-holder')));
			// parse entity
			$.extend(outputJson, this.parseCollection($('.form')).data);
			// parse actions
			var actionsJson = this.parseCollection($('.actions-form'), true);
			if (actionsJson.actions.length > 0) {
				$.extend(outputJson, actionsJson);
			}
			delete outputJson.entity;
			delete outputJson.resource;
			return outputJson;
		},
		/**
		 * Convert HTML elements to JSON
		 * 
		 * @param {HTMLElement}
		 *            rootElement - Root element that should be parsed
		 *            recursively
		 * @param {Boolean}
		 *            [parseAllExceptExcluded] - Need to parse all elements
		 *            except excluded
		 * 
		 * @returns {Object}
		 * 
		 * <div class="key">activity</div> <div class="value
		 * value__collection"> <div class="items">
		 * <-------------------------------- rootElement !!! <div
		 * class="item edited"> <div class="key">WO_COMMENTS</div> <div
		 * class="value">text_comments</div> </div> <div class="item"> <div
		 * class="key">aid</div> <div class="value">4225274</div> </div>
		 * <div class="item"> <div class="key">caddress</div> <div
		 * class="value">text_address</div> </div> </div> </div>
		 * 
		 * converts to: { "aid": "4225274", "WO_COMMENTS": "text_comments" }
		 */
		parseCollection: function (rootElement, parseAllExceptExcluded) {
			parseAllExceptExcluded = parseAllExceptExcluded || false;
			var returnObject;
			if ($(rootElement).hasClass('items--without-key')) {
				returnObject = [];
			} else {
				returnObject = {};
			}
			$(rootElement).children('.item').each(function (itemIndex, item) {
				var parentKey;
				var valueKey;
				var value;
				var mandatoryField = false;
				var dataItemKey;
				parentKey = $(rootElement).parent().siblings('.key').get(0);
				valueKey = $(item).children('.key').get(0);
				dataItemKey = $(valueKey).text();
				// Logic of mandatory fields
				if ((parentKey !== undefined) && (
					('activity' === $(parentKey).text() && 'aid' === dataItemKey) || ('inventory' === $(parentKey).text() &&
						'invid' === dataItemKey)
				)) {
					mandatoryField = true;
				}
				if (
					($(item).hasClass('edited') || parseAllExceptExcluded || mandatoryField) &&
					!$(item).hasClass('item--excluded')
				) {
					value = $(item).children('.value').get(0);
					if ($(value).children('.items').length > 0) {
						var parsedChild = this.parseCollection($(value).children('.items').get(0), parseAllExceptExcluded);
						if ($(rootElement).hasClass('items--without-key')) {
							returnObject.push(parsedChild);
						} else {
							returnObject[dataItemKey] = parsedChild;
						}
					} else {
						switch ($(value).prop("tagName")) {
							case 'SELECT':
								returnObject[dataItemKey] = $(value).val();
								break;
							case 'CANVAS':
								returnObject[dataItemKey] = value.toDataURL();
								break;
							default:
								if ($(value).hasClass('value__file')) {
									var fileInput = $(value).find('.value__file_input').get(0);
									var file = fileInput.files && fileInput.files[0];
									if (file) {
										returnObject[dataItemKey] = {
											fileName: file.name,
											fileContents: {}
										};
									}
								} else {
									returnObject[dataItemKey] = $(value).text();
								}
								break;
						}
					}
				}
			}.bind(this));
			return returnObject;
		},
		parseIconData: function (rootElement) {
			var colorItem = rootElement.find('#iconColor');
			var textItem = rootElement.find('#iconText');
			var blobItem = rootElement.find('#iconImage');
			var linkIdItem = rootElement.find('#iconLinkId');
			var iconData = {};
			var hasData = false;
			if (colorItem.hasClass('edited')) {
				hasData = true;
				iconData.color = colorItem.find('.value__item').val();
			}
			if (textItem.hasClass('edited')) {
				hasData = true;
				iconData.text = textItem.find('.value__item').text();
			}
			if (blobItem.hasClass('edited')) {
				hasData = true;
				iconData.image = {};
			}
			if (!hasData) {
				return {};
			}
			var linkId = linkIdItem.find('.value__item').text();
			if (linkId.length) {
				var linksIconData = {};
				linksIconData[linkId] = iconData;
				return {
					linksIconData: linksIconData
				};
			}
			return {
				iconData: iconData
			}
		},
		_attachFiles: function (data) {
			if (!$.isPlainObject(data)) {
				return false;
			}
			$.each(data, function (dataKey, dataValue) {
				var entityId = '';
				if ('activity' === dataKey || 'inventory' === dataKey) {
					if ('activity' === dataKey) {
						entityId = dataValue.aid;
					} else {
						entityId = dataValue.invid;
					}
					if (!entityId) {
						return true;
					}
					$.each(dataValue, function (propertyName, propertyValue) {
						if ($.isPlainObject(propertyValue) && propertyValue.fileContents) {
							var fileInput = $('.value__item.value__file[data-entity-id="' + entityId + '"][data-property-id="' +
								propertyName + '"]').find('.value__file_input').get(0);
							var file = fileInput.files && fileInput.files[0];
							if (file) {
								propertyValue.fileContents = file;
							}
						}
					});
				} else if ('activityList' === dataKey || 'inventoryList' === dataKey) {
					$.each(dataValue, function (entityId, entity) {
						$.each(entity, function (propertyName, propertyValue) {
							if ($.isPlainObject(propertyValue) && propertyValue.fileContents) {
								var fileInput = $('.value__item.value__file[data-entity-id="' + entityId + '"][data-property-id="' +
									propertyName + '"]').find('.value__file_input').get(0);
								var file = fileInput.files && fileInput.files[0];
								if (file) {
									propertyValue.fileContents = file;
								}
							}
						});
					});
				} else if ('actions' === dataKey) {
					$.each(dataValue, function (actionId, action) {
						if (!action.properties) {
							return true;
						}
						$.each(action.properties, function (propertyName, propertyValue) {
							if ($.isPlainObject(propertyValue) && propertyValue.fileContents) {
								var fileInput = $('.value__item.value__file[data-entity-id="action-' + actionId + '"][data-property-id="' +
									propertyName + '"]').find('.value__file_input').get(0);
								var file = fileInput.files && fileInput.files[0];
								if (file) {
									propertyValue.fileContents = file;
								}
							}
						});
					});
				} else if ('iconData' === dataKey) {
					if ($.isPlainObject(dataValue.image)) {
						var fileInput = $('.icon-options-holder #iconImage .value__file_input').get(0);
						var file = fileInput.files && fileInput.files[0];
						if (file) {
							dataValue.image = file;
						}
					}
				} else if ('linksIconData' === dataKey) {
					if (!$.isPlainObject(dataValue)) {
						return;
					}
					Object.keys(dataValue).forEach(function (linkId) {
						var iconData = dataValue[linkId];
						if ($.isPlainObject(iconData.image)) {
							var fileInput = $('.icon-options-holder #iconImage .value__file_input').get(0);
							var file = fileInput.files && fileInput.files[0];
							if (file) {
								iconData.image = file;
							}
						}
					});
				}
			});
		},
		/**
		 * Update JSON
		 * 
		 * @private
		 */
		_updateResponseJSON: function () {
			var jsonToSend = this.generateJson();
			$('.json__response').text(JSON.stringify(jsonToSend, null, 4));
		},
		/**
		 * Initialization function
		 */
		init: function () {
			this._log(window.location.host + ' PLUGIN HAS BEEN STARTED');
			window.addEventListener("message", this._getPostMessageData.bind(this), false);
			var jsonToSend = {
				apiVersion: 1,
				method: 'ready',
				sendInitData: true
			};
			// parse data items
			var dataItems = ['customerInventories', 'resource'];
			if (dataItems) {
				$.extend(jsonToSend, { dataItems: dataItems });
			}
			this._sendPostMessageData(jsonToSend);
		}
	});
})(jQuery);