"use strict";

(function ($) {
	window.OfscPlugin = function (debugMode) {
		this.debugMode = debugMode || false;
	};

	var inventoryDetails = false;

	var resourcesVersion = '215.0.3+1614692810930';

	$.extend(window.OfscPlugin.prototype, {
		/**
		 * Dictionary of enums
		 */
		dictionary: {
			astatus: {
				pending: {
					label: 'pending',
					translation: 'Pending',
					outs: ['started', 'cancelled', 'suspended', 'enroute'],
					color: '#ffde00'
				},
				enroute: {
					label: 'enroute',
					translation: 'En Route',
					outs: ['started', 'cancelled', 'pending'],
					color: '#ff920c'
				},
				started: {
					label: 'started',
					translation: 'Started',
					outs: ['complete', 'suspended', 'notdone', 'cancelled'],
					color: '#a2de61'
				},
				complete: {
					label: 'complete',
					translation: 'Completed',
					outs: [],
					color: '#79B6EB'
				},
				suspended: {
					label: 'suspended',
					translation: 'Suspended',
					outs: [],
					color: '#9FF'
				},
				notdone: {
					label: 'notdone',
					translation: 'Not done',
					outs: [],
					color: '#60CECE'
				},
				cancelled: {
					label: 'cancelled',
					translation: 'Cancelled',
					outs: [],
					color: '#80FF80'
				}
			},
			invpool: {
				customer: {
					label: 'customer',
					translation: 'Customer',
					outs: ['deinstall'],
					color: '#04D330'
				},
				install: {
					label: 'install',
					translation: 'Installed',
					outs: ['provider'],
					color: '#00A6F0'
				},
				deinstall: {
					label: 'deinstall',
					translation: 'Deinstalled',
					outs: ['customer'],
					color: '#00F8E8'
				},
				provider: {
					label: 'provider',
					translation: 'Resource',
					outs: ['install'],
					color: '#FFE43B'
				}
			}
		},

		actions: {
			activity: [{
					value: '',
					translation: 'Select Action...'
				},
				{
					value: 'create',
					translation: 'Create Activity'
				}
			],
			inventory: [{
					value: '',
					translation: 'Select Action...'
				},
				{
					value: 'create',
					translation: 'Create Inventory'
				},
				{
					value: 'delete',
					translation: 'Delete Inventory'
				},
				{
					value: 'install',
					translation: 'Install Inventory'
				},
				{
					value: 'deinstall',
					translation: 'Deinstall Inventory'
				},
				{
					value: 'undo_install',
					translation: 'Undo Install Inventory'
				},
				{
					value: 'undo_deinstall',
					translation: 'Undo Deinstall Inventory'
				}
			],
			queue: [{
					value: '',
					translation: 'Select Action...'
				},
				{
					value: 'activate_queue',
					translation: 'Activate'
				},
				{
					value: 'deactivate_queue',
					translation: 'Deactivate'
				}
			]
		},

		mandatoryActionProperties: {},

		/**
		 * Which field shouldn't be editable
		 *
		 * format:
		 *
		 * parent: {
		 *     key: true|false
		 * }
		 *
		 */
		renderReadOnlyFieldsByParent: {
			data: {
				apiVersion: true,
				method: true,
				entity: true
			},
			resource: {
				pid: true,
				pname: true,
				gender: true
			}
		},

		/**
		 * Check for string is valid JSON
		 *
		 * @param {*} str - String that should be validated
		 *
		 * @returns {boolean}
		 *
		 * @private
		 */
		_isJson: function (str) {
			try {
				JSON.parse(str);
			} catch (e) {
				return false;
			}
			return true;
		},

		/**
		 * Return origin of URL (protocol + domain)
		 *
		 * @param {String} url
		 *
		 * @returns {String}
		 *
		 * @private
		 */
		_getOrigin: function (url) {
			if (url != '') {
				if (url.indexOf("://") > -1) {
					return 'https://' + url.split('/')[2];
				} else {
					return 'https://' + url.split('/')[0];
				}
			}

			return '';
		},

		/**
		 * Return domain of URL
		 *
		 * @param {String} url
		 *
		 * @returns {String}
		 *
		 * @private
		 */
		_getDomain: function (url) {
			if (url != '') {
				if (url.indexOf("://") > -1) {
					return url.split('/')[2];
				} else {
					return url.split('/')[0];
				}
			}

			return '';
		},

		/**
		 * get domain / company name
		 */
		_getDomainURL: function () {
			//return document.referrer.match(/\:\/\/([^\/]+)\.etadirect\.com\//)[1];
			//Reg Ex modified to handle both etadirect.com and fs.ocs.oraclecloud.com URLs
			return document.referrer.match(/\:\/\/([^\/]+)\.(?:etadirect.com|fs.ocs.oraclecloud.com)/)[1];
		},

		/**
		 * Sends postMessage to document.referrer
		 *
		 * @param {Object} data - Data that will be sent
		 *
		 * @private
		 */
		_sendPostMessageData: function (data) {
			var isString = 'string' === typeof data;

			var originUrl = document.referrer || (document.location.ancestorOrigins && document.location.ancestorOrigins[0]) || '';
			var domain = originUrl ? this._getDomain(originUrl) : '*OFS*';
			var targetOrigin = originUrl ? this._getOrigin(originUrl) : '*';
			// var targetOrigin = this._getOrigin('https://example.com'); // Use URL of OFS App here to protect from unauthorized embedding

			if (targetOrigin) {
				this._log(window.location.host + ' -> ' + (isString ? '' : data.method) + ' ' + domain, isString ? data : JSON.stringify(data, null, 4));

				parent.postMessage(data, targetOrigin);
			} else {
				this._log(window.location.host + ' -> ' + (isString ? '' : data.method) + ' ERROR. UNABLE TO GET REFERRER');
			}
		},

		/**
		 * Handles during receiving postMessage
		 *
		 * @param {MessageEvent} event - Javascript event
		 *
		 * @private
		 */
		_getPostMessageData: function (event) {

			if (typeof event.data === 'undefined') {
				this._log(window.location.host + ' <- NO DATA ' + this._getDomain(event.origin), null, null, true);

				return false;
			}

			if (!this._isJson(event.data)) {
				this._log(window.location.host + ' <- NOT JSON ' + this._getDomain(event.origin), null, null, true);

				return false;
			}

			var data = JSON.parse(event.data);

			if (!data.method) {
				this._log(window.location.host + ' <- NO METHOD ' + this._getDomain(event.origin), null, null, true);

				return false;
			}

			this._log(window.location.host + ' <- ' + data.method + ' ' + this._getDomain(event.origin), JSON.stringify(data, null, 4));

			switch (data.method) {
				case 'init':
					this.pluginInitEnd(data);
					break;

				case 'open':
					this.pluginOpen(data);
					break;

				case 'wakeup':
					this.pluginWakeup(data);
					break;

				case 'error':
					data.errors = data.errors || {
						error: 'Unknown error'
					};
					this.processProcedureResult(document, event.data);
					this._showError(data.errors);
					break;

				case 'callProcedureResult':
					this.processProcedureResult(document, event.data);
					break;

				default:
					this.processProcedureResult(document, event.data);
					this._log(window.location.host + ' <- UNKNOWN METHOD: ' + data.method + ' ' + this._getDomain(event.origin), null, null, true);
					break;
			}
		},

		/**
		 * Show alert with error
		 *
		 * @param {Object} errorData - Object with errors
		 *
		 * @private
		 */
		_showError: function (errorData) {
			alert(JSON.stringify(errorData, null, 4));
		},

		/**
		 * Logs to console
		 *
		 * @param {String} title - Message that will be log
		 * @param {String} [data] - Formatted data that will be collapsed
		 * @param {String} [color] - Color in Hex format
		 * @param {Boolean} [warning] - Is it warning message?
		 *
		 * @private
		 */
		_log: function (title, data, color, warning) {
			if (!this.debugMode) {
				return;
			}
			if (!color) {
				color = '#0066FF';
			}
			if (!!data) {
				console.groupCollapsed('%c[Plugin API] ' + title, 'color: ' + color + '; ' + (!!warning ? 'font-weight: bold;' : 'font-weight: normal;'));
				console.log('[Plugin API] ' + data);
				console.groupEnd();
			} else {
				console.log('%c[Plugin API] ' + title, 'color: ' + color + '; ' + (!!warning ? 'font-weight: bold;' : ''));
			}
		},

		_getBlob: function (url) {
			return new Promise(function (resolve, reject) {
				var xhr = new XMLHttpRequest();

				xhr.responseType = 'blob';
				xhr.open('GET', url, true);

				xhr.onreadystatechange = function () {
					if (xhr.readyState === xhr.DONE) {
						if (200 == xhr.status || 201 == xhr.status) {
							try {
								return resolve(xhr.response);
							} catch (e) {
								return reject(e);
							}
						}

						return reject(new Error(
							'Server returned an error. HTTP Status: ' + xhr.status
						));
					}
				};

				xhr.send();
			});
		},

		/**
		 * Business login on plugin init
		 */
		saveToLocalStorage: function (data) {
			this._log(window.location.host + ' INIT. SET DATA TO LOCAL STORAGE', JSON.stringify(data, null, 4));

			var initData = {};

			$.each(data, function (key, value) {
				if (-1 !== $.inArray(key, ['apiVersion', 'method'])) {
					return true;
				}

				initData[key] = value;
			});

			localStorage.setItem('pluginInitData', JSON.stringify(initData));
		},

		/**
		 * Business login on plugin init end
		 *
		 * @param {Object} data - JSON object that contain data from OFS
		 */
		pluginInitEnd: function (data) {
			this.saveToLocalStorage(data);

			var messageData = {
				apiVersion: 1,
				method: 'initEnd'
			};

			if (localStorage.getItem('pluginWakeupCount') < localStorage.getItem('pluginWakeupMaxCount')) {
				this._log(window.location.host + ' UNFINISHED WAKEUP DATA FOUND IN LOCAL STORAGE');

				messageData.wakeupNeeded = true;
			}

			this._sendPostMessageData(messageData);
		},
		/**
		 * Ajax call to update the properties
		 */
		ajaxCall: function (url, payload, method, headers) {
			$.ajax({
				dataType: "json",
				url: url,
				data: JSON.stringify(payload),
				method: method,
				//async: false,
				crossDomain: true,
				headers: headers,
				processData: false,
				contentType: 'application/json; charset=utf-8',
				timeout: 15000,
				success: function (response) {
					console.log("Update Resource properties - Success messagae: " + JSON.stringify(response));
				}.bind(this),
				error: function (errorData) {
					console.log("Update Resource properties - Error messagae:" + JSON.stringify(errorData));
				}
			});
		},
		/**
		 * Business login on plugin open
		 *
		 * @param {Object} receivedData - JSON object that contain data from OFS
		 */
		pluginOpen: function (receivedData) {
			
			var $parentThis = this;
			var resourceTimeZone = receivedData.resource.time_zone;
			var TimeZoneMapping = {
                "19": "Alaska",
                "6": "Arizona",
                "4": "Central",
                "2": "Eastern",
                "15": "GMT",
                "17": "Hawaii (Adak)",
                "18": "Hawaii (Honolulu)",
                "5": "Mountain",
                "7": "Pacific"
            };
            var timeZone = TimeZoneMapping[resourceTimeZone];
			// Set the timezone to retreive the Date & time for Activate route & punch in 
			if ("Alaska" == timeZone || "Arizona" == timeZone || "Central" == timeZone
			 	|| "Eastern" == timeZone || "Mountain" == timeZone || "Pacific" == timeZone) {
				resourceTimeZone = "US/" + timeZone;
			} else if ("Hawaii (Adak)" == timeZone) {
				resourceTimeZone = "America/Adak";
			} else if ("Hawaii (Honolulu)" == timeZone) {
				resourceTimeZone = "Pacific/Honolulu";
			}
			// if the resource time zone is null, then assign to EST.
			if (resourceTimeZone == null || "" == resourceTimeZone || typeof (resourceTimeZone) == undefined) {
				resourceTimeZone = "EST";
			}
			
			// format date yyyy-mm-dd
			function formatDate(formatDate) {
			    var d = new Date(formatDate),
			        month = ("00" + (d.getMonth() + 1)).slice(-2),
			        day = ("00" + d.getDate()).slice(-2),
			        year = d.getFullYear();
			    return [year, month, day].join('-');
			}
			
			var isChanged = false;
			$('#mobile-layout').html('No search conducted...');
			this._clearWakeupData();
			if (localStorage.getItem('pluginInitData')) {
				this._log(window.location.host + ' OPEN. GET DATA FROM LOCAL STORAGE', JSON.stringify(JSON.parse(localStorage.getItem('pluginInitData')), null, 4));
			}

			var pluginOpenData = receivedData;
			// Get the domain name from the URL
			var domainName = this._getDomainURL();
			var headers = {
					'accept': 'application/json',
					'Content-Type': "application/json",
					'Authorization':
						'Basic ' + btoa(receivedData.securedData.clientId + "@" + domainName + ":" + receivedData.securedData.clientSecret)
				};
			
			var binManagementJSON = {};
			var subInventoryItemList = [];
			
			var subInventoryList = [];
			var subInventoryOwner = [];
			if(receivedData.resource.R_SUBINVENTORY_LIST != null)
				subInventoryList = receivedData.resource.R_SUBINVENTORY_LIST.split(",");
			if(receivedData.resource.R_SUBINVENTORY_OWNER != null)
			subInventoryOwner = receivedData.resource.R_SUBINVENTORY_OWNER.split(",");
			var resourceId = receivedData.resource.external_id;
			
			var primaryOwnedSubInventories = {};
			var sharedSubInventories = {};
			primaryOwnedSubInventories["Primary Sub-Inventory"] = resourceId;
			for(var i = 0; i < subInventoryOwner.length ; i++){
				if(subInventoryOwner[i] == resourceId){
					primaryOwnedSubInventories[subInventoryList[i]] = subInventoryOwner[i];
				} else {
					sharedSubInventories[subInventoryList[i]]  = subInventoryOwner[i];
				}
			}
			
			
			if(receivedData.inventory) {
				inventoryDetails  = true;
				console.log("Build only one item and submit for details");
			} else {
				inventoryDetails = false;
				$.each(sharedSubInventories, function(key, value){
					console.log(value+"   --   -0");
					resourceInventory(value, 0);
				});
				if((Object.keys(primaryOwnedSubInventories).length + Object.keys(sharedSubInventories).length) > 1){
					var optionValue = $('<option />').attr({"value": ""}).text("Select Sub-Inventory");
					$('#search_sub_inventory').append(optionValue);
				}
				
				$.each(primaryOwnedSubInventories, function(key, value){
					var optionValue = $('<option />').attr({"value": value, "data-invtype":"primary-owned"}).text(key);
					$('#search_sub_inventory').append(optionValue);
				});
				
				$.each(sharedSubInventories, function(key, value){
					var optionValue = $('<option />').attr({"value": value, "data-invtype":"shared"}).text(key);
					$('#search_sub_inventory').append(optionValue);
				});
			}
			
			if(inventoryDetails){
				$('.edit_item_number').html(receivedData.inventory.I_ITEM_NUMBER);
				$('.edit_item_desc').html(receivedData.inventory.I_ITEM_DESCRIPTION);
				$('.edit_quantity').html((receivedData.inventory.quantity== null?0:receivedData.inventory.quantity));
				$('#primary-bin-name').val(receivedData.inventory.I_PRIMARY_BIN_NAME);
				// Modified to fix the INC2343370 for NaN issue
				$('#primary-bin-qty').val(getPrimiaryBinQty((receivedData.inventory.quantity == null?0:receivedData.inventory.quantity), receivedData.inventory.I_SECONDARY_BIN_QTY, receivedData.inventory.I_OUTOFBOX_BIN_QTY));
				$('#secondary-bin-name').val(receivedData.inventory.I_SECONDARY_BIN_NAME);
				$('#secondary-bin-qty').val(receivedData.inventory.I_SECONDARY_BIN_QTY);
				$('#out-of-box-bin-name').val(receivedData.inventory.I_OUTOFBOX_BIN_NAME);
				$('#out-of-box-bin-qty').val(receivedData.inventory.I_OUTOFBOX_BIN_QTY);
				$('#edit-invid-val').val(receivedData.inventory.invid);
				if(receivedData.inventory.I_BIN_MANAGEMENT != null && 'Y' == receivedData.inventory.I_BIN_MANAGEMENT){
					$('#bin-mgt').prop("checked", true);
				}
				
				$('.part-number-container').css({"display":"flex"});
				$('#searchBypartyNumber').prop('checked',true);
				$('#partNumber').val(receivedData.inventory.I_ITEM_NUMBER);
				$('#edit-item').show();
				var optionValue = $('<option />').attr({"value": resourceId}).text("CAR_STOCK" == receivedData.inventory.I_SUBINVENTORY?"Primary Sub-Inventory":receivedData.inventory.I_SUBINVENTORY);
				$('#search_sub_inventory').append(optionValue);
				$('#mobile-layout, .part-search-container').hide();
				$('.search-container').find('input, select').prop('disabled',true);
			}
			
			function getPrimiaryBinQty(quantity, secondaryBinQty, OoOBinQty){
				secondaryBinQty = (secondaryBinQty != null && "" != secondaryBinQty && secondaryBinQty != undefined)?parseInt(secondaryBinQty):0;
				OoOBinQty = (OoOBinQty != null && "" != OoOBinQty && OoOBinQty != undefined)?parseInt(OoOBinQty):0;
				return (parseInt(quantity) - (secondaryBinQty + OoOBinQty));
			}
			function resourceInventory(subInventoryOwner, offSet){
				var totalResults = 0;
				//var offSet = 0;
				//do {
				var rInventoryURL = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/resources/" + subInventoryOwner + "/inventories?offset=" + offSet + "&limit=100";
				$.ajax({
					url: rInventoryURL,
					method: 'GET',
					dataType: 'json',
					processData: false,
					contentType: 'application/json; charset=utf-8',
					headers: headers,
					//async: false,
					crossDomain: true,
					timeout: 8000,
					success: function (successData) {
						console.log(successData);
						totalResults = successData.totalResults;
						if(successData.items.length > 0){
							subInventoryItemList = subInventoryItemList.concat(successData.items);
						}
						offSet = offSet + 100;
						if(totalResults > offSet){
							console.log(subInventoryOwner+"   --   "+offSet);
							resourceInventory(subInventoryOwner, offSet);
						}
					},
					error: function (errorData) {
						console.log(errorData);
					}
				});
				//} while (totalResults > offSet);
			}
			
			$('input[name=seachBy]').click(function(){
				$('#partNumber').val('');
				var searchType = $('input[name=seachBy]:checked').val();
				if('ALL' == searchType || 'BIN_MGT' == searchType){
					$('.part-number-container').hide();
				}else if('PART_NUMBER' == searchType) {
					$('.part-number-container').css({"display":"flex"});
				}
			}.bind(this));
			
			$('#searchParts').click(function(){
				$('#edit-item').hide();
				$('#mobile-layout').show();
				var subInventoyName = $( "#search_sub_inventory option:selected" ).text();
				if("Primary Sub-Inventory" == subInventoyName){
					subInventoyName = "CAR_STOCK";
				}
				var subInventoyNumber = $( "#search_sub_inventory option:selected" ).val();
				var searchType = $('input[name=seachBy]:checked').val();
				var partNumber = $('#partNumber').val();
				var addedItemList = [];
				if("" != subInventoyNumber && ("ALL" == searchType || "BIN_MGT" == searchType || ("PART_NUMBER" == searchType && "" != partNumber))){
					var itemExist = false;
					$('#mobile-layout').html('');
					if(primaryOwnedSubInventories.hasOwnProperty(subInventoyName) || "CAR_STOCK" == subInventoyName){
						$.each(receivedData.inventoryList, function (i, v) {
							if(v.invpool === 'provider' && v.I_SUBINVENTORY == subInventoyName 
									&& ("BIN_MGT" != searchType || 'Y' == v.I_BIN_MANAGEMENT)
									&& ("" == partNumber || v.I_ITEM_NUMBER.indexOf(partNumber) != -1)){
								itemExist = true;
								if(addedItemList.indexOf(v.I_ITEM_NUMBER) == -1){
									addedItemList.push(v.I_ITEM_NUMBER);
									var flexPartsDiv = $('<div />').addClass('flex-container-row');
									var partsDiv = $('<div />').css({'flex-basis':'90%'});
									partsDiv.append($('<div />').html('Item: ' + v.I_ITEM_NUMBER));
									partsDiv.append($('<div />').html(v.I_ITEM_DESCRIPTION));
									partsDiv.append($('<div />').html('Quantity: ' + (v.quantity == null? 0 : v.quantity)));
									
									var binNames = "";
									if(v.I_PRIMARY_BIN_NAME != null){
										binNames += v.I_PRIMARY_BIN_NAME;
									}
									if(v.I_PRIMARY_BIN_QTY != null && "" != v.I_PRIMARY_BIN_QTY){
										binNames +='('+getPrimiaryBinQty((v.quantity == null ? 0 : v.quantity), v.I_SECONDARY_BIN_QTY, v.I_OUTOFBOX_BIN_QTY)+')'; // Modified to fix the INC2343370 for NaN issue
									}
									if("" != binNames){
										binNames += ',';
									}
									if(v.I_SECONDARY_BIN_NAME != null){
										binNames += v.I_SECONDARY_BIN_NAME;
									}
									if(v.I_SECONDARY_BIN_QTY != null && "" != v.I_SECONDARY_BIN_QTY){
										binNames +='('+v.I_SECONDARY_BIN_QTY+')';
									}
									if("" != binNames && !binNames.endsWith(",")){
										binNames += ',';
									}
									if(v.I_OUTOFBOX_BIN_NAME != null){
										binNames += v.I_OUTOFBOX_BIN_NAME;
									}
									if(v.I_OUTOFBOX_BIN_QTY != null && "" != v.I_OUTOFBOX_BIN_QTY){
										binNames +='('+v.I_OUTOFBOX_BIN_QTY+')';
									}
									if(binNames.endsWith(",")){
										binNames = binNames.substring(0,binNames.length-1);
									}
									if("" != binNames){
										partsDiv.append($('<div />').css({'word-break':'break-all'}).html('Bin mgt - ' + binNames));
									}
									flexPartsDiv.append(partsDiv);
									var imageDiv = $('<div />').css({'flex-basis':'10%'});
									var anchorTag = $('<div />').addClass('editItem'+v.invid).css({"cursor":"pointer"});
									anchorTag.append($('<img />').attr({'src':'edit_image.png'}).css({'width':'20px'}));
									if(primaryOwnedSubInventories.hasOwnProperty(subInventoyName) || "CAR_STOCK" == subInventoyName){
										imageDiv.append(anchorTag);
									}
									flexPartsDiv.append(imageDiv);
									$('#mobile-layout').append(flexPartsDiv);
									$('#mobile-layout').append($('<div />').addClass('hr-line'));
									
									$('.editItem'+v.invid).click(function(){
										$('#bin-mgt').prop("checked", false);
										var editInvid = v.invid;
										$('#mobile-layout').hide();
										var subInventoyName = $( "#search_sub_inventory option:selected" ).text();
										if("Primary Sub-Inventory" == subInventoyName){
											subInventoyName = "CAR_STOCK";
										}
										$.each(receivedData.inventoryList, function (i, v) {
											if(v.invpool === 'provider' && v.I_SUBINVENTORY == subInventoyName && v.invid == editInvid){
												$('.edit_item_number').html(v.I_ITEM_NUMBER);
												$('.edit_item_desc').html(v.I_ITEM_DESCRIPTION);
												$('.edit_quantity').html(v.quantity == null? 0 : v.quantity);
												$('#primary-bin-name').val(v.I_PRIMARY_BIN_NAME);
												$('#primary-bin-qty').val(getPrimiaryBinQty((v.quantity == null ? 0 : v.quantity), v.I_SECONDARY_BIN_QTY, v.I_OUTOFBOX_BIN_QTY)); // Modified to fix the INC2343370 for NaN issue
												$('#secondary-bin-name').val(v.I_SECONDARY_BIN_NAME);
												$('#secondary-bin-qty').val(v.I_SECONDARY_BIN_QTY);
												$('#out-of-box-bin-name').val(v.I_OUTOFBOX_BIN_NAME);
												$('#out-of-box-bin-qty').val(v.I_OUTOFBOX_BIN_QTY);
												$('#edit-invid-val').val(v.invid);
												if(v.I_BIN_MANAGEMENT != null && 'Y' == v.I_BIN_MANAGEMENT){
													$('#bin-mgt').prop("checked", true);
												}
											}
										});
										$('#edit-item').show();
									}.bind(this));
								}
							}
						});

					}else {
						
						$.each(subInventoryItemList, function (i, v) {
							if( v.I_SUBINVENTORY == subInventoyName 
									&& ("BIN_MGT" != searchType || 'Y' == v.I_BIN_MANAGEMENT)
									&& ("" == partNumber || v.I_ITEM_NUMBER.indexOf(partNumber) != -1)){
								itemExist = true;
								if(addedItemList.indexOf(v.I_ITEM_NUMBER) == -1){
									addedItemList.push(v.I_ITEM_NUMBER);
									var flexPartsDiv = $('<div />').addClass('flex-container-row');
									var partsDiv = $('<div />').css({'flex-basis':'100%'});
									partsDiv.append($('<div />').attr({"data-itemnumber":v.I_ITEM_NUMBER}).html('Item: ' + v.I_ITEM_NUMBER));
									partsDiv.append($('<div />').html(v.I_ITEM_DESCRIPTION));
									partsDiv.append($('<div />').html('Quantity: ' + (v.quantity == null? 0 : v.quantity)));
									
									var binNames = "";
									if(v.I_PRIMARY_BIN_NAME && v.I_PRIMARY_BIN_NAME != null){
										binNames += v.I_PRIMARY_BIN_NAME;
									}
									if(v.I_PRIMARY_BIN_QTY && v.I_PRIMARY_BIN_QTY != null && "" != v.I_PRIMARY_BIN_QTY){
										//binNames +='('+v.I_PRIMARY_BIN_QTY+')';
										binNames +='('+getPrimiaryBinQty((v.quantity == null ? 0 : v.quantity), v.I_SECONDARY_BIN_QTY, v.I_OUTOFBOX_BIN_QTY)+')'; // Modified to fix the INC2343370 for NaN issue
									}
									if("" != binNames){
										binNames += ',';
									}
									if(v.I_SECONDARY_BIN_NAME && v.I_SECONDARY_BIN_NAME != null){
										binNames += v.I_SECONDARY_BIN_NAME;
									}
									if(v.I_SECONDARY_BIN_QTY && v.I_SECONDARY_BIN_QTY != null && "" != v.I_SECONDARY_BIN_QTY){
										binNames +='('+v.I_SECONDARY_BIN_QTY+')';
									}
									if("" != binNames && !binNames.endsWith(",")){
										binNames += ',';
									}
									if(v.I_OUTOFBOX_BIN_NAME && v.I_OUTOFBOX_BIN_NAME != null){
										binNames += v.I_OUTOFBOX_BIN_NAME;
									}
									if(v.I_OUTOFBOX_BIN_QTY && v.I_OUTOFBOX_BIN_QTY != null && "" != v.I_OUTOFBOX_BIN_QTY){
										binNames +='('+v.I_OUTOFBOX_BIN_QTY+')';
									}
									if(binNames.endsWith(",")){
										binNames = binNames.substring(0,binNames.length-1);
									}
									if("" != binNames){
										partsDiv.append($('<div />').css({'word-break':'break-all'}).html('Bin mgt - ' + binNames));
									}
									flexPartsDiv.append(partsDiv);
									$('#mobile-layout').append(flexPartsDiv);
									$('#mobile-layout').append($('<div />').addClass('hr-line'));
								}
							}
						});
					}
					
					var buttonsDiv = $('<div />').addClass('cp_wrapper buttons-panel bottom-buttons');
					buttonsDiv.append($('<button />').addClass('button dismiss').attr({"type":"button","id":"dismiss-btn"}).html('Dismiss'));
					if(!itemExist){
						$('#mobile-layout').append($('<div />').append('No match found.'));
						$('#mobile-layout').append($('<div />').addClass('hr-line'));
					} else if (isChanged) {
						buttonsDiv.append($('<button />').addClass('button submit').attr({"type":"submit","id":"submit-btn"}).html('Submit'));
					}
					$('#mobile-layout').append(buttonsDiv);
					$('#dismiss-btn').click(function () {
						this._sendPostMessageData({
		                    apiVersion: 1,
		                    method: 'close',
		                    wakeupNeeded: false,
		                    backScreen: 'default'
						});
					}.bind(this));
					
					$('#submit-btn').click(function () {
						var binMgtChanges = '';
						if(isChanged){
							$.each(receivedData.inventoryList, function (i, v) {
								if('provider' == v.invpool && 'BIN_MGT' == v.I_BIN_MGT_ACTION){
									$.extend(binManagementJSON,{
										[v.invid]:{
											"I_BIN_MANAGEMENT":v.I_BIN_MANAGEMENT,
											"I_PRIMARY_BIN_NAME":v.I_PRIMARY_BIN_NAME,
											"I_PRIMARY_BIN_QTY":v.I_PRIMARY_BIN_QTY,
											"I_SECONDARY_BIN_NAME":v.I_SECONDARY_BIN_NAME,
											"I_SECONDARY_BIN_QTY":v.I_SECONDARY_BIN_QTY,
											"I_OUTOFBOX_BIN_NAME":v.I_OUTOFBOX_BIN_NAME,
											"I_OUTOFBOX_BIN_QTY":v.I_OUTOFBOX_BIN_QTY,
										}
									});
									var subInventoryName = ("CAR_STOCK" == v.I_SUBINVENTORY) ? resourceId : v.I_SUBINVENTORY;
									binMgtChanges += "<UpdateBinLocation>" +
											"<subinventory>"+subInventoryName+"</subinventory>"+
											"<item>"+v.I_ITEM_NUMBER+"</item>"+
											"<quantity>"+(v.quantity == null ? 0 : v.quantity)+"</quantity>"+
											"<pribinname>"+v.I_PRIMARY_BIN_NAME+"</pribinname>"+
											"<pribinqty>"+v.I_PRIMARY_BIN_QTY+"</pribinqty>"+
											"<secbinname>"+v.I_SECONDARY_BIN_NAME+"</secbinname>"+
											"<secbinqty>"+v.I_SECONDARY_BIN_QTY+"</secbinqty>"+
											"<oobbinname>"+v.I_OUTOFBOX_BIN_NAME+"</oobbinname>"+
											"<oobbinqty>"+v.I_OUTOFBOX_BIN_QTY+"</oobbinqty>"+
											"<binmgt>"+v.I_BIN_MANAGEMENT+"</binmgt>"+
											"<action>BIN_MGT</action></UpdateBinLocation>";
								}
							});
							if("" != binMgtChanges){
								binMgtChanges = "<UpdateBinLocations>"+binMgtChanges+"</UpdateBinLocations>";
							}
							
							var srDate;
							try{
								srDate = new Date(new Date().toLocaleString('en-US', { timeZone: resourceTimeZone }));	
							}catch(err){
								srDate = new Date();
							}
							
							var resourceTimeZoneDate = formatDate(srDate);
							var serviceRequestURL = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/serviceRequests";
							var serviceReqeustParams = {
									date: resourceTimeZoneDate,
									requestType: receivedData.securedData.requestType,
									resourceId: receivedData.resource.external_id,
									S_BIN_MGT: binMgtChanges
							}
							var closeParams = {
								apiVersion: 1,
			                    method: 'close',
			                    wakeupNeeded: false,
			                    backScreen: 'default',
			                    inventoryList: binManagementJSON
							}
							
							var payload = {
									"serviceRequestURL": serviceRequestURL,
									"serviceReqeustParams": serviceReqeustParams,
									"headers": headers,
									"closeParams": closeParams
							}
							$parentThis.createServiceRequest(payload);
						}
						
					}.bind(this));
				} else {
					alert('Please select Sub-Inventory / Seary by / Part number fileds');
					$('#mobile-layout').html('Invalid search performed...');
				}
			}.bind(this));
			
			$('#edit-dismiss').click(function(){
				if(inventoryDetails){
					this._sendPostMessageData({
	                    apiVersion: 1,
	                    method: 'close',
	                    wakeupNeeded: false,
	                    backScreen: 'default'
	                    //,
	                    //backInventoryId: receivedData.inventory.invid
					});
				}else{
					$('#searchParts').trigger('click');
				}
			}.bind(this));
			
			$('#secondary-bin-qty, #out-of-box-bin-qty').on('change',function(){
				var itemQuantity = parseInt($('.edit_quantity').html());
				var editSecondaryBinQty = parseInt($('#secondary-bin-qty').val());
				if(isNaN(editSecondaryBinQty)){
					editSecondaryBinQty = 0;
				}
				if(editSecondaryBinQty < 0){
					$('#secondary-bin-qty').val('0');
				}
				var editOoOBinQty =  parseInt($('#out-of-box-bin-qty').val());
				if(isNaN(editOoOBinQty)){
					editOoOBinQty = 0;
				}
				if(editOoOBinQty < 0){
					$('#out-of-box-bin-qty').val('0');
				}
				$('#primary-bin-qty').val(itemQuantity - (editSecondaryBinQty+editOoOBinQty));
			});
			
			$('#edit-submit').click(function(){
				isChanged = true;
				var editInvId = $('#edit-invid-val').val();
				var editPribinName = $('#primary-bin-name').val().toUpperCase();
				var editPribinQty = parseInt($('#primary-bin-qty').val());
				var editSecbinName = $('#secondary-bin-name').val().toUpperCase();
				var editSecbinQty = parseInt($('#secondary-bin-qty').val());
				if(!isNaN(editSecbinQty)){
					receivedData.inventoryList[editInvId].I_SECONDARY_BIN_QTY = editSecbinQty;
				} else {
					receivedData.inventoryList[editInvId].I_SECONDARY_BIN_QTY = '';
				}
				var editOoObinName = $('#out-of-box-bin-name').val().toUpperCase();
				var editOoObinQty = parseInt($('#out-of-box-bin-qty').val());
				if(!isNaN(editOoObinQty)){
					receivedData.inventoryList[editInvId].I_OUTOFBOX_BIN_QTY = editOoObinQty;
				} else{
					receivedData.inventoryList[editInvId].I_OUTOFBOX_BIN_QTY = '';
				}
				var editbigMgt = $('#bin-mgt').is(':checked')?'Y':'N';
				receivedData.inventoryList[editInvId].I_BIN_MANAGEMENT = editbigMgt;
				receivedData.inventoryList[editInvId].I_PRIMARY_BIN_NAME = editPribinName;
				receivedData.inventoryList[editInvId].I_PRIMARY_BIN_QTY = editPribinQty;
				receivedData.inventoryList[editInvId].I_SECONDARY_BIN_NAME = editSecbinName;
				receivedData.inventoryList[editInvId].I_OUTOFBOX_BIN_NAME = editOoObinName;
				receivedData.inventoryList[editInvId].I_BIN_MGT_ACTION = 'BIN_MGT';
				if(inventoryDetails){
					submitSingleInvenory();
				}else{
					$('#searchParts').trigger('click');
				}
			}.bind(this));
			
			
			function submitSingleInvenory() {
				var binMgtChanges = '';
				if(isChanged){
					$.each(receivedData.inventoryList, function (i, v) {
						if('provider' == v.invpool && 'BIN_MGT' == v.I_BIN_MGT_ACTION){
							$.extend(binManagementJSON,{
								[v.invid]:{
									"I_BIN_MANAGEMENT":v.I_BIN_MANAGEMENT,
									"I_PRIMARY_BIN_NAME":v.I_PRIMARY_BIN_NAME,
									"I_PRIMARY_BIN_QTY":v.I_PRIMARY_BIN_QTY,
									"I_SECONDARY_BIN_NAME":v.I_SECONDARY_BIN_NAME,
									"I_SECONDARY_BIN_QTY":v.I_SECONDARY_BIN_QTY,
									"I_OUTOFBOX_BIN_NAME":v.I_OUTOFBOX_BIN_NAME,
									"I_OUTOFBOX_BIN_QTY":v.I_OUTOFBOX_BIN_QTY,
								}
							});
							var subInventoryName = ("CAR_STOCK" == v.I_SUBINVENTORY) ? resourceId : v.I_SUBINVENTORY;
							binMgtChanges += "<UpdateBinLocation>" +
									"<subinventory>"+subInventoryName+"</subinventory>"+
									"<item>"+v.I_ITEM_NUMBER+"</item>"+
									"<quantity>"+(v.quantity == null ? 0 : v.quantity)+"</quantity>"+
									"<pribinname>"+v.I_PRIMARY_BIN_NAME+"</pribinname>"+
									"<pribinqty>"+v.I_PRIMARY_BIN_QTY+"</pribinqty>"+
									"<secbinname>"+v.I_SECONDARY_BIN_NAME+"</secbinname>"+
									"<secbinqty>"+v.I_SECONDARY_BIN_QTY+"</secbinqty>"+
									"<oobbinname>"+v.I_OUTOFBOX_BIN_NAME+"</oobbinname>"+
									"<oobbinqty>"+v.I_OUTOFBOX_BIN_QTY+"</oobbinqty>"+
									"<binmgt>"+v.I_BIN_MANAGEMENT+"</binmgt>"+
									"<action>BIN_MGT</action></UpdateBinLocation>";
						}
					});
					if("" != binMgtChanges){
						binMgtChanges = "<UpdateBinLocations>"+binMgtChanges+"</UpdateBinLocations>";
					}
					
					var srDate;
					try{
						srDate = new Date(new Date().toLocaleString('en-US', { timeZone: resourceTimeZone }));	
					}catch(err){
						srDate = new Date();
					}
					
					var resourceTimeZoneDate = formatDate(srDate);
					var serviceRequestURL = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/serviceRequests";
					var serviceReqeustParams = {
							date: resourceTimeZoneDate,
							requestType: receivedData.securedData.requestType,
							resourceId: receivedData.resource.external_id,
							S_BIN_MGT: binMgtChanges
					}
					var closeParams = {
						apiVersion: 1,
	                    method: 'close',
	                    wakeupNeeded: false,
	                    backScreen: 'default',
	                    //backInventoryId: receivedData.inventory.invid,
	                    inventoryList: binManagementJSON
					}
					
					var payload = {
							"serviceRequestURL": serviceRequestURL,
							"serviceReqeustParams": serviceReqeustParams,
							"headers": headers,
							"closeParams": closeParams
					}
					$parentThis.createServiceRequest(payload);
				}
			}
			
		},
		createServiceRequest: function(payload){
			try{
				$.ajax({
					dataType: "json",
					url: payload.serviceRequestURL,
					data: JSON.stringify(payload.serviceReqeustParams),
					method: "POST",
					//async: false,
					crossDomain: true,
					headers: payload.headers,
					processData: false,
					contentType: 'application/json; charset=utf-8',
					timeout: 15000,
					success: function(response) {
						console.log("Notes create Service Request - Success messagae: " + JSON.stringify(response));
						this._sendPostMessageData(payload.closeParams); 
					}.bind(this),
					error: function(errorData) {
						console.log("Notes create Service Request - Error messagae: " + JSON.stringify(errorData));
						this._sendPostMessageData(payload.closeParams); 
					}.bind(this)
				});
			} catch(err){
					var resourceErrorPayload = {"R_PLUGIN_ERROR":"error while creating Service Request: "+err.message};
			}
		},

		/**
		 * Business login on plugin wakeup (background open for sync)
		 *
		 * @param {Object} receivedData - JSON object that contain data from OFS
		 */
		pluginWakeup: function (receivedData) {
			this._log(window.location.host + ' WAKEUP', JSON.stringify(receivedData, null, 4));

			var wakeupData = {
				pluginWakeupCount: +localStorage.getItem('pluginWakeupCount'),
				pluginWakeupMaxCount: +localStorage.getItem('pluginWakeupMaxCount'),
				pluginWakeupDontRespondOn: +localStorage.getItem('pluginWakeupDontRespondOn'),
				pluginWakeupChangeIcon: JSON.parse(localStorage.getItem('pluginWakeupChangeIcon'))
			};

			wakeupData.pluginWakeupCount = wakeupData.pluginWakeupCount + 1;

			localStorage.setItem('pluginWakeupCount', wakeupData.pluginWakeupCount);
			localStorage.setItem('pluginWakeupMaxCount', wakeupData.pluginWakeupMaxCount);
			localStorage.setItem('pluginWakeupDontRespondOn', wakeupData.pluginWakeupDontRespondOn);
			localStorage.setItem('pluginWakeupChangeIcon', wakeupData.pluginWakeupChangeIcon);

			this._log(window.location.host + ' SAVE WAKEUP DATA TO LOCAL STORAGE', JSON.stringify(wakeupData, null, 4));

			if (wakeupData.pluginWakeupDontRespondOn == wakeupData.pluginWakeupCount) {
				this._log(window.location.host + ' EMULATE NOT RESPONDING PLUGIN');

				return;
			}

			var iconUrl = './online.svg';
			var iconPromise = wakeupData.pluginWakeupChangeIcon ? this._getBlob(iconUrl) : Promise.resolve(null);

			iconPromise.then(function (iconFile) {
				var iconDataParams = {};

				if (iconFile) {
					iconDataParams.iconData = {
						text: '' + wakeupData.pluginWakeupCount,
						image: iconFile
					};
				}

				if (wakeupData.pluginWakeupCount < wakeupData.pluginWakeupMaxCount) {
					setTimeout(function () {
						this._log(window.location.host + ' SLEEP. RETRY NEEDED');

						this._sendPostMessageData($.extend({
							apiVersion: 1,
							method: 'sleep',
							wakeupNeeded: true
						}, iconDataParams));
					}.bind(this), 2000);
				} else {
					setTimeout(function () {
						this._log(window.location.host + ' SLEEP. NO RETRY');

						this._sendPostMessageData($.extend({
							apiVersion: 1,
							method: 'sleep',
							wakeupNeeded: false
						}, iconDataParams));
					}.bind(this), 12000);
				}
			}.bind(this)).catch(function () {
				this._log('Unable to load icon file "' + iconUrl + '"', null, null, true);
			}.bind(this));
		},

		/**
		 * Save configuration of wakeup (background open for sync) behavior for Plugin
		 * to Local Storage
		 *
		 * @private
		 */
		_saveWakeupData: function () {
			var wakeupData = {
				pluginWakeupCount: 0,
				pluginWakeupMaxCount: 0,
				pluginWakeupDontRespondOn: 0,
				pluginWakeupChangeIcon: false
			};

			if ($('#wakeup').is(':checked')) {
				wakeupData.pluginWakeupMaxCount = parseInt($('#repeat_count').val());

				if ($('#dont_respond').is(':checked')) {
					wakeupData.pluginWakeupDontRespondOn = parseInt($('#dont_respond_on').val());
				}

				if ($('#wakeup_change_icon').is(':checked')) {
					wakeupData.pluginWakeupChangeIcon = true;
				}
			}

			localStorage.setItem('pluginWakeupCount', wakeupData.pluginWakeupCount);
			localStorage.setItem('pluginWakeupMaxCount', wakeupData.pluginWakeupMaxCount);
			localStorage.setItem('pluginWakeupDontRespondOn', wakeupData.pluginWakeupDontRespondOn);
			localStorage.setItem('pluginWakeupChangeIcon', wakeupData.pluginWakeupChangeIcon);

			this._log(window.location.host + ' SAVE WAKEUP DATA TO LOCAL STORAGE', JSON.stringify(wakeupData, null, 4));
		},

		/**
		 * Clear previous configuration of wakeup (background open for sync) behavior for Plugin
		 * from the Local Storage
		 *
		 * @private
		 */
		_clearWakeupData: function () {
			localStorage.removeItem('pluginWakeupCount');
			localStorage.removeItem('pluginWakeupMaxCount');
			localStorage.removeItem('pluginWakeupDontRespondOn');
			localStorage.removeItem('pluginWakeupChangeIcon');

			this._log(window.location.host + ' CLEAR WAKEUP DATA FROM LOCAL STORAGE');
		},

		/**
		 * Update JSON
		 *
		 * @private
		 */
		_updateResponseJSON: function () {
			var jsonToSend = this.generateJson();

			$('.json__response').text(JSON.stringify(jsonToSend, null, 4));
		},

		/**
		 * Initialization function
		 */
		init: function () {
			if (navigator.serviceWorker) {
				this._log(window.location.host + ' Service Worker is supported');

				navigator.serviceWorker.register('binmgt-service-worker.js').then(function (registration) {
					this._log(window.location.host + ' Service Worker is registered with scope: ' + registration.scope);

					registration.addEventListener('updatefound', function () {
						this._log(window.location.host + ' Service Worker update is found');
						var newServiceWorker = registration.installing;
						newServiceWorker.addEventListener('statechange', function () {
							switch (newServiceWorker.state) {
								case "installed":
									this._log(window.location.host + ' New Service Worker is installed');
									break;
							}
						}.bind(this));
					}.bind(this));

					navigator.serviceWorker.addEventListener('controllerchange', function () {
						this.notifyAboutNewVersion();
					}.bind(this));

					this.startApplication();
				}.bind(this), function (err) {
					this._log(window.location.host + ' Service Worker registration failed: ' + err);
					this.startApplication();
				}.bind(this));

				return;
			} else {
				this._log(window.location.host + ' Service Worker is not supported');
			}

			this.startApplication();
		},

		startApplication: function () {
			this._log(window.location.host + ' PLUGIN HAS BEEN STARTED');

			window.addEventListener("message", this._getPostMessageData.bind(this), false);

			var jsonToSend = {
				apiVersion: 1,
				method: 'ready',
				sendInitData: true
			};

			//parse data items
			var dataItems = JSON.parse(localStorage.getItem('dataItems'));

			if (dataItems) {
				$.extend(jsonToSend, {
					dataItems: dataItems
				});
			}

			this._sendPostMessageData(jsonToSend);
		},

		notifyAboutNewVersion: function () {
			this._log(window.location.host + ' New Service Worker is activated. Page refresh is needed');
			var footer = document.querySelector('.footer');
			var versionNotificationElement = document.createElement('div');
			versionNotificationElement.className = 'new-version-notification';
			versionNotificationElement.innerHTML = 'New version is detected. Please reopen the page';
			footer.appendChild(versionNotificationElement);
		}
	});

	window.OfscPlugin.getVersion = function () {
		return resourcesVersion;
	};

	function getPositionInRouteEnum() {
		var result = [{
				label: '{"position": "first"}',
				text: 'First'
			},
			{
				label: '{"position": "last"}',
				text: 'Last'
			},
			{
				label: '{"position": "notOrdered"}',
				text: 'Not Ordered'
			}
		];

		if (pluginOpenData && pluginOpenData.activityList) {
			Object.keys(pluginOpenData.activityList).forEach(function (aid) {
				result.push({
					label: '{"position": "afterActivity", "activityId": "' + aid + '"}',
					text: 'After activity ' + aid
				});
			});
		}

		return result;
	}

	function getCurrentDateIso() {
		var date = new Date();
		var result = [date.getFullYear(), date.getMonth() + 1, date.getDate()];

		if (result[1] < 10) {
			result[1] = '0' + result[1];
		}

		if (result[2] < 10) {
			result[2] = '0' + result[2];
		}

		return result.join('-');
	}

	/**
	 * @returns {ResourceTimeObject}
	 */
	function getResourceTimeObject() {
		var resource = (pluginOpenData && pluginOpenData.resource) || {};

		return {
			browserTimeDiffMs: resource.browserTimeDiffMs || 0,
			pluginOpenTime: resource.currentTime || null
		};
	}

	/**
	 * @typedef {{
	 *     browserTimeDiffMs: number,
	 *     pluginOpenTime: string|null
	 * }} ResourceTimeObject
	 */

})(jQuery);