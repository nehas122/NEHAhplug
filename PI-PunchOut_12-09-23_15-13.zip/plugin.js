"use strict";
(function($) {
	window.OfscPlugin = function(debugMode) {
		this.debugMode = debugMode || false;
	};
	var g_wakeupNeeded, g_wakeupMethod;
	$.extend(window.OfscPlugin.prototype, {
        /**
         * Dictionary of enums
         */
		dictionary: {
			astatus: {
				pending: {
					label: 'pending',
					translation: 'Pending',
					outs: ['started', 'cancelled', 'suspended'],
					color: '#FFDE00'
				},
				started: {
					label: 'started',
					translation: 'Started',
					outs: ['complete', 'suspended', 'notdone', 'cancelled'],
					color: '#A2DE61'
				},
				complete: {
					label: 'complete',
					translation: 'Completed',
					outs: [],
					color: '#79B6EB'
				},
				suspended: {
					label: 'suspended',
					translation: 'Suspended',
					outs: [],
					color: '#9FF'
				},
				notdone: {
					label: 'notdone',
					translation: 'Not done',
					outs: [],
					color: '#60CECE'
				},
				cancelled: {
					label: 'cancelled',
					translation: 'Cancelled',
					outs: [],
					color: '#80FF80'
				}
			},
			invpool: {
				customer: {
					label: 'customer',
					translation: 'Customer',
					outs: ['deinstall'],
					color: '#04D330'
				},
				install: {
					label: 'install',
					translation: 'Installed',
					outs: ['provider'],
					color: '#00A6F0'
				},
				deinstall: {
					label: 'deinstall',
					translation: 'Deinstalled',
					outs: ['customer'],
					color: '#00F8E8'
				},
				provider: {
					label: 'provider',
					translation: 'Resource',
					outs: ['install'],
					color: '#FFE43B'
				}
			}
		},
		actions: {
			activity: [
				{
					value: '',
					translation: 'Select Action...'
				},
				{
					value: 'create',
					translation: 'Create Activity'
				}
			],
			inventory: [
				{
					value: '',
					translation: 'Select Action...'
				},
				{
					value: 'create',
					translation: 'Create Inventory'
				},
				{
					value: 'delete',
					translation: 'Delete Inventory'
				},
				{
					value: 'install',
					translation: 'Install Inventory'
				},
				{
					value: 'deinstall',
					translation: 'Deinstall Inventory'
				},
				{
					value: 'undo_install',
					translation: 'Undo Install Inventory'
				},
				{
					value: 'undo_deinstall',
					translation: 'Undo Deinstall Inventory'
				}
			]
		},

        /**
         * Check for string is valid JSON
         *
         * @param {*} str - String that should be validated
         *
         * @returns {boolean}
         *
         * @private
         */
		_isJson: function(str) {
			try {
				JSON.parse(str);
			} catch (e) {
				return false;
			}
			return true;
		},
        /**
         * Return origin of URL (protocol + domain)
         *
         * @param {String} url
         *
         * @returns {String}
         *
         * @private
         */
		_getOrigin: function(url) {
			if (url != '') {
				if (url.indexOf("://") > -1) {
					return 'https://' + url.split('/')[2];
				} else {
					return 'https://' + url.split('/')[0];
				}
			}
			return '';
		},
        /**
         * Return domain of URL
         *
         * @param {String} url
         *
         * @returns {String}
         *
         * @private
         */
		_getDomain: function(url) {
			if (url != '') {
				if (url.indexOf("://") > -1) {
					return url.split('/')[2];
				} else {
					return url.split('/')[0];
				}
			}
			return '';
		},
		/**
		* get domain / company name
		*/
		_getDomainURL: function() {
			//return document.referrer.match(/\:\/\/([^\/]+)\.etadirect\.com\//)[1];
			//Reg Ex modified to handle both etadirect.com and fs.ocs.oraclecloud.com URLs
			return document.referrer.match(/\:\/\/([^\/]+)\.(?:etadirect.com|fs.ocs.oraclecloud.com)/)[1];
		},
        /**
         * Sends postMessage to document.referrer
         *
         * @param {Object} data - Data that will be sent
         *
         * @private
         */
		_sendPostMessageData: function(data) {
			var originUrl = document.referrer || (document.location.ancestorOrigins && document.location.ancestorOrigins[0]) || '';
			var isString = 'string' === typeof data;
			if (originUrl) {
				this._log(window.location.host + ' -> ' + (isString ? '' : data.method) + ' ' + this._getDomain(originUrl), isString ? data : JSON.stringify(data, null, 4));
				parent.postMessage(data, this._getOrigin(originUrl));
			} else {
				this._log(window.location.host + ' -> ' + (isString ? '' : data.method) + ' ERROR. UNABLE TO GET REFERRER');
			}
		},
        /**
         * Handles during receiving postMessage
         *
         * @param {MessageEvent} event - Javascript event
         *
         * @private
         */
		_getPostMessageData: function(event) {
			if (typeof event.data === 'undefined') {
				this._log(window.location.host + ' <- NO DATA ' + this._getDomain(event.origin), null, null, true);
				return false;
			}
			if (!this._isJson(event.data)) {
				this._log(window.location.host + ' <- NOT JSON ' + this._getDomain(event.origin), null, null, true);
				return false;
			}
			var data = JSON.parse(event.data);
			if (!data.method) {
				this._log(window.location.host + ' <- NO METHOD ' + this._getDomain(event.origin), null, null, true);
				return false;
			}
			this._log(window.location.host + ' <- ' + data.method + ' ' + this._getDomain(event.origin), JSON.stringify(data, null, 4));
			switch (data.method) {
				case 'init':
					this.pluginInitEnd(data);
					break;
				case 'open':
					this.pluginOpen(data);
					break;
				case 'wakeup':
					this.pluginWakeup(data);
					break;
				case 'error':
					data.errors = data.errors || { error: 'Unknown error' };
					this._showError(data.errors);
					break;
				default:
					this._log(window.location.host + ' <- UNKNOWN METHOD: ' + data.method + ' ' + this._getDomain(event.origin), null, null, true);
					break;
			}
		},
        /**
         * Show alert with error
         *
         * @param {Object} errorData - Object with errors
         *
         * @private
         */
		_showError: function(errorData) {
			alert(JSON.stringify(errorData, null, 4));
		},
        /**
         * Logs to console
         *
         * @param {String} title - Message that will be log
         * @param {String} [data] - Formatted data that will be collapsed
         * @param {String} [color] - Color in Hex format
         * @param {Boolean} [warning] - Is it warning message?
         *
         * @private
         */
		_log: function(title, data, color, warning) {
			if (!this.debugMode) {
				return;
			}
			if (!color) {
				color = '#0066FF';
			}
			if (!!data) {
				console.groupCollapsed('%c[Plugin API] ' + title, 'color: ' + color + '; ' + (!!warning ? 'font-weight: bold;' : 'font-weight: normal;'));
				console.log('[Plugin API] ' + data);
				console.groupEnd();
			} else {
				console.log('%c[Plugin API] ' + title, 'color: ' + color + '; ' + (!!warning ? 'font-weight: bold;' : ''));
			}
		},

        /**
         * Business login on plugin init
         */
		saveToLocalStorage: function(data) {
			this._log(window.location.host + ' INIT. SET DATA TO LOCAL STORAGE', JSON.stringify(data, null, 4));
			var initData = {};
			$.each(data, function(key, value) {
				if (-1 !== $.inArray(key, ['apiVersion', 'method'])) {
					return true;
				}
				initData[key] = value;
			});
			localStorage.setItem('pluginInitData', JSON.stringify(initData));
		},
        /**
         * Business login on plugin init end
         *
         * @param {Object} data - JSON object that contain data from OFSC
         */
		pluginInitEnd: function(data) {
			this.saveToLocalStorage(data);
			var messageData = {
				apiVersion: 1,
				method: 'initEnd'
			};
			if (localStorage.getItem('pluginWakeupCount') < localStorage.getItem('pluginWakeupMaxCount')) {
				this._log(window.location.host + ' UNFINISHED WAKEUP DATA FOUND IN LOCAL STORAGE');
				messageData.wakeupNeeded = true;
			}
			this._sendPostMessageData(messageData);
		},
		/**
         * Clear previous configuration of wakeup (background open for sync) behavior for Plugin
         * from the Local Storage
         *
         * @private
         */
		_clearWakeupData: function() {
			localStorage.removeItem('pluginWakeupCount');
			localStorage.removeItem('pluginWakeupMaxCount');
			localStorage.removeItem('pluginWakeupDontRespondOn');
			localStorage.removeItem('punchoutResourseUpdateQueue');
			localStorage.removeItem('punchOutEODQueue');

			this._log(window.location.host + ' CLEAR WAKEUP DATA FROM LOCAL STORAGE');
		},
		/**
		* Ajax call to update the properties
		*/
		ajaxCall: function(url, payload, method, headers) {
			$.ajax({
				dataType: "json",
				url: url,
				data: JSON.stringify(payload),
				method: method,
				//async: false,
				crossDomain: true,
				headers: headers,
				processData: false,
				contentType: 'application/json; charset=utf-8',
				timeout: 15000,
				success: function(response) {
					console.log("Update Resource properties - Success messagae: " + JSON.stringify(response));
				}.bind(this),
				error: function(errorData) {
					console.log("Update Resource properties - Error messagae:" + JSON.stringify(errorData));
				}
			});
		},
		/**
		 * Popup method
		 */
		popupEnable: function(message, enableButton, displayPopup, styleClass){
			if(message != null && "" != message && typeof(message) != undefined){
				$('#messagePanel ul').html($('<li/>').addClass(styleClass).append(message));
				if(enableButton){
					$('#messagePanel #notification-clear').show();
				} else {
					$('#messagePanel #notification-clear').hide();
				}
				if(displayPopup){
					$('#messagePanel').show();
				} else {
					$('#messagePanel').hide();
				}
			}
		},
        /**
         * Business login on plugin open
         *
         * @param {Object} receivedData - JSON object that contain data from OFSC
         */
		pluginOpen: function(receivedData) {
			this._clearWakeupData();
			if (localStorage.getItem('pluginInitData')) {
				this._log(window.location.host + ' OPEN. GET DATA FROM LOCAL STORAGE', JSON.stringify(JSON.parse(localStorage.getItem('pluginInitData')), null, 4));
			}
			
			// Get the domain name from the URL
			var domainName = this._getDomainURL();
			
			//remainder section variables
			var totalReminders = 0;
			var excessReminders = 0;
			var returnableReminders = 0;
			
			// reimbursible expenses variables
			var resourceExpanses = parseFloat('0.0');
			var reimbursableExpensesArr = [];
			var reimbursableExpensesAmt = [];
			
			//Report section variables
			var totalMilage = 0;
			var punchInDt;
			var rPunchinTime = receivedData.resource.R_PUNCH_IN_TIME;
			if(rPunchinTime != null && '' != rPunchinTime && typeof(rPunchinTime) != undefined){
				rPunchinTime = rPunchinTime.split("|")[0]; // rPunchinTime.replace("|",""); Modified for CHG0078516 - OFSC EOD Summation Logic
                punchInDt = rPunchinTime.substr(0, 10);
				console.log("Punch In Date:" + punchInDt);
			}
			rPunchinTime += ':00'; // Added for CHG0078516 - OFSC EOD Summation Logic
			
			var totalReImbursableAmountSum;
			var totalReImbursableAmount = 0;
			var nonPaidTimeMinutes = 0;
			var punchOutHour;
			var punchOutMinute;
			
			// Resource update URL
			var resourceUpdateUrl = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/resources/" + receivedData.resource.external_id;
			
			//First activity for the next day variables
			var resourceTimeZone = receivedData.resource.time_zone;
			
			var TimeZoneMapping = {
                "19": "Alaska",
                "6": "Arizona",
                "4": "Central",
                "2": "Eastern",
                "15": "GMT",
                "17": "Hawaii (Adak)",
                "18": "Hawaii (Honolulu)",
                "5": "Mountain",
                "7": "Pacific"
            };
			
            var timeZone = TimeZoneMapping[resourceTimeZone];
			
			
			// Set the timezone to retreive the Date & time for Activate route & punch in 
			if ("Alaska" == timeZone || "Arizona" == timeZone || "Central" == timeZone
			 	|| "Eastern" == timeZone || "Mountain" == timeZone || "Pacific" == timeZone) {
				resourceTimeZone = "US/" + timeZone;
			} else if ("Hawaii (Adak)" == timeZone) {
				resourceTimeZone = "America/Adak";
			} else if ("Hawaii (Honolulu)" == timeZone) {
				resourceTimeZone = "Pacific/Honolulu";
			}
			// if the resource time zone is null, then assign to EST.
			if (resourceTimeZone == null || "" == resourceTimeZone || typeof (resourceTimeZone) == undefined) {
				resourceTimeZone = "EST";
			}
			

			// format date and time yyyy-mm-dd hh:mm:ss Added for CHG0078516 - OFSC EOD Summation Logic
			function formatDTime(dateTimeString){
				var[requestDate, requestTime]= dateTimeString.split(' ');
				var [year,month,date] = requestDate.split('-');
				var [hours,minutes,seconds]= requestTime.split(':')
				return new Date(year,month-1,date,hours,minutes,seconds);
			}

			// format date yyyy-mm-dd
			function formatDate(formatDate) {
			    var d = new Date(formatDate),
			        month = ("00" + (d.getMonth() + 1)).slice(-2),
			        day = ("00" + d.getDate()).slice(-2),
			        year = d.getFullYear();
			    return [year, month, day].join('-');
			}

			// format dateString to date Added for CHG0078516 - OFSC EOD Summation Logic
			function convertStringToDate(stringDate){
				var [year,month,date] = stringDate.split('-');
				return new Date(year,month-1,date);
			}
		
			// format date yyyy-MM-dd HH:mm / yyyy-MM-ddTHH:mm
			function formatDateTime(formatDate,fillValue) {
			    var d = new Date(formatDate),
			        month = ("00" + (d.getMonth() + 1)).slice(-2),
			        day = ("00" + d.getDate()).slice(-2),
			        year = d.getFullYear(),
					hours = ("00" + d.getHours()).slice(-2),
					minutes = ("00" + d.getMinutes()).slice(-2);
			    return [year, month, day].join('-')+fillValue+[hours, minutes].join(':');
			}
			
			// Building Authorization headers
			var headers = {
				'Authorization':
					'Basic ' + btoa(receivedData.securedData.clientId + "@" + domainName + ":" + receivedData.securedData.clientSecret)
			};
			
			var tomorrowDate, nextDayDate, todayDate, todayDateOnly;
			try{
				// Tomorrow Date 
				tomorrowDate = new Date(new Date().toLocaleString('en-US', { timeZone: resourceTimeZone }));
				tomorrowDate.setDate(tomorrowDate.getDate()+1);
				nextDayDate = formatDate(tomorrowDate);
				
				// Today Date
				var todayDate = new Date(new Date().toLocaleString('en-US', { timeZone: resourceTimeZone }));
				var todayDateOnly =  formatDate(todayDate);
			}catch(err){
				var resourceErrorPayload = {"R_PLUGIN_ERROR": "Error calling workschedule api : "+err.message};
				this.ajaxCall(resourceUpdateUrl, resourceErrorPayload, "PATCH", headers);
				// Tomorrow Date 
				tomorrowDate = new Date();
				tomorrowDate.setDate(tomorrowDate.getDate()+1);
				nextDayDate = formatDate(tomorrowDate);
				
				// Today Date
				todayDate = new Date();
				todayDateOnly =  formatDate(todayDate);
			}
			
			// Start Reminder section
			$.each(receivedData.inventoryList, function (i, v) {
				if (v.invtype === 'EXCESS') {
					totalReminders += 1;
					excessReminders += 1;
					$('#excessItemList').append("<li>Excess Id: " + v.I_EXCESS_ID + " Parts - " + v.I_ITEM_NUMBER + " Qty - " + v.quantity + "</li>");
				} else if (v.invtype === 'DEFECTIVE') {
					totalReminders += 1;
					returnableReminders += 1;
					$('#returnableItemList').append("<li>Returnable Id: " + v.I_RETURN_ID + " Parts - " + v.I_ITEM_NUMBER + " Qty - " + v.quantity + "</li>");
				}
			});
			$('#count_reminders').text('(' + totalReminders + ')');
			$('#excessCount').text('(' + excessReminders + ')');
			$('#returnableCount').text('(' + returnableReminders + ')');
			
			// action to enable or disable the reminder section
			enableReminder();
			$('.reminder_header').click(function () {
				$('.reminder-items').toggle();
				enableReminder();
            }); 

			function enableReminder(){
				if($('.reminder-items').is(":visible")){
					$('.reminder_header .arrow-grid').removeClass('arrow-maximize-grid margin-top-5').addClass('arrow-minimize-grid margin-top-10');
				} else {
					$('.reminder_header .arrow-grid').addClass('arrow-maximize-grid margin-top-5').removeClass('arrow-minimize-grid margin-top-10');
				}
			}
			// End Reminder section
			
			
			// Reimbursable expenses start
			/*Restricting User to enter invalid character in ReImbursable Section*/
            $('#cpf_NewReimbursableExpensesAmount_inner').keypress(function (event) {
                if ((event.which != 46 || $(this).val().indexOf('.') != -1) && (event.which < 48 || event.which > 57)) {
                    event.preventDefault();
                }
            });

			/*Restricting User to enter invalid amount in ReImbursable Section*/
			$('#cpf_NewReimbursableExpensesAmount_inner').keyup(function () {
                if(parseFloat($(this).val())> 999999.99){
					$(this).val($(this).val().slice(0, -1));
				};
            });

            /*ReImursable Section Add Behaviour*/
            $('#add_expenses_reimbursable').click(function () {
                $('.add_expenses_reimbursable_row').removeClass('display-none');
            });

			/*Binding New Section Added to ReImbursable Section*/
            function bindReImbursableSection(selectedItemName, selectedItem, expenseAmount) {
				console.log('expenseAmount:', expenseAmount);
				var trElement = $('<tr />').addClass('tr_expenses_reimbursable');
				trElement.append($('<input />').attr({"type":"hidden","name":"key_expenses_reimbursable","class":"key_expenses_reimbursable","value":selectedItem}));
				trElement.append($('<input />').attr({"type":"hidden","name":"name_expenses_reimbursable","class":"name_expenses_reimbursable","value":"PARKING EXPENSE"}));
				trElement.append($('<td />').addClass("no_border").append(selectedItemName));
				trElement.append($('<td />').addClass("no_border").append($('<a/>').attr({"selectedAmount":expenseAmount,"selectedItem":selectedItem,"href":"#"}).addClass("remove_expenses_reimbursable").append("Remove")));
				trElement.append($('<td />').attr({"align":"right"}).addClass("no_border").append("$ ").append($('<input />').attr({"type":"text","maxlength":"9","selectedItem":selectedItem,"value":expenseAmount}).addClass("sum_expenses_reimbursable read form-item")));
				$('.add_expenses_reimbursable_result table').prepend(trElement);               
            }
			
			// ReImbursable Save Action
            $('#reImbursableSaveBtn').click(function () {
                var selectedItem = $('#cpf_ReimbursableExpensesType_inner').val();
                var selectedItemName = $('#cpf_ReimbursableExpensesType_inner option:selected').text();
                var expenseAmountInput = $('#cpf_NewReimbursableExpensesAmount_inner');
                var expenseAmount = parseFloat(expenseAmountInput.val()).toFixed(2);
                if (selectedItem !== undefined && selectedItem !== null && selectedItem !== '' && expenseAmount !== undefined && expenseAmount !== null && expenseAmount !== '') {
					resourceExpanses = parseFloat(resourceExpanses) + parseFloat(expenseAmount);
					resourceExpanses = parseFloat(resourceExpanses).toFixed(2);	
                    if ($.isNumeric(expenseAmount) && parseFloat(expenseAmount).toFixed(2) > 0.00) {
                        var tempObj = {"key":selectedItem,"name":selectedItemName, "sum":expenseAmount };
                        reimbursableExpensesArr.push(selectedItem);
                        reimbursableExpensesAmt.push(tempObj);
                        bindReImbursableSection(selectedItemName, selectedItem, expenseAmount);
                        $('.add_expenses_reimbursable_row').addClass('display-none');
                        expenseAmountInput.val('');
                        $('#btn_save').css("visibility", "visible");
                    } else {
                        if (parseFloat(expenseAmount).toFixed(2) === 0) {
                            alert('Amount Should Be Greater Than Zero(0)');
                        } else {
                            alert('Only Positive Numeric Values Are Allowed');
                        }
                    }				
                } else {
                    alert('Please Fill Out All The Fields');
                }
            });
			
			//Removing Added Reimbursable Tag
            $(document).on("click", "a.remove_expenses_reimbursable", function () {
                $('#btn_save').css("visibility", "visible");
                var removableItem = $(this).attr('selectedItem');
                reimbursableExpensesArr.splice(reimbursableExpensesArr.indexOf(removableItem), 1);
                for(var i=0;i<reimbursableExpensesAmt.length;i++ ){
                    if(reimbursableExpensesAmt[i].key === removableItem){
                        reimbursableExpensesAmt.splice(i, 1);
                    }
                }
                $(this).parent().parent().remove();
            });

			//Capturing ReImbursable Amount
            $(document).on('keyup', 'input.sum_expenses_reimbursable.read', function () {
				var temp123 = parseFloat($(this).val());
				if(temp123> 999999.99){
						$(this).val($(this).val().slice(0, -1));

				};
                $('#btn_save').css("visibility", "visible");
                var selectedElement = $(this).attr('selectedItem');
                var prevValue = parseFloat($(this).val()).toFixed(2);
                reimbursableExpensesAmt.forEach(function (data) {
                    if (data.key === selectedElement) {
                        data.sum = prevValue;
                    }
                });
            });
			// Reimbursable expences End
			
			// Notification section Start
			var nextDayShiftStartTime = "";			// change for CHG0079933
			try{
				var workScheduleRecordType = "";
					var workScheduleURL = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/resources/" + receivedData.resource.external_id+"/workSchedules/calendarView?dateFrom="+todayDateOnly+"&dateTo="+todayDateOnly;
					// Ajax call to get the tech nextday activities
					$.ajax({
						dataType: "json",
						url: workScheduleURL,
						method: "GET",
						async: false,	// uncommented for CHG0079933
						crossDomain: true,
						headers: headers,
						processData: false,
						contentType: 'application/json; charset=utf-8',
						timeout: 15000,
						success: function(response) {
							console.log("While retreiving work schedule for tech - Success messagae: " + JSON.stringify(response));
							if(response.hasOwnProperty(todayDateOnly)){
								var dateResponse = response[todayDateOnly];
								if(dateResponse.hasOwnProperty("on-call")){
									// Change CHG0083120 starts
										$('.calc_mess.notification_message').text("You are On-Call today");
										/*workScheduleRecordType = dateResponse["on-call"].recordType;
										if(dateResponse["on-call"].recordType === 'extra_working'){
											$('.calc_mess.notification_message').text("You are On-Call today");
										}else{
											$('.calc_mess.notification_message').text("You are not On-Call today");
										}*/
									// Change CHG0083120 ends
								}else{
									$('.calc_mess.notification_message').text("You are not On-Call today");
								}
								// Change CHG0079933 Starts
								if(dateResponse.hasOwnProperty("regular")){
									nextDayShiftStartTime = dateResponse["regular"].workTimeStart;
									nextDayShiftStartTime += ":00";									
								}
								// Change CHG0079933 Ends
							} 
						}.bind(this),
						error: function(errorData) {
							console.log("While retreiving work schedule for tech - Error messagae:" + JSON.stringify(errorData));
							$('.calc_mess.notification_message').text("Shift information is available online only");
						}
					});
			}catch(err){
				var resourceErrorPayload = {"R_PLUGIN_ERROR": "Error calling workschedule api : "+err.message};
				this.ajaxCall(resourceUpdateUrl, resourceErrorPayload, "PATCH", headers);
			}
			// Notification section end
			//get the today Activities
			try{
					var nextDayActivityListURL = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/resources/" + receivedData.resource.external_id+"/routes/"+punchInDt;
					// Ajax call to get the tech today activities
					$.ajax({
						dataType: "json",
						url: nextDayActivityListURL,
						method: "GET",
						async: false,
						crossDomain: true,
						headers: headers,
						processData: false,
						contentType: 'application/json; charset=utf-8',
						timeout: 15000,
						success: function(response) {
							console.log("While retreiving next activities for tech - Success messagae: " + JSON.stringify(response));
							if(response.totalResults > 0){
								receivedData.activityList = response.items;
							}else{
								receivedData.activityList = [];
							}
						}.bind(this),
						error: function(errorData) {
							console.log("While retreiving today activities for tech - Error messagae:" + JSON.stringify(errorData));
							receivedData.activityList = [];
						}
					});
			}catch(err){
				var resourceErrorPayload = {"R_PLUGIN_ERROR": "Error calling nextday activity list: "+err.message};
				this.ajaxCall(resourceUpdateUrl, resourceErrorPayload, "PATCH", headers);
			}

			// to check if eod date is same as punchIn date Start added for CHG0078516 - OFSC EOD Summation Logic
			var todayDateFormat = convertStringToDate(todayDateOnly);
			var punchInDateonly = convertStringToDate(punchInDt);
			// pull all activity date of next day back to previous day todaysDateTime
			var dates = [];
			if(todayDateFormat>punchInDateonly){
				do{
					punchInDateonly.setDate(punchInDateonly.getDate()+1);
					dates.push(formatDate(punchInDateonly));
				}
				while(todayDateFormat > punchInDateonly );

				if (dates.length >0 ){
					$.each(dates, function(k,v){
						
						try{
							var previousDayActivityListURL = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/resources/" + receivedData.resource.external_id+"/routes/"+v;
							// Ajax call to get the tech today activities
							$.ajax({
								dataType: "json",
								url: previousDayActivityListURL,
								method: "GET",
								async: false,
								crossDomain: true,
								headers: headers,
								processData: false,
								contentType: 'application/json; charset=utf-8',
								timeout: 15000,
								success: function(response) {
									console.log("While retreiving next activities for tech - Success messagae: " + JSON.stringify(response));
									if(response.totalResults > 0){
										receivedData.activityList = $.merge(response.items, receivedData.activityList);
									}
								}.bind(this),
								error: function(errorData) {
									console.log("While retreiving today activities for tech - Error messagae:" + JSON.stringify(errorData));
								}
							});
						}catch(err){
							var resourceErrorPayload = {"R_PLUGIN_ERROR": "Error calling nextday activity list: "+err.message};
							this.ajaxCall(resourceUpdateUrl, resourceErrorPayload, "PATCH", headers);
						}
					});
				}
			}
			// End added for CHG0078516 - OFSC EOD Summation Logic
			
			// First Activity of next day Start
				var nextDayActivityListURL = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/resources/" + receivedData.resource.external_id+"/routes/"+nextDayDate;
				// Ajax call to get the tech nextday activities
				$.ajax({
					dataType: "json",
					url: nextDayActivityListURL,
					method: "GET",
					//async: false,
					crossDomain: true,
					headers: headers,
					processData: false,
					contentType: 'application/json; charset=utf-8',
					timeout: 15000,
					success: function(response) {
						console.log("While retreiving next activities for tech - Success messagae: " + JSON.stringify(response));
						if(response.totalResults > 0){
							$.each(response.items, function(key, value){
								if(value.positionInRoute === 1){
									var address = value.caddress;
									var addressLine = value.A_ORDER_ADDRESS_1;
									if(!(value.aworktype)){
										value.aworktype = ''
									}
									if(!(value.cname)){
										value.cname = ''
									}
									if(!(address)){
										address = ''
									}
									if(!(addressLine)){
										addressLine = ''
									}
									$('#next_day_activity_wrapper').append($('<span />').attr({"style":"color:#120209"}).append("Type: " + value.activityType));
									$('#next_day_activity_wrapper').append($('<span />').attr({"style":"color:#7D7D7D"}).append(" Customer: "));
									$('#next_day_activity_wrapper').append($('<span />').attr({"style":"color:#FF2B5D"}).append(value.cname));
									$('#next_day_activity_wrapper').append($('<span />').attr({"style":"color:#7D7D7D"}).append(" Address: "));
									$('#next_day_activity_wrapper').append($('<span />').attr({"style":"color:#7D7D7D"}).append(address + addressLine));
									$('#next_day_activity_wrapper').append($('<span />').attr({"style":"color:#7D7D7D"}).append(" Appt #: "));
									$('#next_day_activity_wrapper').append($('<span />').attr({"style":"color:#1C51FF"}).append(value.apptNumber));
									$('#next_day_activity_wrapper').append($('<span />').attr({"style":"color:#000000"}).append(" Activity: "+value.activityId));
								}
							});
						}else{
							$('#next_day_activity_wrapper').text("There are no activities for tomorrow.");
						}
					}.bind(this),
					error: function(errorData) {
						if(errorData.statusText == 'timeout'){
							$('#next_day_activity_wrapper').text("Information is available online only.");
						}
						else{
						console.log("While retreiving next activities for tech - Error messagae:" + JSON.stringify(errorData));
						$('#next_day_activity_wrapper').text("There are no activities for tomorrow.");
						}
					}
				});
			
			// First Activity of next day End
			dates.push(punchInDt);
			
			// Change CHG0079933 Starts	
			var techTimeZoneDateTime = formatDateTime(todayDate,"T");
			var techPunchOutTimeZoneDate = techTimeZoneDateTime.split('T')[0];
            var techPunchOutTimeZoneTime = techTimeZoneDateTime.split('T')[1];
            techPunchOutTimeZoneTime += ":00";
			// Change CHG0079933 Ends
			
			// Report section start
			if (Object.keys(receivedData.activityList).length > 0){
				var payCode = receivedData.resource.P_PAYCODE; 
				if(payCode == null) payCode = '';
				$.each(receivedData.activityList, function(i, v){
					if(v.status === "started"){
						$('#punch-out-submit-btn').attr('disabled', true);
					}else if(v.status === "pending"){
						if(payCode != 'CALL_IN_IO'){  
							if(dates.includes(v.date)){ //punchInDt == v.date Commented for CHG0078516 - OFSC EOD Summation Logic
								var activityStartDate = v.startTime.split(" ")[0];
								var activityStartTime = v.startTime.split(" ")[1];
								if(v.date === techPunchOutTimeZoneDate && 
									nextDayShiftStartTime > techPunchOutTimeZoneTime &&								
									(((activityStartTime > techPunchOutTimeZoneTime) && 
										(activityStartDate === v.date) && 
										(activityStartTime >= nextDayShiftStartTime)) || 
										(activityStartDate > v.date))) {} else {	// Change CHG0079933									
									$('#punch-out-submit-btn').attr('disabled', true);
								}
							}
						}
					}
				});
			}
			
			//caculating time difference with ETA
            function calculateTimeDiffEta(eta, etaEnd) {
                var calculatedTime = '0:00';
                if (eta && etaEnd) {
                    var startHour = eta.split(':')[0];
                    var startMinutes = eta.split(':')[1];
                    var laborHour = etaEnd.split(':')[0];
                    var laborMinutes = etaEnd.split(':')[1];
                    var tempHour = laborHour - startHour;
                    var tempMinutes = laborMinutes - startMinutes;
					if(tempHour < 0){ tempHour = tempHour + 24;}
                    var firstDate = (tempHour * 60) + (tempMinutes);
                    var displayHour = parseInt(firstDate / 60);
                    var displayMinute = parseInt(firstDate % 60);
                    calculatedTime = displayHour + ':' + displayMinute;
                }
				return calculatedTime;
            }
			
			
			//
			function getTimeHHMM(dateString){
				var etaTime = "";
				if(dateString != null && dateString.includes(" ")){
					var dateArray = dateString.split(" ");
					var time = dateArray[1];
					if(time != null && time.includes(":")){
						var timeArray = time.split(":");
					    etaTime = [timeArray[0], timeArray[1]].join(':');
					}
				}
				return etaTime;
			}
			
			//Start Parts Debrief section CHG0073864
			var installCount = 0;
			var appt_number = "";
			$.each(receivedData.inventoryList, function (i, v) {
				if(v.invpool === 'install'){
					appt_number = "";
					$.each(receivedData.activityList, function(key, value){
						if(value.activityId == v.inv_aid){
							appt_number = value.apptNumber;
							//break;
						}
					});
					installCount++;
					$('#DebriefInstallItemList').after("<tr class=\"cl-row debrief_row display-none\">\n" +
					"<td>" + v.inv_aid + "</td>\n" +
					"<td>" + appt_number + "</td>\n" +
					"<td>" + v.I_ITEM_NUMBER + "</td>\n" +
					"<td>" + v.I_ITEM_DESCRIPTION + "</td>\n" +
					"<td>" + v.I_SUBINVENTORY + "</td>\n" +
					"<td>" + v.quantity + "</td>\n" +
					"</tr>");
				}
			});
			if(installCount == 0){
				$('.partsdebriefsection').hide();
			}
			enableDebriefRow();
			$('.debrief_header').click(function () {
				$('.debrief_row').toggle();
				enableDebriefRow();
            });
			
			function enableDebriefRow(){
				if($('.debrief_row').is(":visible")){
					$('.debrief_header .arrow-grid').removeClass('arrow-maximize-grid margin-top-5').addClass('arrow-minimize-grid margin-top-10');
				} else {
					$('.debrief_header .arrow-grid').addClass('arrow-maximize-grid margin-top-5').removeClass('arrow-minimize-grid margin-top-10');
				}
			}
			
			//End Parts Debrief section  CHG0073864
			
			$.each(receivedData.activityList, function (i, v) {
				if ((v.status === 'complete' || v.status === 'completed' || v.status === 'suspended' || v.status === 'cancelled') && (v.status != 'cancelled' && formatDTime(v.endTime) >= formatDTime(rPunchinTime)) ){ // Added for CHG0078516 - OFSC EOD Summation Logic
					if('LU' !== v.activityType && 'Commute Non Paid' !== v.activityType && 'Personal Time' !== v.activityType){
						if(v.A_ODOMETER_END !== null && v.A_ODOMETER_START !== null && v.A_ODOMETER_START !== undefined && v.A_ODOMETER_END !== undefined){
							var odometerDiff = (parseFloat(v.A_ODOMETER_END) - parseFloat(v.A_ODOMETER_START));
							totalMilage += odometerDiff;
						}
						var xmlData = v.A_EXPENSES_PLUGIN;
						var tempTag = $(xmlData).find('A_EXPENSE_SECTION');
						var tempAmount = $(xmlData).find('A_AMOUNT');
						var tags = [];
						$.each(tempTag, function (key, value) {
							tags.push($(value).text());
						});
						$.each(tempAmount, function (key, value) {
							tags.push($(value).text());
						});
						
						var previousTagsLength = tempTag.length;
						var tagObj1 = [];
						for (var i = 0; i < previousTagsLength; i++) { // length should match properly
							var tempObj = {};
							tempObj.type = tags[i];
							tempObj.amount = tags[i + (previousTagsLength)];
							tagObj1.push(tempObj);
						}
						$.each(tagObj1, function (i, tempVal) {
							if (tempVal.type === "reimbursable_expenses_type") {
								totalReImbursableAmountSum = parseFloat(totalReImbursableAmount)+parseFloat(tempVal.amount);
								totalReImbursableAmount = totalReImbursableAmountSum.toFixed(2);
							}
						});
					} else {
						if(v.activityType !== 'LU'){
							var startTime = getTimeHHMM(v.startTime);
							var endTime = getTimeHHMM(v.endTime);
							console.log('startTime:' + startTime);
							console.log('endTime:' + endTime);
							var calculatedTimeObj = calculateTimeDiffEta(startTime, endTime)
							console.log('calculatedTimeObj:' + calculatedTimeObj);
							if(calculatedTimeObj != null && calculatedTimeObj.indexOf(':') != -1){
								var splitTempCalculatedTime= calculatedTimeObj.split(':');
								var hours = parseInt(splitTempCalculatedTime[0]);
								var minutes = parseInt(splitTempCalculatedTime[1]);
								nonPaidTimeMinutes = nonPaidTimeMinutes + (hours*60 + minutes);
							}

						}
					}
				}	
			});
			
			// Assigning Values to the Report Total Section
			totalMilage=Math.round(totalMilage); // Added for CHG0078516 - OFSC EOD Summation Logic
			$('#calculated_totals_time').text('(' + totalMilage + ')');
			$('#calculated_totals_time_hour').text('(' + totalMilage + ')');
			$('#calculated_totals_time_min').text('(' + totalMilage + ')');
			
			if(receivedData.resource.R_TOTAL_MILEAGE_DIFF !== undefined && receivedData.resource.R_TOTAL_MILEAGE_DIFF !== null && receivedData.resource.R_TOTAL_MILEAGE_DIFF !== NaN){
				if(parseInt(receivedData.resource.R_TOTAL_MILEAGE_DIFF) !== NaN){
					$('#overridden_mileage').val(totalMilage + parseInt(receivedData.resource.R_TOTAL_MILEAGE_DIFF));
				}else{
					$('#overridden_mileage').val(totalMilage);
				}
			}else {
				$('#overridden_mileage').val(totalMilage);
			}
			
			//Assigning updated values to the UI element
			$('#realTotalMilage').text('(' + totalMilage + ')');
			$('#calculated_mileage').text('(' + totalMilage + ')');
			$('#overridden_expenses').val(totalReImbursableAmount);
			$('#realTotalAmount').text('(' + totalReImbursableAmount + ')');
			$('#calculated_expenses').text('(' + totalReImbursableAmount + ')');
			$('#nonpaid_totals_time').text('(' + totalMilage + ')');
			
			// Binding Existing ReImbursable Tabs on page load
			if (receivedData.resource.R_EXPENSES !== undefined) {
				var existingReImbursableEntry = JSON.parse(receivedData.resource.R_EXPENSES);
				$.each(existingReImbursableEntry, function (i, v) {
					var tempObj = {"key": v.key, "name":v.name, "sum": v.sum};
					bindReImbursableSection(v.name, v.key, v.sum);
					reimbursableExpensesArr.push(v.key);
					reimbursableExpensesAmt.push(tempObj);
				})
			}
			
			//Enabling Save button on milage Change
            $('#overridden_mileage').keyup(function () {
                $('#btn_save').css("visibility", "visible");
            });

			 $('#overridden_mileage').on('change keyup',function () {
				var ovrMileage = $('#overridden_mileage').val();
				if("" == ovrMileage || ovrMileage == null){
					ovrMileage = 0;
				}
				ovrMileage = parseInt(ovrMileage);
				$('#overridden_mileage').val(ovrMileage);
				$('#realTotalMilage').text('(' + ovrMileage + ')');
			 });
		
			if(receivedData.resource.R_PUNCH_IN_TIME != undefined && receivedData.resource.R_PUNCH_IN_TIME != null && '' != receivedData.resource.R_PUNCH_IN_TIME){
				var timeStamp = receivedData.resource.R_PUNCH_IN_TIME;
				var splitTimeStamp = timeStamp.split("|");
				if(splitTimeStamp[0] == ""){
					splitTimeStamp.splice(0,1);
				};
				
				var timeStampObj = [];
				console.log(splitTimeStamp);
				$.each(splitTimeStamp, function (i, v) {
					var temp = v.split(' ');
					var tempObj = {date: temp[0], time: temp[1]};
					timeStampObj.push(tempObj)
				});
				console.log(timeStampObj);
				
				var timeStampLength = timeStampObj.length;
				var lengthToCount;
				if (timeStampLength % 2 === 0) {
					lengthToCount = timeStampLength;
				} else {
					lengthToCount = timeStampLength - 1;
				}
				
				var totalDiffInMin = 0;
				for (var i = 0; i < lengthToCount; i++) {
					if (i % 2 !== 0) {
						var temp1 = new Date(timeStampObj[i].date.replace(/[-]/g,"/") + ' ' + timeStampObj[i].time);
						var temp = new Date(timeStampObj[i - 1].date.replace(/[-]/g,"/") + ' ' + timeStampObj[i - 1].time);
						console.log(temp1);
						console.log(temp);
						var diffHour = temp1.getHours() - temp.getHours();
						console.log(diffHour);
						if (diffHour < 0) {
							diffHour = diffHour + 24;
						}
						console.log(diffHour);
						var diffMin = temp1.getMinutes() - temp.getMinutes();
						console.log(diffMin);
						totalDiffInMin += (diffHour * 60) + (diffMin);
						console.log(totalDiffInMin);
						var displayHour = parseInt(totalDiffInMin / 60);
						var displayMinute = parseInt(totalDiffInMin % 60);
						console.log(displayHour);
						console.log(displayMinute);
					}
				}
				
				if (timeStampLength % 2 !== 0) {
					var tFormSplit = formatDateTime(todayDate,'T').split('T');
					var currentDateHours = tFormSplit[1].substring(0,2);
					var currentDateMin = tFormSplit[1].substring(3,5);	
					
					var prevDate = new Date(timeStampObj[timeStampLength - 1].date.replace(/[-]/g,"/") + ' ' + timeStampObj[timeStampLength - 1].time);
					var diffHour = currentDateHours - prevDate.getHours();
					console.log(diffHour);
					if (diffHour < 0) {
						diffHour = diffHour + 24;
					}
					console.log(diffHour);
					var diffMin = currentDateMin - prevDate.getMinutes();
					console.log(diffMin);

					totalDiffInMin += (diffHour * 60) + (diffMin);

					console.log(totalDiffInMin);
					var displayHour = parseInt(totalDiffInMin / 60);
					var displayMinute = parseInt(totalDiffInMin % 60);
					console.log(displayHour);
				}
				console.log('totalDiffInMin:' + totalDiffInMin);
				if(nonPaidTimeMinutes > 0)
					totalDiffInMin = totalDiffInMin - nonPaidTimeMinutes;

				console.log('totalDiffInMin afetr deducting non paid hours:' + totalDiffInMin);
				punchOutHour = parseInt(totalDiffInMin / 60);
				punchOutMinute = parseInt(totalDiffInMin % 60);
				
				if(!isNaN(punchOutHour)){
					$('#overridden_totals_time_hour').val(punchOutHour);
				}else{
					$('#overridden_totals_time_hour').val(0);
				}
				
				if(!isNaN(punchOutMinute)){
					console.log(punchOutMinute);
					console.log(typeof punchOutMinute);
					if(punchOutMinute <= 9 && punchOutMinute >= 0){
						punchOutMinute = '0'+punchOutMinute;
					}
					$('#overridden_totals_time_min').val(punchOutMinute);
				}else{
					$('#overridden_totals_time_min').val(0);
				}
	
				if(!isNaN(punchOutHour) && !isNaN(punchOutHour)){
					$('#realTotalTime').text('(' + punchOutHour + ':' + punchOutMinute + ')');
				}else{
					$('#realTotalTime').text(0);
				}
			} else {
				punchOutHour = '0';
				punchOutMinute = '0';
				$('#overridden_totals_time_hour').val(0);
				$('#overridden_totals_time_min').val(0);
				$('#realTotalTime').text(0);
			}
			
			$.each(receivedData.activityList, function (i, v) {
				if((v.status === 'complete' || v.status === 'completed' || v.status === 'suspended' || v.status === 'cancelled') && (v.status != 'cancelled' && formatDTime(v.endTime) >= formatDTime(rPunchinTime))){ // Added for CHG0078516 - OFSC EOD Summation Logic
					var odometerDiff;
					if(v.A_ODOMETER_END && v.A_ODOMETER_START){
						odometerDiff = (v.A_ODOMETER_END - v.A_ODOMETER_START).toFixed(2); // Added for CHG0078516 - OFSC EOD Summation Logic
					}else{
						odometerDiff = 0;
					}
					
					var individualTotalReImbursableAmount = 0;
					var xmlData = v.A_EXPENSES_PLUGIN;
					var tempTag = $(xmlData).find('A_EXPENSE_SECTION');
					var tempAmount = $(xmlData).find('A_AMOUNT');
					var tags = [];
					var startTime = getTimeHHMM(v.startTime);
					var endTime = getTimeHHMM(v.endTime);
					var tempCalculatedTime = calculateTimeDiffEta(startTime, endTime)
					$.each(tempTag, function (key, value) {
						tags.push($(value).text());
					});
					$.each(tempAmount, function (key, value) {
						tags.push($(value).text());
					});									
					var previousTagsLength = tempTag.length;
					var tagObj1 = [];
					for (var i = 0; i < previousTagsLength; i++) { // length should match properly
						var tempObj = {};
						tempObj.type = tags[i];
						tempObj.amount = tags[i + (previousTagsLength)];
						tagObj1.push(tempObj);
					}
					console.log('calculating individualTotalReImbursableAmount');
					$.each(tagObj1, function (i, v) {
						if (v.type === "reimbursable_expenses_type") {
							individualTotalReImbursableAmount = parseFloat(individualTotalReImbursableAmount)+parseFloat(v.amount);

							individualTotalReImbursableAmount = individualTotalReImbursableAmount.toFixed(2);
						}
					});

					var cName = (v.customerName) ? v.customerName:''
					var appt_number = (v.apptNumber) ? v.apptNumber:''
					var caddress = (v.streetAddress) ? v.streetAddress:''
					var tracking = 'tracking'
					if(v.aworktype === 'LU'){
						tracking = 'Lunch Break!'
					}

					$('.heads.details').after("<tr class=\"cl-row details_row display-none\">\n" +
					"<td colspan=\"3\">" +
					"<span style=\"color:#120209\">" + cName + "</span> " +
					"<span style=\"color:#7D7D7D\">Receipt Date:</span> " +
					"<span style=\"color:#FF2B5D\">" + punchInDt + "</span> " +
					" <span style=\"color:#7D7D7D\">" + tracking + "</span> " +
					"<span style=\"color:#1C51FF\">" + appt_number + "</span>" +
					" <span style=\"color:#000000\">" +caddress + "</span> " +
					"</td>\n" +
					"</tr>" +
					"<tr class=\"cl-row details_row display-none\">\n" +
					"<td>" + tempCalculatedTime + "</td>\n" +
					"<td>" + odometerDiff + "</td>\n" +
					"<td>" + individualTotalReImbursableAmount + "</td>\n" +
					"</tr>");
				}	
			});
			
			// action to enable or disable the Details section
			enableDetailsRow();
			$('.heads.details td').click(function () {
				$('.details_row').toggle();
				enableDetailsRow();
            });
			
			function enableDetailsRow(){
				if($('.details_row').is(":visible")){
					$('.heads.details .arrow-grid').removeClass('arrow-maximize-grid margin-top-5').addClass('arrow-minimize-grid margin-top-10');
				} else {
					$('.heads.details .arrow-grid').addClass('arrow-maximize-grid margin-top-5').removeClass('arrow-minimize-grid margin-top-10');
				}
			}
			// Report section end
			
			// Save button action
			$('#btn_save').click(function () {
				try{
					$('#btn_save').css("visibility", "hidden");
          // Added parseInt as part of CHG0078516 - OFSC EOD Summation Logic
					var resourceUpdatePayLoad = {
						"R_TOTAL_TIME_DIFF": "0",
	                    "R_TOTAL_MILEAGE_DIFF": (parseInt($('#overridden_mileage').val()) - totalMilage).toString(),
	                    "R_TOTAL_EXPENSES_DIFF": "0",
	                    "R_EXPENSES": JSON.stringify(reimbursableExpensesAmt)
					}
					var current=this;
					$.ajax({
					url : '//'+ window.location.host + '/robots.txt' + '?rand=' + Math.random(),
					timeout : 2000,
					type : 'GET', 
					tryCount : 0,
					retryLimit : 3,
					success : function(json) {
						console.log("online configuration");
						current.ajaxCall(resourceUpdateUrl, resourceUpdatePayLoad, "PATCH", headers);
					},
					error : function(xhr, textStatus, errorThrown ) {
						if (textStatus == 'timeout') {
							this.tryCount++;
							if (this.tryCount <= this.retryLimit) {
								//try again
								$.ajax(this);
								return false;
							}            
							punchoutOfflineRequest();
						}
						if (xhr.status == 500) {
							punchoutOfflineRequest();
						} else {
							punchoutOfflineRequest();
						}
					}
					});
					
					function punchoutOfflineRequest(){
						var punchoutOfflineRequest = {
							"resourceUpdateUrl": resourceUpdateUrl,
							"resourceUpdatePayLoad": resourceUpdatePayLoad,
							"headers": headers,
							"method": "PATCH"
						};
						localStorage.setItem("punchoutResourseUpdateQueue", JSON.stringify(punchoutOfflineRequest));
					}
				}catch(err){
					var resourceErrorPayload = {"R_PLUGIN_ERROR": "Error on Button Save action: "+err.message};
					this.ajaxCall(resourceUpdateUrl, resourceErrorPayload, "PATCH", headers);
				}
			}.bind(this));
			
			//Punch out button action
			$('#punch-out-submit-btn').click(function () {
				try{
					$('#punch-out-submit-btn').attr('disabled', true);
					
					//Change Starts - CHG0078233
					// Check if user is authorized , if not alert user and return
					var punchOutResource = receivedData.resource.email; 
					punchOutResource = punchOutResource.toLowerCase();
					var punchOutUser = receivedData.user.ulogin;
					punchOutUser = punchOutUser.toLowerCase();
					if (punchOutResource != punchOutUser) {
						alert("Not allowed to Punch Out for other Technicians");
						$('#punch-out-submit-btn').attr('disabled', false);
						return false;
					}
					//Change Ends - CHG0078233
					
					var $btn = $(this);
					var count = ($btn.data("click_count") || 0) + 1;
					$btn.data("click_count", count);		
					if ( count == 1 ){
						console.log('Click Count :'+count);
					} else {
						alert('Punch out button clicked already, please wait');
						var multipunchOutCloseJson = {
	                                apiVersion: 1,
	                                method: 'close',
	                                backScreen: 'default'
	                            }
						thisVar._sendPostMessageData(multipunchOutCloseJson);		
						return false;
					}
					
					// to load cursor wait & enable please wait loading
					$('body').css({"cursor": "wait"});
					this.popupEnable("Please wait ...", false, true, "regularMessage");
					
					var totalSumAmount = 0.00;
	                $.each(reimbursableExpensesAmt, function (i, v) {
	                    totalSumAmount += parseFloat(v.sum)
	                });
	                $.createElement = function (name, value) {
	                    var temp = document.createElementNS(name, name);
	                    if (value !== undefined) {
	                        temp.innerHTML = value;
	                    }
	                    return temp;
	                };
					
					var $seExpensesPluginXml = $('<XMLDocument />');
	                reimbursableExpensesAmt.forEach(function (data) {
	                    var $seExpensesPlugin = $.createElement('DebriefExpenseLine');
	                    $seExpensesPlugin.append($.createElement('A_EXPENSE_TYPE', data.key));
	                    $seExpensesPlugin.append($.createElement('A_AMOUNT', data.sum));
	                    $seExpensesPlugin.append($.createElement('A_OVERRIDE_PRICE', ''));
	                    $seExpensesPlugin.append($.createElement('A_PRICE_OVERRIDE_REASON_CODE', ''));
	                    $seExpensesPluginXml.append($seExpensesPlugin);
	                });
	                var tempString = JSON.stringify($seExpensesPluginXml.html());
	                var tempStructure = tempString.replace(/&/g, "&amp;").replace(/>/g, "&gt;").replace(/</g, "&lt;").replace(/"/g, "");
					
					if(totalSumAmount > 0){
						totalReImbursableAmount = parseFloat(totalReImbursableAmount)  + parseFloat(totalSumAmount);
					}
					totalReImbursableAmount = parseFloat(totalReImbursableAmount).toFixed(2);
					
					var todaysDate;
					try{
						todaysDate = new Date(new Date().toLocaleString('en-US', { timeZone: resourceTimeZone }));
					} catch(err){
						todaysDate = new Date();
					}
					var todaysDateTime = formatDateTime(todaysDate," ");
					
					if(punchInDt == null || "" == punchInDt || typeof(punchInDt) == undefined){
						var currentDate;
						try{
							currentDate = new Date(new Date().toLocaleString('en-US', { timeZone: resourceTimeZone }));	
						}catch(err){
							currentDate = new Date();
						}
						punchInDt =  formatDate(currentDate);
					}
					var createActivityURL = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/activities";
					var createActivityPayload = {
						"resourceId": receivedData.resource.external_id,
						"date": punchInDt,
						"apptNumber": receivedData.resource.external_id +"-"+ todaysDateTime + "-EOD",
						"activityType": "EOD",
						"A_REPORT_DATE": punchInDt,
						"A_USER_TOTAL_MILEAGE": $('#overridden_mileage').val(),
						"A_CALCULATED_TOTAL_MILEAGE": totalMilage.toString(),
						"A_USER_TOTAL_EXPENSES": totalReImbursableAmount.toString(),
						"A_CALCULATED_TOTAL_EXPENSES": totalReImbursableAmount.toString(),
						"A_USER_TOTAL_TIME": punchOutHour + ':' + punchOutMinute,
						"A_CALCULATED_TOTAL_TIME": punchOutHour + ':' + punchOutMinute,
						"A_EXPENSE_PLUGIN": $seExpensesPluginXml.html(),
						"A_EXPENSES_OUTBOUND": tempStructure,
						"A_MILEAGE": totalMilage.toString(),
						"setPositionInRoute": {
					          "position": "first"
					     }
					};
					var startActivityURL = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/activities/<ACTIVITY_ID>/custom-actions/start";
					var completeActivityURL = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/activities/<ACTIVITY_ID>/custom-actions/complete";
					var resourceUpdatePayload = {
						"R_WORKING_STATUS": "not_working",
						"R_TOTAL_TIME_DIFF": "0",
	                    "R_TOTAL_MILEAGE_DIFF": (parseFloat($('#overridden_mileage').val()) - totalMilage).toString(),
	                    "R_TOTAL_EXPENSES_DIFF": "0",
	                    "R_EXPENSES": JSON.stringify(reimbursableExpensesAmt)
					};
					var deactivateRouteURL = "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/resources/" + receivedData.resource.external_id + "/routes/" + punchInDt + "/custom-actions/deactivate";
					var serviceRequestURL= "https://" + domainName + ".fs.ocs.oraclecloud.com/rest/ofscCore/v1/serviceRequests";
					
					var dateResourceTimeZone;
					try{
						dateResourceTimeZone = new Date(new Date().toLocaleString('en-US', { timeZone: resourceTimeZone }));	
					}catch(err){
						dateResourceTimeZone = new Date();
					}
					var dateResourceTimeZoneDateTime = formatDateTime(dateResourceTimeZone,"T");
					var dateResourceTimeZoneDate = formatDate(dateResourceTimeZone);
					
					var dateUTCTimeZone = new Date(new Date().toLocaleString('en-US', { timeZone: "UTC" }));
					var dateUTCTimeZoneDateTime = formatDateTime(dateUTCTimeZone,"T");
					var serviceReqeustParams= {
						"SR_ACTION_TIME_EST": dateResourceTimeZoneDateTime,
						"SR_ACTION_TIME_UTC": dateUTCTimeZoneDateTime,
						"date": dateResourceTimeZoneDate,
						"resourceId": receivedData.resource.external_id,
						"requestType": receivedData.securedData.requestType
					};
	
					var payload = {
						"createActivityURL": createActivityURL,
						"createActivityPayload": createActivityPayload,
						"startActivityURL": startActivityURL,
						"completeActivityURL": completeActivityURL,
						"resourceUpdateUrl": resourceUpdateUrl,
						"resourceUpdatePayload": resourceUpdatePayload,	
						"deactivateRouteURL": deactivateRouteURL,
						"serviceRequestURL": serviceRequestURL,
						"serviceReqeustParams": serviceReqeustParams,
						"headers": headers,
						"paycode": receivedData.resource.P_PAYCODE,
						"workScheduleRecordType": workScheduleRecordType
					};
					
					// Ajax call to Create new EOD activity
				    var current= this;
					$.ajax({
					url : '//'+ window.location.host + '/robots.txt' + '?rand=' + Math.random(),
					timeout : 2000,
					type : 'GET', 
					tryCount : 0,
					retryLimit : 3,
					success : function(json) {
						console.log("online configuration");
						current.submitPunchOut(payload, false, false);
					},
					error : function(xhr, textStatus, errorThrown ) {
						if (textStatus == 'timeout') {
							this.tryCount++;
							if (this.tryCount <= this.retryLimit) {
								//try again
								$.ajax(this);
								return false;
							}            
							punchOutEODQueue();
						}
						if (xhr.status == 500) {
							punchOutEODQueue();
						} else {
							punchOutEODQueue();
						}
					}
					});
					
					function punchOutEODQueue(){
						// Start of CHG0070440
						// Start of CHG0078758
						current.popupEnable("Currently you are in Offline Mode and your Punch Out CAN NOT be sent to your timesheet. Ensure you have connectivity and try again. If it does not succeed on the next attempt, report your Punch Out Time: " +payload.serviceReqeustParams.SR_ACTION_TIME_EST.replace("T"," ") + " to your manager and request to reset your working status.", true, true, "errorMessage"); ////CHG0070440
						// End of CHG0078758
						console.log('offline configuration');
						localStorage.setItem("punchOutEODQueue", JSON.stringify(payload));
						g_wakeupNeeded = true;
						g_wakeupMethod = false;
						//End of CHG0070440
						//current.closeMethod(true, false);
						// to load cursor wait & enable please wait loading
						$('body').css({"cursor": "default"});
					}
				}catch(err){
					var resourceErrorPayload = {"R_PLUGIN_ERROR": "Error calling PunchOut action: "+err.message};
					this.ajaxCall(resourceUpdateUrl, resourceErrorPayload, "PATCH", headers);
				}
			}.bind(this));
			
			$('#messagePanel #notification-clear').click(function() {
				$('#messagePanel').hide();
				this.closeMethod(g_wakeupNeeded, g_wakeupMethod);
			}.bind(this));
		},
		startEODActivty: function(payload, ajaxErrorMessage){
			try{
				$.ajax({
					dataType: "json",
					url: payload.startActivityURL,
					method: "POST",
					//async: false,
					crossDomain: true,
					headers: payload.headers,
					processData: false,
					contentType: 'application/json; charset=utf-8',
					timeout: 15000,
					success: function(response) {
						console.log("Start EOD Activity  - Success messagae:" + JSON.stringify(response));
						/* CHG0073168 */
						var punchOutLogsPayload = {"R_PUNCHOUT_LOGS": "End of day Activity Started Successfuly"};
						this.ajaxCall(payload.resourceUpdateUrl, punchOutLogsPayload, "PATCH", payload.headers);
						/* CHG0073168 */
						this.completeEODActivity(payload, ajaxErrorMessage);
					}.bind(this),
					error: function(errorData) {
						console.log("Start EOD Activity  - Error messagae:" + JSON.stringify(errorData));
						ajaxErrorMessage += "API: "+payload.startActivityURL+"<br />Response: "+JSON.stringify(errorData);
						this.completeAction(false, ajaxErrorMessage, payload);
					}.bind(this)
				});
			}catch(err){
				var resourceErrorPayload = {"R_PLUGIN_ERROR": "Error on creating EODActivity: "+err.message};
				this.ajaxCall(payload.resourceUpdateUrl, resourceErrorPayload, "PATCH", payload.headers);
			}
		},
		completeEODActivity: function(payload, ajaxErrorMessage){
			try{
				$.ajax({
					dataType: "json",
					url: payload.completeActivityURL,
					method: "POST",
					//async: false,
					crossDomain: true,
					headers: payload.headers,
					processData: false,
					contentType: 'application/json; charset=utf-8',
					timeout: 15000,
					success: function(response) {
						console.log("Complete EOD Activity  - Success messagae:" + JSON.stringify(response));
						/* CHG0073168 */
						var punchOutLogsPayload = {"R_PUNCHOUT_LOGS": "End of day Activity Completed Successfuly"};
						this.ajaxCall(payload.resourceUpdateUrl, punchOutLogsPayload, "PATCH", payload.headers);
						/* CHG0073168 */
						/* CHG0073282 - removed working status update from plugin */
						/* 
						this.updateResourceRequest(payload, ajaxErrorMessage);
						*/
						this.deactivateRoute(payload, ajaxErrorMessage);//CHG0073282 - removed working status update from plugin
					}.bind(this),
					error: function(errorData) {
						console.log("Complete EOD Activity  - Error messagae:" + JSON.stringify(errorData));
						ajaxErrorMessage += "API: "+payload.completeActivityURL+"<br />Response: "+JSON.stringify(errorData);
						this.completeAction(false, ajaxErrorMessage, payload);
					}.bind(this)
				});
			}catch(err){
				var resourceErrorPayload = {"R_PLUGIN_ERROR": "Error on complete EODActivity: "+err.message};
				this.ajaxCall(payload.resourceUpdateUrl, resourceErrorPayload, "PATCH", payload.headers);
			}
		},
		updateResourceRequest: function(payload, ajaxErrorMessage){
			try{
				$.ajax({
					dataType: "json",
					url: payload.resourceUpdateUrl,
					data: JSON.stringify(payload.resourceUpdatePayload),
					method: "PATCH",
					//async: false,
					crossDomain: true,
					headers: payload.headers,
					processData: false,
					contentType: 'application/json; charset=utf-8',
					timeout: 15000,
					success: function(response) {
						console.log("Update Resource properties - Success messagae: " + JSON.stringify(response));
						/* CHG0073168 */
						var punchOutLogsPayload = {"R_PUNCHOUT_LOGS": "Working status updated"};
						this.ajaxCall(payload.resourceUpdateUrl, punchOutLogsPayload, "PATCH", payload.headers);
						/* CHG0073168 */
						this.deactivateRoute(payload, ajaxErrorMessage);
					}.bind(this),
					error: function(errorData) {
						console.log("Update Resource properties - Error messagae:" + JSON.stringify(errorData));
						ajaxErrorMessage += "API: "+payload.resourceUpdateUrl+"<br />Request: "+JSON.stringify(payload.resourceUpdatePayload)+"<br />Response: "+JSON.stringify(errorData);
						this.completeAction(false, ajaxErrorMessage, payload);
					}.bind(this)
				});
			}catch(err){
				var resourceErrorPayload = {"R_PLUGIN_ERROR": "Error on Update Resource Request: "+err.message};
				this.ajaxCall(payload.resourceUpdateUrl, resourceErrorPayload, "PATCH", payload.headers);
			}
		},
		deactivateRoute: function(payload, ajaxErrorMessage){
			try{
				if("CALL_IN_IO" != payload.paycode && "working" != payload.workScheduleRecordType){
					$.ajax({
						dataType: "json",
						url: payload.deactivateRouteURL,
						method: "POST",
						//async: false,
						crossDomain: true,
						headers: payload.headers,
						processData: false,
						contentType: 'application/json; charset=utf-8',
						timeout: 15000,
						success: function(response) {
							console.log("Deactivate Resource Route - Success messagae:" + JSON.stringify(response));
							/* CHG0073168 */
							var punchOutLogsPayload = {"R_PUNCHOUT_LOGS": "Route Deactivated"};
							this.ajaxCall(payload.resourceUpdateUrl, punchOutLogsPayload, "PATCH", payload.headers);
							/* CHG0073168 */
							this.createServiceRequest(payload, ajaxErrorMessage);
						}.bind(this),
						error: function(errorData) {
							console.log("Deactivate Resource Route - Error messagae:" + JSON.stringify(errorData));
							ajaxErrorMessage += "API: "+payload.deactivateRouteURL+"<br />Response: "+JSON.stringify(errorData);
							this.completeAction(false, ajaxErrorMessage, payload);
						}.bind(this)
					});	
				} else {
					this.createServiceRequest(payload, ajaxErrorMessage);
				}
			}catch(err){
				var resourceErrorPayload = {"R_PLUGIN_ERROR": "Error on Deactivaite Route: "+err.message};
				this.ajaxCall(payload.resourceUpdateUrl, resourceErrorPayload, "PATCH", payload.headers);
			}
		},
		createServiceRequest: function(payload, ajaxErrorMessage){
			try{
				$.ajax({
					dataType: "json",
					url: payload.serviceRequestURL,
					data: JSON.stringify(payload.serviceReqeustParams),
					method: "POST",
					//async: false,
					crossDomain: true,
					headers: payload.headers,
					processData: false,
					contentType: 'application/json; charset=utf-8',
					timeout: 15000,
					success: function(response) {
						console.log("Punch Out resource Service Request - Success messagae: " + JSON.stringify(response));
						this.completeAction(true, ajaxErrorMessage, payload);
					}.bind(this),
					error: function(errorData) {
						console.log("Punch Out resource Service Request - Error messagae: " + JSON.stringify(errorData));
						ajaxErrorMessage += "API: "+payload.serviceRequestURL+"<br />Request: "+JSON.stringify(payload.serviceReqeustParams)+"<br />Response: "+JSON.stringify(errorData);
						this.completeAction(false, ajaxErrorMessage, payload);
					}.bind(this)
				});
			}catch(err){
				var resourceErrorPayload = {"R_PLUGIN_ERROR": "Error on Creating service request: "+err.message};
				this.ajaxCall(payload.resourceUpdateUrl, resourceErrorPayload, "PATCH", payload.headers);
			}
		},
		completeAction: function(callNextAjax, ajaxErrorMessage, payload){
			$('body').css({"cursor": "default"});
			// Send post message data to OFSC
			if(!callNextAjax && "" != ajaxErrorMessage){ 
				if(!g_wakeupNeeded){
					var errorMessage = (ajaxErrorMessage.split("statusText").pop()).replace(/[^a-zA-Z 0-9]+/g, '');
					errorMessage = errorMessage ?  "<br>Error status: " + errorMessage : "";
					this.popupEnable("Punch out Failed. Please try again immediately. If the issue still exists,please take a screenshot and report the error below to ITSC at 1-800-641-2425 option 3." + errorMessage, true, true, "errorMessage");
				}
				var resourceErrorPayload = {"R_PLUGIN_ERROR":ajaxErrorMessage};
				this.ajaxCall(payload.resourceUpdateUrl, resourceErrorPayload, "PATCH", payload.headers);
			} else {
				this.popupEnable("Punch Out Succeeded At: " +payload.serviceReqeustParams.SR_ACTION_TIME_EST.replace("T"," "), true, true, "successMessage"); // CHG0070440
			}
		},
		/**
		* Submit punchin action on offline & online mode
		*/
		submitPunchOut: function(payload, wakeupNeeded, wakeupMethod){
			try{
				g_wakeupNeeded = wakeupNeeded;
				g_wakeupMethod = wakeupMethod;
				var ajaxErrorMessage = "";
				var eodActivityId = "";
				$.ajax({
					dataType: "json",
					url: payload.createActivityURL,
					data: JSON.stringify(payload.createActivityPayload),
					method: "POST",
					//async: false,
					crossDomain: true,
					headers: payload.headers,
					processData: false,
					contentType: 'application/json; charset=utf-8',
					timeout: 15000,
					success: function(response) {
						console.log("Create New EOD Activity - Success messagae: " + JSON.stringify(response));
						if(response.hasOwnProperty("activityId")){
							eodActivityId = response.activityId;
							//Replace activity id using eod Activity id
							payload.startActivityURL = payload.startActivityURL.replace('<ACTIVITY_ID>',eodActivityId);
							payload.completeActivityURL = payload.completeActivityURL.replace('<ACTIVITY_ID>',eodActivityId);
							$.extend(payload.resourceUpdatePayload, { "R_EOD_ACTIVITY_ID": eodActivityId.toString() });
							/* CHG0073168 */
							var punchOutLogsPayload = {"R_PUNCHOUT_LOGS": "End of day Activity Created Successfuly"};
							this.ajaxCall(payload.resourceUpdateUrl, punchOutLogsPayload, "PATCH", payload.headers);
							/* CHG0073168 */
							this.startEODActivty(payload, ajaxErrorMessage);
						} else {
							ajaxErrorMessage += "API: "+payload.createActivityURL+"<br />Request: "+JSON.stringify(payload.createActivityPayload)+"<br />Response: EOD Activity creation failed- "+JSON.stringify(response);
							this.completeAction(false, ajaxErrorMessage, payload);
						}
					}.bind(this),
					error: function(errorData) {
						ajaxErrorMessage += "API: "+payload.createActivityURL+"<br />Request: "+JSON.stringify(payload.createActivityPayload)+"<br />Response: "+JSON.stringify(errorData);
						this.completeAction(false, ajaxErrorMessage, payload);
						console.log("Create New EOD Activity - Error messagae:" + JSON.stringify(errorData));
					}.bind(this)
				});
			}catch(err){
				var resourceErrorPayload = {"R_PLUGIN_ERROR": "Error on submit PunchOut: "+err.message};
				this.ajaxCall(payload.resourceUpdateUrl, resourceErrorPayload, "PATCH", payload.headers);
			}
		},		
		/**
		 * Close method 
		 */
		closeMethod: function (wakeNeeded, wakeupMethod) {
			console.log('closeMethod called - wakeNeeded: ' + wakeNeeded);
			if(wakeupMethod){
				this._sendPostMessageData({
                    apiVersion: 1,
                    method: 'sleep',
                    wakeupNeeded: wakeNeeded
                });			
			} else {
			 	this._sendPostMessageData({
	                apiVersion: 1,
	                method: 'close',
	                wakeupNeeded: wakeNeeded,
	                backScreen: 'default'
	            });  
			}
        },
		/**
		 * Business login on plugin wakeup (background open for sync)
		 *
		 * @param {Object} receivedData - JSON object that contain data from OFSC
		 */
		pluginWakeup: function(receivedData) {
			this._log(window.location.host + ' WAKEUP', JSON.stringify(receivedData, null, 4));
			var wakeupData = {
				pluginWakeupCount: +localStorage.getItem('pluginWakeupCount'),
				pluginWakeupMaxCount: +localStorage.getItem('pluginWakeupMaxCount'),
				pluginWakeupDontRespondOn: +localStorage.getItem('pluginWakeupDontRespondOn')
			};
		
			wakeupData.pluginWakeupCount = wakeupData.pluginWakeupCount + 1;
		
			localStorage.setItem('pluginWakeupCount', wakeupData.pluginWakeupCount);
			localStorage.setItem('pluginWakeupMaxCount', wakeupData.pluginWakeupMaxCount);
			localStorage.setItem('pluginWakeupDontRespondOn', wakeupData.pluginWakeupDontRespondOn);
		
			this._log(window.location.host + ' SAVE WAKEUP DATA TO LOCAL STORAGE', JSON.stringify(wakeupData, null, 4));
			
			//call the punch in
			if(localStorage.getItem('punchoutResourseUpdateQueue') !== '' && localStorage.getItem('punchoutResourseUpdateQueue') !== null && localStorage.getItem('punchoutResourseUpdateQueue') !== undefined ){
				var punchOutResourceUpdatePayload = JSON.parse(localStorage.getItem('punchoutResourseUpdateQueue'));
				console.log(punchOutResourceUpdatePayload);
				this.ajaxCall(punchOutResourceUpdatePayload.resourceUpdateUrl, punchOutResourceUpdatePayload.resourceUpdatePayLoad, 
				"PATCH", punchOutResourceUpdatePayload.headers);
				if(localStorage.getItem('punchOutEODQueue') == '' || localStorage.getItem('punchOutEODQueue') == null && localStorage.getItem('punchOutEODQueue') == undefined){
					this.closeMethod(false, true);
				}
				localStorage.setItem('punchoutResourseUpdateQueue', '');
			} 
			
			if(localStorage.getItem('punchOutEODQueue') !== '' && localStorage.getItem('punchOutEODQueue') !== null && localStorage.getItem('punchOutEODQueue') !== undefined ){
				var punchOutEODQueuePayload = JSON.parse(localStorage.getItem('punchOutEODQueue'));
				this.submitPunchOut(punchOutEODQueuePayload, false, true);
				localStorage.setItem('punchOutEODQueue', '');
			} 
				
			
			if (wakeupData.pluginWakeupDontRespondOn == wakeupData.pluginWakeupCount) {
				this._log(window.location.host + ' EMULATE NOT RESPONDING PLUGIN');
				return;
			}
		
			if (wakeupData.pluginWakeupCount < wakeupData.pluginWakeupMaxCount) {
				setTimeout(function() {
					this._log(window.location.host + ' SLEEP. RETRY NEEDED');
					this._sendPostMessageData({
						apiVersion: 1,
						method: 'sleep',
						wakeupNeeded: true
					});
				}.bind(this), 2000);
			} else {
				setTimeout(function() {
					this._log(window.location.host + ' SLEEP. NO RETRY');
					this._sendPostMessageData({
						apiVersion: 1,
						method: 'sleep',
						wakeupNeeded: false
					});
				}.bind(this), 12000);
			}
		},
        /**
         * Initialization function
         */
		init: function() {
			if (navigator.serviceWorker) {
				this._log(window.location.host + ' Service Worker is supported');
				navigator.serviceWorker.register('punchout-service-worker.js').then(function(registration) {
					this._log(window.location.host + ' Service Worker is registered with scope: ' + registration.scope);
					registration.addEventListener('updatefound', function() {
						this._log(window.location.host + ' Service Worker update is found');
						var newServiceWorker = registration.installing;
						newServiceWorker.addEventListener('statechange', function() {
							switch (newServiceWorker.state) {
								case "installed":
									this._log(window.location.host + ' New Service Worker is installed');
									break;
							}
						}.bind(this));
					}.bind(this));
					navigator.serviceWorker.addEventListener('controllerchange', function() {
						this.notifyAboutNewVersion();
					}.bind(this));
					this.startApplication();
				}.bind(this), function(err) {
					this._log(window.location.host + ' Service Worker registration failed: ' + err);
					this.startApplication();
				}.bind(this));
				return;
			} else {
				this._log(window.location.host + ' Service Worker is not supported');
			}
			this.startApplication();
		},
		startApplication: function() {
			this._log(window.location.host + ' PLUGIN HAS BEEN STARTED');

			window.addEventListener("message", this._getPostMessageData.bind(this), false);
			var jsonToSend = {
				apiVersion: 1,
				method: 'ready',
				sendInitData: true
			};
			//parse data items
            var dataItems = ["resource", "customerInventories", "installedInventories"];
            if (dataItems) {
                $.extend(jsonToSend, {dataItems: dataItems});
            }
			this._sendPostMessageData(jsonToSend);
		},
		notifyAboutNewVersion: function() {
			this._log(window.location.host + ' New Service Worker is activated. Page refresh is needed');
			alert("New version is detected. Please reopen the page");
			var footer = document.querySelector('.footer');
			var versionNotificationElement = document.createElement('div');
			versionNotificationElement.className = 'new-version-notification';
			versionNotificationElement.innerHTML = 'New version is detected. Please reopen the page';
			footer.appendChild(versionNotificationElement);
		}
	});
	window.OfscPlugin.getVersion = function() {
		return resourcesVersion;
	};
})(jQuery);